#include<stdio.h>
#include<string.h>
#include<time.h>

void leeNombre(char n[]);
void nombreMayus(char n[],char nM[]);
int numIntentos();
int rangoNum();
int generaNum(int max);

int main(){
	char nombre[20]; //nombre del jugador
	int opcion; //opcion que escoje el usuario
	char nombreMayuscula[20]; //nombre del jugadro en mayuscula
	int numeroIntentos; //numero maximo de intentos que tendra el juego
	int ranMax; //rango para generar el numero random
	int bandera=0; //indica si ya se configuro el juego
	int numeroAdivinar; //numero random generado para adivinar
	int intento; //numero que ingresa el usuario cuando juega
	int i=0; //contador del bucle
	
	printf(".........................................................\n");
	printf("            JUEGO PARA ADIVINAR UN NUMERO ALEATORIO\n");
	printf(".........................................................\n\n");
	printf("AUTOR: BRYAN MENDOZA\n\n");
	
	leeNombre(nombre);
	nombreMayus(nombre,nombreMayuscula);
	
	do{
		printf("\n1. Configurar\n");
		printf("2. Jugar\n");
		printf("3. Salir\n");
		printf("Ingrese una opcion: ");
		scanf("%d",&opcion);
		
		switch(opcion){
			case 1:
				numeroIntentos=numIntentos();
				ranMax=rangoNum();
				bandera=1;
				break;
				
			case 2: //jugar
				if(bandera==1){
					numeroAdivinar=generaNum(ranMax);
					do{
						printf("%s ingrese un numero: ",nombreMayuscula);
						scanf("%d",&intento);
						i++;
						if(intento==numeroAdivinar)
							printf("FELICIDADES %s: Haz Ganado\n\n",nombreMayuscula);
							
						if((intento!=numeroAdivinar) && (i!=numeroIntentos) && (intento<numeroAdivinar))
							printf("QUE MAL %s: El numero ingresado es menor al numero a adivinar. Intenta otra vez\n",nombreMayuscula);
						
						if((intento!=numeroAdivinar) && (i!=numeroIntentos) && (intento>numeroAdivinar))
							printf("QUE MAL %s: El numero ingresado es mayor al numero a adivinar. Intenta otra vez\n",nombreMayuscula);
							
						if((intento!=numeroAdivinar) && (i==numeroIntentos))
							printf("%s se acabaron tus intentos\nHAZ PERDIDO\n\n",nombreMayuscula);
					}while((i!=numeroIntentos)&&(intento!=numeroAdivinar));
				}
				else
					printf("ERROR: %s primero debe configurar el juego\n\n",nombreMayuscula);
			break;
			
			case 3:
				printf("Gracias %s por usar mi programa\n",nombreMayuscula);
			break;
				
			default:
				printf("Opcion no valida\n");
			break;
		}
	}while(opcion!=3); //fin del bucle

	return 0;
}

void leeNombre(char n[]){ //funcion que pide y lee el nombre del jugador
	printf("Ingrese su nombre en minusculas:");
	gets(n);
} //fin funcion leeNombre

void nombreMayus(char n[],char nM[]){ //funcion que transforma el nombre en mayuscula y guarda en otro vector
	int i; //contador del bucle
	int x; //numero ascii de la letra
	for(i=0;i<strlen(n);i++){
		x=n[i]-32;
		nM[i]=("%c",x);
	}
} //fin de la funcion nombreMayus

int numIntentos(){ //funcion que pide el numero de intentos que tendra el juego
	int nint; //numero de intentos
	printf("Ingrese el numero de intentos que tendra el juego: ");
	scanf("%i",&nint);
	return nint;
} //fin funcion numIntentos

int rangoNum(){ //funcio que pide el rango maximo para calcula el numero aleatorio
	int max; //rango maximo para calcular el numero aleatorio
	printf("Ingrese hasta que numero quiere que se genere el numero aleatorio: ");
	scanf("%i",&max);
	return max;
} //fin funcion rangoNum

int generaNum(int max){ //funcion que genera un numero aleatorio 
	int nran=0; //numero aleatorio generado
	srand(time(NULL));
	nran=(rand() % max);
	printf("El numero aleatorio es %d\n",nran);
	return nran;
} //fin funcion generaNum
