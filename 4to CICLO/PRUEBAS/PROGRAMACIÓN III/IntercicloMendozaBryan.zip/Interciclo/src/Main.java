import Controlador.CtrlPrograma;

public class Main {
    public static void main(String[]args){
        //Autor: Bryan Mendoza
        CtrlPrograma n = new CtrlPrograma();
    }
}
