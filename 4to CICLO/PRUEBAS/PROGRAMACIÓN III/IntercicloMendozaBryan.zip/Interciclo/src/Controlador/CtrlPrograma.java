package Controlador;

import Modelo.ManejoTexto;
import Vista.Ventana;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CtrlPrograma implements ActionListener {
    Ventana vista;
    ManejoTexto modelo;

    public CtrlPrograma(){
        this.vista = new Ventana();
        this.modelo = new ManejoTexto();
        vista.buttonCancel.addActionListener(this);
        vista.buttonOK.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == vista.buttonOK){
            modelo.separaLineas(vista.getTexto());
            modelo.generarNumeroLinea();
            vista.setInformacion(modelo.imprimirTodo());
        }
        if(e.getSource() == vista.buttonCancel){
            borrarEntradas();
        }
    }

    public void borrarEntradas(){
        vista.setTexto("");
        vista.setInformacion("");
    }
}
