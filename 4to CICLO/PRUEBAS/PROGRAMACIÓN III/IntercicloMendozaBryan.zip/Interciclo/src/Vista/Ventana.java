package Vista;

import javax.swing.*;

public class Ventana extends JFrame {
    private JPanel contentPane;
    public JButton buttonOK;
    public JButton buttonCancel;
    private JTextArea texto;
    private JTextArea informacion;

    public String getTexto() {
        return texto.getText();
    }

    public void setTexto(String text) {
        this.texto.setText(text);
    }

    public String getInformacion() {
        return informacion.getText();
    }

    public void setInformacion(String informacio) {
        this.informacion.setText(informacio);
    }

    public Ventana() {
        pack();
        setVisible(true);
        setLocation(600,250);
        setSize(500,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(contentPane);
    }

}
