package Modelo;

import javax.swing.*;
import java.util.*;

public class ManejoTexto {
    ArrayList<String> palabras;
    ArrayList<Integer> posicion;
    String[] lineas;
    Map<String, List<Integer>> indexado;
    public ManejoTexto() {
        this.palabras = new ArrayList<String>();
        this.posicion = new ArrayList<Integer>();
        this.lineas = null;
      //  this.lineas = new String[100];
        this.indexado = new HashMap<>();
    }

    public Map<String, List<Integer>> generarNumeroLinea() {
        for (int i = 0; i < lineas.length; i++) {
            String linea = lineas[i];
            String[] palabras = linea.split(" "); //divide cada linea en palabrs

            for (String palabra : palabras) {
                if (!indexado.containsKey(palabra)) {
                    indexado.put(palabra, new ArrayList<>());
                }
                indexado.get(palabra).add(i + 1); // agg el número de línea a la lista de líneas
            }
        }

        return indexado;
    }
    public void muestraPalabras(){
        String todo="";
        for(String pal:palabras){
            todo = todo.concat(pal);
            todo = todo.concat("\n");
        }
        JOptionPane.showMessageDialog(null,todo);
    }
    public String imprimirTodo() {
        List<String> palabrasOrdenadas = new ArrayList<>(indexado.keySet());
        Collections.sort(palabrasOrdenadas); //ordena
        String muestra="",todo="";

        for (String palabra : palabrasOrdenadas) {
            muestra = palabra + ": ";
            List<Integer> lineas = indexado.get(palabra);
            for (int i = 0; i < lineas.size(); i++) {
                //JOptionPane.showMessageDialog(null,lineas.get(i));
                muestra = muestra + lineas.get(i);
                //       System.out.print(lineas.get(i));
                if (i < lineas.size() - 1) {
                    muestra = muestra + " ";
                    //  System.out.print(" ");
                }
            }
            muestra = muestra + "\n";
            todo = todo + muestra;
        }
        System.out.println(todo);
        return todo;
    }
    /*public void separa(String text){
        int j=0,k=0;
        for(int i=0;i<text.length();i++){
            Character carac = text.charAt(i);
            // System.out.println(carac);
            if(carac == '\n') {
                lineas[j] = text.substring(k,i-1);
                k=i+1;
                j++;
            }
        }
        String aux;
        for(String linea: lineas){
            StringTokenizer elementos; // separa en palabras
            elementos = new StringTokenizer(linea," ");
            while(elementos.hasMoreTokens()){
                aux = elementos.nextToken();
                anadePalabra(aux); //añade las palabras sin repetir
            } // aux contiene una palabra separada por espacio
        }
        // System.out.println(Arrays.asList(parts));
    }*/

    public void separaLineas(String text){
        String aux;
        lineas = text.split("\n"); //separa cada linea y guarda en el vector cada linea
       /* for(String linea: lineas){
            StringTokenizer palabras = new StringTokenizer(linea," "); // separa en palabras
            while(palabras.hasMoreTokens()){
                aux = palabras.nextToken();
                anadePalabra(aux); //añade las palabras sin repetir
            } // aux contiene una palabra separada por espacio
        }*/
        // System.out.println(Arrays.asList(parts));
    }

   /* public void separa(String text){
        String aux;
        lineas = text.split("\n"); //separa cada linea y guarda en el vector cada linea
        for(String linea: lineas){
            int y=0,z=0,k=0;
            String palabras[] = new String[200];
            for(String e:lineas){
                for(int i=0;i<e.length();i++){
                    Character carac = e.charAt(i);
                    // System.out.println(carac);
                    if(carac == ' ') {
                        palabras[z] = e.substring(y,i-1);
                        y=i+1;
                        z++;
                        //  System.out.println("espacio");
                    }
                }
            }
            while(palabras[k]!=null){
                anadePalabra(palabras[k]); //añade las palabras sin repetir
                k++;
            } // aux contiene una palabra separada por espacio
        }
        // System.out.println(Arrays.asList(parts));
    }*/

    public void anadePalabra(String palabra){
        boolean existente = false;
        for(int i=0; i<palabras.size();i++){
            if(palabras.get(i).equals(palabra)) existente = true;
        }
        if(!existente) palabras.add(palabra);
    }

}

