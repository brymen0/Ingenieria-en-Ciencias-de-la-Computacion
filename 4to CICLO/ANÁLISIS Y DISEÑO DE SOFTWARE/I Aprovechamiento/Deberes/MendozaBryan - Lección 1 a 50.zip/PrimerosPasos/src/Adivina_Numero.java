import java.util.*;

import javax.swing.JOptionPane;

public class Adivina_Numero {

	public static void main(String[] args) {
		int random = (int) (Math.random()*100);
		int num = -8, intento = 0;
		Scanner entrada = new Scanner(System.in);
		while(random != num) {
			num = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un número"));
			if(random > num)
				JOptionPane.showMessageDialog(null, "El numero a adivinar es mayor a "+num);
			else if(random < num) JOptionPane.showMessageDialog(null, "El numero a adivinar es menor a "+num);
			intento ++;
		}
		JOptionPane.showMessageDialog(null, "Haz adivinado el numero, en "+intento+" intentos");
	}

}
