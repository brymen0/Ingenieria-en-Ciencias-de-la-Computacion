package POO;

public interface Jefes {
	String tomar_decisiones(String decision);
}
