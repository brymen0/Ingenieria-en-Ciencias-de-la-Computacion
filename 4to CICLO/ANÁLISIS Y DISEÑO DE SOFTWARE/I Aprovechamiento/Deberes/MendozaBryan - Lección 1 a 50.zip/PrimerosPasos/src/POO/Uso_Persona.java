package POO;

import java.util.Date;
import java.util.GregorianCalendar;

public class Uso_Persona {

	public static void main(String[] args) {
		Persona [] lasPersonas = new Persona[2];
		lasPersonas[0] = new Empleado2("Bryan Mendoza", 900, 2009, 01, 10);
		lasPersonas[1] = new Alumno("Juan Castro", "Computación");
		
		for(Persona e: lasPersonas)
			System.out.println(e.getNombre() +", "+ e.dame_descripcion());
	}

}

abstract class Persona{
	private String nombre;

	public Persona(String nombre) {
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}
	
	public abstract String dame_descripcion();
	
}

class Empleado2 extends Persona{
	private float sueldo;
	private Date altaContrato;
	private int id;
	private static int idSiguiente = 1;
	
	public Empleado2(String nom, float sueldo, int agno, int mes, int dia) {
		super(nom);
		this.sueldo = sueldo;
		GregorianCalendar calendario = new GregorianCalendar(agno, mes-1, dia);
		this.altaContrato = calendario.getTime();
		id = idSiguiente;
		idSiguiente ++;
	}
	
	public String dame_descripcion() {
		return "Este empleado tiene un Id: "+id+", con un sueldo de "+sueldo;
	}
	
	public int getId() {
		return id;
	}

	public float getSueldo() {
		return sueldo;
	}

	public Date getAltaContrato() {
		return altaContrato;
	}


	public float subir_sueldo(float porcentaje) {
		float aumento = sueldo * porcentaje/100;
		return sueldo += aumento;
	}
}

class Alumno extends Persona{
	private String carrera;
	
	public Alumno(String nom, String carr) {
		super(nom);
		carrera = carr;
	}
	
	public String dame_descripcion() {
		return "Este alumno está estudiando la carrera "+carrera;
	}
}
