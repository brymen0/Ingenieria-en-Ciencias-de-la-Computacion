package POO;

import paquetepruebas.Clase3;
public class Clase2 {

	public static void main(String[] args) {
	
		Clase1 miobj = new Clase1();
		Clase3 miobj2 = new Clase3();
		
	}

}
