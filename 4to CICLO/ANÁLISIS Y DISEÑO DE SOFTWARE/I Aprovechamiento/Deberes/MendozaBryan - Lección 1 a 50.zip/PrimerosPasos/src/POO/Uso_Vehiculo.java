package POO;

import java.util.*;
import javax.swing.*;

public class Uso_Vehiculo {

	public static void main(String[] args) {
		Coche miCoche1 = new Coche(); //instaciar una clase
		miCoche1.setColor("Rojo");
		Furgoneta miFurgoneta1 = new Furgoneta(580, 7);
		miFurgoneta1.setColor("azul");
		miFurgoneta1.configura_asientos("si");
		miFurgoneta1.configura_climatizador("si");
		System.out.println(miCoche1.dime_datos()+" "+miCoche1.getColor());
		System.out.println(miFurgoneta1.dime_datos()+" "+miFurgoneta1.dimeDatosFurgoneta());
	}
}
