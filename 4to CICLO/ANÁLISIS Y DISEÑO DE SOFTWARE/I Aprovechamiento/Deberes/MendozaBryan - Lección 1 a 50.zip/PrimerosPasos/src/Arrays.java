import javax.swing.JOptionPane;
import java.lang.*;

public class Arrays {

	public static void main(String[] args) {
		String[] paises = new String[8];
		for(int i=0; i<8; i++) {
			paises[i] = JOptionPane.showInputDialog("Ingrese un pais");
		}
		System.out.println("Los paises ingresados son");
		for(String elemento:paises)
			System.out.println("País: "+elemento);
	}

}
