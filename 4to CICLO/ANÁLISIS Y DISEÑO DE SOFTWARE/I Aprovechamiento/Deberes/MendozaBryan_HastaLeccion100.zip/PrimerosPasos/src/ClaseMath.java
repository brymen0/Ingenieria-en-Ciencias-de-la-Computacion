public class ClaseMath {

	public static void main(String[] args) {
		double raiz = Math.sqrt(25);
		System.out.println(raiz);
		
		float num1 = 9.85F;
		int redondeado = Math.round(num1);
		System.out.println(redondeado);
		
		double num2 = 11.28;
		int result = (int)Math.round(num2);
		System.out.println(result);
		
		double base = 7F;
		double exponente = 3F;
		int result2 = (int)Math.pow(base, exponente);
		System.out.println("El resultado de "+base+" elevado a "+exponente+" es igual a "+result2);
	}

}
