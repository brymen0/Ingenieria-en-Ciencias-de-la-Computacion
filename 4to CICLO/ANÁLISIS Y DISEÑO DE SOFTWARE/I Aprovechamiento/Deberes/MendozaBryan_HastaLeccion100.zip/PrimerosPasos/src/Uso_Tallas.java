import java.util.*;

public class Uso_Tallas {

	//enum Talla {MINI, MEDIANO, GRANDE, MUY_GRANDE}
	
	enum Talla{
		
		MINI("S"), MEDIANO("M"), GRANDE("L"), MUY_GRANDE("XL");
		private String abreviatura;
		
		private Talla(String abreviatura) {
			this.abreviatura = abreviatura;
		}

		public String getAbreviatura() {
			return abreviatura;
		}
		
	}
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		System.out.println("Escribe una talla: MINI, MEDIANO, GRANDE, MUY_GRANDE");
		String dato = entrada.next().toUpperCase();
		Talla laTalla = Enum.valueOf(Talla.class, dato);
		System.out.println("Talla: "+laTalla);
		System.out.println("Abrevitura: "+laTalla.getAbreviatura());
	}

}
