import java.util.*;
import javax.swing.*;

public class AreasCondicionales {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		System.out.println("Elige una opcion:");
		System.out.println("1. Cuadrado\n2. Triángulo\n3. Círculo\n4. Rectángulo");
		int opcion = entrada.nextInt();
		float area, lado;
		switch(opcion){
			case 1: //cuadrado
				lado = Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de un lado:"));
				area = lado*lado;
				System.out.println("La area del cuadrado es: "+ area);
				break;
			
			case 2: //triangulo
				lado = Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de la base:"));
				float altura = Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de la altura:"));
				area = (lado * altura)/2;
				System.out.println("La area del triangulo es: "+ area);
				break;
				
			case 3: //circulo
				float radio = Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor del radio:"));
				area = (float) (Math.PI*Math.pow(radio, 2));
				System.out.println("La area del circulo es: "+ area);
				break;
				
			case 4: //rectangulo
				lado = Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de un lado:"));
				float lado2 = Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor del otro lado:"));
				area = lado*lado2;
				System.out.println("La area del rectangulo es: "+ area);
				break;
			
			default:
				System.out.println("Opcion no valida");
		}
	}
}

