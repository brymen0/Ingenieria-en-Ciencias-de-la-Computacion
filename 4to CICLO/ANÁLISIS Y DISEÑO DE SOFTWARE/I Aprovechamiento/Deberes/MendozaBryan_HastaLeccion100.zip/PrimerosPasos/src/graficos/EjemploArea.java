package graficos;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class EjemploArea {

	public static void main(String[] args) {
		MarcoArea mimarco = new MarcoArea();
		mimarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mimarco.setVisible(true);
	}
}



class MarcoArea extends JFrame{
	
	public MarcoArea() {
		setBounds(600, 300, 600, 350);
		LaminaArea milamina = new LaminaArea();
		add(milamina);
		setVisible(true);
	}
}

class LaminaArea extends JPanel{
	
	private JTextArea miarea;
	
	public LaminaArea() {		
		miarea = new JTextArea(8,20);
		
		JScrollPane laminaBarras = new JScrollPane(miarea);
		miarea.setLineWrap(true);
		add(laminaBarras);
		
		JButton miboton = new JButton("Dale");
		miboton.addActionListener(new GestionaArea());
		add(miboton);
	}
	
	private class GestionaArea implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println(miarea.getText());
		}	
	}
}