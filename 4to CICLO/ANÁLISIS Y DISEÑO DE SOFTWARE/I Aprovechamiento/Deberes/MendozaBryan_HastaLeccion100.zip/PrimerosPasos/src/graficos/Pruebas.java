package graficos;

import java.awt.GraphicsEnvironment;
import javax.swing.*;

public class Pruebas {

	public static void main(String[] args) {
		String fuente = JOptionPane.showInputDialog("Introduce una fuente");
		boolean esta = false;
		String[] nombreFuentes = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
		for(String e: nombreFuentes) {
			if(e.equals(fuente)) 
				esta = true;
		}
		if(esta) System.out.println("Si esta instalada la fuente");
		else System.out.println("No esta instalada la fuente");
	}

}
