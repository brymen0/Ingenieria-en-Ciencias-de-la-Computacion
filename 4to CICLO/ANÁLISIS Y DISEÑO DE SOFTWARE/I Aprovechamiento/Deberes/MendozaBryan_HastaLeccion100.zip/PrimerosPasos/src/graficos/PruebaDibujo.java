package graficos;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;

public class PruebaDibujo {

	public static void main(String[] args) {
		MarcoConDibujos miMarco = new MarcoConDibujos();
		miMarco.setVisible(true);
		miMarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}

 class MarcoConDibujos extends JFrame{
	 public MarcoConDibujos() {
		 setTitle("Prueba con dibujo");
		 setSize(400,400);
		 LaminaConFiguras miLamina = new LaminaConFiguras();
		 add(miLamina);
	 }
 }
 
 class LaminaConFiguras extends JPanel{
	 public void paintComponent(Graphics g) {
		 super.paintComponent(g);
		 //g.drawRect(20,30,100,80);
		 //g.drawLine(10,20,100,200);
		 //g.drawArc(50,100,100,200,60,150);
		 Graphics2D g2 = (Graphics2D) g;
		 Rectangle2D rectangulo = new Rectangle2D.Double(100,100,200,150);
		 //Ellipse2D elipse = new Ellipse2D.Double(100,100,200,150);
		 Ellipse2D elipse = new Ellipse2D.Double();
		 elipse.setFrame(rectangulo);
		 g2.draw(rectangulo);
		 g2.fill(elipse); //rellena la figura
		 g2.draw(new Line2D.Double(100,100,300,250));
		 double centroX = rectangulo.getCenterX();
		 double centroY = rectangulo.getCenterY();
		 double radio = 150;
		 Ellipse2D circulo = new Ellipse2D.Double();
		 circulo.setFrameFromCenter(centroX,centroY, centroX+radio, centroY+radio);
		 g2.draw(circulo);
	 }
 }
