package graficos;

import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;

public class MarcoSliders {

	public static void main(String[] args) {
		FrameSliders miMarco = new FrameSliders();
		miMarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

class FrameSliders extends JFrame{
	public FrameSliders(){
		setBounds(550,350,550,350);
		LaminaSliders miLamina = new LaminaSliders();
		add(miLamina);
		setVisible(true);
	}
}

class LaminaSliders extends JPanel{
	public LaminaSliders() {
		JSlider control  = new JSlider(0,100,50);
		control.setMajorTickSpacing(50);
		control.setMinorTickSpacing(25);
		
		control.setPaintTicks(true);
		control.setPaintLabels(true);
		control.setFont(new Font("Serif", Font.ITALIC,12));
		control.setSnapToTicks(true); //convierte como en iman a las marcas
		add(control);
	}
}
