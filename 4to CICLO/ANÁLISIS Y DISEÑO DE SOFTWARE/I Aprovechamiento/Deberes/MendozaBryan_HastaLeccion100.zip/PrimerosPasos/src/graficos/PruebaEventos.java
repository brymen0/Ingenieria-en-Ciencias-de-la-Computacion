package graficos;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class PruebaEventos {

	public static void main(String[] args) {
		MarcoBotones miMarco = new MarcoBotones();
		miMarco.setVisible(true);
		miMarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}

class MarcoBotones extends JFrame{
	public MarcoBotones() {
		setTitle("Botones y eventos");
		setBounds(300,200,500,300);
		LaminaBotones miLamina = new LaminaBotones();
		add(miLamina);
	}
}

class LaminaBotones extends JPanel {
	JButton botonAzul = new JButton("Azul");
	JButton botonAmarillo = new JButton("Amarillo");
	JButton botonRojo = new JButton("Rojo");
	
	public LaminaBotones() {
		add(botonAzul);
		add(botonAmarillo);
		add(botonRojo);
		ColorFondo Amarillo = new ColorFondo(Color.YELLOW);
		ColorFondo Azul = new ColorFondo(Color.BLUE);
		ColorFondo Rojo = new ColorFondo(Color.RED);
		botonAzul.addActionListener(Azul);
		botonAmarillo.addActionListener(Rojo);
		botonRojo.addActionListener(Amarillo);
	}
	
	class ColorFondo implements ActionListener{
		private Color ColorDeFondo;
		public ColorFondo(Color c) {
			ColorDeFondo = c;
		}
		
		public void actionPerformed(ActionEvent e) {
			setBackground(ColorDeFondo);
		}
	}
}
