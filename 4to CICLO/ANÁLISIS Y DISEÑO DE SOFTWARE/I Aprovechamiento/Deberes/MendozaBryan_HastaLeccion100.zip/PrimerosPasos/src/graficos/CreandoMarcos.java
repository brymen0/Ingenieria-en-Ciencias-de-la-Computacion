package graficos;

import java.awt.Frame;

import javax.swing.*;

public class CreandoMarcos {

	public static void main(String[] args) {
		miMarco marco1 = new miMarco();
		marco1.setVisible(true);
		marco1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //frena el programa cuando se cierra la ventana
	}

}

class miMarco extends JFrame{
	public miMarco() {
		//setLocation(500,300);
		//setSize(500,300);
		setBounds(500,90,500,500);
		//setResizable(false);
		//setExtendedState(Frame.MAXIMIZED_BOTH);
		setTitle("Configuration");
	}
}
