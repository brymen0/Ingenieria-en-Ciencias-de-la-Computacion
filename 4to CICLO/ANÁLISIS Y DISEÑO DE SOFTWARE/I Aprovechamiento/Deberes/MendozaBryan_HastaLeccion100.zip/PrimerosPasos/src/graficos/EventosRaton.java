package graficos;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.*;

public class EventosRaton {

	public static void main(String[] args) {
		MarcoRaton miMarco = new MarcoRaton();
		miMarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}

class MarcoRaton extends JFrame{
	public MarcoRaton() {
		setVisible(true);
		setBounds(500,250,500,400);
		EventosDeRaton EventoRaton = new EventosDeRaton();
		addMouseMotionListener(EventoRaton);
	}
}

class EventosDeRaton implements MouseMotionListener{

	@Override
	public void mouseDragged(MouseEvent e) {
		System.out.println("Estas arrastrando");
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		System.out.println("Estas moviendo");
	}
}

/*class EventosDeRaton implements MouseListener{

	@Override
	public void mouseClicked(MouseEvent e) {
		System.out.println("Click");
	}

	@Override
	public void mousePressed(MouseEvent e) {
		System.out.println("Presionar");
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		System.out.println("Levantar");
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		System.out.println("entrar");
	}

	@Override
	public void mouseExited(MouseEvent e) {
		System.out.println("salir");
	}
}*/

/*class EventosDeRaton extends MouseAdapter{

	@Override
	public void mouseClicked(MouseEvent e) {
		//System.out.println("click");
		//System.out.println("Coordenada X: "+e.getX()+" Coordenada y: "+e.getY());
		//System.out.println(e.getClickCount());
	}
	
	public void mousePressed(MouseEvent e) {
		if(e.getModifiersEx() == MouseEvent.BUTTON1_DOWN_MASK) System.out.println("boton izquierdo");
		else if(e.getModifiersEx() == MouseEvent.BUTTON2_DOWN_MASK) System.out.println("Rueda");
		else if(e.getModifiersEx() == MouseEvent.BUTTON3_DOWN_MASK) System.out.println("boton derecho");
	}

}*/