package graficos;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.*;
import javax.imageio.*;
import java.io.*;
public class PruebaImagenes {

	public static void main(String[] args) {
		MarcoImagen miMarco = new MarcoImagen();
		miMarco.setVisible(true);
		miMarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}

class MarcoImagen extends JFrame{
	public MarcoImagen() {
		setTitle("Prueba con fuentes");
		setBounds(750,200,500,500);
		LaminaConImagen miLamina = new LaminaConImagen();
		add(miLamina);
		miLamina.setForeground(Color.BLUE);//establecer todo de un solo color
	}
}

class LaminaConImagen extends JPanel{
	private Image imagen;
	
	public LaminaConImagen() {
		try {
			imagen = ImageIO.read(new File("src/graficos/bola.gif"));
		} catch (IOException e) {
			System.out.println("La imagen no ha sido encontrada");
		}
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		//File miImagen = new File("src/graficos/bola.gif");
		g.drawImage(imagen, 0,0, null);
		for(int i=0; i<100; i++) {
			for(int j=0; j<500;j++)
				if(i+j>0)
				g.copyArea(0,0,imagen.getWidth(this),imagen.getHeight(this),i*imagen.getWidth(this),j*imagen.getHeight(this)); //copia una imagen en otra parte
		}
	}
}
