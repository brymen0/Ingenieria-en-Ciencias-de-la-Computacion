package graficos;

import javax.swing.*;
import java.awt.*;
 
public class TrabajandoConFuentes {

	public static void main(String[] args) {
		MarcoConFuente miMarco = new MarcoConFuente();
		miMarco.setVisible(true);
		miMarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}

class MarcoConFuente extends JFrame{
	public MarcoConFuente() {
		setTitle("Prueba con fuentes");
		setSize(400,400);
		LaminaConFuentes miLamina = new LaminaConFuentes();
		add(miLamina);
		miLamina.setForeground(Color.BLUE);//establecer todo de un solo color
	}
}

class LaminaConFuentes extends JPanel{
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		Font miFuente = new Font("Calibri",Font.ITALIC,30);
		g2.setFont(miFuente); 
		//g2.setColor(Color.GREEN.darker());
		g2.drawString("Bryan ", 100,100);
		//g2.setColor(new Color(200,200,200));
		g2.setFont(new Font("Courier", Font.PLAIN, 50));
		g2.drawString("Curso JAVA", 50,60);
	}
}
