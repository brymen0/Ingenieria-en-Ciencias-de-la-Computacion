package graficos;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class PruebaArea {

	public static void main(String[] args) {
		MarcoPruebaArea mimarco = new MarcoPruebaArea();
		mimarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mimarco.setVisible(true);
	}
}

class MarcoPruebaArea extends JFrame{
	
	private JPanel laminaBotones;
	private JButton botonInsertar, botonSaltoLinea;
	private JTextArea areaTexto;
	private JScrollPane laminaConBarras;
	
	public MarcoPruebaArea() {
		setBounds(600, 300, 600, 350);
		
		setLayout(new BorderLayout());
		laminaBotones = new JPanel();
		botonInsertar = new JButton("insertar");
		
		botonInsertar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				areaTexto.append("En un lugar de Cuenca de cuyo nombre no quiero arcordarme...");	
			}	
		});
		
		laminaBotones.add(botonInsertar);
		botonSaltoLinea = new JButton("Salto Linea");
		botonSaltoLinea.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				boolean saltar =!areaTexto.getLineWrap();
				areaTexto.setLineWrap(saltar);
				/*if(saltar) botonSaltoLinea.setText("Quitar salto");
				else botonSaltoLinea.setText("Salto linea");*/
				
				botonSaltoLinea.setText(saltar ? "Quitar salto" : "Salto linea");
			}
		});
		
		laminaBotones.add(botonSaltoLinea);
		add(laminaBotones, BorderLayout.SOUTH);
		
		areaTexto = new JTextArea(8,20);
		laminaConBarras = new JScrollPane(areaTexto);
		add(laminaConBarras, BorderLayout.CENTER);
	}
}