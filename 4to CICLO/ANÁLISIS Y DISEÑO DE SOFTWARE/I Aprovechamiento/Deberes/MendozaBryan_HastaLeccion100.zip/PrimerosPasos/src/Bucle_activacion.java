import java.util.*;

public class Bucle_activacion {

	public static void main(String[] args) {
		String clave;
		String pass = "17m";
		
		Scanner entrada = new Scanner(System.in);
		System.out.println("Ingrese la contraseña: ");
		clave = entrada.nextLine();
		while(clave.equals(pass) == false) {
			System.out.println("Clave incorrecta\nIngrese nuevamente la  contraseña:");
			clave = entrada.nextLine();
		}
		System.out.println("Clave correcta. Acceso permitido");
	}

}
