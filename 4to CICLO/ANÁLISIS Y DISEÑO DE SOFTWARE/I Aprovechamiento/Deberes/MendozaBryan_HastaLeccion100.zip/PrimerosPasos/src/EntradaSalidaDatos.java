import java.util.*;
import javax.swing.*;
public class EntradaSalidaDatos {
	public static void main(String [] args) {
		/*Scanner entrada = new Scanner(System.in);
		System.out.println("Ingrese su nombre");
		String name = entrada.nextLine();
		System.out.println("Ingrese su edad");
		int edad = entrada.nextInt();
		System.out.println("Su nombre es "+name+" y tiene "+edad+" años");*/
		
		// Segunda forma
		String carrera = JOptionPane.showInputDialog("Ingresa que carrera estudias");
		int ciclo = Integer.parseInt(JOptionPane.showInputDialog("Ingrese en que ciclo esta"));
		System.out.println("Estas en "+ciclo+" de "+carrera);
		
		double mil= 1000;
		double respuesta = mil/6;
		System.out.println(String.format("%.3f", respuesta));
	}
}
