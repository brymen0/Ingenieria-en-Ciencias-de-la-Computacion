import javax.swing.*;

public class Peso_Ideal {

	public static void main(String[] args) {
		String genero = "";
		do {
			genero = JOptionPane.showInputDialog("Ingrese su genero(H/M):");
			if(genero.equalsIgnoreCase("M") == false && genero.equalsIgnoreCase("H") == false)
				JOptionPane.showMessageDialog(null, "ERROR: Debe ingresar M o H");
		}while(genero.equalsIgnoreCase("M") == false && genero.equalsIgnoreCase("H") == false);
		
		int altura = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su altura en centimetros: "));
		int peso;
		if(genero == "H")
			peso = altura - 110;
		else peso = altura - 120;
		JOptionPane.showMessageDialog(null, "Su peso ideal es "+peso+" kg");
	}

}
