package paquetepruebas;

import POO.Clase1;

public class Clase3 extends Clase1{
	
}
