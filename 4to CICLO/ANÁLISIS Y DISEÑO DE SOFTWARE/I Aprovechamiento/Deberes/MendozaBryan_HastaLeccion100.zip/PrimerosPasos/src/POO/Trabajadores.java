package POO;

public interface Trabajadores {
	double Establece_bonus(double gratificacion);
	
	double bonusBase = 50;
}
