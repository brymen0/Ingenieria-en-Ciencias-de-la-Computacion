package POO;

public interface Jefes extends Trabajadores{
	String tomar_decisiones(String decision);
}
