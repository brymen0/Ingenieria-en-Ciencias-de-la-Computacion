package POO;

import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.Timer;
import java.awt.Toolkit;

public class PruebaTemporizador2 {

	public static void main(String[] args) {
		Reloj miReloj = new Reloj();
		miReloj.enMarcha(1000, true);
		JOptionPane.showMessageDialog(null, "Pulsa Ok para parar");
		System.exit(0);
	}

}

class Reloj{
	
	public void enMarcha(int intervalo, final boolean sonido){
		
		class DameHora2 implements ActionListener{
			
			public void actionPerformed(ActionEvent e) {
				Date ahora = new Date();
				System.out.println("La hora cada 3 segundos: "+ahora);
				if(sonido) Toolkit.getDefaultToolkit().beep();
			}
		}
		
		ActionListener oyente = new DameHora2();
		Timer miTemporizador = new Timer(intervalo, oyente);
		miTemporizador.start();
	}
	
}
