package POO;

public class Clase1 {
	protected int mivar = 5;
	int mivar2 = 7;
	
	String mimetodo() {
		return "El valor de mivar2 es: "+mivar2;
	}
}
