package POO;

public class Pruebas {

	public static void main(String[] args) {
		Empleados trabajador1 = new Empleados("Bryan");
		Empleados trabajador2 = new Empleados("Juan");
		Empleados trabajador3 = new Empleados("Maria");
		trabajador1.setSeccion("RRHH");
		System.out.println(trabajador1.devuelve_datos() + "\n"+ trabajador2.devuelve_datos() + 
				"\n"+ trabajador3.devuelve_datos());
		System.out.println(Empleados.id_siguiente());
		
	}

}


class Empleados{
	private String nombre;
	private String seccion;
	private int id;
	private static int id_siguiente = 1;

	public Empleados(String nombre) {
		this.nombre = nombre;
		seccion = "administracion";
		id = id_siguiente;
		id_siguiente++;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public void setSeccion(String seccion) {
		this.seccion = seccion;
	}
	
	public String devuelve_datos() {
		return "El nombre es "+nombre+", la seccion es "+seccion+" y el id: "+id;
	}
	
	public static String id_siguiente() {
		return "El Id siguiente es "+id_siguiente;
	}
}