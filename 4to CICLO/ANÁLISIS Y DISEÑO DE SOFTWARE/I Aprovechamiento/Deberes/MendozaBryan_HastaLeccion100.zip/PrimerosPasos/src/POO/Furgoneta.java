package POO;

public class Furgoneta extends Coche{
	private int capacidad_extra;
	private int plazas_extra;
	public Furgoneta(int capacidad_extra, int plazas_extra) {
		super();
		this.capacidad_extra = capacidad_extra;
		this.plazas_extra = plazas_extra;
	}
	
	public String dimeDatosFurgoneta() {
		return "La capacidad de carga es "+capacidad_extra + " y tiene "+plazas_extra+" plazas extra";
	}
}
