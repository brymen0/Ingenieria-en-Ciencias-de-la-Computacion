package POO;

import java.awt.Toolkit;
import java.awt.event.*;
import java.util.*;

import javax.swing.JOptionPane;
import javax.swing.Timer;

public class PruebaTemporizador{
	public static void main(String [] args) {
		DameHora oyente = new DameHora(); 
		Timer miTemporizador = new Timer(5000, oyente);
		miTemporizador.start();
		JOptionPane.showMessageDialog(null, "Pulsa Ok para detener");
		System.exit(0);
	}
	
}

class DameHora implements ActionListener{
	public void actionPerformed(ActionEvent e) {
		Date ahora = new Date();
		System.out.println("Te pongo la hora cada 5 segundos: "+ahora);
		Toolkit.getDefaultToolkit().beep();
	}
}