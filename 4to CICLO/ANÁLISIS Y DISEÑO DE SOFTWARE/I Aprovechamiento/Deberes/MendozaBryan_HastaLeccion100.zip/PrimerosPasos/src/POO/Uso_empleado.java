package POO;
import java.util.*;
public class Uso_empleado {
	public static void main(String[] args) {
		Jefatura jefe_RRHH = new Jefatura("Juan Mendoza", 700, 2006, 9, 25);
		jefe_RRHH.setIncentivo(250);
		Empleado[]misEmpleados = new Empleado[6];
		misEmpleados[0] = new Empleado("Bryan Mendoza", 500, 1990, 12, 17);
		misEmpleados[1] = new Empleado("Alex Barahona", 650, 1995, 06, 02);
		misEmpleados[2] = new Empleado("Emily Estrada", 450, 2003, 10, 30);
		misEmpleados[3] = new Empleado("Cristian Chiriboga");
		misEmpleados[4] = jefe_RRHH; //polimorfismo en accion. Principio de sustitucion
		misEmpleados[5] = new Jefatura("Maria Once", 675, 1999, 5, 26);
		Jefatura jefa_Finanzas = (Jefatura) misEmpleados[5];
		jefa_Finanzas.setIncentivo(500);
		
		System.out.println(jefa_Finanzas.tomar_decisiones("Dar más dias de vacaciones a los empleados"));
		System.out.println("El jefe "+jefa_Finanzas.getNombre()+" tiene un bonus de "+jefa_Finanzas.Establece_bonus(500));
		System.out.println("El empleado "+misEmpleados[3].getNombre()+" tiene un bonus de "+misEmpleados[3].Establece_bonus(150));
		for(Empleado e:misEmpleados)
			e.subir_sueldo(5);
		
		Arrays.sort(misEmpleados);
		
		for(Empleado e:misEmpleados)
			System.out.println("Nombre: "+e.getNombre()+" ID: "+e.getId()+" Sueldo: "+e.getSueldo()+" Fecha alta: "+e.getAltaContrato());
	}
}

class Empleado implements Comparable, Trabajadores{
	private String nombre;
	private float sueldo;
	private Date altaContrato;
	private int id;
	private static int idSiguiente = 1;
	
	public Empleado(String nombre, float sueldo, int agno, int mes, int dia) {
		this.nombre = nombre;
		this.sueldo = sueldo;
		GregorianCalendar calendario = new GregorianCalendar(agno, mes-1, dia);
		this.altaContrato = calendario.getTime();
		id = idSiguiente;
		idSiguiente ++;
	}
	
	
	public int getId() {
		return id;
	}
	
	public Empleado(String nombre) {
		this(nombre,450,2000,01,01);
	}
	
	public String getNombre() {
		return nombre;
	}

	public float getSueldo() {
		return sueldo;
	}

	public Date getAltaContrato() {
		return altaContrato;
	}


	public float subir_sueldo(float porcentaje) {
		float aumento = sueldo * porcentaje/100;
		return sueldo += aumento;
	}
	
	public int compareTo(Object miObjeto) {
		Empleado otroEmpleado = (Empleado) miObjeto;
		if(this.id < otroEmpleado.id) return -1;
		else if(this.id > otroEmpleado.id) 	return 1;
		else return 0;
	}
	
	public double Establece_bonus(double gratificacion) {
		return Trabajadores.bonusBase + gratificacion;
	}
}

class Jefatura extends Empleado implements Jefes{
	private float incentivo;
	
	public Jefatura(String nom, float sue, int agno, int mes, int dia) {
		super(nom, sue, agno, mes , dia);
	}

	public float getIncentivo() {
		return incentivo;
	}

	public void setIncentivo(float incentivo) {
		this.incentivo = incentivo;
	}
	
	public float getSueldo() {
		float sueldoJefe = super.getSueldo();
		return sueldoJefe +incentivo;
	}
	
	public String tomar_decisiones(String decision) {
		return "Un miembro de la dirección ha tomado la decisión de "+decision;
	}
	
	public double Establece_bonus(double gratificacion) {
		double prima = 100;
		return Trabajadores.bonusBase + gratificacion + prima;
	}
}

class Director extends Jefatura{
	public Director(String nom, float sue, int agno, int mes, int dia) {
		super(nom, sue, agno, mes , dia); 
	}
}