
public class Declaracion_variables_Constantes_Operadores {

	public static void main(String[] args) {
		byte edad=25;
		System.out.println("Hola alumnos"+edad);
		System.out.println(edad);
		int a = 5;
		int b;
		b = 4;
		int c = a+b;
		float d = (float)a/b;
		c++;
		System.out.println(c);
		System.out.println(d);
		
		//contantes
		final double apulgadas= 2.54;
		double cm = 6;
		double resultado = cm / apulgadas;
		System.out.println("En " +cm+" cm hay "+resultado+" pulgadas");
	}

}
