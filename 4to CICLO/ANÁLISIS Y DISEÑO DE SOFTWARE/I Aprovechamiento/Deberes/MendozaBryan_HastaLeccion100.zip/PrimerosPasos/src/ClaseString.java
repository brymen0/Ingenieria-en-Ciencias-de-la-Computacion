
public class ClaseString {

	public static void main(String[] args) {
		String nombre = "Bryan";
		System.out.println("Mi nombre es "+nombre+" y tiene "+nombre.length()+" letras");
		System.out.println("La primera letra de mi nombre es "+nombre.charAt(0));
		
		int ultimaletra = nombre.length();
		System.out.println("La ultima letra de mi nombre es "+nombre.charAt(ultimaletra-1));
		
		
		String frase = "Hoy es un dia estupendo para aprender a programar en JAVA";
		String subfrase = frase.substring(0,28)+" irnos a la playa y desestresarnos";
		System.out.println(subfrase);
		
		String alumno1, alumno2;
		alumno1 = "Bryan"; alumno2="bryan";
		System.out.println(alumno1.equalsIgnoreCase(alumno2));
	}

}
