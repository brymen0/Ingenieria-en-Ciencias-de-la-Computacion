package com.iteratrlearning.shu_book.chapter_04;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import static com.iteratrlearning.shu_book.chapter_04.Attributes.*;

public class PrescriptionImporter implements Importer{
	private static final String NAME_PREFIX= "Patient: ";
	private static final String DRUG_PREFIX= "Drug: ";
	private static final String QUANTITY_PREFIX= "Quantity: ";
	private static final String DATE_PREFIX= "Date: ";
	private static final String CONDICTION_PREFIX= "Condiction: ";
	
	@Override
	public Document importFile(File file) throws IOException {
		final TextFile textFile=new TextFile(file);
		
		textFile.addLineSuffix(NAME_PREFIX,PATIENT);
		textFile.addLineSuffix(DRUG_PREFIX,DRUG);
		textFile.addLineSuffix(QUANTITY_PREFIX,QUANTITY);
		textFile.addLineSuffix(DATE_PREFIX, DATE);
		textFile.addLineSuffix(CONDICTION_PREFIX,CONDICTION);
		
		final Map<String, String> attributes=textFile.getAttributes();
		attributes.put(TYPE,"PRESCRIPTION");
		return new Document(attributes);
	}
}

