package BankAnalize;

import java.util.List;
import java.nio.file.Path;
import java.io.IOException;
import java.nio.file.Paths;
import java.nio.file.Files;
import Bank.BankTransaction;
import Bank.BankStatementProcessor;
import BankParser.BankStatementParser;


public abstract class BankStatementAnalyzer {
    final List<BankTransaction> bankTransactions;
    final BankStatementProcessor bankStatementProcessor;
    private static final String RESOURCES = "src/Resorces/";

    public  BankStatementAnalyzer(final String fileName, final BankStatementParser bankStatementParser) throws IOException {

        final Path path = Paths.get(RESOURCES + fileName);
        final List<String> lines = Files.readAllLines(path);

        bankTransactions = bankStatementParser.parseLinesFrom(lines);

        bankStatementProcessor = new BankStatementProcessor(bankTransactions);

    }

    public abstract void analyze();

}
