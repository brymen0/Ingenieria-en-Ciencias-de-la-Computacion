package BankAnalize;

import java.io.IOException;
import BankParser.BankStatementParser;


public class BankStatementAnalizeAmountForCategory extends BankStatementAnalyzer{
    private  final String Category;
    public BankStatementAnalizeAmountForCategory(String fileName, BankStatementParser bankStatementParser, String Category) throws IOException {

        super(fileName, bankStatementParser);
        this.Category = Category;
    }

    @Override
    public void analyze() {

        System.out.println("Total amount is : " + bankStatementProcessor.calculateTotalForCategory(Category));
    }
}
