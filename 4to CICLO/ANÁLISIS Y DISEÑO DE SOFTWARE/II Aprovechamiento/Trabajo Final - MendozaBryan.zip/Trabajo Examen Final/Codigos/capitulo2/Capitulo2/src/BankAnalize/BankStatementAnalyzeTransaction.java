package BankAnalize;

import java.time.Month;
import java.io.IOException;
import BankParser.BankStatementParser;

public class BankStatementAnalyzeTransaction extends BankStatementAnalyzer{

    private final Month endMonth;
    private final Month beginMonth;
    public BankStatementAnalyzeTransaction(String fileName, BankStatementParser bankStatementParser, Month beingMonth, Month endMonth) throws IOException {
        super(fileName, bankStatementParser);
        this.endMonth = endMonth;
        this.beginMonth = beingMonth;
    }

    @Override
    public void analyze() {
        System.out.println("Min transaction between " + beginMonth + " and " + endMonth + " is " + bankStatementProcessor.findMinTransaction(beginMonth, endMonth));
        System.out.println("Max transaction between " + beginMonth + " and " + endMonth + " is " + bankStatementProcessor.findMaxTransaction(beginMonth, endMonth));
    }
}
