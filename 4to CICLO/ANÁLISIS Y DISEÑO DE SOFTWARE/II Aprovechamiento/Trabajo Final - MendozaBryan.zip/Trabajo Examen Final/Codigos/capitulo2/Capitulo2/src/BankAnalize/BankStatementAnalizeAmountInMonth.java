package BankAnalize;

import java.time.Month;
import java.io.IOException;
import BankParser.BankStatementParser;

public class BankStatementAnalizeAmountInMonth extends BankStatementAnalyzer{

    private final Month month;
    public BankStatementAnalizeAmountInMonth(String fileName, BankStatementParser bankStatementParser, Month month) throws IOException {
        super(fileName, bankStatementParser);
        this.month = month;
    }

    @Override
    public void analyze() {

        System.out.println("Total amount is : " + bankStatementProcessor.calculateTotalInMonth(month));
    }

}
