import BankAnalize.*;
import BankParser.BankStatementCSVParser;

import java.time.Month;

public class MainApplication {

    public static void main(String[] args) throws Exception {
        String nombreArchivo = "bank-data-simple.csv";
        new BankStatementAnalizeTotalAmount(nombreArchivo, new BankStatementCSVParser()).analyze();
        new BankStatementAnalizeAmountInMonth(nombreArchivo, new BankStatementCSVParser(), Month.JANUARY).analyze();
        new BankStatementAnalizeAmountForCategory(nombreArchivo, new BankStatementCSVParser(), "Deliveroo").analyze();
        new BankStatementAnalyzeTransaction(nombreArchivo, new BankStatementCSVParser(), Month.JANUARY, Month.FEBRUARY).analyze();
        new BankStatementAnalyzeHistogram(nombreArchivo, new BankStatementCSVParser()).analyze();
    }
}
