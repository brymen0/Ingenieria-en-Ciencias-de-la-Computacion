package BankAnalize;

import java.io.IOException;
import BankParser.BankStatementParser;

public class BankStatementAnalizeTotalAmount extends BankStatementAnalyzer{
    public BankStatementAnalizeTotalAmount(String fileName, BankStatementParser bankStatementParser) throws IOException {
        super(fileName, bankStatementParser);
    }
    @Override
    public void analyze() {

        System.out.println("Total amount is : " + bankStatementProcessor.calculateTotalAmount());
    }
}
