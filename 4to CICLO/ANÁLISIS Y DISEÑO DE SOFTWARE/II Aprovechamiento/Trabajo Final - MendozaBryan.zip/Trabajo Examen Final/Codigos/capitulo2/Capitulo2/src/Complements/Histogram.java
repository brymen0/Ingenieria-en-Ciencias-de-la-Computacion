package Complements;

import javax.swing.*;



import java.util.Map;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;


public class Histogram extends JFrame {

    private CategoryDataset createDataset(String RowKey, Map<String, Double> Data) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        for(Map.Entry<String, Double> data : Data.entrySet()){
            dataset.addValue(data.getValue(), RowKey, data.getKey());
        }

        return dataset;
    }

    private JFreeChart createHistogram(String title, String xaxisLabel, String yaxisLabel, CategoryDataset dataset) {

        return ChartFactory.createBarChart(
                title,
                xaxisLabel,
                yaxisLabel,
                dataset,
                PlotOrientation.VERTICAL,
                true, true, false
        );
    }

    public void displayHistogram(String title, String xaxisLabel, String yaxisLabel, String rowKey, Map<String, Double> data) {

        CategoryDataset dataset = createDataset(rowKey, data);
        JFreeChart chart = createHistogram(title, xaxisLabel, yaxisLabel, dataset);

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(500, 500));
        setContentPane(chartPanel);

        // Configurar la ventana
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
    }
}
