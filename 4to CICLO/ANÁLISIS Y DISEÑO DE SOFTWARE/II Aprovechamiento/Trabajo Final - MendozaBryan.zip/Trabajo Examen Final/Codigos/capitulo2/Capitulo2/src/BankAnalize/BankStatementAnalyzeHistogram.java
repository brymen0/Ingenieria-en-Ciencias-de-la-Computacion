package BankAnalize;

import BankParser.BankStatementParser;

import java.io.IOException;

public class BankStatementAnalyzeHistogram extends BankStatementAnalyzer{
    public BankStatementAnalyzeHistogram(String fileName, BankStatementParser bankStatementParser) throws IOException {
        super(fileName, bankStatementParser);
    }

    @Override
    public void analyze() {
        bankStatementProcessor.monthExpensesHistogram();
        bankStatementProcessor.descriptionsExpensesHistogram();
    }
}
