package Bank;

import Complements.Histogram;

import java.util.LinkedHashMap;
import java.util.List;
import java.time.Month;
import java.util.Map;


public class BankStatementProcessor {
    private final List<BankTransaction> bankTransactions;

    public BankStatementProcessor(final List<BankTransaction> bankTransactions) {
        this.bankTransactions = bankTransactions;
    }

    public double calculateTotalAmount() {
        double total = 0;
        for (final BankTransaction bankTransaction : bankTransactions) {
            total += bankTransaction.getAmount();
        }
        return total;
    }

    public double calculateTotalInMonth(final Month month) {
        double total = 0;
        for (final BankTransaction bankTransaction : bankTransactions) {
            if (bankTransaction.getDate().getMonth() == month) {

                total += bankTransaction.getAmount();
            }
        }
        return total;
    }

    public double calculateExpensesPerMonth(final Month month){
        double total = 0;

        for (final BankTransaction bankTransaction : bankTransactions) {
            if (bankTransaction.getDate().getMonth() == month && bankTransaction.getAmount() < 0) {

                total += bankTransaction.getAmount();
            }
        }

        return total;
    }

    public double calculateExpensesPerDescription(final String description){
        double total = 0;

        for (final BankTransaction bankTransaction : bankTransactions) {
            if (bankTransaction.getDescription().equals(description) && bankTransaction.getAmount() < 0) {

                total += bankTransaction.getAmount();
            }
        }

        return total;
    }


    public double calculateTotalForCategory(final String category) {
        double total = 0;
        for (final BankTransaction bankTransaction : bankTransactions) {
            if (bankTransaction.getDescription().equals(category)) {
                total += bankTransaction.getAmount();
            }
        }
        return total;
    }

    public double findMaxTransaction(final Month beginMonth, final Month endMonth){
       // double total = bankTransactions.getFirst().getAmount();
        double total = bankTransactions.get(0).getAmount();

        for (final BankTransaction bankTransaction : bankTransactions) {
            if ((bankTransaction.getDate().getMonth().compareTo(beginMonth) >= 0 && bankTransaction.getDate().getMonth().compareTo(endMonth) <= 0)  && Math.abs(bankTransaction.getAmount()) > Math.abs(total)) {
                total = bankTransaction.getAmount();
            }
        }
        return total;

    }

    public double findMinTransaction(final Month beginMonth, final Month endMonth){
        //double total = bankTransactions.getFirst().getAmount();
        double total = bankTransactions.get(0).getAmount();
        for (final BankTransaction bankTransaction : bankTransactions) {
            if ((bankTransaction.getDate().getMonth().compareTo(beginMonth) >= 0 && bankTransaction.getDate().getMonth().compareTo(endMonth) <= 0)  && Math.abs(bankTransaction.getAmount()) < Math.abs(total)) {
                total = bankTransaction.getAmount();
            }
        }
        return total;

    }

    public void monthExpensesHistogram(){
        Map<String, Double> expensesPerMonth = new LinkedHashMap<>();

        for(final Month month : Month.values()){

            expensesPerMonth.put(month.toString(), Math.abs(calculateExpensesPerMonth(month)));
        }

        new Histogram().displayHistogram("Gastos por mes", "Meses", "Dolares", "Gastos", expensesPerMonth);
    }

    public void descriptionsExpensesHistogram(){
        Map<String, Double> expensesDescription = new LinkedHashMap<>();

        for (final BankTransaction bankTransaction : bankTransactions) {
            expensesDescription.put(bankTransaction.getDescription(), Math.abs(calculateExpensesPerDescription(bankTransaction.getDescription())));
        }

        new Histogram().displayHistogram("Gastos por descripcion", "Descripcion", "Dolares", "Gastos", expensesDescription);
    }
}
