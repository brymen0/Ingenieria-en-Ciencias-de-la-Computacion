public interface Exporter {
    String export(SummaryStatistics summaryStatistics);
}

