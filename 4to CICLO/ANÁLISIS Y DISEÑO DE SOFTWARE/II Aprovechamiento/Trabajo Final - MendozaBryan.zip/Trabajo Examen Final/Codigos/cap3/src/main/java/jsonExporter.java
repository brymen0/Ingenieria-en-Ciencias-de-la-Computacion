import com.google.gson.Gson;

public class jsonExporter implements Exporter{


	@Override
	public String export(SummaryStatistics summaryStatistics) {
		Gson json = new Gson();
		String JSON = json.toJson(summaryStatistics);
        return JSON;
		
	}

}
