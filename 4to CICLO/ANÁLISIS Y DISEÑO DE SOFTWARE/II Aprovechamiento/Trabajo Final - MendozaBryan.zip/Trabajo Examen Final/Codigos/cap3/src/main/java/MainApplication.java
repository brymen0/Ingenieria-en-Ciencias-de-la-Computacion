import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Month;
import java.util.List;

public class MainApplication {

    public static void main(final String[] args) throws Exception {
        final BankStatementParser bankStatementParser = new BankStatementCSVParser();
        final Path path = Paths.get("src/main/resources/bank-data-simple.csv");
        final List<String> lines = Files.readAllLines(path);
        final List<BankTransaction> transactions = bankStatementParser.parseLinesFrom(lines);
        BankStatementProcessor statementProcessor = new BankStatementProcessor(transactions);

        //uso de la funcion findTransactions
        // Definir un filtro (ejemplo: transacciones con un monto mayor o igual a 100)
        BankTransactionFilter filter = transaction -> transaction.getAmount() >= 100;
        // Llamar al método findTransactions con el filtro definido
        List<BankTransaction> filteredTransactions = statementProcessor.findTransactions(filter);
        // Imprimir los detalles de las transacciones filtradas
        System.out.println("Transacciones con monto mayores a 100");
        for (BankTransaction transaction : filteredTransactions) {
            System.out.println("Transacción encontrada: " + transaction);
        }
        System.out.println("-----------");

        Month monthToFilter = Month.FEBRUARY;
        // Definir el filtro para encontrar transacciones en el mes especificado
        BankTransactionFilter filter2 = transaction -> transaction.getDate().getMonth() == monthToFilter;
        // Llamar al método findTransactions con el filtro definido
        List<BankTransaction> transactionsInMonth = statementProcessor.findTransactions(filter2);
        // Imprimir los detalles de las transacciones encontradas
        System.out.println("Transacciones en " + monthToFilter + ":");
        for (BankTransaction transaction : transactionsInMonth) {
            System.out.println(transaction);
        }
        System.out.println("-----------");

        final BankStatementAnalyzer bankStatementAnalyzer = new BankStatementAnalyzer();
        final Exporter exporter = new HtmlExporter();
        System.out.println("Resumen de estadisticas en formato Html");
        //exporta resumen de resultados en formato Html
        bankStatementAnalyzer.analyze("bank-data-simple.csv", bankStatementParser, exporter);
        System.out.println("-----------");

        //exporta resumen de resultados en formato xml
        System.out.println("Resumen de estadisticas en formato xml");
        final Exporter exporter2 = new xmlExporter();
        bankStatementAnalyzer.analyze("bank-data-simple.csv", bankStatementParser, exporter2);
        System.out.println("-----------");

        //exporta resumen de resultados en formato json
        System.out.println("Resumen de estadisticas en formato json");
        final Exporter exporter3 = new jsonExporter();
        bankStatementAnalyzer.analyze("bank-data-simple.csv", bankStatementParser, exporter3);

        //abre la vista
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUIBankStatementAnalyzer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> {
            GUIBankStatementAnalyzer frame = new GUIBankStatementAnalyzer(); // Crear una instancia de GUIBankStatementAnalyzer
            frame.setVisible(true); // Hacer visible la instancia creada
        });
    }
}
