public class xmlExporter implements Exporter {

	@Override
	public String export(SummaryStatistics summaryStatistics) {
		 String result = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
	        result += "<xml>";
	        result += "<root>";
	        result += "<elemento1>The sum is: " + summaryStatistics.getSum() + "</>";
	        result += "<elemento2>The average is: " + summaryStatistics.getAverage() + "</elemento2>";
	        result += "<elemento3>The max is: " + summaryStatistics.getMax() + "</elemento3>";
	        result += "<elemento1>The min is: " + summaryStatistics.getMin() + "</elemento4>";
	        result += "<root>";
	        result += "</xml>";
	        return result;
		
	}
}


/*String result = "<!doctype xml>";
		
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
	      DocumentBuilder docBuilder = null;
		try {
			docBuilder = docFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      Document doc = docBuilder.newDocument();
	      Element rootElement = doc.createElement("root");
	      doc.appendChild(rootElement);
	      
	      //Primer elemento
	      Element elemento1 = doc.createElement("elemento1");
	      rootElement.appendChild(elemento1);
	      
	      //Se agrega un atributo al nodo elemento y su valor
	      Attr attr = doc.createAttribute("The sum is");
	      attr.setValue(""+summaryStatistics.getSum());
	      elemento1.setAttributeNode(attr);
	        
	      Element elemento2 = doc.createElement("elemento2");
	      elemento2.setTextContent("The average is"+summaryStatistics.getAverage());
	      rootElement.appendChild(elemento2);
	      
	      Element elemento3 = doc.createElement("elemento3");
	      elemento3.setTextContent("The max is"+summaryStatistics.getMax());
	      rootElement.appendChild(elemento3);
	      
	      Element elemento4 = doc.createElement("elemento4");
	      elemento4.setTextContent("The min is"+summaryStatistics.getMin());
	      rootElement.appendChild(elemento4);
	      
	      TransformerFactory transformerFactory = TransformerFactory.newInstance();
	      Transformer transformer = null;
		try {
			transformer = transformerFactory.newTransformer();
		} catch (TransformerConfigurationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	      DOMSource source = new DOMSource(doc);
	      StreamResult resultado = new StreamResult(new File("/ruta/prueba.xml"));
	      try {
			transformer.transform(source, resultado);
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
