package org.reglasDeNegocio;

import java.util.List;

public class Rule {
    private String name;
    private String description;
    private List<CompositeCondition> conditions;
    private Action action;
    private RulePriority priority;

    public Rule(String nombre, String descripcion, List<CompositeCondition> conditions, Action action, RulePriority priority) {
        this.name = nombre;
        this.description = descripcion;
        this.conditions = conditions;
        this.action = action;
        this.priority = priority;
    }

    public void perform(Facts facts) {
        // Evalúa todas las condiciones
        boolean allConditionsMet = conditions.stream().allMatch(condition -> condition.evaluate(facts));

        // Si todas las condiciones se cumplen, ejecuta la acción
        if (allConditionsMet) {
            action.execute(facts);
        }
    }

    public String getNombre() {
        return name;
    }

    public String getDescripcion() {
        return description;
    }

    public RulePriority getPriority () {
        return priority;
    }
}
