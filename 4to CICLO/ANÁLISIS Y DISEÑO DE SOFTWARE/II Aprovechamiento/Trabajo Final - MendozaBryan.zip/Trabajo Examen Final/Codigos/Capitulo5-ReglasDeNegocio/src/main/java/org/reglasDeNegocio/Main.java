package org.reglasDeNegocio;

public class Main {

    public static void main(final String...args) {
        var env = new Facts();

        final var businessRuleEngine = new BusinessRuleEngine(env);

        // Crear condiciones compuestas
        CompositeCondition condition1 = facts -> "CEO".equals(facts.getFact("jobTitle"));
        CompositeCondition condition2 = facts -> Integer.parseInt(facts.getFact("age")) > 30;

        // Crear reglas con diferentes prioridades
        final Rule ruleSendEmailToSalesWhenCEO =
                RuleBuilder.name("emailToSales").description("Envía un email al departamento de ventas")
                        .priority(RulePriority.HIGH)
                        .when(condition1).when(condition2)
                        .then(facts -> {
                            var name = facts.getFact("name");
                            System.out.println("Relevant customer!!!: " + name);
                        })
                        .getRule();

        final Rule ruleSendEmailToMarketingWhenCEO =
                RuleBuilder.name("emailToMarketing").description("Envía un email al departamento de marketing")
                        .priority(RulePriority.LOW)
                        .when(condition1)
                        .then(facts -> {
                            var name = facts.getFact("name");
                            System.out.println("Marketing: " + name);
                        })
                        .getRule();

        final Rule ruleSendEmailToHRWhenOlderThan30 =
                RuleBuilder.name("emailToHR").description("Envía un email al departamento de recursos humanos")
                        .priority(RulePriority.MEDIUM)
                        .when(condition2)
                        .then(facts -> {
                            var name = facts.getFact("name");
                            System.out.println("Older than 30: " + name);
                        })
                        .getRule();

        // Añadir reglas al motor de reglas
        businessRuleEngine.addRule(ruleSendEmailToSalesWhenCEO);
        businessRuleEngine.addRule(ruleSendEmailToMarketingWhenCEO);
        businessRuleEngine.addRule(ruleSendEmailToHRWhenOlderThan30);

        // Ejecutar el motor de reglas
        businessRuleEngine.run();
    }
}
