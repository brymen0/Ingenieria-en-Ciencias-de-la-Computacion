package org.reglasDeNegocio;

public interface CompositeCondition {
    boolean evaluate(Facts facts);
}
