package org.reglasDeNegocio;

@FunctionalInterface
interface Action{
    void execute(Facts facts);
}
