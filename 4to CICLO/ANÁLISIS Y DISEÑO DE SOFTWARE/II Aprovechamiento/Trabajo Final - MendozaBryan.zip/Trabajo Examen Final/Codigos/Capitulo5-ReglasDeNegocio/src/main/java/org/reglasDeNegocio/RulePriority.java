package org.reglasDeNegocio;

public enum RulePriority {
    LOW, MEDIUM, HIGH
}
