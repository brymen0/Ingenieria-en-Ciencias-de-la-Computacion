package org.reglasDeNegocio;

import java.util.ArrayList;
import java.util.List;

public class RuleBuilder {
    private List<CompositeCondition> conditions = new ArrayList<>();
    private Action action;
    private String name;
    private String description;
    private RulePriority priority = RulePriority.MEDIUM; // Prioridad predeterminada

    private RuleBuilder(String name) {
        this.name = name;
    }
    
    public static RuleBuilder name (String name) {
        return new RuleBuilder(name);
    }

    public RuleBuilder description (String description) {
        this.description = description;
        return this;
    }

    public RuleBuilder priority(RulePriority priority) {
        this.priority = priority;
        return this;
    }

    public RuleBuilder when(CompositeCondition condition) {
        this.conditions.add(condition);
        return this;
    }

    public RuleBuilder then(Action action) {
        this.action = action;
        return this;
    }

    public Rule getRule () {
        // Verifica que se hayan proporcionado nombre, descripción, al menos una condición y una acción
        if (name == null || description == null || conditions.isEmpty() || action == null) {
            throw new IllegalStateException("Incomplete rule configuration");
        }

        return new Rule(name, description, conditions, action, priority);
    }
}