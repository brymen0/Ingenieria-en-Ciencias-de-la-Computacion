package org.reglasDeNegocio;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Facts {
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Map<String, String> facts = new HashMap<>();

    public Facts () {
        loadFromJson("src\\main\\resources\\data.json");
    }

    public String getFact(String name) {
        return this.facts.get(name);
    }

    public void setFact(String name, String value) {
        this.facts.put(name, value);
    }

    public void loadFromJson(String filePath) {
        try {
            // Lee el archivo JSON y carga los datos en el mapa de hechos
            File file = new File(filePath);
            Map<String, String> loadedData = objectMapper.readValue(file, HashMap.class);

            if (loadedData != null) {
                // Agrega los datos al mapa de hechos existente
                this.facts.putAll(loadedData);
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
