package org.reglasDeNegocio;

@FunctionalInterface
public interface Condition {

    boolean evaluate(Facts facts);
}
