package org.reglasDeNegocio;

public enum Stage {
    LEAD, INTERESTED, EVALUATING, CLOSED
}
