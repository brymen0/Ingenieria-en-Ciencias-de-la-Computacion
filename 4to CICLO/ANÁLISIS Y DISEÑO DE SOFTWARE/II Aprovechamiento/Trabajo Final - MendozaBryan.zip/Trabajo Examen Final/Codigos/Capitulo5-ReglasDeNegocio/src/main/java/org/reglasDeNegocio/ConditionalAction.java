package org.reglasDeNegocio;

public interface ConditionalAction {
    void perform(Facts facts);
    boolean evaluate(Facts facts);

}
