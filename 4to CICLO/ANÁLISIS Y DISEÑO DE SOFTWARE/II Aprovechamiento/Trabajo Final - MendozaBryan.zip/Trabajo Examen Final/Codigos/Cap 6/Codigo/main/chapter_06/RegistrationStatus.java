package com.iteratrlearning.shu_book.chapter_06;

public enum RegistrationStatus {
    SUCCESS,
    DUPLICATE
}
