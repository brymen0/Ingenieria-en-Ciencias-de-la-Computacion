package com.iteratrlearning.shu_book.chapter_06;

public enum DeleteStatus {
    SUCCESS,
    UNKNOWN_TWOOT,
    NOT_YOUR_TWOOT,
}
