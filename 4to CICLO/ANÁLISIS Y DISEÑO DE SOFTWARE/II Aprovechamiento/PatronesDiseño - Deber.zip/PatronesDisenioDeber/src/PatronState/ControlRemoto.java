package PatronState;

public class ControlRemoto { //contexto
    private EstadoTV estado;

    public ControlRemoto() {
        estado = new TVApagada(); // Inicia con la TV apagada
    }

    public void setEstado(EstadoTV estado) {
        this.estado = estado;
    }

    public void presionarBotonEncender() {
        estado.encender();
        setEstado(new TVEncendida());
    }

    public void presionarBotonApagar() {
        estado.apagar();
        setEstado(new TVApagada());
    }
}
