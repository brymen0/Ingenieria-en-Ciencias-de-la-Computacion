package PatronState;

public class TVApagada implements EstadoTV{
    @Override
    public void encender() {
        System.out.println("Encendiendo la TV");
    }

    @Override
    public void apagar() {
        System.out.println("La TV ya está apagada");
    }
}
