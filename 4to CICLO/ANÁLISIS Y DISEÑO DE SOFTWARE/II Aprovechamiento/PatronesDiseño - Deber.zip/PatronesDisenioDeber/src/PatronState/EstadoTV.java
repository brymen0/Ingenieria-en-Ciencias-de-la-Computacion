package PatronState;

public interface EstadoTV {
    void encender();
    void apagar();
}
