package PatronState;

public class TVEncendida implements EstadoTV{
    @Override
    public void encender() {
        System.out.println("La TV ya está encendida");
    }

    @Override
    public void apagar() {
        System.out.println("Apagando la TV");
    }
}
