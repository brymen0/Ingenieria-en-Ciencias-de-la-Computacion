package PatronState;

public class mainState {
    public static void main(String[] args) {
        ControlRemoto controlRemoto = new ControlRemoto();//contexto

        // Operaciones con el control remoto
        controlRemoto.presionarBotonEncender();
        controlRemoto.presionarBotonApagar();
        controlRemoto.presionarBotonApagar();
        controlRemoto.presionarBotonEncender();
    }
}
