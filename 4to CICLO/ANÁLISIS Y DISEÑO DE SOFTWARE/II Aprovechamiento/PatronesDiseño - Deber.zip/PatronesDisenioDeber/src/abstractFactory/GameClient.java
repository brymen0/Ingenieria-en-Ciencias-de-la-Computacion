package abstractFactory;

public class GameClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Seleccionar la fábrica del nivel fácil
        GameLevelFactory easyFactory = new EasyLevelFactory();
        Enemy easyEnemy = easyFactory.createEnemy();
        Obstacle easyObstacle = easyFactory.createObstacle();

        // Utilizar los productos del nivel fácil
        easyEnemy.attack();
        easyObstacle.block();

        System.out.println("----------------------");

        // Seleccionar la fábrica del nivel difícil
        GameLevelFactory hardFactory = new HardLevelFactory();
        Enemy hardEnemy = hardFactory.createEnemy();
        Obstacle hardObstacle = hardFactory.createObstacle();

        // Utilizar los productos del nivel difícil
        hardEnemy.attack();
        hardObstacle.block();
	}

}
