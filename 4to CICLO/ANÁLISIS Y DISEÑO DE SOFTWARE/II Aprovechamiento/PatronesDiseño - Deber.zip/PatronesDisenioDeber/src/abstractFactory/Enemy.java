package abstractFactory;

public interface Enemy {
	void attack();
}
