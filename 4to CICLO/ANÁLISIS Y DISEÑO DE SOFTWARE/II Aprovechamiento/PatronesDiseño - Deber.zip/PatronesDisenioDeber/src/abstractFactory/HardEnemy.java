package abstractFactory;

public class HardEnemy implements Enemy {
	@Override
    public void attack() {
        System.out.println("Hard enemy attacks fiercely!");
    }
}
