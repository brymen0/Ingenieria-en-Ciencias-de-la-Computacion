package abstractFactory;

public interface GameLevelFactory {
	Enemy createEnemy();
	Obstacle createObstacle();
}
