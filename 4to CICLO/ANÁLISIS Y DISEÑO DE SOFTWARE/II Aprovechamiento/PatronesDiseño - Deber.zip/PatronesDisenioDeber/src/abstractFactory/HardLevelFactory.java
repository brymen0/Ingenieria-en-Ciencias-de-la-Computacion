package abstractFactory;

public class HardLevelFactory implements GameLevelFactory {
	@Override
    public Enemy createEnemy() {
        return new HardEnemy();
    }

    @Override
    public Obstacle createObstacle() {
        return new HardObstacle();
    }
}
