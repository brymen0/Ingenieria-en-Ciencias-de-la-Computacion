package abstractFactory;

public class EasyLevelFactory implements GameLevelFactory {
	@Override
    public Enemy createEnemy() {
        return new EasyEnemy();
    }

    @Override
    public Obstacle createObstacle() {
        return new EasyObstacle();
    }
}
