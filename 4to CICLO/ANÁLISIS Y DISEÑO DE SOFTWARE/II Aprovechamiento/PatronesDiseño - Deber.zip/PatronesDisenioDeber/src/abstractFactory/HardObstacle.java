package abstractFactory;

public class HardObstacle implements Obstacle {
	@Override
    public void block() {
        System.out.println("Hard obstacle presents a significant challenge!");
    }
}
