package abstractFactory;

public interface Obstacle {
	void block ();
}
