package abstractFactory;

public class EasyEnemy implements Enemy {
	@Override
    public void attack() {
        System.out.println("Easy enemy attacks!");
    }
}
