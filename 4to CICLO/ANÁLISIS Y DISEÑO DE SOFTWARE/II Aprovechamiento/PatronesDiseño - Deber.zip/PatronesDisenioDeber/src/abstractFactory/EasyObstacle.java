package abstractFactory;

public class EasyObstacle implements Obstacle {
	@Override
    public void block() {
        System.out.println("Easy obstacle blocks the way!");
    }
}
