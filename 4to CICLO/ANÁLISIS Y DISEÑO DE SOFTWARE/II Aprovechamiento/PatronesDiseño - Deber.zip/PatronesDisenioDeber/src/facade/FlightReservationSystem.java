package facade;

//Subsistema para la gestión de reservas de vuelos
public class FlightReservationSystem {
	public void reserveFlight(String flightNumber, int seatsReserved) {
        // Lógica de reserva de vuelo
        System.out.println("Reservando " + seatsReserved + " asientos para el vuelo " + flightNumber);
    }
}
