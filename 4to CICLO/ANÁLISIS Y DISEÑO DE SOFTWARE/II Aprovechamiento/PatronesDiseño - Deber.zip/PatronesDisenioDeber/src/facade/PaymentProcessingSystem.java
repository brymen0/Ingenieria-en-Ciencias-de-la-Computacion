package facade;

//Subsistema para el procesamiento de pagos
public class PaymentProcessingSystem {
	public void processPayment(String creditCardNumber, double amount) {
        // Lógica de procesamiento de pagos
        System.out.println("Procesando pago de $" + amount + " con la tarjeta " + creditCardNumber);
    }
}
