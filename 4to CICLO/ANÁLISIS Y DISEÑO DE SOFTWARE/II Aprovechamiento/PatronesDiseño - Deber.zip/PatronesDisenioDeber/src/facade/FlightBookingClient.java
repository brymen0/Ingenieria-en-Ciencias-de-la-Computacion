package facade;

//Cliente que utiliza el Patrón Facade
public class FlightBookingClient {
	public static void main(String[] args) {
        // Crear la fachada del sistema de reservas de vuelos
        FlightBookingFacade bookingFacade = new FlightBookingFacade();

        // Cliente realiza la reserva utilizando la interfaz unificada
        bookingFacade.bookFlight("ABC123", 2, "1234-5678-9012");
    }
}
