package facade;

//Subsistema para la verificación de disponibilidad de vuelos
public class FlightAvailabilitySystem {
	public boolean checkAvailability(String flightNumber, int seatsNeeded) {
        // Lógica de verificación de disponibilidad
        System.out.println("Verificación de disponibilidad para el vuelo " + flightNumber);
        return seatsNeeded <= 50; // Simulación de disponibilidad
    }
}
