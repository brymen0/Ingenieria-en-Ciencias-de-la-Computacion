package facade;

//Facade que proporciona una interfaz unificada para el sistema de reservas de vuelos
public class FlightBookingFacade {
	private FlightAvailabilitySystem availabilitySystem;
    private FlightReservationSystem reservationSystem;
    private PaymentProcessingSystem paymentSystem;

    public FlightBookingFacade() {
        this.availabilitySystem = new FlightAvailabilitySystem();
        this.reservationSystem = new FlightReservationSystem();
        this.paymentSystem = new PaymentProcessingSystem();
    }

    // Método unificado para realizar todo el proceso de reserva
    public void bookFlight(String flightNumber, int seatsNeeded, String creditCardNumber) {
        // Verificar disponibilidad
        if (availabilitySystem.checkAvailability(flightNumber, seatsNeeded)) {
            // Realizar reserva
            reservationSystem.reserveFlight(flightNumber, seatsNeeded);

            // Procesar pago
            double totalAmount = calculateTotalAmount(seatsNeeded);
            paymentSystem.processPayment(creditCardNumber, totalAmount);

            System.out.println("Reserva completada con éxito para el vuelo " + flightNumber);
        } else {
            System.out.println("No hay disponibilidad para el vuelo " + flightNumber);
        }
    }

    private double calculateTotalAmount(int seatsReserved) {
        // Lógica para calcular el monto total basado en la cantidad de asientos reservados
        return seatsReserved * 100.0; // Precio ficticio por asiento
    }
}
