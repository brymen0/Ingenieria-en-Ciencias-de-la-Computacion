package PatronVisitor;

public interface Elemento {
    void aceptar(Visitor visitor);
}
