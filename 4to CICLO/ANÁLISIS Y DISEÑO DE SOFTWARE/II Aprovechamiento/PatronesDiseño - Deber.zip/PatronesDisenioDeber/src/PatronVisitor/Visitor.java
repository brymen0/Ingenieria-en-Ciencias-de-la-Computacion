package PatronVisitor;

public interface Visitor {
    void visitarCirculo(Circulo circulo);
    void visitarCuadrado(Cuadrado cuadrado);
}
