package PatronVisitor;

public class mainVisitor {
    public static void main(String[] args) {
        Elemento circulo = new Circulo(5);
        Elemento cuadrado = new Cuadrado(4);

        Visitor calculadora = new CalculadoraAreaPerimetro();

        circulo.aceptar(calculadora);
        cuadrado.aceptar(calculadora);
    }
}
