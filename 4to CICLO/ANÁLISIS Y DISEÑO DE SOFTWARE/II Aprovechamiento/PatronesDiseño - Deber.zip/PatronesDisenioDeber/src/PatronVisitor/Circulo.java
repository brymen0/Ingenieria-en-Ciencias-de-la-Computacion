package PatronVisitor;

public class Circulo implements Elemento{
    private double radio;

    public Circulo(double radio) {
        this.radio = radio;
    }

    public double getRadio() {
        return radio;
    }

    @Override
    public void aceptar(Visitor visitor) {
        visitor.visitarCirculo(this);
    }
}
