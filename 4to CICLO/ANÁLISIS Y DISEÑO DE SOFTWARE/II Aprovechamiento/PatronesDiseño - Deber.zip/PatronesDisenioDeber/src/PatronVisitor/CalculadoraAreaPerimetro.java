package PatronVisitor;

public class CalculadoraAreaPerimetro implements Visitor{
    @Override
    public void visitarCirculo(Circulo circulo) {
        double area = Math.PI * circulo.getRadio() * circulo.getRadio();
        double perimetro = 2 * Math.PI * circulo.getRadio();
        System.out.println("Círculo - Área: " + area + ", Perímetro: " + perimetro);
    }

    @Override
    public void visitarCuadrado(Cuadrado cuadrado) {
        double area = cuadrado.getLado() * cuadrado.getLado();
        double perimetro = 4 * cuadrado.getLado();
        System.out.println("Cuadrado - Área: " + area + ", Perímetro: " + perimetro);
    }
}
