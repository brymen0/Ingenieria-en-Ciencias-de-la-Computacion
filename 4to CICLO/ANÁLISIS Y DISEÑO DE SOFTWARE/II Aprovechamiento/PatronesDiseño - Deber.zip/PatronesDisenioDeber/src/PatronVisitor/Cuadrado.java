package PatronVisitor;

public class Cuadrado implements Elemento{
    private double lado;

    public Cuadrado(double lado) {
        this.lado = lado;
    }

    public double getLado() {
        return lado;
    }

    @Override
    public void aceptar(Visitor visitor) {
        visitor.visitarCuadrado(this);
    }
}
