package PatronProxy;

public class MainProxy {

    public static void main(String[] args) {
        Imagen imagen = new ProxyImagen("foto1.jpg");
        imagen.mostrar();// La imagen real se carga y muestra solo cuando es necesario
        imagen.mostrar();// La segunda vez, la imagen real ya está cargada y se muestra directamente desde el proxy
    }

}
