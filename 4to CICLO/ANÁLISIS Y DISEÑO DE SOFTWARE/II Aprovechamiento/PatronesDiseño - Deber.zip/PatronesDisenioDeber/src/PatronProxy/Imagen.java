package PatronProxy;

public interface Imagen {
    void mostrar();
}
