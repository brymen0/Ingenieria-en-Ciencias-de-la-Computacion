package PatronProxy;

public class ImagenReal implements Imagen{
    private String nombreArchivo;

    public ImagenReal(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
        cargarImagenDesdeDisco();
    }

    private void cargarImagenDesdeDisco() {
        System.out.println("Cargando imagen desde el disco: " + nombreArchivo);
    }

    @Override
    public void mostrar() {
        System.out.println("Mostrando imagen: " + nombreArchivo);
    }
}
