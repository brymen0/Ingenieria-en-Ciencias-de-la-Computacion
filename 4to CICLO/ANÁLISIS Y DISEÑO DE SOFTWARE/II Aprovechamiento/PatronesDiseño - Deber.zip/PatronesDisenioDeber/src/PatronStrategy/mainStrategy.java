package PatronStrategy;

public class mainStrategy {
    public static void main(String[] args) {
        Animal pato = new Animal();
        pato.setComportamientoVuelo(new VuelaConAlas());
        System.out.print("Pato: ");
        pato.realizarVuelo();

        Animal avion = new Animal();
        avion.setComportamientoVuelo(new VueloPlaneado());
        System.out.print("Avion: ");
        avion.realizarVuelo();

        Animal pingüino = new Animal();
        pingüino.setComportamientoVuelo(new VueloNoPuedeVolar());
        System.out.print("Pinguino: ");
        pingüino.realizarVuelo();
    }
}
