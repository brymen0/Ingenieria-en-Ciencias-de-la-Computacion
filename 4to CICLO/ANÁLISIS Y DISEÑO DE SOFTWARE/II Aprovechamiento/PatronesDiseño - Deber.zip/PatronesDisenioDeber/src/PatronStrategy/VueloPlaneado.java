package PatronStrategy;

public class VueloPlaneado implements ComportamientoVuelo{
    @Override
    public void volar() {
        System.out.println("Volando planeado");
    }
}
