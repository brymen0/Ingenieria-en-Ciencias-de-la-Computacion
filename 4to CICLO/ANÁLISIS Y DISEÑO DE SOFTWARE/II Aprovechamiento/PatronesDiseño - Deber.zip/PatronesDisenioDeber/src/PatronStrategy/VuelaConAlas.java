package PatronStrategy;

public class VuelaConAlas implements ComportamientoVuelo{
    @Override
    public void volar() {
        System.out.println("Volando con alas");
    }
}
