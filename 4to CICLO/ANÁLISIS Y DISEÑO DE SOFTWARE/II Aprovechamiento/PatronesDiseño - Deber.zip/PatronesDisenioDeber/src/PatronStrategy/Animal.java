package PatronStrategy;

public class Animal {
    private ComportamientoVuelo comportamientoVuelo;

    public void setComportamientoVuelo(ComportamientoVuelo comportamientoVuelo) {
        this.comportamientoVuelo = comportamientoVuelo;
    }

    public void realizarVuelo() {
        comportamientoVuelo.volar();
    }
}
