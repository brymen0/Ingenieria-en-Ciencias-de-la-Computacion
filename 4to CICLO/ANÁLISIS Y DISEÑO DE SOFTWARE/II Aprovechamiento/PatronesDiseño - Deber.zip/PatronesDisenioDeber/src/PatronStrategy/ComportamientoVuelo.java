package PatronStrategy;

public interface ComportamientoVuelo {
    void volar();
}
