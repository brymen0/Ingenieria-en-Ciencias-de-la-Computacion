package PatronStrategy;

public class VueloNoPuedeVolar implements ComportamientoVuelo{
    @Override
    public void volar() {
        System.out.println("No puede volar");
    }
}
