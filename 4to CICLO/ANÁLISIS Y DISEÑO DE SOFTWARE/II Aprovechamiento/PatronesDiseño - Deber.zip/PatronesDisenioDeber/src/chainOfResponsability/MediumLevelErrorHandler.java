package chainOfResponsability;

//Implementación concreta del manejador de errores para errores de nivel medio
public class MediumLevelErrorHandler extends BaseErrorHandler {
	@Override
    protected boolean canHandleError(Error error) {
        return error.getDescription().toLowerCase().contains("medio");
    }

    @Override
    protected void handle(Error error) {
        System.out.println("Manejador de errores de nivel medio: " + error.getDescription());
    }
}
