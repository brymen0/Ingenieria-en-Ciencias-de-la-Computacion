package chainOfResponsability;

public class ErrorHandlerClient {
	public static void main(String[] args) {
        // Configurando la cadena de manejadores de errores
        ErrorHandler lowLevelHandler = new LowLevelErrorHandler();
        ErrorHandler mediumLevelHandler = new MediumLevelErrorHandler();
        ErrorHandler highLevelHandler = new HighLevelErrorHandler();

        lowLevelHandler.setNextHandler(mediumLevelHandler);
        mediumLevelHandler.setNextHandler(highLevelHandler);

        // Simulando errores
        Error lowError = new Error("Error de nivel bajo");
        Error mediumError = new Error("Error de nivel medio");
        Error highError = new Error("Error de nivel alto");

        // Manejando los errores
        lowLevelHandler.handleRequest(lowError);
        lowLevelHandler.handleRequest(mediumError);
        lowLevelHandler.handleRequest(highError);
    }
}
