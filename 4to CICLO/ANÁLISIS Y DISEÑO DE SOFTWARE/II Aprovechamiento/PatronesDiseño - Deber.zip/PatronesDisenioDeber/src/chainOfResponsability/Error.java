package chainOfResponsability;

//Clase base para representar un error
public class Error {
	 private String description;

	    public Error(String description) {
	        this.description = description;
	    }

	    public String getDescription() {
	        return description;
	    }
}
