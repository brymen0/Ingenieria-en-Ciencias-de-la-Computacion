package chainOfResponsability;

//Interfaz del manejador de errores
public interface ErrorHandler {
	void handleRequest(Error error);

    void setNextHandler(ErrorHandler nextHandler);
}
