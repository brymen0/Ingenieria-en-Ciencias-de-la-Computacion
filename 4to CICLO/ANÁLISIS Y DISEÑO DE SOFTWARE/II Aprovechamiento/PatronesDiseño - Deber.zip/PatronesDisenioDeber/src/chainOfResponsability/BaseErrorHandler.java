package chainOfResponsability;

//Implementación base del manejador de errores
public abstract class BaseErrorHandler implements ErrorHandler {
	private ErrorHandler nextHandler;

    @Override
    public void setNextHandler(ErrorHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    @Override
    public void handleRequest(Error error) {
        if (canHandleError(error)) {
            handle(error);
        } else if (nextHandler != null) {
            nextHandler.handleRequest(error);
        } else {
            System.out.println("Error no manejado: " + error.getDescription());
        }
    }

    protected abstract boolean canHandleError(Error error);

    protected abstract void handle(Error error);
}
