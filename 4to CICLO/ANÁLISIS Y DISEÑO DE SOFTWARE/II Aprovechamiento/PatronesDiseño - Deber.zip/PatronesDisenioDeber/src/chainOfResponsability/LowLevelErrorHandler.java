package chainOfResponsability;

//Implementación concreta del manejador de errores para errores de nivel bajo
public class LowLevelErrorHandler extends BaseErrorHandler {
	@Override
    protected boolean canHandleError(Error error) {
        return error.getDescription().toLowerCase().contains("bajo");
    }

    @Override
    protected void handle(Error error) {
        System.out.println("Manejador de errores de nivel bajo: " + error.getDescription());
    }
}
