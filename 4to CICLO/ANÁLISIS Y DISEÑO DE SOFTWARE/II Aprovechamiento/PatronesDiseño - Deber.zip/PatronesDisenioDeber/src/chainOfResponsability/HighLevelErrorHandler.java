package chainOfResponsability;

//Implementación concreta del manejador de errores para errores de nivel alto
public class HighLevelErrorHandler extends BaseErrorHandler {
	@Override
    protected boolean canHandleError(Error error) {
        return error.getDescription().toLowerCase().contains("alto");
    }

    @Override
    protected void handle(Error error) {
        System.out.println("Manejador de errores de nivel alto: " + error.getDescription());
    }
}
