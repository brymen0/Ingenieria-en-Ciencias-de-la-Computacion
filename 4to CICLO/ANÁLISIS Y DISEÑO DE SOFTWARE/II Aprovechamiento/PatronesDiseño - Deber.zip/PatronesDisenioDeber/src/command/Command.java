package command;

//Interfaz Command que representa una acción del jugador
public interface Command {
	void execute ();
}
