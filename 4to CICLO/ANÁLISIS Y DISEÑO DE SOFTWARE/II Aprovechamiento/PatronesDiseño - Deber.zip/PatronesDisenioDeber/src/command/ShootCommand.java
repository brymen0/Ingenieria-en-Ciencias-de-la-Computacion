package command;

//Clase concreta que implementa el comando para la acción de disparar
public class ShootCommand implements Command {
	@Override
    public void execute() {
        System.out.println("Disparando");
    }
}
