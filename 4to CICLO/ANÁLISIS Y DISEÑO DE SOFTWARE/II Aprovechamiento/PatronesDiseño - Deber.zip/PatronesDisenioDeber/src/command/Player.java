package command;

import java.util.HashMap;
import java.util.Map;

//Clase Invoker que ejecuta los comandos
public class Player {
	 private Map<String, Command> commandMap = new HashMap<>();

	 public void setCommand(String key, Command command) {
	     commandMap.put(key, command);
	 }

	 public void pressButton(String key) {
	     if (commandMap.containsKey(key)) {
	         commandMap.get(key).execute();
	     } else {
	         System.out.println("Tecla no asignada");
	     }
	 }
}
