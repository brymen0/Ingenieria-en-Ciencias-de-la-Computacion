package command;

//Clase concreta que implementa el comando para la acción de saltar
public class JumpCommand implements Command {
	@Override
    public void execute() {
        System.out.println("Saltando");
    }
}
