package command;

//Cliente que utiliza el Patrón Command
public class GameClient {
	public static void main(String[] args) {
        // Creando comandos para las acciones del jugador
        Command moveCommand = new MoveCommand();
        Command jumpCommand = new JumpCommand();
        Command shootCommand = new ShootCommand();

        // Creando el jugador y asignando comandos a teclas
        Player player = new Player();
        player.setCommand("W", moveCommand);
        player.setCommand("Space", jumpCommand);
        player.setCommand("MouseLeft", shootCommand);

        // Simulando la pulsación de teclas
        player.pressButton("W"); // Moverse
        player.pressButton("Space"); // Saltar
        player.pressButton("A"); // Tecla no asignada
        player.pressButton("MouseLeft"); // Disparar
    }
}
