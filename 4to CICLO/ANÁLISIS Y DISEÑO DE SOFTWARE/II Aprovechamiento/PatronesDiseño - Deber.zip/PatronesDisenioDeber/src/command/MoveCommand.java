package command;

//Clase concreta que implementa el comando para la acción de moverse
public class MoveCommand implements Command {
	@Override
    public void execute() {
        System.out.println("Moviendo al jugador");
    }
}
