package PatronFactory;

public class AnimalFactory {
    Animal crearAnimal (String animalT) {
        Animal animal = null;
        if (animalT.equalsIgnoreCase("perro")) {
            animal = new Perro ();
            System.out.println("Animal: Perro creado");
        } else if (animalT.equalsIgnoreCase("vaca")) {
            animal = new Vaca ();
            System.out.println("Animal: Vaca creado");
        }
        return animal;
    }
}
