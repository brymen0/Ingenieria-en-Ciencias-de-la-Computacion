package PatronFactory;

public class Perro implements Animal{
    @Override
    public void hablar() {
        System.out.println("El perro hace Guaff");
    }
}
