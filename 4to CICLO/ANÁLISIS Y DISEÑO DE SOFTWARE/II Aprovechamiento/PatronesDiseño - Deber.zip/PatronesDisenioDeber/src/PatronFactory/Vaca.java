package PatronFactory;

public class Vaca implements Animal{
    @Override
    public void hablar() {
        System.out.println("La vaca hace Muuuuu");
    }
}
