package PatronFactory;

public interface Animal {
    void hablar();
}
