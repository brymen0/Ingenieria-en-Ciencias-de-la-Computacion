package PatronFactory;

public class MainFactory {
    public static void main(String[]args){
        AnimalFactory factory = new AnimalFactory();
        Perro perro = (Perro) factory.crearAnimal("perro");
        perro.hablar();
        Vaca vaca = (Vaca) factory.crearAnimal("vaca");
        vaca.hablar();
    }
}
