package bridge;

//Abstracción: Representa las entidades y la lógica del juego
public interface Game {
	void initialize();
    void update();
    void render();
}
