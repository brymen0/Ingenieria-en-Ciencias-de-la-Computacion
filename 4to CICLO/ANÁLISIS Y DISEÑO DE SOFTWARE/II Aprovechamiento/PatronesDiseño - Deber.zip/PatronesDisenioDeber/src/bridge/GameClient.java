package bridge;

//Cliente que utiliza el juego y la engine gráfica
public class GameClient {
	public static void main(String[] args) {
        // Utilizando una implementación específica de la engine gráfica
        GraphicsEngine graphicsEngine = new SimpleGraphicsEngine();

        // Creando el juego utilizando la abstracción y el Bridge
        Game simpleGame = new SimpleGame(graphicsEngine);

        // Interactuando con el juego
        simpleGame.initialize();
        simpleGame.update();
        simpleGame.render();

        // Limpiando recursos
        graphicsEngine.cleanup();
    }
}
