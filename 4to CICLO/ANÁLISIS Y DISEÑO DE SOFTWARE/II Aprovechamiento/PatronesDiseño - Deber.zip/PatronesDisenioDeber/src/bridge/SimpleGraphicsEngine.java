package bridge;

//Clase que implementa la implementación utilizando el Bridge
public class SimpleGraphicsEngine implements GraphicsEngine {
	@Override
    public void renderEntity(Entity entity) {
        System.out.println("Renderizando entidad: " + entity.getName());
    }

    @Override
    public void renderBackground(String background) {
        System.out.println("Renderizando fondo: " + background);
    }

    @Override
    public void cleanup() {
        System.out.println("Limpiando recursos de la engine gráfica simple");
    }
}
