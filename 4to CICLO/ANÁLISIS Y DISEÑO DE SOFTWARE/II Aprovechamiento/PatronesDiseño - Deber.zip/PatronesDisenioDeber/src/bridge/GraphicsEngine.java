package bridge;

//Implementación: Define cómo se renderizan los gráficos y se gestionan los recursos del hardware
public interface GraphicsEngine {
	void renderEntity(Entity entity);
    void renderBackground(String background);
    void cleanup();
}
