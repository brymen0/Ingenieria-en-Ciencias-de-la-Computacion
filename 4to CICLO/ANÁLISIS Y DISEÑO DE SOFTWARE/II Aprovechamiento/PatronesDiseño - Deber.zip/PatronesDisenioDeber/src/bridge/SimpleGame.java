package bridge;

//Clase que implementa la abstracción utilizando el Bridge
public class SimpleGame implements Game {
	private GraphicsEngine graphicsEngine;

    public SimpleGame(GraphicsEngine graphicsEngine) {
        this.graphicsEngine = graphicsEngine;
    }

    @Override
    public void initialize() {
        System.out.println("Inicializando el juego simple");
    }

    @Override
    public void update() {
        System.out.println("Actualizando el estado del juego simple");
    }

    @Override
    public void render() {
        System.out.println("Renderizando el juego simple");
        Entity player = new Entity("Player");
        graphicsEngine.renderEntity(player);
        graphicsEngine.renderBackground("Simple Background");
    }
}
