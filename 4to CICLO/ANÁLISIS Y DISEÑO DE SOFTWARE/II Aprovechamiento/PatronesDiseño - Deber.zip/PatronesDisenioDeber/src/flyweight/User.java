package flyweight;

//Interfaz Flyweight que define las operaciones comunes para los usuarios
public interface User {
	void displayInfo();
}
