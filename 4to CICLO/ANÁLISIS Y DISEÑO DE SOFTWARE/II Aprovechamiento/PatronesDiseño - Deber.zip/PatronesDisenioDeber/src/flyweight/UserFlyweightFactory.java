package flyweight;

import java.util.HashMap;
import java.util.Map;

//Factory Flyweight que gestiona y crea instancias de usuarios
public class UserFlyweightFactory {
	private Map<String, User> userFlyweights;

    public UserFlyweightFactory() {
        this.userFlyweights = new HashMap<>();
    }

    public User getUser(String username, String defaultRole) {
        // Verificar si ya existe un usuario con el mismo rol
        if (!userFlyweights.containsKey(defaultRole)) {
            // Si no existe, crear un nuevo usuario y almacenarlo en el mapa
            User newUser = new ConcreteUser(username, defaultRole);
            userFlyweights.put(defaultRole, newUser);
        }

        // Devolver la instancia del usuario existente o recién creado
        return userFlyweights.get(defaultRole);
    }
}
