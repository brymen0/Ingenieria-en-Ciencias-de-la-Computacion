package flyweight;

//Cliente que utiliza el Patrón Flyweight
public class UserManegementClient {
	public static void main(String[] args) {
        // Crear la fábrica Flyweight
        UserFlyweightFactory userFactory = new UserFlyweightFactory();

        // Crear varios usuarios con roles compartidos
        User user1 = userFactory.getUser("usuario1", "admin");
        User user2 = userFactory.getUser("usuario2", "user");
        User user3 = userFactory.getUser("usuario3", "admin");
        User user4 = userFactory.getUser("usuario4", "user");

        // Mostrar la información de los usuarios
        user1.displayInfo();
        user2.displayInfo();
        user3.displayInfo();
        user4.displayInfo();

        // Verificar si los usuarios comparten instancias Flyweight
        System.out.println("Usuarios 1 y 3 comparten la misma instancia: " + (user1 == user3));
    }
}
