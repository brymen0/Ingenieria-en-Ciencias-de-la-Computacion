package flyweight;

//Clase concreta Flyweight que implementa la interfaz User
public class ConcreteUser implements User {
	private String username;
    private String role;

    public ConcreteUser(String username, String role) {
        this.username = username;
        this.role = role;
    }

    @Override
    public void displayInfo() {
        System.out.println("Usuario: " + username + ", Rol: " + role);
    }
}
