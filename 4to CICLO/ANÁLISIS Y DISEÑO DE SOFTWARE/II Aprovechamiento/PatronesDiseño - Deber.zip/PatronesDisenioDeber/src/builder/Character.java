package builder;

//Clase que representa un personaje en un juego
public class Character {
	private String name;
    private int level;
    private String weapon;
    private String armor;

    public Character(String name, int level, String weapon, String armor) {
        this.name = name;
        this.level = level;
        this.weapon = weapon;
        this.armor = armor;
    }

    @Override
    public String toString() {
        return "Character{" +
                "name='" + name + '\'' +
                ", level=" + level +
                ", weapon='" + weapon + '\'' +
                ", armor='" + armor + '\'' +
                '}';
    }
}
