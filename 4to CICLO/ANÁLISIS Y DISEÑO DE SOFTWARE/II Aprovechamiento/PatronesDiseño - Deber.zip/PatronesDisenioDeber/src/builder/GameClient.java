package builder;

public class GameClient {
	public static void main(String[] args) {
        // Creando un personaje utilizando el Builder
        CharacterBuilder builder = new ConcreteCharacterBuilder();
        CharacterDirector director = new CharacterDirector(builder);
        Character character = director.createDefaultCharacter();

        // Mostrando el personaje creado
        System.out.println(character);
    }
}
