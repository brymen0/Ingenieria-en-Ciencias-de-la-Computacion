package builder;

//Interfaz del Builder que define los métodos para construir un personaje
public interface CharacterBuilder {
	CharacterBuilder setName(String name);
    CharacterBuilder setLevel(int level);
    CharacterBuilder setWeapon(String weapon);
    CharacterBuilder setArmor(String armor);
    Character build();
}
