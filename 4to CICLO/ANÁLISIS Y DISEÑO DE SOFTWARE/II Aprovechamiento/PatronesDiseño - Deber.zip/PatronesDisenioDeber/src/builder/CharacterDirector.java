package builder;

//Director que utiliza el Builder para construir un personaje con configuración predeterminada
public class CharacterDirector {
	private CharacterBuilder characterBuilder;

    public CharacterDirector(CharacterBuilder characterBuilder) {
        this.characterBuilder = characterBuilder;
    }

    public Character createDefaultCharacter() {
        return characterBuilder
                .setName("DefaultCharacter")
                .setLevel(1)
                .setWeapon("Sword")
                .setArmor("Leather Armor")
                .build();
    }
}
