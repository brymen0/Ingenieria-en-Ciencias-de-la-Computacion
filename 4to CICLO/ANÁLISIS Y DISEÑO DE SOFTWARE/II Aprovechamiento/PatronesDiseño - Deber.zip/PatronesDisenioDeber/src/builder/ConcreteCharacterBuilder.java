package builder;

//Implementación concreta del Builder
public class ConcreteCharacterBuilder implements CharacterBuilder {
	private String name;
    private int level;
    private String weapon;
    private String armor;

    @Override
    public CharacterBuilder setName(String name) {
        this.name = name;
        return this;
    }

    @Override
    public CharacterBuilder setLevel(int level) {
        this.level = level;
        return this;
    }

    @Override
    public CharacterBuilder setWeapon(String weapon) {
        this.weapon = weapon;
        return this;
    }

    @Override
    public CharacterBuilder setArmor(String armor) {
        this.armor = armor;
        return this;
    }

    @Override
    public Character build() {
        return new Character(name, level, weapon, armor);
    }
}
