package interpreter;

import java.util.Map;

//Cliente que utiliza el Patrón Interpreter
public class SearchClient {
	public static void main(String[] args) {
        // Crear un contexto con algunas variables de prueba
        Map<String, Boolean> variables = Map.of("keyword1", true, "keyword2", false, "keyword3", true);
        Context context = new Context(variables);

        // Crear una expresión compleja: keyword1 AND (keyword2 OR keyword3)
        Expression expression = new AndExpression(
            new VariableExpression("keyword1"),
            new OrExpression(
                new VariableExpression("keyword2"),
                new VariableExpression("keyword3")
            )
        );

        // Evaluar la expresión en el contexto
        boolean result = expression.interpret(context);

        // Imprimir el resultado
        System.out.println("Resultado de la expresión: " + result);
    }
}
