package interpreter;

//Interfaz para la interpretación de expresiones
public interface Expression {
	boolean interpret(Context context);
}
