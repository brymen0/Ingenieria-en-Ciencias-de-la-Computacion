package interpreter;

import java.util.Map;

//Contexto que almacena información de evaluación
public class Context {
	private Map<String, Boolean> variables;

    public Context(Map<String, Boolean> variables) {
        this.variables = variables;
    }

    public boolean getVariable(String name) {
        return variables.getOrDefault(name, false);
    }
}
