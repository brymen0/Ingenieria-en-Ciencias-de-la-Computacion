package PatronIterator;

public class mainIterator {
    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca(5);

        biblioteca.agregarLibro(new Libro("El alquimista"));
        biblioteca.agregarLibro(new Libro("La biblia"));
        biblioteca.agregarLibro(new Libro("IT"));

        Iterador iterador = biblioteca.crearIterador();

        while (iterador.hasNext()) {
            Libro libro = (Libro) iterador.siguiente();
            System.out.println("Libro: " + libro.getTitulo());
        }
    }
}
