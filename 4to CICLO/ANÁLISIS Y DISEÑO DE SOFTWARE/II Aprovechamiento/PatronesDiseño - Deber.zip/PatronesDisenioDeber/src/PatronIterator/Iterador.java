package PatronIterator;

public interface Iterador {
    boolean hasNext();
    Object siguiente();
}
