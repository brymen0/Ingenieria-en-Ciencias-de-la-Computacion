package PatronIterator;

public interface Agregado {
    Iterador crearIterador();
}
