package PatronIterator;

public class IteradorLibros implements Iterador{
    private Libro[] libros;
    private int posicionActual = 0;

    public IteradorLibros(Libro[] libros) {
        this.libros = libros;
    }

    @Override
    public boolean hasNext() {
        return posicionActual < libros.length && libros[posicionActual] != null;
    }

    @Override
    public Object siguiente() {
        Libro libro = libros[posicionActual];
        posicionActual++;
        return libro;
    }
}
