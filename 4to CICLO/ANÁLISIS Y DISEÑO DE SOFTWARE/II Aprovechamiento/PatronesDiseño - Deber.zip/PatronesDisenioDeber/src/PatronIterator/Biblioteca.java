package PatronIterator;

public class Biblioteca implements Agregado{
    private Libro[] libros;
    private int contadorLibros = 0;

    public Biblioteca(int capacidad) {
        libros = new Libro[capacidad];
    }

    public void agregarLibro(Libro libro) {
        if (contadorLibros < libros.length) {
            libros[contadorLibros] = libro;
            contadorLibros++;
        } else {
            System.out.println("La biblioteca está llena, no se puede agregar más libros.");
        }
    }

    @Override
    public Iterador crearIterador() {
        return new IteradorLibros(libros);
    }
}
