package adapter;

//Interfaz estándar para el sistema
public interface StandardPeripheral {
	void sendCommand (String command);
    String receiveResponse();
}
