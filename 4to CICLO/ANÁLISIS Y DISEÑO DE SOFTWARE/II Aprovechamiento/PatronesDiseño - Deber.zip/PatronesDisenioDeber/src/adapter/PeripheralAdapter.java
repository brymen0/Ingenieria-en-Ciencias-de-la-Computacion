package adapter;

//Adaptador que hace que un dispositivo periférico específico implemente la interfaz estándar
public class PeripheralAdapter implements StandardPeripheral {
	private SpecificPeripheral specificPeripheral;

    public PeripheralAdapter(SpecificPeripheral specificPeripheral) {
        this.specificPeripheral = specificPeripheral;
    }

    @Override
    public void sendCommand(String command) {
        System.out.println("Adaptando el comando estándar para el dispositivo específico");
        specificPeripheral.issueSpecificCommand();
    }

    @Override
    public String receiveResponse() {
        System.out.println("Adaptando la respuesta estándar para el dispositivo específico");
        specificPeripheral.processSpecificResponse();
        return "Respuesta adaptada";
    }
}
