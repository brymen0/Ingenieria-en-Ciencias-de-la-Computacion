package adapter;

//Interfaz específica del dispositivo periférico
public interface SpecificPeripheral {
	void issueSpecificCommand();
    void processSpecificResponse();
}
