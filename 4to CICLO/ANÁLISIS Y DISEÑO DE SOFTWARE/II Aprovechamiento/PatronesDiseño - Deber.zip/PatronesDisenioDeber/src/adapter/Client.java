package adapter;

public class Client {
	public static void main(String[] args) {
        // Usando el sistema con la interfaz estándar
        StandardPeripheral standardPeripheral = new StandardPeripheralImpl();
        standardPeripheral.sendCommand("Comando desde el sistema");
        standardPeripheral.receiveResponse();

        System.out.println("----------------------");

        // Usando el adaptador con un dispositivo periférico específico
        SpecificPeripheral specificPeripheral = new SpecificPeripheralImpl();
        StandardPeripheral adaptedPeripheral = new PeripheralAdapter(specificPeripheral);
        adaptedPeripheral.sendCommand("Comando desde el sistema adaptado");
        adaptedPeripheral.receiveResponse();
    }
}
