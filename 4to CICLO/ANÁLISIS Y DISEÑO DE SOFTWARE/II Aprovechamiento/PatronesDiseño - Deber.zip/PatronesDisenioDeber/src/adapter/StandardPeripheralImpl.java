package adapter;

//Clase concreta que implementa la interfaz estándar
public class StandardPeripheralImpl implements StandardPeripheral {
	@Override
    public void sendCommand(String command) {
        System.out.println("Enviando comando estándar: " + command);
    }

    @Override
    public String receiveResponse() {
        String response = "Respuesta estándar";
        System.out.println("Recibiendo respuesta estándar: " + response);
        return response;
    }
}
