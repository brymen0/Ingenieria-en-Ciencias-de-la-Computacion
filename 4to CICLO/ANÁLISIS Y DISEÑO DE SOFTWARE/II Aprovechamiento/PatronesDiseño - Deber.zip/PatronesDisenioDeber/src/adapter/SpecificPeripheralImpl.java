package adapter;

//Clase que representa un dispositivo periférico específico
public class SpecificPeripheralImpl implements SpecificPeripheral {
	@Override
    public void issueSpecificCommand() {
        System.out.println("Emitiendo comando específico del dispositivo");
    }

    @Override
    public void processSpecificResponse() {
        System.out.println("Procesando respuesta específica del dispositivo");
    }
}
