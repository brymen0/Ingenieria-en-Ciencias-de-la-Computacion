package PatronTemplate;

public abstract class Bebida {
    public final void prepararBebida() {
        hervirAgua();
        prepararIngredientes();
        verterEnTaza();
        agregarCondimentos();
    }
    private void hervirAgua() {
        System.out.println("Hirviendo agua");
    }

    private void verterEnTaza() {
        System.out.println("Vertiendo en taza");
    }

    // Métodos Abstractos (a implementar por subclases)
    abstract void prepararIngredientes();
    abstract void agregarCondimentos();
}
