package PatronTemplate;

public class MainTemplate {
    public static void main(String[] args) {
        Bebida te = new Te();
        Bebida cafe = new Cafe();
        System.out.println("TÉ");
        te.prepararBebida();
        System.out.println("\nCAFÉ");
        cafe.prepararBebida();
        }
}
