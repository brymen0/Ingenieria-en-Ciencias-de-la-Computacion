package PatronTemplate;

class Cafe extends Bebida {
    @Override
    void prepararIngredientes() {
        System.out.println("Moliendo granos de café");
    }

    @Override
    void agregarCondimentos() {
        System.out.println("Añadiendo azúcar y leche");
    }
}