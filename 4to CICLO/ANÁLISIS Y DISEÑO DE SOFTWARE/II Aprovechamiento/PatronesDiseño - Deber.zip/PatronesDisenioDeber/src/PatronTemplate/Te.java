package PatronTemplate;

public class Te extends Bebida {
    @Override
    void prepararIngredientes() {
        System.out.println("Añadiendo hojas de té");
    }

    @Override
    void agregarCondimentos() {
        System.out.println("Añadiendo limón");
    }
}
