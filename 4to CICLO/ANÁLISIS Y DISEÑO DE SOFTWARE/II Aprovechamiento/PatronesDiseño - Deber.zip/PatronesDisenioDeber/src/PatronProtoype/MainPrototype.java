package PatronProtoype;

public class MainPrototype {
    public static void main(String[] args) {
        Jugador jugador1 = new Jugador("Messi", "Inter Miami");

        Jugador jugador2 = jugador1.clonar();
        Jugador jugador3 = jugador1.clonar();

        // Modificamos las propiedades de las personas clonadas
        jugador2.setNombre("Moises Caicedo");
        jugador2.setEquipo("Chelsea FC");
        jugador3.setNombre("Lewandowski");
        jugador3.setEquipo("FC Barcelona");

        System.out.println("Prototipo: " + jugador1);
        System.out.println("Clon 1: " + jugador2);
        System.out.println("Clon 2: " + jugador3);
    }
}
