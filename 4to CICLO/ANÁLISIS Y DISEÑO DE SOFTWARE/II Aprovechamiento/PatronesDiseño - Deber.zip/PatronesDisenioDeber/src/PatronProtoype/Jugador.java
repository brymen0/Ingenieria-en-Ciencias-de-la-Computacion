package PatronProtoype;

public class Jugador implements Cloneable {
    private String nombre;
    private String equipo;

    public Jugador(String nombre, String equipo) {
        this.nombre = nombre;
        this.equipo = equipo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

    public Jugador clonar() {
        return new Jugador(nombre, equipo);
    }

    @Override
    public String toString() {
        return "Jugador [Nombre=" + nombre + ", equipo=" + equipo + "]";
    }
}
