package composite;

//Cliente que utiliza el Patrón Composite
public class OrganizationClient {
	public static void main(String[] args) {
        // Creando empleados individuales
        Employee employee1 = new IndividualEmployee("Juan", "Desarrollador");
        Employee employee2 = new IndividualEmployee("Maria", "Diseñador");

        // Creando un departamento y añadiendo empleados individuales
        Department developmentDepartment = new Department("Departamento de Desarrollo");
        developmentDepartment.addEmployee(employee1);
        developmentDepartment.addEmployee(employee2);

        // Creando más empleados individuales
        Employee employee3 = new IndividualEmployee("Carlos", "Gerente de Proyecto");
        Employee employee4 = new IndividualEmployee("Ana", "QA");

        // Creando otro departamento y añadiendo empleados individuales
        Department managementDepartment = new Department("Departamento de Gestión");
        managementDepartment.addEmployee(employee3);
        managementDepartment.addEmployee(employee4);

        // Creando un departamento que contiene subdepartamentos y empleados individuales
        Department organization = new Department("Organización");
        organization.addEmployee(developmentDepartment);
        organization.addEmployee(managementDepartment);

        // Mostrando detalles de la organización
        organization.showDetails();
    }
}
