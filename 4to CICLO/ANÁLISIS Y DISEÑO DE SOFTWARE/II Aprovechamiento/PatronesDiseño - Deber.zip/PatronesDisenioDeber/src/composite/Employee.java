package composite;

//Interfaz componente que define la operación común a hojas e hijos
public interface Employee {
	void showDetails ();
}
