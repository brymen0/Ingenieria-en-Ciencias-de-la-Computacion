package composite;

import java.util.ArrayList;
import java.util.List;

//Clase compuesta que representa un departamento que puede contener empleados individuales o subdepartamentos
public class Department implements Employee {
	private String name;
    private List<Employee> employees = new ArrayList<>();

    public Department(String name) {
        this.name = name;
    }

    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    @Override
    public void showDetails() {
        System.out.println("Departamento: " + name);
        System.out.println("Miembros del Departamento:");

        for (Employee employee : employees) {
            employee.showDetails();
        }
    }
}
