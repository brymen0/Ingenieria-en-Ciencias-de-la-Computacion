package PatronSingleton;

import java.util.Random;

public class SingletonDirector extends Persona {
    private static SingletonDirector instancia; // Instancia única

    private SingletonDirector(String nombre, int edad) {
        super(nombre, edad);
    }

    public static SingletonDirector getInstance() {
        if (instancia == null) {
            System.out.println("Creando...");
            Random random = new Random();
            int edad = random.nextInt(99);
            instancia = new SingletonDirector("Juan", edad);
        }
        return instancia;
    }

    public void informacion() {
        System.out.println("Nombre: " + instancia.getNombre() + ", Edad: " + instancia.getEdad());
    }
}
