package PatronSingleton;

public class MainSingleton {
    public static void main(String[] args) {
        SingletonDirector director = SingletonDirector.getInstance();
        director.informacion();
        SingletonDirector director2 = SingletonDirector.getInstance();
        director2.informacion();
    }
}
