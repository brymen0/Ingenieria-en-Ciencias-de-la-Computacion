package decorator;

//Interfaz del decorador que extiende la interfaz de usuario base
public interface UIThemeDecorator extends UIComponent {

}
