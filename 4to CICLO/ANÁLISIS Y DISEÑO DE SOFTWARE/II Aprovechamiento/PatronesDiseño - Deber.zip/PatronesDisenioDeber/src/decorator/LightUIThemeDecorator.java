package decorator;

//Clase concreta de decorador que aplica otro tema específico
public class LightUIThemeDecorator implements UIThemeDecorator {
	private UIComponent uiComponent;

    public LightUIThemeDecorator(UIComponent uiComponent) {
        this.uiComponent = uiComponent;
    }

    @Override
    public void display() {
        applyLightTheme();
        uiComponent.display();
    }

    private void applyLightTheme() {
        System.out.println("Aplicando Tema Claro");
    }
}
