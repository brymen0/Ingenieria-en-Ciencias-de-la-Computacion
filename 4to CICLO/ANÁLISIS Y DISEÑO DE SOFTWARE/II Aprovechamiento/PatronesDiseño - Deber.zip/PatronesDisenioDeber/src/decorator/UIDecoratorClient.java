package decorator;

public class UIDecoratorClient {
	public static void main(String[] args) {
        // Creando la interfaz de usuario base
        UIComponent basicUI = new BasicUIComponent();

        // Aplicando diferentes temas mediante decoradores
        UIComponent darkThemeUI = new DarkUIThemeDecorator(basicUI);
        UIComponent lightThemeUI = new LightUIThemeDecorator(basicUI);

        // Mostrando las interfaces de usuario con diferentes temas
        System.out.println("Interfaz de Usuario Básica:");
        basicUI.display();

        System.out.println("\nInterfaz de Usuario con Tema Oscuro:");
        darkThemeUI.display();

        System.out.println("\nInterfaz de Usuario con Tema Claro:");
        lightThemeUI.display();
    }
}
