package decorator;

//Clase concreta que implementa la interfaz de usuario base
public class BasicUIComponent implements UIComponent {
	@Override
    public void display() {
        System.out.println("Interfaz de Usuario Básica");
    }
}
