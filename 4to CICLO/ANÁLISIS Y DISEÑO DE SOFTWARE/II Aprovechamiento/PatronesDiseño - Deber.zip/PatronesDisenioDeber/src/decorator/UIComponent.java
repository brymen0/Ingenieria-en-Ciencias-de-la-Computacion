package decorator;

//Interfaz que define la operación común para la interfaz de usuario
public interface UIComponent {
	void display();
}
