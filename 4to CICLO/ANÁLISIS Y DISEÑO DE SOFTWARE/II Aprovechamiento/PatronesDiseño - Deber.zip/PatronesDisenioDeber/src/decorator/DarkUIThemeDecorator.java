package decorator;

//Clase concreta de decorador que aplica un tema específico
public class DarkUIThemeDecorator implements UIThemeDecorator {
	private UIComponent uiComponent;

    public DarkUIThemeDecorator(UIComponent uiComponent) {
        this.uiComponent = uiComponent;
    }

    @Override
    public void display() {
        applyDarkTheme();
        uiComponent.display();
    }

    private void applyDarkTheme() {
        System.out.println("Aplicando Tema Oscuro");
    }
}
