package PatronMediator;

public class mainMediator {
    public static void main(String[] args) {
        SalaChat sala = new SalaChat();

        Usuario usuario1 = new Usuario(sala, "Usuario1");
        Usuario usuario2 = new Usuario(sala, "Usuario2");
        Usuario usuario3 = new Usuario(sala, "Usuario3");

        sala.agregarUsuario(usuario1);
        sala.agregarUsuario(usuario2);
        sala.agregarUsuario(usuario3);

        usuario1.enviarMensaje("Hola, ¿cómo están?");
        usuario2.enviarMensaje("Todo bien, gracias.");
    }
}
