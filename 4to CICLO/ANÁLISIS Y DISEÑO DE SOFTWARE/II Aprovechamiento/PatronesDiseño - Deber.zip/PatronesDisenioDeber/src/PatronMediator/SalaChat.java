package PatronMediator;

import java.util.ArrayList;
import java.util.List;

public class SalaChat implements Mediador{
    private List<Usuario> usuarios = new ArrayList<>();

    public void agregarUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    @Override
    public void enviarMensaje(String mensaje, Usuario remitente) {
        for (Usuario usuario : usuarios) {
            // Excluir al remitente
            if (usuario != remitente) {
                usuario.recibirMensaje(remitente.getNombre() + ": " + mensaje);
            }
        }
    }
}
