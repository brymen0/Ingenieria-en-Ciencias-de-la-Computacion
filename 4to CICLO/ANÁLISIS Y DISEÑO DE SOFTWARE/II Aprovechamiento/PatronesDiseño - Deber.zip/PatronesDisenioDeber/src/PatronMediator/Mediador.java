package PatronMediator;

public interface Mediador {
    void enviarMensaje(String mensaje, Usuario usuario);
}
