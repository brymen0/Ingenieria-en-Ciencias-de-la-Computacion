package PatronMediator;

public class Usuario {
    private Mediador mediador;
    private String nombre;

    public Usuario(Mediador mediador, String nombre) {
        this.mediador = mediador;
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void enviarMensaje(String mensaje) {
        mediador.enviarMensaje(mensaje, this);
    }

    public void recibirMensaje(String mensaje) {
        System.out.println(nombre + " recibe mensaje: " + mensaje);
    }
}
