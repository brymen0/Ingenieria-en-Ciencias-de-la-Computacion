package PatronObserver;

public class mainObserver {
    public static void main(String[] args) {
        Producto producto = new Producto();

        // Crear observadores
        Observador cliente1 = new Cliente("Cliente 1");
        Observador cliente2 = new Cliente("Cliente 2");
        // Suscribir observadores al sujeto
        producto.agregarObservador(cliente1);
        producto.agregarObservador(cliente2);
        // Cambiar el precio del producto
        producto.setPrecio(50.0);
        producto.setPrecio(51.50);
    }
}
