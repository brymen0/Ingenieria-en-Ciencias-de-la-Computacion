package PatronObserver;

import java.util.ArrayList;
import java.util.List;

public class Producto implements Sujeto{
    private double precio;
    private List<Observador> observadores = new ArrayList<>();

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
        notificarObservadores();
    }

    @Override
    public void agregarObservador(Observador observador) {
        observadores.add(observador);
    }

    @Override
    public void eliminarObservador(Observador observador) {
        observadores.remove(observador);
    }

    @Override
    public void notificarObservadores() {
        for (Observador observador : observadores) {
            observador.actualizar(precio);
        }
    }
}
