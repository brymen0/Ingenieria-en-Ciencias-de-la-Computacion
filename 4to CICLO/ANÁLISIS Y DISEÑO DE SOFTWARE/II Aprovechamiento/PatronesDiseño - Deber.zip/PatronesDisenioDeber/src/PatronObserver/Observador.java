package PatronObserver;

public interface Observador {
    void actualizar(double precio);
}
