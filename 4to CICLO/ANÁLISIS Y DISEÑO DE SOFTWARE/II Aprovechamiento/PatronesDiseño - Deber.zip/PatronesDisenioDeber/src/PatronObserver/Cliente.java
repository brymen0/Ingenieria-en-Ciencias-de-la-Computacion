package PatronObserver;

public class Cliente implements Observador{
    private String nombre;

    public Cliente(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void actualizar(double precio) {
        System.out.println(nombre + " recibió una notificación: El precio del producto es ahora " + precio);
    }
}
