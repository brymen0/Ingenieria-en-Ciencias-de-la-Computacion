package PatronMemento;

public class mainMemento {
    public static void main(String[] args) {
        EditorTexto editor = new EditorTexto("Contenido inicial");
        Historial historial = new Historial();

        historial.agregarMemento(editor.guardar());// Guardar el estado inicial
        editor.setContenido("Contenido modificado"); // Modificar el contenido
        historial.agregarMemento(editor.guardar()); // Guardar el nuevo estado

        // Restaurar al estado anterior
        Memento estadoAnterior = historial.obtenerUltimoMemento();
        if (estadoAnterior != null) {
            editor.restaurar(estadoAnterior);
            System.out.println("Contenido después de deshacer: " + editor.getContenido());
        }
    }
}
