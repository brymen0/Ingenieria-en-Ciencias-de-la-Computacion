package PatronMemento;

import java.util.ArrayList;
import java.util.List;

public class Historial { //cuidador
    private List<Memento> historial = new ArrayList<>();

    public void agregarMemento(Memento memento) {
        historial.add(memento);
    }

    public Memento obtenerUltimoMemento() {
        if (!historial.isEmpty()) {
            int indiceUltimo = historial.size() - 2;
            return historial.get(indiceUltimo);
        } else {
            return null;
        }
    }
}
