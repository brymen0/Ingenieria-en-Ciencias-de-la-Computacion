package decorator;

public interface Forma {
	void dibujar();
}
