package decorator;

public class Rectangulo implements Forma {
	@Override
	public void dibujar() {
		// TODO Auto-generated method stub
		System.out.println("Forma: Rectangulo");
	}
}
