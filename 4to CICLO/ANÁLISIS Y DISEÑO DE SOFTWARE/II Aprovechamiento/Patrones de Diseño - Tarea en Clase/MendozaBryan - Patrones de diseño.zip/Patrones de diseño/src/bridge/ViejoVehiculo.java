package bridge;

public class ViejoVehiculo implements TipoVehiculo {
	@Override
	public void libro(){
		System.out.println("Viejo Vehiculo");
	}
}
