package observer;

public interface Observador {
	public void actualizar();
	public void setAsunto(Asunto asunto);
}
