package abstractFactory;

public class LenovoFabricaMovil extends FabricaMovil {
	Lenovo crearMovilLenovo () {
		return new Lenovo ();
	}
}
