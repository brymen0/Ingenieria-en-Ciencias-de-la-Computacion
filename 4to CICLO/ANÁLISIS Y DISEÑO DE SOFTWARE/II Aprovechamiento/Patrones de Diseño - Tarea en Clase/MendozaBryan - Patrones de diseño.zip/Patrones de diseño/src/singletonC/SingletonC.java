package singletonC;

public class SingletonC implements Cloneable{
	private static SingletonC instancia = new SingletonC ();
	public SingletonC () {
		System.out.println("Creando...");
	}
	
	public static SingletonC getInstancia () {
		return instancia;
	}
	
	protected Object clone () throws CloneNotSupportedException {
		return super.clone();
	}
	
	public static void main (String[] args) throws Exception {
		SingletonC s1 = SingletonC.getInstancia();
		SingletonC s2 = SingletonC.getInstancia();
		
		print("s1", s1);
		print("s2", s2);
		
		SingletonC s3 = (SingletonC)s2.clone();
		print ("s3", s3);
	}
	
	static void print (String name, SingletonC obj) {
		System.out.println(String.format("Objeto: %s, Codigo Hash:", name, obj.hashCode()));
	}
}
