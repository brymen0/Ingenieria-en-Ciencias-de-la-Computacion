package flyweight;

public interface Molde {
	void dibujar();
}
