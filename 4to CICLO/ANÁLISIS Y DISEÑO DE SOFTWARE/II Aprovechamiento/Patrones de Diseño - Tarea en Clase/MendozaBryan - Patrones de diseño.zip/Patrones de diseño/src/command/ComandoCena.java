package command;

public class ComandoCena implements Comando {
	Cena cena;
	
	public ComandoCena(Cena cena) {
		this.cena=cena;
	}
	
	@Override
	public void ejecutar() {
		cena.hacerCena();
	}
}
