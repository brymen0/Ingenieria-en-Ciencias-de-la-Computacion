package command;

public class InvocadorComida {
	Comando comando;

	public InvocadorComida(Comando comando) {
		this.comando=comando;
	}
	
	public void setComando(Comando comando){
		this.comando=comando;
	}
	
	public void invocar(){
		comando.ejecutar();
	}
}
