package template;

public class PruebaTemplate {
	public static void main(String[] args) {
		PlantillaCompra online = new Orden_Compra_Online();
		online.procesarOrden();
		PlantillaCompra offline = new Orden_Compra_En_Tienda();
		offline.procesarOrden();
	}
}
