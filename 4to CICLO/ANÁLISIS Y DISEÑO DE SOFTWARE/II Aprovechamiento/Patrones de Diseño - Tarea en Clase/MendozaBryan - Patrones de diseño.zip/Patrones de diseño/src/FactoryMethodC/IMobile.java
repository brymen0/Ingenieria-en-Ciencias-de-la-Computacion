package FactoryMethodC;

public interface IMobile {
	public void costo();
	public void capacidadCamara();
	public void poderBateria();
}
