package FactoryMethodC;

public class FactoryTest {

	public static void main(String[] args) {
		MobileFactory factory = new MobileFactory();
		Lenovo lenovoMaquina = (Lenovo)factory.crearMovil("len");
		lenovoMaquina.poderBateria();
		System.out.println("\n****************");
		Samsung samsungMaquina = (Samsung)factory.crearMovil("sam");
		samsungMaquina.costo();
	}

}
