package facade;

public class PruebaPatronFacade {
	public static void main(String[] args) {
		FormadordeFormas hacerForma = new FormadordeFormas();
		hacerForma.dibujarCirculo();
		hacerForma.dibujarCuadrado();
		hacerForma.dibujarRectangulo();
	}
}
