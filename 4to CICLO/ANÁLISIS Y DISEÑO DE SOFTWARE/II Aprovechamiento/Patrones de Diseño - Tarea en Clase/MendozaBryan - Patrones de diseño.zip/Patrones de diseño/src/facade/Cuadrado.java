package facade;

public class Cuadrado implements Forma {
	@Override
	public void dibujar() {
		System.out.println("Cuadrado::dibujar()");
	}
}
