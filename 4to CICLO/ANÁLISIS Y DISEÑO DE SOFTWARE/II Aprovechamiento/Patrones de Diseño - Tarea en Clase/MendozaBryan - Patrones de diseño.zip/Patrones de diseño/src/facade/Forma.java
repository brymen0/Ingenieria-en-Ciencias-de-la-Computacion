package facade;

public interface Forma {
	void dibujar();
}
