package visitor;

public interface ElementoDeCarroDeCompras {
	public int accept(CarroDeComprasDelVisitante visitante);
}
