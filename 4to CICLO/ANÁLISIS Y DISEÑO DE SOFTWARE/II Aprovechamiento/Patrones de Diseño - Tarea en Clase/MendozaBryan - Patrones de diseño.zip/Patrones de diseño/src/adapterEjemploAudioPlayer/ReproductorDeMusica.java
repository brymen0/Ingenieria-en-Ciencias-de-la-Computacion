package adapterEjemploAudioPlayer;

public interface ReproductorDeMusica {
	public void play (String tipoAudio, String nombreArchivo);
}
