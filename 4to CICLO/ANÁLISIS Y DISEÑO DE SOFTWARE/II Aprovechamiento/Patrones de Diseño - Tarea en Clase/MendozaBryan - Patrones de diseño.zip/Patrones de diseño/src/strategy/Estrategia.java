package strategy;

public interface Estrategia {
	public void ordenar(int[] numeros);
}
