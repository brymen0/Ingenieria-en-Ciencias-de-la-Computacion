package interpreter;

public interface Expresion {
	public boolean interpreta(String contexto);
}
