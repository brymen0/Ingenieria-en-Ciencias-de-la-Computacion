package bridge;

public class NuevoVehiculo implements TipoVehiculo {
	@Override
	public void libro(){
	System.out.println("Nuevo Vehiculo");
	}
}
