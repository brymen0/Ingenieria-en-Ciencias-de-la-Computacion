package bridge;

public interface TipoVehiculo {
	//Implementador para el patrón de puente
	abstract public void libro();
}
