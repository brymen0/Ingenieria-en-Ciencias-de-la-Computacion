package FactoryMethodC;

public class MobileFactory {
	public MobileFactory () {
		
	}
	
	IMobile crearMovil (String type) {
		IMobile movil = null;
		if ("len".equalsIgnoreCase(type)) {
			movil = new Lenovo ();
			System.out.println("Móvil Lenovo creado");
		} else if ("sam".equalsIgnoreCase(type)) {
			movil = new Samsung();
			System.out.println("Móvil Samsung creado");
		}
		return movil;
	}
}
