package FactoryMethodC;

public class Samsung implements IMobile {
	public void costo() {
		System.out.println("El costo de Samsung empieza en $600");
	}

	@Override
	public void capacidadCamara() {
		System.out.println("La capacidad de la cámara de Samsung comienza en los " + "4 mp");
	}

	@Override
	public void poderBateria() {
		System.out.println("El poder de la batería Samsung comienza en los " + "1200 mAh");
	}
}
