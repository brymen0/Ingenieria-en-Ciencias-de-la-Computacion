package FactoryMethodC;

public class Lenovo implements IMobile {

	public void costo() {
		System.out.println("El costo de Lenovo empieza en $1000");
	}

	@Override
	public void capacidadCamara() {
		System.out.println("La capacidad de la cámara de Lenovo comienza en los " + "10 mp");
	}

	@Override
	public void poderBateria() {
		System.out.println("El poder de la batería Lenovo comienza en los " + "2500 mAh");
	}
	
	public String toString () {
		return " Lenovo [toString()=" + super.toString() + "]";
	}
}
