package prototype;

public class PrototypeTest {
	public Bicicleta HacerJaguar (Bicicleta basicaBicicleta) {
		basicaBicicleta.makeAdvanced();
		return basicaBicicleta;
	}
	
	public static void main (String[] args) {
		Bicicleta bicicleta = new Bicicleta();
		Bicicleta basicaBicicleta = bicicleta.clonar();
		PrototypeTest pt = new PrototypeTest ();
		Bicicleta BicicletaAvanzada = pt.HacerJaguar(basicaBicicleta);
		System.out.println("Prototype Desing Pattern:" + BicicletaAvanzada.getModelo());
		System.out.println("Prototype Desing Pattern:" + BicicletaAvanzada.toString());
	}
}
