package adapterEjemploAudioPlayer;

public interface ReproductorDeMusicaAvanzado {
	public void playVlc (String nombreArchivo);
	public void playMp4 (String nombreArchivo);
}
