package adapterEjemploAudioPlayer;

public class AudioPlayer implements ReproductorDeMusica {
	MediaAdapter mediaAdapter;
	@Override
	public void play(String tipoDeAudio, String nombreArchivo) {
		if (tipoDeAudio.equalsIgnoreCase("mp3")) {
			System.out.println("Reproduciendo mp3 " +
					"-> Nombre del Archivo: " + nombreArchivo);
		} else if (tipoDeAudio.equalsIgnoreCase("vlc") ||
				tipoDeAudio.equalsIgnoreCase("mp4")) {
			mediaAdapter = new MediaAdapter (tipoDeAudio);
			mediaAdapter.play(tipoDeAudio, nombreArchivo);
		} else {
			System.out.println("Reproducción Inválida," + 
					" no soporta el formato ." + tipoDeAudio);
		}
	}
}
