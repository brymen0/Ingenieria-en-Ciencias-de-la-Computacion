package decorator;

public class Circulo implements Forma{
	@Override
	public void dibujar() {
	// TODO Auto-generated method stub
	System.out.println("Forma: Cirulo");
	}
}
