package iterator;

public interface Iterador {
	public abstract Object siguiente();
	public abstract boolean tieneSiguiente();
}
