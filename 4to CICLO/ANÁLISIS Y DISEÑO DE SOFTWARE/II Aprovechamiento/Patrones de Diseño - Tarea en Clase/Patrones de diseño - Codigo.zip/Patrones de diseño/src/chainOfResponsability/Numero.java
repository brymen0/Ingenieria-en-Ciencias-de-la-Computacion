package chainOfResponsability;

public class Numero {
	private int numero;
	
	public int getNumero(){	
		return numero;
	}
	
	public Numero(int num){
		numero=num;
	}
	
}
