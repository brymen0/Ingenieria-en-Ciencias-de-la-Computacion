package chainOfResponsability;

public interface Cadena {
	void setSiguiente(Cadena siguienteEnCadena);
	void proceso(Numero solicitud);
}
