package command;

public class ComandoAlmuerzo implements Comando {
	Almuerzo almuerzo;
	
	public ComandoAlmuerzo(Almuerzo al) {
		almuerzo=al;
	}
	
	@Override
	public void ejecutar() {
		almuerzo.hacerAlmuerzo();
	}
}
