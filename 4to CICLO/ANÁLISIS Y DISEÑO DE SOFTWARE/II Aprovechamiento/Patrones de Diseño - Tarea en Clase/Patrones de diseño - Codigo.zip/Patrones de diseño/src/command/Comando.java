package command;

public interface Comando {
	void ejecutar();
}
