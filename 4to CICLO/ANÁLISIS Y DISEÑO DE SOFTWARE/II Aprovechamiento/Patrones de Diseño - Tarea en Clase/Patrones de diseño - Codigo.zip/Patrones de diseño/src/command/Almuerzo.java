package command;

public class Almuerzo {
	public void hacerAlmuerzo(){
		System.out.println("se esta haciendo el almuerzo");
	}
}
