package command;

public class Cena {
	public void hacerCena(){
		System.out.println("se esta haciendo la cena");
	}
}
