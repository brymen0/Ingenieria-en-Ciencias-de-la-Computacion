package facade;

public class Rectangulo implements Forma {
	@Override
	public void dibujar() {
		System.out.println("Rectangulo::dibujar()");
	}
}
