package facade;

public class Circulo implements Forma {
	@Override
	public void dibujar() {
		System.out.println("Circulo::dibujar()");
	}
}
