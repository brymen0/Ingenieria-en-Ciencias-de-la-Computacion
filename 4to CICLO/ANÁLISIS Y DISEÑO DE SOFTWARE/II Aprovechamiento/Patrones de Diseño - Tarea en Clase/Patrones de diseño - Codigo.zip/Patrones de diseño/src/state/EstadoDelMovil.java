package state;

public interface EstadoDelMovil {
	public void getEstado();
}
