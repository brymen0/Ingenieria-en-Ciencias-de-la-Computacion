package builder;

class Pastel {
	private double azucar;
	private double mantequilla;
	private double leche;
	private int cerezas;
	
	private Pastel (ConstruirPastel construir) {
		this.azucar = construir.azucar;
		this.mantequilla = construir.mantequilla;
		this.leche = construir.leche;
		this.cerezas = construir.cerezas;
	}
	
	public static class ConstruirPastel {
		private double azucar;
		private double mantequilla;
		private double leche;
		private int cerezas;
		
		public ConstruirPastel azucar (double tazas) {
			this.azucar = tazas;
			return this;
		}
		
		public ConstruirPastel mantequilla (double tazas) {
			this.mantequilla = tazas;
			return this;
		}
		
		public ConstruirPastel leche (double tazas) {
			this.leche = tazas;
			return this;
		}
		
		public ConstruirPastel cerezas (int tazas) {
			this.cerezas = tazas;
			return this;
		}
		
		public Pastel construir () {
			return new Pastel (this);
		}
	}
	
	public String toString () {
		return "Pastel [azucar=" + azucar + ", mantequilla=" + mantequilla
				+ ", leche=" + leche + ", cerezas=" + cerezas + "]";
	}
}
