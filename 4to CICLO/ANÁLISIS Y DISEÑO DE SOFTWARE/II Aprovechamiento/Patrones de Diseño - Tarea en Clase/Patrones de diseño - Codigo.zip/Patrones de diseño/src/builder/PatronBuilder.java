package builder;

public class PatronBuilder {
	public static void main (String[] args) {
		Pastel bizcocho = new Pastel.ConstruirPastel().azucar(1).mantequilla(0.5).leche(0.5).cerezas(2).construir();
		System.out.println(bizcocho);
	}
}
