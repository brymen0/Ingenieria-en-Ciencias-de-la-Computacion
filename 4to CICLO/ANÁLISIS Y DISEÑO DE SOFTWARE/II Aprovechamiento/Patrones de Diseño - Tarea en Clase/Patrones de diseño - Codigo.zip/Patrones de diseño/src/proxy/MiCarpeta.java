package proxy;

public interface MiCarpeta {
	void RealizarOperacion();
}
