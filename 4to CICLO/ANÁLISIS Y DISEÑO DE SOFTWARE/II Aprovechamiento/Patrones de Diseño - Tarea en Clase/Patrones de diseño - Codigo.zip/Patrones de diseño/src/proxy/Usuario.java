package proxy;

public class Usuario {
	String nombreUsuario;
	String contrasena;
	public Usuario(String nombreUsuario, String contrasena){
		super(); this.nombreUsuario =
				nombreUsuario; this.contrasena =
				contrasena;
	}
	public String getNombreUsuario(){
		return nombreUsuario;
	}
	public void setNombreUsuario(String nombreUsuario){
		this.nombreUsuario= nombreUsuario;
	}
	public String getContrasena(){
		return contrasena;
	}
	public void setContrasena(String
		contrasena){ this.contrasena=contrasena;
	}
}
