package abstractFactory;

public class Abstract_Factory_Test {
	public static void main (String[] args) {
		FabricaMovil fabrica = new FabricaMovil();
		LenovoFabricaMovil lmf = (LenovoFabricaMovil) fabrica.crearMovil ("lenf");
		Lenovo ln = (Lenovo)lmf.crearMovilLenovo();
		ln.capacidadCamara();
	}
}
