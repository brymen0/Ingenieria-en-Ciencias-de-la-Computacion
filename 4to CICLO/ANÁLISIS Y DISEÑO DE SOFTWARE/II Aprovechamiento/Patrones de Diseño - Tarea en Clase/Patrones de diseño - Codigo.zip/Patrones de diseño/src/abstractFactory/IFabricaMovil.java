package abstractFactory;

public interface IFabricaMovil {
	IFabricaMovil crearMovil (String type);
}
