package abstractFactory;

public class SamsungFabricaMovil extends FabricaMovil{
	Samsung crearMovilSamsung () {
		return new Samsung();
	}
}
