package abstractFactory;

public class Lenovo implements IMovil {

	@Override
	public void costo() {
		System.out.println("El costo de Lenovo empieza en 1000");
	}

	@Override
	public void capacidadCamara() {
		System.out.println("La capacidad de la cámara de Lenovo comienza en los 10 MP");
	}

	@Override
	public void podeBateria() {
		System.out.println("El poder de la bateria Lenovo comienza en los 2500mAh");
	}
	
	public String toString () {
		return " Lenovo [toString()=+"+super.toString()+"]";
	}
}
