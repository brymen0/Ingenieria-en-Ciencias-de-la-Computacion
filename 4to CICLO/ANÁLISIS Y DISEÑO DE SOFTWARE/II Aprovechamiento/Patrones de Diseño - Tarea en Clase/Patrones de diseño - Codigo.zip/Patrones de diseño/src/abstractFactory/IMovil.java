package abstractFactory;

public interface IMovil {
	public void costo ();
	public void capacidadCamara();
	public void podeBateria ();
}
