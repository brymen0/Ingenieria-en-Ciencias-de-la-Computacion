package abstractFactory;

public class Samsung implements IMovil {
	@Override
	public void costo() {
		System.out.println("El costo de Samsung empieza en 1000");
	}

	@Override
	public void capacidadCamara() {
		System.out.println("La capacidad de la cámara de Samsung comienza en los 10 MP");
	}

	@Override
	public void podeBateria() {
		System.out.println("El poder de la bateria Samsung comienza en los 2500mAh");
	}
	
	public String toString () {
		return " Samsung [toString()=+"+super.toString()+"]";
	}
}
