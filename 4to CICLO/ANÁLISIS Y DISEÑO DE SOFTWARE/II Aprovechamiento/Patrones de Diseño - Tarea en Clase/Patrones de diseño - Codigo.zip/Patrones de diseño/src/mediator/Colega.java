package mediator;

public abstract class Colega {
	IMediador mediador;
	public abstract void hacerAlgo();
}
