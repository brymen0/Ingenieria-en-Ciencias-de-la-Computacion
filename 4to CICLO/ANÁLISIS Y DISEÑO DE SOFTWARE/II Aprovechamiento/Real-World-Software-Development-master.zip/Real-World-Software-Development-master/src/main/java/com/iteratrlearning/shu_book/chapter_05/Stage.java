package com.iteratrlearning.shu_book.chapter_05;

public enum Stage {
    LEAD, INTERESTED, EVALUATING, CLOSED
}
