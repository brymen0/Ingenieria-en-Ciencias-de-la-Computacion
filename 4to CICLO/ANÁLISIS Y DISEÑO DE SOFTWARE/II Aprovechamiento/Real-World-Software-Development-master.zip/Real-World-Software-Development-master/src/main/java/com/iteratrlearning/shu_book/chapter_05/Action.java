package com.iteratrlearning.shu_book.chapter_05;

@FunctionalInterface
interface Action{
    void execute(Facts facts);
}
