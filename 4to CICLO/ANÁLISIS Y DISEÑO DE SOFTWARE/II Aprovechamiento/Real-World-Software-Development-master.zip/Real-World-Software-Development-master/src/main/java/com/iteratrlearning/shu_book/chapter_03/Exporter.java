package com.iteratrlearning.shu_book.chapter_03;

public interface Exporter {
    String export(SummaryStatistics summaryStatistics);
}

