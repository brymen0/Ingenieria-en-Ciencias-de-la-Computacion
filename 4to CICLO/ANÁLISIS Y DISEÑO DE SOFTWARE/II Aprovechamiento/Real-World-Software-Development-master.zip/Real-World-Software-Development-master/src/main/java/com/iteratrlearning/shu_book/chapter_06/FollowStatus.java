package com.iteratrlearning.shu_book.chapter_06;

// tag::FollowStatus[]
public enum FollowStatus {
    SUCCESS,
    INVALID_USER,
    ALREADY_FOLLOWING
}
// end::FollowStatus[]
