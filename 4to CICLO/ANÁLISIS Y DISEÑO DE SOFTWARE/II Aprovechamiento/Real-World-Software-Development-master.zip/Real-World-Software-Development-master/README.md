This is the sample code for the book "Real World Software Development"
written by Richard Warburton and Raoul-Gabriel Urma and published by
O'Reilly Media.

Full details can be found online at http://shop.oreilly.com/product/0636920053996.do

