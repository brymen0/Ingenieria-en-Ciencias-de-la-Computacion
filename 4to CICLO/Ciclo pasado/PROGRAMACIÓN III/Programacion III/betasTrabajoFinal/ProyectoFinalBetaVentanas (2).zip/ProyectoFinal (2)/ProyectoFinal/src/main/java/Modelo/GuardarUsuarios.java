/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author aleca
 */
public class GuardarUsuarios {
    private ArrayList<Usuario> ListaUsuarios; //lista de usuarios

    public GuardarUsuarios() { //constructor
        ListaUsuarios = new ArrayList<>(); //reamos la lista
    }
    public void eliminarUsuario(int pos){ // metodo para eliminar usuario
        ListaUsuarios.remove(pos);
    }
    
    //metodo para agregar el usuario de acuerdo al cargo
    public void AddUsuario(String cedula, String nombres, String apellidos, String email, String password, String telefono, String cargo) {
        if(cargo.equals("USUARIO"))
            ListaUsuarios.add(new Usuario(cedula, nombres, apellidos, email, password, telefono, cargo));
        if(cargo.equals("SOLICITANTE"))
            ListaUsuarios.add(new Solicitante(cedula, nombres, apellidos, email, password, telefono, cargo));
        if(cargo.equals("AUTORIZADOR"))
            ListaUsuarios.add(new Autorizador(cedula, nombres, apellidos, email, password, telefono, cargo));
        if(cargo.equals("ADMINISTRADOR"))
            ListaUsuarios.add(new Administrador(cedula, nombres, apellidos, email, password, telefono, cargo));
    }
    
    //metodo para modificar el usuario de acuerdo al cargo
    public void setUsuario(String cedula, String nombres, String apellidos, String email, String password, String telefono, String cargo, int pos) {
        if(cargo.equals("USUARIO"))
            ListaUsuarios.set(pos,new Usuario(cedula, nombres, apellidos, email, password, telefono, cargo));
        if(cargo.equals("SOLICITANTE"))
            ListaUsuarios.set(pos,new Solicitante(cedula, nombres, apellidos, email, password, telefono, cargo));
        if(cargo.equals("AUTORIZADOR"))
            ListaUsuarios.set(pos,new Autorizador(cedula, nombres, apellidos, email, password, telefono, cargo));
        if(cargo.equals("ADMINISTRADOR"))
            ListaUsuarios.set(pos,new Administrador(cedula, nombres, apellidos, email, password, telefono, cargo));
        
    }
   
    public int TamLista(){ //retorna el tamanio de la lista
        return ListaUsuarios.size();
    }
    
    public int Buscar(String dato, int col){ //busacr un usuario
        int i = 0;
        while(i<ListaUsuarios.size()){
            if(col==0 && ListaUsuarios.get(i).getCedula().equalsIgnoreCase(dato)){
                return i;
            }
            i++;
        }
        
        return -1; //si no existe
    }

    public Usuario getUsuario(int pos) { //retorna el usuario en esa posicion
        return ListaUsuarios.get(pos);
    }
    
    public void abrirArchivo(){ //para abrir el archivo generado
        try{
            ObjectInputStream archivo;
            File path = new File("archivoDeUsuarios");
            if(path.exists()){
                archivo = new ObjectInputStream (new FileInputStream("archivoDeUsuarios"));
                ListaUsuarios = (ArrayList<Usuario>)archivo.readObject();
                archivo.close();
            }
        }catch(ClassNotFoundException e){
            
        }catch(IOException e){}
    }
    public void guardarDatos(){ //para guardar el archivo generado
        try{
            ObjectOutputStream archivo =new ObjectOutputStream (new FileOutputStream ("archivoDeUsuarios"));
            archivo.writeObject(ListaUsuarios); // Graba los objetos (el vector) \n" +
            archivo.flush(); // Vacía el buffer de salida\n" +
            archivo.close(); // cierra el archivo
        }catch(IOException e){
            JOptionPane.showMessageDialog(null, "Error al guardar el archivo");
        }
        
    }
    
}
