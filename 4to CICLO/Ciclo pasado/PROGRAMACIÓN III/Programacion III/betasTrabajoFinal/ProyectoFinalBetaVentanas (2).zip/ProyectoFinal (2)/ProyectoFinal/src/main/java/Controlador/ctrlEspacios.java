/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Vista.*;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author aleca
 */
public class ctrlEspacios /*implements ActionListener, MouseListener*/{
 /*   VentGestion ventGest;
    VentEspacios ventespacios;
    public ctrlEspacios(VentEspacios ventespacios, VentGestion ventGest) {
        this.ventespacios = ventespacios;
        
      //  this.ventespacios.txtCodigo.addMouseListener(this);
        this.ventespacios.txtUbicacion.addMouseListener(this);
        this.ventespacios.btnSalir.addActionListener(e->{
            this.ventespacios.dispose();
            ventGest.setEnabled(true);

        });
        PonerImagen();
        this.ventespacios.btnAgregarElem.addActionListener(e->{
            if(true){
                //int op = JOptionPane.showConfirmDialog(null, "No existe el usuario. ¿Desea crear una cuenta?", "Advertencia", 0,1);
               
                VentElementos ventElem = new VentElementos();
         //       ctrlElement ctrlE = new ctrlElement(ventElem, ventespacios);
                this.ventespacios.setEnabled(false);
                ventElem.setVisible(true);
                ImageIcon image =new ImageIcon("fondo3.png");
                Icon icono=new ImageIcon(image.getImage().getScaledInstance(ventElem.Fondo.getWidth(), ventElem.Fondo.getHeight(), Image.SCALE_DEFAULT));//para escaclar al tamanio del JLabel
                ventElem.Fondo.setIcon(icono);
                ventElem.Fondo.repaint();//para q se vea
                
            }
            
               
        
        });
    }
    public void PonerImagen(){
         //add imagen fondo
                                            
        ImageIcon image =new ImageIcon("fondo3.png");
        Icon icono=new ImageIcon(image.getImage().getScaledInstance(ventespacios.Fondo.getWidth(), ventespacios.Fondo.getHeight(), Image.SCALE_DEFAULT));//para escaclar al tamanio del JLabel
  //      ventespacios.Fondo.setIcon(icono);
  //      this.ventespacios.Fondo.repaint();//para q se vea
        ////////////////////////////////////////////////////////////////////////
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        
    }

    @Override
    public void mouseClicked(MouseEvent e) {
      
    }

    @Override
    public void mousePressed(MouseEvent e) {
     /*   if(e.getSource()==ventGestBl.txtCodigo){
            if(ventGestBl.txtCodigo.getText().equals("Ingrese el nombre del bloque")){
                ventGestBl.txtCodigo.setText("");
                ventGestBl.txtCodigo.setForeground(Color.black);
                
            }
            if(ventGestBl.txtUbicacion.getText().isEmpty()){
                ventGestBl.txtUbicacion.setText("Ingrese la ubicación");
                ventGestBl.txtUbicacion.setForeground(Color.gray);
            }
        }
        
        if(e.getSource()==ventGestBl.txtUbicacion){
            if(ventGestBl.txtUbicacion.getText().equals("Ingrese la ubicación")){
                ventGestBl.txtUbicacion.setText("");
                ventGestBl.txtUbicacion.setForeground(Color.black);
                
            }
            if(ventGestBl.txtCodigo.getText().isEmpty()){
                ventGestBl.txtCodigo.setText("Ingrese el nombre del bloque");
                ventGestBl.txtCodigo.setForeground(Color.gray);
            }
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
     
    }

    @Override
    public void mouseEntered(MouseEvent e) {
       
    }

    @Override
    public void mouseExited(MouseEvent e) {
     
    }

}

class ctrlElement implements ActionListener, MouseListener{
    VentGestBl ventGestBl;
    VentElementos ventElem;
    public ctrlElement(VentElementos ventElem, VentGestBl ventGestBl) {
        this.ventGestBl = ventGestBl;
        this.ventElem = ventElem;
        this.ventElem.jComboBox1.addMouseListener(this);
        this.ventElem.txtCantidad.addMouseListener(this);
        this.ventElem.btnSalir.addActionListener(e->{
            this.ventElem.dispose();
            ventGestBl.setEnabled(true);

        });
        this.ventElem.btnCancelar.addActionListener(e->{
            int op = JOptionPane.showConfirmDialog(null, "Desea salir sin guardar los cambios", "Advertencia", 0,1);
            if(op==0){
                this.ventElem.dispose();
                ventGestBl.setEnabled(true);
               
            }
        });
        
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
    }

    @Override
    public void mouseClicked(MouseEvent e) {
      
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if(e.getSource()==ventElem.txtCantidad){
            if(ventElem.txtCantidad.getText().equals("Cantidad de elementos")){
                ventElem.txtCantidad.setText("");
                ventElem.txtCantidad.setForeground(Color.black);
                
            }
        }
        
        if(e.getSource()==ventElem.jComboBox1){
            if(ventElem.txtCantidad.getText().isEmpty()){
                ventElem.txtCantidad.setText("Cantidad de elementos");
                ventElem.txtCantidad.setForeground(Color.gray);
            }
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
     
    }

    @Override
    public void mouseEntered(MouseEvent e) {
       
    }

    @Override
    public void mouseExited(MouseEvent e) {
     
    }
    */
}
    
