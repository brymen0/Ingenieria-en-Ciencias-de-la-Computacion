/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Vista.*;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *
 * @author aleca
 */
public class ctrlAgenda implements ActionListener, MouseListener{
    VentAgenda ventAgenda;
    VentGestion ventGest;
    public ctrlAgenda(VentAgenda ventAgenda, VentGestion ventGest) {
        this.ventAgenda = ventAgenda;
        PonerImagen();
        this.ventAgenda.btnSalir.addActionListener(e->{
            this.ventAgenda.dispose();
            ventGest.setEnabled(true);

        });
       
    }
    public void PonerImagen(){
         //add imagen fondo
                                            
        ImageIcon image =new ImageIcon("fondo3.png");
        Icon icono=new ImageIcon(image.getImage().getScaledInstance(ventAgenda.Fondo.getWidth(), ventAgenda.Fondo.getHeight(), Image.SCALE_DEFAULT));//para escaclar al tamanio del JLabel
        ventAgenda.Fondo.setIcon(icono);
        this.ventAgenda.Fondo.repaint();//para q se vea
        ////////////////////////////////////////////////////////////////////////
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        
    }

    @Override
    public void mouseClicked(MouseEvent e) {
      
    }

    @Override
    public void mousePressed(MouseEvent e) {
       
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
     
    }

    @Override
    public void mouseEntered(MouseEvent e) {
       
    }

    @Override
    public void mouseExited(MouseEvent e) {
     
    }
    
}
    

