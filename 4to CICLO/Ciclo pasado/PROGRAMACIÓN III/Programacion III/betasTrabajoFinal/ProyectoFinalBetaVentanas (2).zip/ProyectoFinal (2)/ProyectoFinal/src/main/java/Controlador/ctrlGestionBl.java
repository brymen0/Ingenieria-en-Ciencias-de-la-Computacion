/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Vista.*;
import Vista.VentGestion;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author aleca
 */
public class ctrlGestionBl implements ActionListener, MouseListener{
    VentGestion ventGest;
    VentGestBl ventGestBl;
    public ctrlGestionBl(VentGestBl ventGestBl, VentGestion ventGest) {
        this.ventGestBl = ventGestBl;
        
        this.ventGestBl.txtCodigo.addMouseListener(this);
        this.ventGestBl.txtUbicacion.addMouseListener(this);
        this.ventGestBl.txtNombre.addMouseListener(this);
        this.ventGestBl.SpinNespacios.addMouseListener(this);
        this.ventGestBl.SpinNpisos.addMouseListener(this);
        this.ventGestBl.btnSalir.addActionListener(e->{
            this.ventGestBl.dispose();
            ventGest.setEnabled(true);

        });
        PonerImagen();
       
    }
    public void PonerImagen(){
         //add imagen fondo
                                            
        ImageIcon image =new ImageIcon("fondo3.png");
        Icon icono=new ImageIcon(image.getImage().getScaledInstance(ventGestBl.Fondo.getWidth(), ventGestBl.Fondo.getHeight(), Image.SCALE_DEFAULT));//para escaclar al tamanio del JLabel
        ventGestBl.Fondo.setIcon(icono);
        this.ventGestBl.Fondo.repaint();//para q se vea
        ////////////////////////////////////////////////////////////////////////
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        
    }

    @Override
    public void mouseClicked(MouseEvent e) {
      
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if(e.getSource()==ventGestBl.txtCodigo){
            if(ventGestBl.txtCodigo.getText().equals("Ingrese el código del bloque")){
                ventGestBl.txtCodigo.setText("");
                ventGestBl.txtCodigo.setForeground(Color.black);
                
            }
            if(ventGestBl.txtUbicacion.getText().isEmpty()){
                ventGestBl.txtUbicacion.setText("Ingrese la ubicación");
                ventGestBl.txtUbicacion.setForeground(Color.gray);
            }
            if(ventGestBl.txtNombre.getText().isEmpty()){
                ventGestBl.txtNombre.setText("Ingrese el nombre del bloque");
                ventGestBl.txtNombre.setForeground(Color.gray);
            }
        }
        
        if(e.getSource()==ventGestBl.txtUbicacion){
            if(ventGestBl.txtUbicacion.getText().equals("Ingrese la ubicación")){
                ventGestBl.txtUbicacion.setText("");
                ventGestBl.txtUbicacion.setForeground(Color.black);
                
            }
            if(ventGestBl.txtCodigo.getText().isEmpty()){
                ventGestBl.txtCodigo.setText("Ingrese el código del bloque");
                ventGestBl.txtCodigo.setForeground(Color.gray);
            }
            if(ventGestBl.txtNombre.getText().isEmpty()){
                ventGestBl.txtNombre.setText("Ingrese el nombre del bloque");
                ventGestBl.txtNombre.setForeground(Color.gray);
            }
        }
        if(e.getSource()==ventGestBl.txtNombre){
            if(ventGestBl.txtNombre.getText().equals("Ingrese el nombre del bloque")){
                ventGestBl.txtNombre.setText("");
                ventGestBl.txtNombre.setForeground(Color.black);
                
            }
            if(ventGestBl.txtUbicacion.getText().isEmpty()){
                ventGestBl.txtUbicacion.setText("Ingrese la ubicación");
                ventGestBl.txtUbicacion.setForeground(Color.gray);
            }
            if(ventGestBl.txtCodigo.getText().isEmpty()){
                ventGestBl.txtCodigo.setText("Ingrese el código del bloque");
                ventGestBl.txtCodigo.setForeground(Color.gray);
            }
        }
        if(e.getSource()==ventGestBl.SpinNespacios){
            if(ventGestBl.txtNombre.getText().isEmpty()){
                ventGestBl.txtNombre.setText("Ingrese el nombre del bloque");
                ventGestBl.txtNombre.setForeground(Color.gray);
            }
            if(ventGestBl.txtUbicacion.getText().isEmpty()){
                ventGestBl.txtUbicacion.setText("Ingrese la ubicación");
                ventGestBl.txtUbicacion.setForeground(Color.gray);
            }
            if(ventGestBl.txtCodigo.getText().isEmpty()){
                ventGestBl.txtCodigo.setText("Ingrese el código del bloque");
                ventGestBl.txtCodigo.setForeground(Color.gray);
            }
        }
        if(e.getSource()==ventGestBl.SpinNpisos){
            if(ventGestBl.txtNombre.getText().isEmpty()){
                ventGestBl.txtNombre.setText("Ingrese el nombre del bloque");
                ventGestBl.txtNombre.setForeground(Color.gray);
            }
            if(ventGestBl.txtUbicacion.getText().isEmpty()){
                ventGestBl.txtUbicacion.setText("Ingrese la ubicación");
                ventGestBl.txtUbicacion.setForeground(Color.gray);
            }
            if(ventGestBl.txtCodigo.getText().isEmpty()){
                ventGestBl.txtCodigo.setText("Ingrese el código del bloque");
                ventGestBl.txtCodigo.setForeground(Color.gray);
            }
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
     
    }

    @Override
    public void mouseEntered(MouseEvent e) {
       
    }

    @Override
    public void mouseExited(MouseEvent e) {
     
    }

}

