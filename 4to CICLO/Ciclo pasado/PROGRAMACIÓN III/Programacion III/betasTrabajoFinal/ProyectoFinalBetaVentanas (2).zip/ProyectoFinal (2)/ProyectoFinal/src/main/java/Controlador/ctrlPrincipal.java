/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

/**
 *
 * @author aleca
 */
import Modelo.*;
import Vista.*;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
public class ctrlPrincipal implements ActionListener, MouseListener{
    PantallaPrin vista;
    GuardarUsuarios model; //modelo de la lista de usuarios
    Color col; //color de los txt
    Usuario user; //variable donde se guarda el usuario que inicio sesion
    
    public ctrlPrincipal(PantallaPrin vista) { //constructor
        
        this.vista = vista;
        this.vista.btnEntrar.addActionListener(this);
        this.vista.CrearCuenta.addMouseListener(this);
        this.vista.txtPass.addMouseListener(this);
        this.vista.txtUsuario.addMouseListener(this);
        col = this.vista.CrearCuenta.getForeground(); //color boton "aqui"
        PonerImagenes();
    }

    public Boolean validarDatos(){
        model = new GuardarUsuarios();
        model.abrirArchivo(); //abrimos el archivo
        int pos = model.Buscar(vista.txtUsuario.getText(), 0);//buscamos usuario

        String password = new String(vista.txtPass.getPassword());
        
        if(pos ==-1){
            return false;
        }else if(model.getUsuario(pos).getPassword().equals(password)==false){ //verificamos contrasenia
            return false;
        }
        user = model.getUsuario(pos); //si todo esta correcto gurdamos usuario que inicio sesion
        return true;
    }
    
    public void PonerImagenes(){
        
        //add imagen 
                                            
        ImageIcon imgBloques =new ImageIcon("escudo.png");
        Icon icono=new ImageIcon(imgBloques.getImage().getScaledInstance(vista.escudo.getWidth(), vista.escudo.getHeight(), Image.SCALE_DEFAULT));//para escaclar al tamanio del JLabel
        vista.escudo.setIcon(icono);
        this.vista.escudo.repaint();//para q se vea
        ////////////////////////////////////////////////////////////////////////
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(validarDatos()){ //validacion Contrasenia y usuario            
            VentGestion vent = new VentGestion();
            ctrlGestion control = new ctrlGestion(vent, vista, user);//inicio de sesion
            vista.setEnabled(false);
            vent.setVisible(true);
            vista.dispose();
        }else{
            JOptionPane.showMessageDialog(null, "Contraseña o nombre de usuario incorrectos");
         }
        
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource()==vista.CrearCuenta){ //para crear una cuenta en caso de no tener registrada
           VentCrearCuenta vent = new VentCrearCuenta();
           ctrlCrearCuenta control = new ctrlCrearCuenta(vent, vista);
           vista.setEnabled(false);
           vent.setVisible(true);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) { //mas es estetico... borrar letras txt
        if(e.getSource()==vista.txtUsuario){
            if(vista.txtUsuario.getText().equals("Ingrese su número de cédula")){
                vista.txtUsuario.setText("");
                vista.txtUsuario.setForeground(Color.black);
                
            }
            if(String.valueOf(vista.txtPass.getPassword()).isEmpty()){
                vista.txtPass.setText("password");
                vista.txtPass.setForeground(Color.gray);
            }
        }
        if(e.getSource()==vista.txtPass){
            if(String.valueOf(vista.txtPass.getPassword()).equals("password")){
                vista.txtPass.setText("");
                vista.txtPass.setForeground(Color.black);
            }
            if(vista.txtUsuario.getText().isEmpty()){
                vista.txtUsuario.setText("Ingrese su número de cédula");
                vista.txtUsuario.setForeground(Color.gray);
            }
                
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }
    @Override
    public void mouseEntered(MouseEvent e) {  //estetico
        if(e.getSource()==vista.CrearCuenta){ 
            vista.CrearCuenta.setForeground(Color.CYAN);
        }
    }
    @Override
    public void mouseExited(MouseEvent e) { //estetico
        vista.CrearCuenta.setForeground(col);
    }
    
}
