/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author aleca
 */
public class GuardarBloques {
    private ArrayList<Bloque> ListaBloques; //lista de usuarios

    public GuardarBloques() { //constructor
        ListaBloques = new ArrayList<>(); //reamos la lista
    }
    public void eliminarBloque(int pos){ // metodo para eliminar usuario
        ListaBloques.remove(pos);
    }
    
    //metodo para agregar el usuario de acuerdo al cargo
    public void AddBloque(String codigo, String nombre, int nPisos, int nEspacios, String ubicacion) {
            ListaBloques.add(new Bloque(codigo, nombre, nPisos, nEspacios, ubicacion));
    }
    
    //metodo para modificar el usuario de acuerdo al cargo
    public void setBloque(String codigo, String nombre, int nPisos, int nEspacios, String ubicacion, int pos) {
            ListaBloques.set(pos,new Bloque(codigo, nombre, nPisos, nEspacios, ubicacion));
        
    }
   
    public int TamLista(){ //retorna el tamanio de la lista
        return ListaBloques.size();
    }
    
    public int Buscar(String dato, int col){ //busacr un usuario
        int i = 0;
        while(i<ListaBloques.size()){
            if(col==0 && ListaBloques.get(i).getCodigo().equalsIgnoreCase(dato)){
                return i;
            }
            i++;
        }
        
        return -1; //si no existe
    }

    public Bloque getBloque(int pos) { //retorna el usuario en esa posicion
        return ListaBloques.get(pos);
    }
    
    public void abrirArchivo(){ //para abrir el archivo generado
        try{
            ObjectInputStream archivo;
            File path = new File("archivoDeUsuarios");
            if(path.exists()){
                archivo = new ObjectInputStream (new FileInputStream("archivoDeBloques"));
                ListaBloques = (ArrayList<Bloque>)archivo.readObject();
                archivo.close();
            }
        }catch(ClassNotFoundException e){
            
        }catch(IOException e){}
    }
    public void guardarDatos(){ //para guardar el archivo generado
        try{
            ObjectOutputStream archivo =new ObjectOutputStream (new FileOutputStream ("archivoDeBloques"));
            archivo.writeObject(ListaBloques); // Graba los objetos (el vector) \n" +
            archivo.flush(); // Vacía el buffer de salida\n" +
            archivo.close(); // cierra el archivo
        }catch(IOException e){
            JOptionPane.showMessageDialog(null, "Error al guardar el archivo");
        }
        
    }
    
}
