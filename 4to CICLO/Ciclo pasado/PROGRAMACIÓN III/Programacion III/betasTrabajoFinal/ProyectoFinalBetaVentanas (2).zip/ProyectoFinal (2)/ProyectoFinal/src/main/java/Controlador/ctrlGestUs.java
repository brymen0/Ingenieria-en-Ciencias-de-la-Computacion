/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.GuardarUsuarios;
import Modelo.validaciones;
import Vista.*;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author aleca
 */
public class ctrlGestUs implements ActionListener, MouseListener, KeyListener{
    VentGestion ventGest;
    VentGestUs ventGestUs;
    GuardarUsuarios model;
    validaciones valida  = new validaciones();//validar datos ingresados por el usuario
    private DefaultTableModel modelTable;//creamos la tabla
    public ctrlGestUs(VentGestUs ventGestUs, VentGestion ventGest) {
        this.ventGestUs = ventGestUs;
        model = new GuardarUsuarios();
        model.abrirArchivo(); //abrimos el archivo con los datos
        DefineTabla();
        cargarDatos();
        activarDesactivar(false);
        PonerImagen();
        this.ventGestUs.txtCedula.addKeyListener(this);
        this.ventGestUs.txtNombre.addKeyListener(this);
        this.ventGestUs.txtApellidos.addKeyListener(this);
        this.ventGestUs.txtEmail.addKeyListener(this);
        this.ventGestUs.txtTelefono.addKeyListener(this);
        this.ventGestUs.txtCargo.addKeyListener(this);
        
        this.ventGestUs.txtCedula.addMouseListener(this);
        this.ventGestUs.txtNombre.addMouseListener(this);
        this.ventGestUs.txtApellidos.addMouseListener(this);
        this.ventGestUs.txtEmail.addMouseListener(this);
        this.ventGestUs.txtTelefono.addMouseListener(this);
        this.ventGestUs.btnCancelar.addMouseListener(this);
        this.ventGestUs.btnGuardar.setVisible(false);
        this.ventGestUs.btnSalir.addActionListener(e->{
            this.ventGestUs.dispose();
            ventGest.setEnabled(true);

        });
        this.ventGestUs.btnRevisar.addActionListener(e->{ //mostrar los datos
            int pos = model.Buscar(ventGestUs.txtCedula.getText(), 0);
            if(pos ==-1){
                int op = JOptionPane.showConfirmDialog(null, "No existe el usuario. ¿Desea crear una cuenta?", "Advertencia", 0,1);
                if(op==0){
                    VentCrearCuenta ventCrear = new VentCrearCuenta();
                    ctrlCrearCuenta control = new ctrlCrearCuenta(ventCrear, ventGestUs);
                    ventGestUs.setEnabled(false); //bloqueamos la ventana principal
                    ventCrear.setVisible(true);
                }
            }else{
                mostrarDatos(pos);
            }
        });
        this.ventGestUs.btnActualizar.addActionListener(e->{ //boton para activar los campos para editar
            int pos = model.Buscar(ventGestUs.txtCedula.getText(), 0);
            if(pos ==-1){
                int op = JOptionPane.showConfirmDialog(null, "No existe el usuario. ¿Desea crear una cuenta?", "Advertencia", 0,1);
                if(op==0){
                    VentCrearCuenta ventCrear = new VentCrearCuenta();
                    ctrlCrearCuenta control = new ctrlCrearCuenta(ventCrear, ventGestUs);
                    ventGestUs.setEnabled(false);
                    ventCrear.setVisible(true);
                }
            }else{
                mostrarDatos(pos);
                activarDesactivar(true);
                
                
            }
        });
        this.ventGestUs.btnEliminar.addActionListener(e->{ //eliminar el usuario
            int pos = model.Buscar(ventGestUs.txtCedula.getText(), 0);
            if(pos ==-1){
                JOptionPane.showMessageDialog(null, "No existe el usuario que desea eliminar");
            }else{
                mostrarDatos(pos);
                int op = JOptionPane.showConfirmDialog(null, "¿Está seguro que desea eliminar este usuario?", "Advertencia", 0,1);
                if(op==0){
                    eliminarDatos(pos);
                    JOptionPane.showMessageDialog(null, "Usuario eliminado con éxito");
                    activarDesactivar(false);
                    limpiartxt();
                }
            }
        });
        this.ventGestUs.btnCancelar.addActionListener(e->{ 
            activarDesactivar(false);
            limpiartxt();
            
        });
        this.ventGestUs.btnGuardar.addActionListener(e->{ //para guardar los camobios realizados
            int pos = model.Buscar(ventGestUs.txtCedula.getText(), 0);
            int op = JOptionPane.showConfirmDialog(null, "¿Está seguro que desea guardar los cambios?", "Advertencia", 0,1);
                if(op==0){
                    actualizarDatos(pos);
                    JOptionPane.showMessageDialog(null, "Usuario actualizado");
                }
            activarDesactivar(false);
            
        });
    }
    public void PonerImagen(){
         //add imagen fondo
                                            
        ImageIcon image =new ImageIcon("fondo3.png");
        Icon icono=new ImageIcon(image.getImage().getScaledInstance(ventGestUs.Fondo.getWidth(), ventGestUs.Fondo.getHeight(), Image.SCALE_DEFAULT));//para escaclar al tamanio del JLabel
        ventGestUs.Fondo.setIcon(icono);
        this.ventGestUs.Fondo.repaint();//para q se vea
        ////////////////////////////////////////////////////////////////////////
    }
       
    public void limpiartxt(){ //limpiar textos
        this.ventGestUs.txtNombre.setText("");
        this.ventGestUs.txtApellidos.setText("");
        this.ventGestUs.txtEmail.setText("");
        this.ventGestUs.txtTelefono.setText("");
        this.ventGestUs.txtCargo.setText("");
    }
    
    public void DefineTabla(){ //creamos tabla
        String data[][]={};
        String col []={"CEDULA","NOMBRES","APELLIDOS","TELÉFONO","CARGO","EMAIL"}; 
        modelTable=new DefaultTableModel(data,col);
        ventGestUs.TblUsers.setModel(modelTable);
    }

    public void cargarDatos(){ //cargamos los datos en la tabla
        int i;
        int cuantos = modelTable.getRowCount();
        for(i = cuantos-1;i>=0;i--){
            modelTable.removeRow(i); 
        }
        for(i = 0; i<model.TamLista();i++){
            modelTable.insertRow(modelTable.getRowCount(), new Object[]{});
            Insertar_Datos_Tabla(model.getUsuario(i).getCedula(), model.getUsuario(i).getNombres(), model.getUsuario(i).getApellidos(), model.getUsuario(i).getTelefono(), model.getUsuario(i).getCargo(), model.getUsuario(i).getEmail());
        }
    }
     
    //insertar datos en la tabla
     public void Insertar_Datos_Tabla(String cedula, String nombre, String apellido, String telefono, String cargo, String email){
        modelTable.setValueAt(cedula, modelTable.getRowCount()-1, 0);
        modelTable.setValueAt(nombre, modelTable.getRowCount()-1, 1);
        modelTable.setValueAt(apellido, modelTable.getRowCount()-1, 2);
        modelTable.setValueAt(telefono, modelTable.getRowCount()-1, 3);
        modelTable.setValueAt(cargo, modelTable.getRowCount()-1, 4);
        modelTable.setValueAt(email, modelTable.getRowCount()-1, 5);
    }
     
    public void activarDesactivar(Boolean estado){ //ddescativar textos y botones
        this.ventGestUs.btnGuardar.setVisible(estado);
        this.ventGestUs.txtCedula.setEnabled(!estado);
        this.ventGestUs.txtNombre.setEnabled(estado);
        this.ventGestUs.txtApellidos.setEnabled(estado);
        this.ventGestUs.txtEmail.setEnabled(estado);
        this.ventGestUs.txtTelefono.setEnabled(estado);
        this.ventGestUs.txtCargo.setEnabled(estado);

    }
    
    public void mostrarDatos(int pos){ 
        this.ventGestUs.txtNombre.setText(model.getUsuario(pos).getNombres());
        this.ventGestUs.txtApellidos.setText(model.getUsuario(pos).getApellidos());
        this.ventGestUs.txtEmail.setText(model.getUsuario(pos).getEmail());
        this.ventGestUs.txtTelefono.setText(model.getUsuario(pos).getTelefono());
        this.ventGestUs.txtCargo.setText(model.getUsuario(pos).getCargo());
    }
    public void actualizarDatos(int pos){ //modificamos los datos
        model.setUsuario(ventGestUs.txtCedula.getText(), ventGestUs.txtNombre.getText(), ventGestUs.txtApellidos.getText(), ventGestUs.txtEmail.getText(), model.getUsuario(pos).getPassword(),ventGestUs.txtTelefono.getText(), ventGestUs.txtCargo.getText(), pos);
        model.guardarDatos();
        cargarDatos(); 
    }
    
    public void eliminarDatos(int pos){ //metodo para eliminar el usuario
       model.eliminarUsuario(pos);
       model.guardarDatos(); //guardamos
       cargarDatos(); //volvemos a cargar
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
    }

    @Override
    public void mouseClicked(MouseEvent e) {
      
    }

    @Override
    public void mousePressed(MouseEvent e) { //estetico para quitar y mostrar frase informativa
        if(e.getSource()==ventGestUs.txtCedula){
            if(ventGestUs.txtCedula.getText().equals("Ingrese el número de cédula")){
                ventGestUs.txtCedula.setText("");
                ventGestUs.txtCedula.setForeground(Color.black);
                
            }
        }
        
        if(e.getSource()==ventGestUs.txtTelefono){
            if(ventGestUs.txtCedula.getText().isEmpty()){
                ventGestUs.txtCedula.setText("Ingrese el número de cédula");
                ventGestUs.txtCedula.setForeground(Color.gray);
            }
        }
        if(e.getSource()==ventGestUs.txtNombre){
           
            if(ventGestUs.txtCedula.getText().isEmpty()){
                ventGestUs.txtCedula.setText("Ingrese el número de cédula");
                ventGestUs.txtCedula.setForeground(Color.gray);
            }
          
        }
        if(e.getSource()==ventGestUs.txtApellidos){
           
            if(ventGestUs.txtCedula.getText().isEmpty()){
                ventGestUs.txtCedula.setText("Ingrese el número de cédula");
                ventGestUs.txtCedula.setForeground(Color.gray);
            }
          
        }
        if(e.getSource()==ventGestUs.txtEmail){
         
            if(ventGestUs.txtCedula.getText().isEmpty()){
                ventGestUs.txtCedula.setText("Ingrese el número de cédula");
                ventGestUs.txtCedula.setForeground(Color.gray);
            }
           
        }
        if(e.getSource()==ventGestUs.btnCancelar){
         
            if(ventGestUs.txtCedula.getText().isEmpty()){
                ventGestUs.txtCedula.setText("Ingrese el número de cédula");
                ventGestUs.txtCedula.setForeground(Color.gray);
            }
           
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
       
    }

    @Override
    public void mouseExited(MouseEvent e) {
     
    }

    @Override
    public void keyTyped(KeyEvent e) {
        int tecla=e.getKeyChar();
        
        if(e.getSource()==ventGestUs.txtCedula || e.getSource()==ventGestUs.txtTelefono){ // validacion para que el usuario digite solo numeros
            boolean num = tecla>= 48 && tecla<=57;///valida que sea numeros del 0 al 9
            if(!num){
                e.consume();
            } 
        }
        if(e.getSource()==ventGestUs.txtNombre || e.getSource()==ventGestUs.txtApellidos){ //validacion para que digite solo letras y espacios
            boolean num= tecla>= 65 && tecla<=90 || tecla==165 || tecla==32;///valida que sea solo letras
            if(!num){
                e.consume();
            } 
        }
        if(e.getSource()==ventGestUs.txtCargo){ //validacion para que digite solo letras
            boolean num= tecla>= 65 && tecla<=90 || tecla==165;///valida que sea solo letras
            if(!num){
                e.consume();
            } 
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }
}
