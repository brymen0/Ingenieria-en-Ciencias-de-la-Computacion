/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.List;

/**
 *
 * @author aleca
 */
public class Espacios {
    private String codigo;
    private String descripcion;
    private String ubicacion;
    private short tipo;
    private int capacidad;
    private List<Elemento> element; 
    public Espacios(String codigo, short tipo, int capacidad) {
        this.codigo = codigo;
        this.tipo = tipo;
        this.capacidad = capacidad;    
    }

    public String getCodigo() {
        return codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public short getTipo() {
        return tipo;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public List<Elemento> getElement() {
        return element;
    }
    
    
}
