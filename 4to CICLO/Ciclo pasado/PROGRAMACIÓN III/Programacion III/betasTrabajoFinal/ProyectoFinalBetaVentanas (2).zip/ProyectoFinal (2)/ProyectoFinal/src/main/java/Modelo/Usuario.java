/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.io.Serializable;

/**
 *
 * @author aleca
 */
public class Usuario implements Serializable{
    //Variables que se utilizaran
    private String cedula;
    private String nombres;
    private String apellidos;
    private String email;
    private String password;
    private String telefono;
    private String cargo;

    //constructor
    public Usuario(String cedula, String nombres, String apellidos, String email, String password, String telefono, String cargo) {
        this.cedula = cedula;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.email = email;
        this.password = password;
        this.telefono = telefono;
        this.cargo = cargo;
    }
    
    //getters y setters
    public String getCedula() {
        return cedula;
    }

    public String getNombres() {
        return nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCargo() {
        return cargo;
    }
    
}
