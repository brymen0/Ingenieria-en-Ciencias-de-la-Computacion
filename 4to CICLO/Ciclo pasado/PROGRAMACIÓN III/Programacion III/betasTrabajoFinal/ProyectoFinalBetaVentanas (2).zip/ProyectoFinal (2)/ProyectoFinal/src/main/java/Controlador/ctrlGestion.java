/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.*;
import Vista.*;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author aleca
 */
public class ctrlGestion implements ActionListener, MouseListener{
    VentGestion vista;
    PantallaPrin ventPrin;
    private GuardarUsuarios model;
    private Usuario user;// obtener usuario que inicio sesion
    
    public ctrlGestion(VentGestion vista, PantallaPrin ventPrin, Usuario user) {  //constructor
        this.vista = vista;
        this.ventPrin = ventPrin; 
        this.user = user;
        PonerImagen();
        this.vista.JPusuarios.addMouseListener(this);
        this.vista.JPbloques.addMouseListener(this);
        this.vista.JPreserva.addMouseListener(this);
        this.vista.JPautorizar.addMouseListener(this);
        this.vista.JPagenda.addMouseListener(this);
        this.vista.btnSalir.addActionListener(e->{
            ventPrin.setEnabled(true);//activamos ventana principal
            this.vista.dispose(); //cerrar solo ventana
        });
        this.vista.btnCerrar.addActionListener(e->{ //si cerramos sesion nos vuelve a la pantalla principal
            this.ventPrin = new PantallaPrin();
            ctrlPrincipal control = new ctrlPrincipal(this.ventPrin);
            this.ventPrin.setVisible(true);
            this.vista.dispose();
        });
        model = new GuardarUsuarios();
        model.abrirArchivo();
    }
    public void PonerImagen(){
         //add imagen fondo
                                            
        ImageIcon imgBloques =new ImageIcon("fondo1.png");
        Icon icono=new ImageIcon(imgBloques.getImage().getScaledInstance(vista.lblFondo.getWidth(), vista.lblFondo.getHeight(), Image.SCALE_DEFAULT));//para escaclar al tamanio del JLabel
        vista.lblFondo.setIcon(icono);
        this.vista.lblFondo.repaint();//para q se vea
        ////////////////////////////////////////////////////////////////////////
        //add imagen fondo
                                            
        ImageIcon imgBloques23 =new ImageIcon("fondo3.png");
        Icon icono32=new ImageIcon(imgBloques23.getImage().getScaledInstance(vista.jLabel13.getWidth(), vista.jLabel13.getHeight(), Image.SCALE_DEFAULT));//para escaclar al tamanio del JLabel
        vista.jLabel13.setIcon(icono32);
        this.vista.jLabel13.repaint();//para q se vea
        ////////////////////////////////////////////////////////////////////////
        //add imagen gestionusuarios
                                            
        ImageIcon imgBloques1 =new ImageIcon("usuarios.png");
        Icon icono1=new ImageIcon(imgBloques1.getImage().getScaledInstance(vista.jLabel1.getWidth(), vista.jLabel1.getHeight(), Image.SCALE_DEFAULT));//para escaclar al tamanio del JLabel
        vista.jLabel1.setIcon(icono1);
        this.vista.jLabel1.repaint();//para q se vea
        ////////////////////////////////////////////////////////////////////////
        //add imagen gestionBloques
                                            
        ImageIcon imgBloques2 =new ImageIcon("bloque.png");
        Icon icono2=new ImageIcon(imgBloques2.getImage().getScaledInstance(vista.jLabel8.getWidth(), vista.jLabel8.getHeight(), Image.SCALE_DEFAULT));//para escaclar al tamanio del JLabel
        vista.jLabel8.setIcon(icono2);
        this.vista.jLabel8.repaint();//para q se vea
        ////////////////////////////////////////////////////////////////////////
        //add imagen reservar
                                            
        ImageIcon imgBloques3 =new ImageIcon("reservar.png");
        Icon icono3=new ImageIcon(imgBloques3.getImage().getScaledInstance(vista.jLabel9.getWidth(), vista.jLabel1.getHeight(), Image.SCALE_DEFAULT));//para escaclar al tamanio del JLabel
        vista.jLabel9.setIcon(icono3);
        this.vista.jLabel9.repaint();//para q se vea
        ////////////////////////////////////////////////////////////////////////
        //add imagen autorizar
                                            
        ImageIcon imgBloques4 =new ImageIcon("autorizar.png");
        Icon icono4=new ImageIcon(imgBloques4.getImage().getScaledInstance(vista.jLabel11.getWidth(), vista.jLabel11.getHeight(), Image.SCALE_DEFAULT));//para escaclar al tamanio del JLabel
        vista.jLabel11.setIcon(icono4);
        this.vista.jLabel11.repaint();//para q se vea
        ////////////////////////////////////////////////////////////////////////
        //add imagen agenda
                                            
        ImageIcon imgBloques5 =new ImageIcon("agendas.png");
        Icon icono5=new ImageIcon(imgBloques5.getImage().getScaledInstance(vista.jLabel12.getWidth(), vista.jLabel12.getHeight(), Image.SCALE_DEFAULT));//para escaclar al tamanio del JLabel
        vista.jLabel12.setIcon(icono5);
        this.vista.jLabel12.repaint();//para q se vea
        ////////////////////////////////////////////////////////////////////////
       
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
    }

    @Override
    public void mouseClicked(MouseEvent e) { 
        if(e.getSource()== vista.JPusuarios && (user.getCargo().equals("ADMINISTRADOR"))){//validamos solo puede ingresar el administrador
            VentGestUs ventUs = new VentGestUs();
            ctrlGestUs control = new ctrlGestUs(ventUs, vista);
            ventUs.setVisible(true);
            vista.setEnabled(false); //desactivar ventana
        }else if(e.getSource()== vista.JPbloques && (user.getCargo().equals("ADMINISTRADOR"))){ //validamos donde solo puede ingresar el administrador
            VentGestBl ventBl = new VentGestBl();
            ctrlGestionBl control = new ctrlGestionBl(ventBl, vista);
            ventBl.setVisible(true);
            vista.setEnabled(false);
        }else if(e.getSource()== vista.JPreserva && (!user.getCargo().equals("USUARIO"))){ //tipo boton donde no puede ingresar el usuario
            VentReservar ventRe = new VentReservar();
            ctrlReservar control = new ctrlReservar(ventRe, vista);
            ventRe.setVisible(true);
            vista.setEnabled(false);
        }else if(e.getSource()== vista.JPautorizar && (user.getCargo().equals("ADMINISTRADOR") || user.getCargo().equals("AUTORIZADOR"))){ //validamos solo puede acceder el administrador y autorizador
            VentAutorizar ventAut = new VentAutorizar();
            ctrlAutorizar control = new ctrlAutorizar(ventAut, vista);
            ventAut.setVisible(true);
            vista.setEnabled(false);
        }else if(e.getSource()== vista.JPagenda){ //pueden acceder todos
            VentAgenda ventAgen = new VentAgenda();
            ctrlAgenda control = new ctrlAgenda(ventAgen, vista);
            ventAgen.setVisible(true);
            vista.setEnabled(false);
        }else{
            JOptionPane.showMessageDialog(null, "Usted no tiene permiso para acceder a esta opción");
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
     
    }

    @Override
    public void mouseEntered(MouseEvent e) {
       
    }

    @Override
    public void mouseExited(MouseEvent e) {
     
    }
}
