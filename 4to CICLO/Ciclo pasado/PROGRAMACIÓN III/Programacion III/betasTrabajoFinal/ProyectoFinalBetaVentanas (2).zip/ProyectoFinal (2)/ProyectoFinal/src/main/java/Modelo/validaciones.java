/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author aleca
 */
public class validaciones {
    
    public boolean validarCedula(String cedula){
        boolean cedulaCorrecta = false;
        try {
            if (cedula.length() == 10){ // ConstantesApp.LongitudCedula
                int tercerDigito = Integer.parseInt(cedula.substring(2, 3));
                if (tercerDigito < 6) {
                    // Coeficientes de validación cédula
                    // El decimo digito se lo considera dígito verificador
                    int[] coefValCedula = { 2, 1, 2, 1, 2, 1, 2, 1, 2 };
                    int verificador = Integer.parseInt(cedula.substring(9,10));
                    int suma = 0;
                    int digito = 0;
                    for (int i = 0; i < (cedula.length() - 1); i++) {
                        digito = Integer.parseInt(cedula.substring(i, i + 1))* coefValCedula[i];
                        suma += ((digito % 10) + (digito / 10));
                    }

                    if ((suma % 10 == 0) && (suma % 10 == verificador)) {
                        cedulaCorrecta = true;
                    } else if ((10 - (suma % 10)) == verificador) {
                        cedulaCorrecta = true;
                    } else {
                     cedulaCorrecta = false;
                    }
                } else {
                    cedulaCorrecta = false;
                }
            } else {
                cedulaCorrecta = false;
            }
        } catch (NumberFormatException nfe) {
            cedulaCorrecta = false;
        } catch (Exception err) {
            cedulaCorrecta = false;
        }
        return cedulaCorrecta;
    } //metodo para validar la cedula
  
    
    ////////////////////////////////////////////////////////////////////////////
    //Validar Telefono
    public boolean validarTelefono(String cadena){
        //int num;
	       System.out.println(cadena.length());
        if(cadena.length()==10)
            return true;
	return false;
    }
    
    ////////////////////////////////////////////////////////////////////////////
    //Validar Solo Letras
    public boolean validarSoloLetra(String cadena)
    {
        //Recorremos cada caracter de la cadena y comprobamos si son letras.
        //Para comprobarlo, lo pasamos a mayuscula y consultamos su numero ASCII.
        //Si está fuera del rango 65 - 90, es que NO son letras.
        //el valor 165 equivalente a la Ñ
        if(cadena.length()==0)return false;
        for (int i = 0; i < cadena.length(); i++)
        {
                char caracter = cadena.toUpperCase().charAt(i);
                int valorASCII = (int)caracter;
                if (valorASCII != 165 && (valorASCII < 65 || valorASCII > 90) && valorASCII != 32)
                        return false; //Se ha encontrado un caracter que no es letra
        }

        //Terminado el bucle sin que se haya retornado false, es que todos los caracteres son letras
        return true;
    }
    
    ////////////////////////////////////////////////////////////////////////////
    //Validar Email
    public boolean validarEmail(String cadena){ //metodo para validar email
       // Patrón para validar el email
        Pattern pattern = Pattern //se le pasa una expresion regular
                .compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@ucuenca.edu.ec");//siempre debe ser @ucuenca.edu.ec
        
        // El email a validar
        Matcher mather = pattern.matcher(cadena);

        if (mather.find()) {
            return true; 
        } else {
            return false; 
        } 
        
    }
}
