/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.proyectofinal;

import Controlador.ctrlPrincipal;
import Vista.PantallaPrin;

/**
 *
 * @author aleca
 */
public class ProyectoFinal {

    public static void main(String[] args) {
        PantallaPrin vista = new PantallaPrin();
  
        ctrlPrincipal control = new ctrlPrincipal(vista);
        
        vista.setVisible(true);
    }
}
