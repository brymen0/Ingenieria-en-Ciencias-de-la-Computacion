/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author aleca
 */
public class Bloque {
    private String nombre;
    private String codigo;
    private int nPisos;
    private int nEspacios;
    private String ubicacion; 
    private ArrayList<Espacios> ListaEspacios; //lista de usuarios
    
    public Bloque(String codigo, String nombre, int nPisos, int nEspacios, String ubicacion) { //Constructor
        this.codigo = codigo;
        this.nEspacios = nEspacios;
        this.nombre = nombre;
        this.nPisos = nPisos;
        this.ubicacion = ubicacion;
        
    }

    public String getCodigo() {
        return codigo;
    }

    public int getnEspacios() {
        return nEspacios;
    }
    public String getNombre() {
        return nombre;
    }

    public int getnPisos() {
        return nPisos;
    }

    public String getUbicacion() {
        return ubicacion;
    }
    public void eliminarEspacio(int pos){ // metodo para eliminar usuario
        ListaEspacios.remove(pos);
    }
    
    //metodo para agregar el usuario de acuerdo al cargo
    public void AddEspacio(String codigo, short tipo, int capacidad) {
            ListaEspacios = new ArrayList<>(); //reamos la lista
            ListaEspacios.add(new Espacios(codigo, tipo, capacidad));
    }
    
    //metodo para modificar el usuario de acuerdo al cargo
    public void setEspacio(String codigo, short tipo, int capacidad, int pos) {
            ListaEspacios.set(pos,new Espacios(codigo, tipo, capacidad));
        
    }
   
    public int TamLista(){ //retorna el tamanio de la lista
        return ListaEspacios.size();
    }
    
    public int Buscar(String dato, int col){ //busacr un usuario
        int i = 0;
        while(i<ListaEspacios.size()){
            if(col==0 && ListaEspacios.get(i).getCodigo().equalsIgnoreCase(dato)){
                return i;
            }
            i++;
        }
        
        return -1; //si no existe
    }

    public Espacios getEspacios(int pos) { //retorna el usuario en esa posicion
        return ListaEspacios.get(pos);
    }
}
