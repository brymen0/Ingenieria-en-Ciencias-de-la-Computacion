   /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.GuardarUsuarios;
import Modelo.validaciones;
import Vista.*;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 * v
 * @author aleca
 */
public class ctrlCrearCuenta implements ActionListener, MouseListener, KeyListener{
    VentCrearCuenta ventCrear;
    GuardarUsuarios model;
    validaciones valida  = new validaciones();
    
    public ctrlCrearCuenta(VentCrearCuenta ventCrear, PantallaPrin ventPrin) {
        this.ventCrear = ventCrear;
        Llamadas();
        PonerImagen();
        this.ventCrear.btnSalir.addActionListener(e->{
            int op = JOptionPane.showConfirmDialog(null, "Desea salir sin guardar los cambios", "Advertencia", 0,1);
            if(op==0){
                this.ventCrear.dispose();
                ventPrin.setEnabled(true);
               
            }
        });
        this.ventCrear.btnCrear.addActionListener(e->{
            if(validarDatos()==true){
                if(agregarUsuario()){
                    ventPrin.setEnabled(true);
                }
                
            }else{
                JOptionPane.showMessageDialog(null, "Ingrese los datos correctamente");
            }
            
        });
    }
    
    public ctrlCrearCuenta(VentCrearCuenta ventCrear, VentGestUs ventGestUs) {
        this.ventCrear = ventCrear;
        Llamadas();
        this.ventCrear.btnSalir.addActionListener(e->{
            int op = JOptionPane.showConfirmDialog(null, "Desea salir sin guardar los cambios", "Advertencia", 0,1);
            if(op==0){
                this.ventCrear.dispose();
                ventGestUs.setEnabled(true);
               
            }
        });
        this.ventCrear.btnCrear.addActionListener(e->{
            if(validarDatos()){
                if(agregarUsuario()){
                    ventGestUs.setEnabled(true);
                }
            }else{
                JOptionPane.showMessageDialog(null, "Ingrese los datos correctamente");
            }
            
        });
    }
     public void PonerImagen(){
         //add imagen fondo
                                            
        ImageIcon image =new ImageIcon("fondo3.png");
        Icon icono=new ImageIcon(image.getImage().getScaledInstance(ventCrear.Fondo.getWidth(), ventCrear.Fondo.getHeight(), Image.SCALE_DEFAULT));//para escaclar al tamanio del JLabel
        ventCrear.Fondo.setIcon(icono);
        this.ventCrear.Fondo.repaint();//para q se vea
        ////////////////////////////////////////////////////////////////////////
        
        //add imagen fondo
                                            
        ImageIcon image1 =new ImageIcon("escudo.png");
        Icon icono1=new ImageIcon(image1.getImage().getScaledInstance(ventCrear.jLabel6.getWidth(), ventCrear.jLabel6.getHeight(), Image.SCALE_DEFAULT));//para escaclar al tamanio del JLabel
        ventCrear.jLabel6.setIcon(icono1);
        this.ventCrear.jLabel6.repaint();//para q se vea
        ////////////////////////////////////////////////////////////////////////
    }
    public void Llamadas(){
        ventCrear.txtCedula.addMouseListener(this);
        ventCrear.txtCedula.addKeyListener(this);
        
        ventCrear.txtNombre.addMouseListener(this);
        ventCrear.txtCedula.addKeyListener(this);
        
        ventCrear.txtApellidos.addMouseListener(this);
        ventCrear.txtApellidos.addKeyListener(this);
        
        ventCrear.txtEmail.addMouseListener(this);
        ventCrear.txtEmail.addKeyListener(this);
        
        ventCrear.txtTelefono.addMouseListener(this);
        ventCrear.txtTelefono.addKeyListener(this);
        
        ventCrear.comboCargo.addActionListener(this);
        ventCrear.txtPass.addMouseListener(this);
    }
    
    public boolean agregarUsuario(){
        model = new GuardarUsuarios();
        model.abrirArchivo();
        if(model.Buscar(ventCrear.txtCedula.getText(), 0)==-1){
            String password = new String(ventCrear.txtPass.getPassword()); 
            model.AddUsuario(ventCrear.txtCedula.getText(), ventCrear.txtNombre.getText(), ventCrear.txtApellidos.getText(), ventCrear.txtEmail.getText(), password,ventCrear.txtTelefono.getText(), ventCrear.comboCargo.getSelectedItem().toString());
            model.guardarDatos();
            JOptionPane.showMessageDialog(null, "Cuenta creada");
            this.ventCrear.dispose();
            return true;
        }else{
            JOptionPane.showMessageDialog(null, "Ya existe una cuenta asociada a este número de cédula");
            return false;
        }
        
    }
    public Boolean validarDatos(){
        Boolean verificar = true;
        if(!valida.validarCedula(ventCrear.txtCedula.getText())){
            ventCrear.SepCed.setForeground(Color.red);
            verificar = false;
        }else ventCrear.SepCed.setForeground(Color.black);
        
        if(ventCrear.txtNombre.getText().isEmpty() || ventCrear.txtNombre.getText().equals("Nombres")){
                ventCrear.SepNom.setForeground(Color.red);
            verificar = false;
        }else ventCrear.SepNom.setForeground(Color.black);
        
        if(ventCrear.txtApellidos.getText().isEmpty() || ventCrear.txtApellidos.getText().equals("Apellidos")){
            ventCrear.SepApe.setForeground(Color.red);
            verificar = false;
        }else ventCrear.SepApe.setForeground(Color.black);
        
        if(!valida.validarTelefono(ventCrear.txtTelefono.getText())){
            ventCrear.SepTel.setForeground(Color.red);
            verificar = false;
        }else ventCrear.SepTel.setForeground(Color.black);
        
        if(!valida.validarEmail(ventCrear.txtEmail.getText())){
            ventCrear.SepEmail.setForeground(Color.red);
            verificar = false;
        }else ventCrear.SepEmail.setForeground(Color.black);
        
        if(String.valueOf(ventCrear.txtPass.getPassword()).isEmpty() || String.valueOf(ventCrear.txtPass.getPassword()).equals("password")){
            ventCrear.SepPass.setForeground(Color.red);
            verificar = false;
        }else ventCrear.SepPass.setForeground(Color.black);
        return verificar;
    }
    
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {    
    }

    @Override
    public void mouseClicked(MouseEvent e) { 
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if(e.getSource()==ventCrear.txtCedula){
            if(ventCrear.txtCedula.getText().equals("Ingrese su número de cédula")){
                ventCrear.txtCedula.setText("");
                ventCrear.txtCedula.setForeground(Color.black);
                
            }
            if(ventCrear.txtTelefono.getText().isEmpty()){
                ventCrear.txtTelefono.setText("Ingrese su número de teléfono");
                ventCrear.txtTelefono.setForeground(Color.gray);
            }
            if(ventCrear.txtNombre.getText().isEmpty()){
                ventCrear.txtNombre.setText("Nombres");
                ventCrear.txtNombre.setForeground(Color.gray);
            }
            if(ventCrear.txtApellidos.getText().isEmpty()){
                ventCrear.txtApellidos.setText("Apellidos");
                ventCrear.txtApellidos.setForeground(Color.gray);
            }
            if(ventCrear.txtEmail.getText().isEmpty()){
                ventCrear.txtEmail.setText("Ingrese su email: ejemploemail@ucuenca.edu.ec");
                ventCrear.txtEmail.setForeground(Color.gray);
            }
            if(String.valueOf(ventCrear.txtPass.getPassword()).isEmpty()){
                ventCrear.txtPass.setText("password");
                ventCrear.txtPass.setForeground(Color.gray);
            }
        }
        
        if(e.getSource()==ventCrear.txtTelefono){
            if(ventCrear.txtTelefono.getText().equals("Ingrese su número de teléfono")){
                ventCrear.txtTelefono.setText("");
                ventCrear.txtTelefono.setForeground(Color.black);
                
            }
            if(ventCrear.txtCedula.getText().isEmpty()){
                ventCrear.txtCedula.setText("Ingrese su número de cédula");
                ventCrear.txtCedula.setForeground(Color.gray);
            }
            if(ventCrear.txtNombre.getText().isEmpty()){
                ventCrear.txtNombre.setText("Nombres");
                ventCrear.txtNombre.setForeground(Color.gray);
            }
            if(ventCrear.txtApellidos.getText().isEmpty()){
                ventCrear.txtApellidos.setText("Apellidos");
                ventCrear.txtApellidos.setForeground(Color.gray);
            }
            if(ventCrear.txtEmail.getText().isEmpty()){
                ventCrear.txtEmail.setText("Ingrese su email: ejemploemail@ucuenca.edu.ec");
                ventCrear.txtEmail.setForeground(Color.gray);
            }
            if(String.valueOf(ventCrear.txtPass.getPassword()).isEmpty()){
                ventCrear.txtPass.setText("password");
                ventCrear.txtPass.setForeground(Color.gray);
            }
        }
        if(e.getSource()==ventCrear.txtNombre){
            if(ventCrear.txtNombre.getText().equals("Nombres")){
                ventCrear.txtNombre.setText("");
                ventCrear.txtNombre.setForeground(Color.black);
                
            }
            if(ventCrear.txtCedula.getText().isEmpty()){
                ventCrear.txtCedula.setText("Ingrese su número de cédula");
                ventCrear.txtCedula.setForeground(Color.gray);
            }
            if(ventCrear.txtTelefono.getText().isEmpty()){
                ventCrear.txtTelefono.setText("Ingrese su número de teléfono");
                ventCrear.txtTelefono.setForeground(Color.gray);
            }
            if(ventCrear.txtApellidos.getText().isEmpty()){
                ventCrear.txtApellidos.setText("Apellidos");
                ventCrear.txtApellidos.setForeground(Color.gray);
            }
            if(ventCrear.txtEmail.getText().isEmpty()){
                ventCrear.txtEmail.setText("Ingrese su email: ejemploemail@ucuenca.edu.ec");
                ventCrear.txtEmail.setForeground(Color.gray);
            }
            if(String.valueOf(ventCrear.txtPass.getPassword()).isEmpty()){
                ventCrear.txtPass.setText("password");
                ventCrear.txtPass.setForeground(Color.gray);
            }
        }
        if(e.getSource()==ventCrear.txtApellidos){
            if(ventCrear.txtApellidos.getText().equals("Apellidos")){
                ventCrear.txtApellidos.setText("");
                ventCrear.txtApellidos.setForeground(Color.black);
                
            }
            if(ventCrear.txtCedula.getText().isEmpty()){
                ventCrear.txtCedula.setText("Ingrese su número de cédula");
                ventCrear.txtCedula.setForeground(Color.gray);
            }
            if(ventCrear.txtTelefono.getText().isEmpty()){
                ventCrear.txtTelefono.setText("Ingrese su número de teléfono");
                ventCrear.txtTelefono.setForeground(Color.gray);
            }
            if(ventCrear.txtNombre.getText().isEmpty()){
                ventCrear.txtNombre.setText("Nombres");
                ventCrear.txtNombre.setForeground(Color.gray);
            }
            if(ventCrear.txtEmail.getText().isEmpty()){
                ventCrear.txtEmail.setText("Ingrese su email: ejemploemail@ucuenca.edu.ec");
                ventCrear.txtEmail.setForeground(Color.gray);
            }
            if(String.valueOf(ventCrear.txtPass.getPassword()).isEmpty()){
                ventCrear.txtPass.setText("password");
                ventCrear.txtPass.setForeground(Color.gray);
            }
        }
        if(e.getSource()==ventCrear.txtEmail){
            if(ventCrear.txtEmail.getText().equals("Ingrese su email: ejemploemail@ucuenca.edu.ec")){
                ventCrear.txtEmail.setText("");
                ventCrear.txtEmail.setForeground(Color.black);
                
            }
            if(ventCrear.txtCedula.getText().isEmpty()){
                ventCrear.txtCedula.setText("Ingrese su número de cédula");
                ventCrear.txtCedula.setForeground(Color.gray);
            }
            if(ventCrear.txtTelefono.getText().isEmpty()){
                ventCrear.txtTelefono.setText("Ingrese su número de teléfono");
                ventCrear.txtTelefono.setForeground(Color.gray);
            }
            if(ventCrear.txtNombre.getText().isEmpty()){
                ventCrear.txtNombre.setText("Nombres");
                ventCrear.txtNombre.setForeground(Color.gray);
            }
            if(ventCrear.txtApellidos.getText().isEmpty()){
                ventCrear.txtApellidos.setText("Apellidos");
                ventCrear.txtApellidos.setForeground(Color.gray);
            }
            if(String.valueOf(ventCrear.txtPass.getPassword()).isEmpty()){
                ventCrear.txtPass.setText("password");
                ventCrear.txtPass.setForeground(Color.gray);
            }
        }
        if(e.getSource()==ventCrear.txtPass){
            if(String.valueOf(ventCrear.txtPass.getPassword()).equals("password")){
                ventCrear.txtPass.setText("");
                ventCrear.txtPass.setForeground(Color.black);
            }
            if(ventCrear.txtCedula.getText().isEmpty()){
                ventCrear.txtCedula.setText("Ingrese su número de cédula");
                ventCrear.txtCedula.setForeground(Color.gray);
            }
            if(ventCrear.txtTelefono.getText().isEmpty()){
                ventCrear.txtTelefono.setText("Ingrese su número de teléfono");
                ventCrear.txtTelefono.setForeground(Color.gray);
            }
            if(ventCrear.txtNombre.getText().isEmpty()){
                ventCrear.txtNombre.setText("Nombres");
                ventCrear.txtNombre.setForeground(Color.gray);
            }
            if(ventCrear.txtApellidos.getText().isEmpty()){
                ventCrear.txtApellidos.setText("Apellidos");
                ventCrear.txtApellidos.setForeground(Color.gray);
            }
            if(ventCrear.txtEmail.getText().isEmpty()){
                ventCrear.txtEmail.setText("Ingrese su email: ejemploemail@ucuenca.edu.ec");
                ventCrear.txtEmail.setForeground(Color.gray);
            }              
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
       
    }

    @Override
    public void mouseExited(MouseEvent e) {
     
    }

    @Override
    public void keyTyped(KeyEvent e) {
        int tecla=e.getKeyChar();
        
        if(e.getSource()==ventCrear.txtCedula || e.getSource()==ventCrear.txtTelefono){
            boolean num = tecla>= 48 && tecla<=57;///valida que sea numeros del 0 al 9
            if(!num){
                e.consume();
            } 
        }
        if(e.getSource()==ventCrear.txtNombre || e.getSource()==ventCrear.txtApellidos){
            boolean num= tecla>= 65 && tecla<=90 || tecla==165 || tecla==32;///valida que sea solo letras
            if(!num){
                e.consume();
            } 
        }
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }
}