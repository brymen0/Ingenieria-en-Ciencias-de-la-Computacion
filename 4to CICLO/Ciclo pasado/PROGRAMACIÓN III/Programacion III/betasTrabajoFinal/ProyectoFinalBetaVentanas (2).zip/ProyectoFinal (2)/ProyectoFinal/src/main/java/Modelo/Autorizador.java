/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author aleca
 */
public class Autorizador extends Usuario{

    public Autorizador(String cedula, String nombres, String apellidos, String email, String password, String telefono, String cargo) {
        super(cedula, nombres, apellidos, email, password, telefono, cargo);
    }

   
    
}
