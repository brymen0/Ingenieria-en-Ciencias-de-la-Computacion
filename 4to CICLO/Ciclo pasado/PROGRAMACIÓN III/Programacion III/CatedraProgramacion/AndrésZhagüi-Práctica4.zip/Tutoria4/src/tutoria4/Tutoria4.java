/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tutoria4;

import controlador.Control;
import vista.Ventana;

/**
 *
 * @author Andrés Zhagüi
 */
public class Tutoria4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Ventana vista = new Ventana();
        Control ctrl = new Control(vista);
        vista.setVisible(true);
    }
    
}
