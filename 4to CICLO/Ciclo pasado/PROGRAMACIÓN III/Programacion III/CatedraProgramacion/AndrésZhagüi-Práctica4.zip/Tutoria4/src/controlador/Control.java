/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import vista.Ventana;

/**
 *
 * @author Andrés Zhagüi
 */
public class Control implements ActionListener {
    private Ventana vista;
    
    public Control(Ventana vista){
        this.vista = vista;
        
        this.vista.agregar.addActionListener(this);
    } 

    @Override
    public void actionPerformed(ActionEvent e) {
        String text = this.vista.ingreso.getText();
            
        if(!text.trim().isEmpty()){
            JButton boton = vista.addButton(text);
              
            boton.addActionListener(e1 ->{
                vista.removeButton(boton);
            });
        }else{
            Toolkit.getDefaultToolkit().beep();
        }    
    }
}
