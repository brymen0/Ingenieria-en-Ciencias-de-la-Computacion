/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Andrés Zhagüi
 */
public class Ventana extends JFrame {   
    public Ventana(){
        setTitle("Botones");
        setBounds(400,100,300,200);
	
        PanelIngreso panel = new PanelIngreso();
        panel1 = new PanelBotones();
	add(panel,BorderLayout.NORTH);
        add(panel1,BorderLayout.CENTER);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }  
    
    private class PanelIngreso extends JPanel{	
        public PanelIngreso() {       
            setLayout(new BorderLayout());

            ingreso = new JTextField();
            add(ingreso,BorderLayout.CENTER);
            
            agregar = new JButton("Agregar");
            add(agregar,BorderLayout.EAST);
        }
    }
    
    private class PanelBotones extends JPanel {
        public PanelBotones(){
            setLayout(new GridLayout(0,5));
        }
    }
    
    public JButton addButton(String nombre){
        JButton nuevo = new JButton(nombre);
        
        panel1.add(nuevo);
        panel1.revalidate();
        panel1.repaint();
        
        return nuevo;
    }
    
    public void removeButton(JButton remover){
        panel1.remove(remover);
        panel1.revalidate();
        panel1.repaint();
    }
    
    public JTextField ingreso;
    public JButton agregar;
    private PanelBotones panel1;
}



