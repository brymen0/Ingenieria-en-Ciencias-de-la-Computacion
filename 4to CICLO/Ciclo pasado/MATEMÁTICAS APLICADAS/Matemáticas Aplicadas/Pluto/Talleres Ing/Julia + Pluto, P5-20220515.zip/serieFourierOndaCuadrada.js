// Variables
let k = 100;
let N = 50;
let t = 0;
let onda = [];

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  translate(150,200);
  let x = 0;
  let y = 0;

  for (let i = 1; i <=N; i++ ){
    let prevx = x;
    let prevy = y;
    let n = 2*i-1;
    let bn = (4*k)/(n*PI);
    x += bn * cos(n*t);
    y += bn * sin(n*t);

    //circunferencia
    stroke(255, 100);
    noFill();
    ellipse(prevx,prevy,2*bn);

    // radio
    stroke(255);
    line(prevx,prevy,x,y);
  }

  onda.unshift(y);
  translate(200,0);
  line(x-200,y, 0, onda[0]);
  beginShape();
  for (let i =0; i < onda.length; i++){
    vertex(i, onda[i]);
  }

  endShape();

  t -= 0.05;
}
