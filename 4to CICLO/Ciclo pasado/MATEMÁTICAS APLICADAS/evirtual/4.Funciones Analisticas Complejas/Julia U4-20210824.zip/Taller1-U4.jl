### A Pluto.jl notebook ###
# v0.14.7

using Markdown
using InteractiveUtils

# ╔═╡ b589b98e-e974-11eb-23e1-2f1b782d2d14
using SymPy

# ╔═╡ 9d5a9f90-ea03-4a57-94a6-08c6524336bf
using Plots

# ╔═╡ f9b1ea61-940d-4039-b892-624958820b19
import_from(sympy, (:re, :im,))

# ╔═╡ fd2c8a8e-ca0b-4b62-82ae-cf27e429c631
I=sympy.I

# ╔═╡ d6e95162-541a-480c-b62b-fe69c54e282c
x,y,u,v,r,θ = symbols("x y u v r θ", real=true)

# ╔═╡ c6907ee0-5b68-45d7-b4ac-22d986e93dc8
f(z)=z^2

# ╔═╡ 3ff82474-dc03-41f9-9d28-3b388d6bb6b5
re(f(x+I*y))

# ╔═╡ 97ed7967-3f4c-412b-83cc-3fab4b31b9ea
begin
	us1 = [re(f(x+I*y)).subs([(x,1/2),(y,a)]) for a in range(-3,stop=3,length=20)]
	vs1 = [im(f(x+I*y)).subs([(x,1/2),(y,a)]) for a in range(-3,stop=3,length=20)]
	plot(us1,vs1, label="x=1/2", xlabel="u", ylabel="v", title="plano w")
	us1 = [re(f(x+I*y)).subs([(x,1),(y,a)]) for a in range(-3,stop=3,length=20)]
	vs1 = [im(f(x+I*y)).subs([(x,1),(y,a)]) for a in range(-3,stop=3,length=20)]
	plot!(us1,vs1, label="x=1")
end

# ╔═╡ ded22be6-a14f-4ee4-be50-9f9a01201988
g(z)=z+1/z

# ╔═╡ 519a8c31-9d8f-444c-845e-598dc8f1f7fd
re(g(r*exp(I*θ)))

# ╔═╡ 16400e4b-c665-4445-90d4-e277e3c61663
im(g(r*exp(I*θ)))

# ╔═╡ 5d054c1a-5ec3-40ad-a394-7583dd7eb298
uqe=sympy.Eq(re(g(r*exp(I*θ))),u)

# ╔═╡ 1eff5744-515e-48ea-92fa-bc7799e838bf
vqe=sympy.Eq(im(g(r*exp(I*θ))),v)

# ╔═╡ 01e84417-be79-4b25-b632-2c3f26ee07bc
a=sympy.solve(uqe, cos(θ))[1]

# ╔═╡ 3c0ec687-cd9b-400e-8abd-9186fd1a47e7
b=sympy.solve(vqe, sin(θ))[1]

# ╔═╡ 197c1184-2e5a-46f4-a0ce-1c519a0679c0
elipse=sympy.Eq(a^2+b^2 , ((sin(θ))^2+(cos(θ))^2).simplify()).subs(r,2)

# ╔═╡ 76c27877-2bf3-46cc-b866-ffcaf19a1df9
sympy.plotting.plot_implicit(elipse, (u, -3, 3), (v,-2,2))

# ╔═╡ cf17eb94-2fc7-4754-8dc4-a179d77114b6
h(z)=(z-I)/-I*z+1

# ╔═╡ a3be678c-83c4-498b-8f52-7c10f05c5506
re(h(x+I*y))

# ╔═╡ d81873f2-5a2c-4652-b408-a0accc5cf41e
im(h(x+I*y))

# ╔═╡ 5b939e24-28e3-4d76-b4aa-526a2948be01
re(h(r*exp(I*θ)))

# ╔═╡ 255f64be-de87-411e-b095-79e6e9d6187f
im(h(r*exp(I*θ)))

# ╔═╡ Cell order:
# ╠═b589b98e-e974-11eb-23e1-2f1b782d2d14
# ╠═9d5a9f90-ea03-4a57-94a6-08c6524336bf
# ╠═f9b1ea61-940d-4039-b892-624958820b19
# ╠═fd2c8a8e-ca0b-4b62-82ae-cf27e429c631
# ╠═d6e95162-541a-480c-b62b-fe69c54e282c
# ╠═c6907ee0-5b68-45d7-b4ac-22d986e93dc8
# ╠═3ff82474-dc03-41f9-9d28-3b388d6bb6b5
# ╠═97ed7967-3f4c-412b-83cc-3fab4b31b9ea
# ╠═ded22be6-a14f-4ee4-be50-9f9a01201988
# ╠═519a8c31-9d8f-444c-845e-598dc8f1f7fd
# ╠═16400e4b-c665-4445-90d4-e277e3c61663
# ╠═5d054c1a-5ec3-40ad-a394-7583dd7eb298
# ╠═1eff5744-515e-48ea-92fa-bc7799e838bf
# ╠═01e84417-be79-4b25-b632-2c3f26ee07bc
# ╠═3c0ec687-cd9b-400e-8abd-9186fd1a47e7
# ╠═197c1184-2e5a-46f4-a0ce-1c519a0679c0
# ╠═76c27877-2bf3-46cc-b866-ffcaf19a1df9
# ╠═cf17eb94-2fc7-4754-8dc4-a179d77114b6
# ╠═a3be678c-83c4-498b-8f52-7c10f05c5506
# ╠═d81873f2-5a2c-4652-b408-a0accc5cf41e
# ╠═5b939e24-28e3-4d76-b4aa-526a2948be01
# ╠═255f64be-de87-411e-b095-79e6e9d6187f
