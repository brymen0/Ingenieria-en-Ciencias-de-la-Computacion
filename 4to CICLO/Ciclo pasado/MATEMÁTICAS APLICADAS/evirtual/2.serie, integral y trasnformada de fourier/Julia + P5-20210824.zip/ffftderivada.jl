### A Pluto.jl notebook ###
# v0.14.5

using Markdown
using InteractiveUtils

# ╔═╡ 2b4964b2-b7fc-11eb-10f3-c747d2c4f49a
begin
	using Plots
	using FFTW
	using LaTeXStrings
end

# ╔═╡ 2c0db621-06ee-4fbc-9857-c3c225ceda5a
begin
	n = 64
	L = 30
	dx = L/n
	xs = range(-L/2, L/2, length=n)
	f(x) = cos(x) * exp(-x^2/25)
	g(x) = -sin(x) * exp(-x^2/25) + (2/25)*x*f(x)
	#fs = cos.(xs) .* exp.(-(xs.^2)/25)
	fs = f.(xs)
	gs = g.(xs)
end

# ╔═╡ 5b03dbaf-9d13-4f7d-beb8-004f63cde752
begin
	Plots.plot(fs, label=L"f(x)")
	Plots.plot!(gs, label=L"f'(x)")
end

# ╔═╡ 7f29c88d-2b52-413e-898b-fea1fa569435
begin
	fhat = fft(fs)
	#i * w * fhat
	freqs = 2*pi*fftfreq(length(fhat),1/dx)
	dfhat = im * freqs .* fhat # derivada de f en fourier
	dfFFT = real.(ifft(dfhat))
	Plots.plot(dfFFT, label=L"f'_{FFT}")
	Plots.plot!(gs, label=L"f'")
	Plots.plot!(fs, label=L"f", linestyle=:dot)
end

# ╔═╡ 047f07a5-8ed0-4da5-bc2a-0091d226fb07


# ╔═╡ Cell order:
# ╠═2b4964b2-b7fc-11eb-10f3-c747d2c4f49a
# ╠═2c0db621-06ee-4fbc-9857-c3c225ceda5a
# ╠═5b03dbaf-9d13-4f7d-beb8-004f63cde752
# ╠═7f29c88d-2b52-413e-898b-fea1fa569435
# ╠═047f07a5-8ed0-4da5-bc2a-0091d226fb07
