### A Pluto.jl notebook ###
# v0.14.5

using Markdown
using InteractiveUtils

# ╔═╡ e21fa9d0-b694-11eb-2606-cd02c4ded85f
using SymPy

# ╔═╡ f5e0abeb-dd1f-497d-a33f-6840f41c6b9a
using Plots

# ╔═╡ 4d8a7392-fa7d-486d-9ec4-25c016a644f6
t=symbols("t", positive=true)

# ╔═╡ b0871815-91f0-4831-9f06-778c6e2f3a8d
ω=symbols("ω")

# ╔═╡ 5b3a5eec-5ae0-4c42-b39c-9bad9ff50fe2
integrate(exp(-t)*cos(5*t)*exp(-im*t*ω),(t,0,oo))

# ╔═╡ 5196418c-1f38-4db4-8e92-96ae308ae27e
f(ω)=integrate(exp(-t)*cos(5*t)*exp(-im*t*ω),(t,0,oo)).doit().evalf()

# ╔═╡ 08c48013-41cd-4181-a8cd-c5ef70cbcf8b
f(1)

# ╔═╡ cfeeaaf7-98a3-4c74-b733-2b4b55c445cc
ωs = range(-10,stop=10,length=40)

# ╔═╡ 624d79c4-4eb6-4138-b7fa-4e3e09159b8d
fhat=f.(ωs)

# ╔═╡ 594622e3-19b0-4ed9-b2f0-474013336aa8
Plots.plot(ωs, abs.(fhat))

# ╔═╡ 571b840e-eb35-494d-aa81-1997c104c27a
Plots.plot(ωs, angle.(fhat))

# ╔═╡ Cell order:
# ╠═e21fa9d0-b694-11eb-2606-cd02c4ded85f
# ╠═f5e0abeb-dd1f-497d-a33f-6840f41c6b9a
# ╠═4d8a7392-fa7d-486d-9ec4-25c016a644f6
# ╠═b0871815-91f0-4831-9f06-778c6e2f3a8d
# ╠═5b3a5eec-5ae0-4c42-b39c-9bad9ff50fe2
# ╠═5196418c-1f38-4db4-8e92-96ae308ae27e
# ╠═08c48013-41cd-4181-a8cd-c5ef70cbcf8b
# ╠═cfeeaaf7-98a3-4c74-b733-2b4b55c445cc
# ╠═624d79c4-4eb6-4138-b7fa-4e3e09159b8d
# ╠═594622e3-19b0-4ed9-b2f0-474013336aa8
# ╠═571b840e-eb35-494d-aa81-1997c104c27a
