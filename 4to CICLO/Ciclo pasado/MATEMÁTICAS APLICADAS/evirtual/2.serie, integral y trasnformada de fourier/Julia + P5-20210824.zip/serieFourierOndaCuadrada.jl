### A Pluto.jl notebook ###
# v0.14.4

using Markdown
using InteractiveUtils

# ╔═╡ a4fc0528-a8eb-11eb-1c3a-b72a9492b006
using Plots

# ╔═╡ 6b24d3ca-a337-4f43-82e6-f78eb418e218
k=1

# ╔═╡ 433f296e-33f4-407e-80ce-ae439b33c03e
f(x)=((x) < 0 ? -k : k)

# ╔═╡ d4dae81e-2156-4023-9edc-b9f51042cd8b
xs = range(-pi,stop=pi,length=200)

# ╔═╡ 07aaa3d7-d470-4d3d-813b-09fe31050ebb
plot(xs, f, legend=false)

# ╔═╡ 39c2cb3b-d8a4-4827-88e0-bd6d5df50553
function F(x,N=1)
	y=0
	for i = 1:N
		n = 2*i-1
		y += 4*k/(n*pi)*sin(n*x)
	end
	return y
end

# ╔═╡ 89be1d21-91e8-4b2d-ac71-c51244872737
begin
	N = 10
	xsF = range(-4*pi, stop=4*pi, length=400) 
	ysF = [F(x,N) for x in xsF]
	plot(xsF, ysF, legend=false)
end

# ╔═╡ Cell order:
# ╠═a4fc0528-a8eb-11eb-1c3a-b72a9492b006
# ╠═6b24d3ca-a337-4f43-82e6-f78eb418e218
# ╠═433f296e-33f4-407e-80ce-ae439b33c03e
# ╠═d4dae81e-2156-4023-9edc-b9f51042cd8b
# ╠═07aaa3d7-d470-4d3d-813b-09fe31050ebb
# ╠═39c2cb3b-d8a4-4827-88e0-bd6d5df50553
# ╠═89be1d21-91e8-4b2d-ac71-c51244872737
