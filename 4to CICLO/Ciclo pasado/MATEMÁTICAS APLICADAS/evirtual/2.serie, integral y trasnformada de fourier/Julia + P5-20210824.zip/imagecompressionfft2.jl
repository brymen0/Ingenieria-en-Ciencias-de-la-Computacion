### A Pluto.jl notebook ###
# v0.14.5

using Markdown
using InteractiveUtils

# ╔═╡ a83aecac-b44b-11eb-0d6e-a7a429b08ba7
begin
	using FFTW
	using Images
	using Colors
	using Plots
end

# ╔═╡ be510222-1c73-4f22-acb2-514452ae4ca8
img = Images.load("./Sharbat_Gula.jpg")
#img = Images.load("./illiniza.jpg")

# ╔═╡ 1c84ba3a-7eaa-4526-9650-623b387264fd
imgg = Gray.(img)

# ╔═╡ 7a034deb-048f-4d93-b026-837cc08eafc5
b = convert(Array{Float64}, imgg) ;

# ╔═╡ 591befa8-ab34-4a24-885e-3e8b8bbe51a2
length(b)

# ╔═╡ db3d367d-354f-4288-8ec9-28ed27e08019
begin
	bt = fft(b);
	btsort = sort(vec(abs.(bt)))
	
	keep=.05
	threshold = btsort[Int(floor((1-keep)*length(btsort)))]
	ind = (abs.(bt)) .> threshold
	btlow = bt .* ind
	blow = real.(ifft(btlow))
    Plots.plot(Gray.(blow), aspect_ratio = 1, axis=nothing)
end

# ╔═╡ 7fc64085-3c7c-419b-a9e5-764f750d6f1d
begin
	plotlyjs()
	#pyplot()
	surface(blow)
end

# ╔═╡ Cell order:
# ╠═a83aecac-b44b-11eb-0d6e-a7a429b08ba7
# ╠═be510222-1c73-4f22-acb2-514452ae4ca8
# ╠═1c84ba3a-7eaa-4526-9650-623b387264fd
# ╠═7a034deb-048f-4d93-b026-837cc08eafc5
# ╠═591befa8-ab34-4a24-885e-3e8b8bbe51a2
# ╠═db3d367d-354f-4288-8ec9-28ed27e08019
# ╠═7fc64085-3c7c-419b-a9e5-764f750d6f1d
