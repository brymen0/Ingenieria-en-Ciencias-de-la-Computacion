// ##########################################
// Series de Fourier - Onda Cuadrada
// https://thecodingtrain.com/CodingChallenges/125-fourier-series.html
// https://bilimneguzellan.net/en/purrier-series-meow-and-making-images-speak/

//Matematicas Aplicadas-18563
//Diego Montero
//Universidad de Cuenca
// ##########################################
//Variables
let k=75;

let t=0;
let onda=[];
let N=10;
function setup() {
  createCanvas(600, 400);
  slider=createSlider(1,50,1);
}

function draw() {
  background(0);
  translate(150,200);
  let x=0;
  let y=0;
  for (let i=1; i<=slider.value(); i++){
    let prevx=x;
    let prevy=y;
    let n=2*i-1;
    let radio = (4*k)/(n*PI);

    x += radio * cos(n*t);
    y += radio * sin(n*t);

    //circunferencia
    stroke(255,100);
    noFill();
    ellipse(prevx,prevy,2*radio);

    //radio circunferencia
    stroke(255);
    line(prevx,prevy,x,y);
  } 
  onda.unshift(y);
    
  translate(200,0);
  //recta radio-onda
  line(x-200,y,0,onda[0]);
  //onda
  beginShape();
  for (let i=0; i<onda.length; i++){
    vertex(i, onda[i]);
  }
  endShape();
  
  //tiempo
  t += 0.05;
  
  //Control tamaño vector
  if (onda.length>250){
    onda.pop();
  }
}
