### A Pluto.jl notebook ###
# v0.14.5

using Markdown
using InteractiveUtils

# ╔═╡ 251dbbe8-b7dd-11eb-344b-dd68b875cc63
begin
	using Plots
	using FFTW
	using LaTeXStrings
end

# ╔═╡ 3b9f5184-3626-4f61-9cab-5a744cbaff5c
begin
	dt=0.001 # tiempo muestreo
	ts = range(0,stop=1,step=dt)
end

# ╔═╡ 05c79037-c432-421d-bb32-ee9ef721c3c1
f_pura = sin.(2*pi*50*ts) + sin.(2*pi*120*ts) # suma de dos frecuencias en sin

# ╔═╡ 5ef32888-7efa-45d2-bf68-524fb1563ebd
N=length(ts)

# ╔═╡ f5d4712d-ccf3-4480-bf71-57f6474c3faa
f_ruido = f_pura + 2.5*randn(N)

# ╔═╡ abc24592-c6a2-4469-b6c8-59ae4d08a6b4
begin
	plot(f_ruido, xlim=(0,100), label="fruido")
	plot!(f_pura, xlim=(0,100), label="fpura")
end

# ╔═╡ 3ea8f2ce-bdcb-42f8-ae8b-ca5976792757
f = f_ruido # funcion de entreda

# ╔═╡ a203cc3c-65dd-4129-a66e-e6369d6de36b
begin
	fhat = fft(f)
	fhatshifted = fftshift(fhat)
	freqs = sort(fftfreq(N, 1/dt))
	#scatter(freqs, abs.(fhatshifted), xlim=(0,300), xlabel=L"\omega")
	plot(freqs, abs2.(fhatshifted)/N, xlim=(0,150), xlabel=L"\omega")
end

# ╔═╡ c6aab0bd-a7dd-4200-a5d9-20b2e1ac8ee0
begin
	#Filtrar
	PSD = abs2.(fhatshifted)/N # Power Spectral Density 
	indices = PSD .> 100
	PSD_filtrado = PSD .* indices
	plot(freqs, PSD_filtrado, xlim=(0,150), xlabel=L"\omega")
end

# ╔═╡ 62598a55-0757-47fa-8000-19d31cbdd07a
begin
	indicesfhat = abs2.(fhat)/N .> 100
	fhat_filtrado = fhat .* indicesfhat
	f_filtrado = real.(ifft(fhat_filtrado))
	plot(ts, f_filtrado, label="f_filtrado", xlim=(0,1))
	plot!(ts, f_pura, label="f_pura", xlim=(0,1), color=:red)
end

# ╔═╡ Cell order:
# ╠═251dbbe8-b7dd-11eb-344b-dd68b875cc63
# ╠═3b9f5184-3626-4f61-9cab-5a744cbaff5c
# ╠═05c79037-c432-421d-bb32-ee9ef721c3c1
# ╠═5ef32888-7efa-45d2-bf68-524fb1563ebd
# ╠═f5d4712d-ccf3-4480-bf71-57f6474c3faa
# ╠═abc24592-c6a2-4469-b6c8-59ae4d08a6b4
# ╠═3ea8f2ce-bdcb-42f8-ae8b-ca5976792757
# ╠═a203cc3c-65dd-4129-a66e-e6369d6de36b
# ╠═c6aab0bd-a7dd-4200-a5d9-20b2e1ac8ee0
# ╠═62598a55-0757-47fa-8000-19d31cbdd07a
