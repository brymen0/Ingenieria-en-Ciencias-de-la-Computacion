### A Pluto.jl notebook ###
# v0.14.5

using Markdown
using InteractiveUtils

# ╔═╡ 1769be32-b253-11eb-04fd-4b432f56f37b
using FFTW

# ╔═╡ b1c30c0a-49d1-4c85-a584-85e1d9f0aa66
using Plots

# ╔═╡ d3bbbe41-1fda-4990-9c7b-eb51b263c2ea
xs = range(-5,stop=5,length=101) # 101 samples: 5-(-5)/101 = 10/101 = 0.1
#xs = -5:0.1:5 

# ╔═╡ 6a9abeb0-7131-441a-bed4-2189c4feac46
length(xs)

# ╔═╡ 9fd070ea-7680-4466-ac4b-70cba95e585c
f = [abs(x) <= 1 ? 1 : 0 for x in xs];

# ╔═╡ e05ba9ed-2f06-460c-a958-7638556fe8d3
length(f)

# ╔═╡ 67fa0240-423a-48b8-b7c3-cfe634f7c95a
begin
	p1=Plots.scatter(xs, f, xlabel="t [s]", ylabel="f(t)", label="f_s", tickfontsize=6, guidefontsize=8,legendfontsize=8)
	p1=Plots.plot!(xs, f, xlabel="t [s]", ylabel="f(t)", label="f")
end

# ╔═╡ 84a3e9e1-f97e-459e-bc2a-8f0ac61ff509
n=length(xs)

# ╔═╡ ce8d4048-fec5-47fa-b7a2-3362f6e186af
F = fft(f)

# ╔═╡ 62b2b0aa-06da-4271-8532-47254b09fc67
typeof(F)

# ╔═╡ 008ba397-e20a-4b30-a122-2b529eecff4c
length(F)

# ╔═╡ 1047c5dd-47c8-4e98-835b-813f2ee1256c
freqs = fftfreq(length(F), 10)

# ╔═╡ ee927e8b-4dd8-4c2c-984f-a9f6c9d383df
idx=sort(freqs)

# ╔═╡ cd0ce55d-2dfa-45ac-814f-bd5ad3a81b34
Fshift = fftshift(F)

# ╔═╡ c3bbddce-03e6-4a5f-8719-4111703092a8
p2=Plots.plot(idx, abs.(Fshift), legend=false, xlabel="f [Hz]", ylabel="Amplitud")

# ╔═╡ 7a0db413-23b8-4fde-a066-8e8e1d74d98a
p3=Plots.plot(idx, (abs.(Fshift.*conj(Fshift)/(n))), legend=false,  xlabel="f [Hz]", ylabel="PSD")

# ╔═╡ 3efc66a7-351d-4990-9340-47625637aa53
p4=Plots.plot(idx, (abs.(Fshift.*conj(Fshift)/(n))), legend=false, yscale=:log, xlabel="f [Hz]", ylabel="PSD (log)")

# ╔═╡ ed8210ec-05e1-47cf-a8f5-1333ab968716
Plots.plot(p1,p2,p3,p4, layout=(4,1), size=(600,800))

# ╔═╡ b906a510-95bd-4203-95fa-6ca1796bd0e5
pyplot()

# ╔═╡ Cell order:
# ╠═1769be32-b253-11eb-04fd-4b432f56f37b
# ╠═b1c30c0a-49d1-4c85-a584-85e1d9f0aa66
# ╠═d3bbbe41-1fda-4990-9c7b-eb51b263c2ea
# ╠═6a9abeb0-7131-441a-bed4-2189c4feac46
# ╠═9fd070ea-7680-4466-ac4b-70cba95e585c
# ╠═e05ba9ed-2f06-460c-a958-7638556fe8d3
# ╠═67fa0240-423a-48b8-b7c3-cfe634f7c95a
# ╠═84a3e9e1-f97e-459e-bc2a-8f0ac61ff509
# ╠═ce8d4048-fec5-47fa-b7a2-3362f6e186af
# ╠═62b2b0aa-06da-4271-8532-47254b09fc67
# ╠═008ba397-e20a-4b30-a122-2b529eecff4c
# ╠═1047c5dd-47c8-4e98-835b-813f2ee1256c
# ╠═ee927e8b-4dd8-4c2c-984f-a9f6c9d383df
# ╠═cd0ce55d-2dfa-45ac-814f-bd5ad3a81b34
# ╠═c3bbddce-03e6-4a5f-8719-4111703092a8
# ╠═7a0db413-23b8-4fde-a066-8e8e1d74d98a
# ╠═3efc66a7-351d-4990-9340-47625637aa53
# ╠═ed8210ec-05e1-47cf-a8f5-1333ab968716
# ╠═b906a510-95bd-4203-95fa-6ca1796bd0e5
