### A Pluto.jl notebook ###
# v0.14.7

using Markdown
using InteractiveUtils

# ╔═╡ db33fe46-cf71-11eb-3c4a-3f83346d295e
using Plots

# ╔═╡ 281a3cad-e5ab-4b67-a1b0-3fe9477afda6
using QuadGK

# ╔═╡ 908d26ef-ab89-490f-91c8-a0e8b1edc041
begin
	c = 1
	N = 10
	dt = 0.01
	xs = range(0, stop=2, length=100)
	ts = range(0.01, stop=1.5, length=100)
end

# ╔═╡ cf7ce01d-8f21-4b18-a467-49080a10762d
i1(x,w,t) = quadgk(p -> sin(w*p)*exp(-c^2*w^2*t)*sin(w*x), 0, 1)[1]

# ╔═╡ 75def552-603b-4d6c-98b0-970f52bfa17c
i2(x,t,n) = quadgk(w -> i1(x,w,t), 0, n)[1]

# ╔═╡ 107f8f45-96d4-40ac-9f58-dbad6701ad87
u(x,t; n=N) = 2/pi*i2(x,t,n)

# ╔═╡ b165b0c5-5347-422b-8c4c-f6fe93865959
u(0,1)

# ╔═╡ 4e2196c1-cd8a-4efb-a13a-bf6f97106b1f


# ╔═╡ 8e6712a0-f26d-4969-b870-593515654e12
begin
	t=0
	value=0
	a = Array{}[]
	for i in 1:500
		value = [u(x,t) for x in xs]
		t += dt
		push!(a, value)
	end
		
end

# ╔═╡ b0df0215-1c53-425f-8a49-81c4074c8b49
begin
	plot(xs, a[1], legend=false, ylim=(-.5,1.5), xlabel="x", ylabel="u(x,t)")
	plot!(xs, a[10], legend=false, ylim=(-.5,1.5), xlabel="x", ylabel="u(x,t)")
	plot!(xs, a[100], legend=false, ylim=(-.5,1.5), xlabel="x", ylabel="u(x,t)")
end

# ╔═╡ 774e61ce-34c8-4ed8-9f2c-8f203b2a9d77
begin
	anim = Plots.Animation()
	for i = 1:1:length(a)
		plot(xs, a[i], legend=false, ylim=(-.5,1.5), xlabel="x", ylabel="u(x,t)")
		Plots.frame(anim)
	end
	
	mp4(anim, "edpcalor-SFT-taller.mp4", fps=1/dt)
end

# ╔═╡ 3ba2b3db-abb2-4e87-a6af-ec305a98bd60
z = Surface((x,t)->u(x,t), xs, ts);

# ╔═╡ 57048fd3-8aed-460d-9e9e-8961ff00a089
surface(xs, ts, z, xlabel="x", ylabel="t", zlabel="u(x,t)")

# ╔═╡ 7024dfb8-bef6-4067-9b91-587fa72bc708
heatmap(xs, ts, z, xlabel="x", ylabel="t", zlabel="u(x,t)")

# ╔═╡ Cell order:
# ╠═db33fe46-cf71-11eb-3c4a-3f83346d295e
# ╠═281a3cad-e5ab-4b67-a1b0-3fe9477afda6
# ╠═908d26ef-ab89-490f-91c8-a0e8b1edc041
# ╠═cf7ce01d-8f21-4b18-a467-49080a10762d
# ╠═b165b0c5-5347-422b-8c4c-f6fe93865959
# ╠═75def552-603b-4d6c-98b0-970f52bfa17c
# ╠═107f8f45-96d4-40ac-9f58-dbad6701ad87
# ╠═4e2196c1-cd8a-4efb-a13a-bf6f97106b1f
# ╠═8e6712a0-f26d-4969-b870-593515654e12
# ╠═b0df0215-1c53-425f-8a49-81c4074c8b49
# ╠═774e61ce-34c8-4ed8-9f2c-8f203b2a9d77
# ╠═3ba2b3db-abb2-4e87-a6af-ec305a98bd60
# ╠═57048fd3-8aed-460d-9e9e-8961ff00a089
# ╠═7024dfb8-bef6-4067-9b91-587fa72bc708
