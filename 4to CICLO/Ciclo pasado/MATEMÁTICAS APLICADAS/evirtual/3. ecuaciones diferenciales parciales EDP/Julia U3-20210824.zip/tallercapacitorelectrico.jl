### A Pluto.jl notebook ###
# v0.14.7

using Markdown
using InteractiveUtils

# ╔═╡ d93e6b08-d4f3-11eb-33b8-b9b7b7a44931
using Plots

# ╔═╡ 8d4dedab-6238-4458-a181-96b4d02b87c0
using SciPy

# ╔═╡ 5011ae3d-80c7-41fc-8e8b-c503928e2bc3
begin
	R=1
	ϕs = range(0,stop=3.5, length=200)
end

# ╔═╡ f773c395-0c68-4d1d-b0e4-48a3dfb6a9cb
function A(n)
	M=Integer(trunc(n/2))
	y=0
	for m in 0:M
		y+=(55*(2*n+1)/(2^n))*(-1)^m*(factorial(big(2*n-2*m)))/(factorial(m)*factorial(n-m)*factorial(big(n-2*m+1)))
	end
	return y
end

# ╔═╡ b61d6a4d-c2ca-436e-8bd9-f8ed79883021
function u(r,ϕ; N=N)
	y = 0
	for n in 0:N
		y+=A(n)*r^n*SciPy.special.eval_legendre(n, cos(ϕ))
	end
	return y
end

# ╔═╡ 0c13e2ed-e0f4-4c6f-9849-ab281ac1c23b
begin
	us= [u(R,ϕ;N=4) for ϕ in ϕs]
	plot(ϕs, us, xticks=([0,pi/2,pi], ["0","\$\\frac{\\pi}{2}\$","\\pi"]), yticks=([0,110]), xlabel="\$\\phi\$", ylabel="\$u(R,\\phi)\$", label="\$n=4\$")
	plot!(ϕs, [u(R,ϕ;N=6) for ϕ in ϕs], label="\$n=6\$")
	plot!(ϕs, [u(R,ϕ;N=11) for ϕ in ϕs], label="\$n=11\$")
end

# ╔═╡ Cell order:
# ╠═d93e6b08-d4f3-11eb-33b8-b9b7b7a44931
# ╠═8d4dedab-6238-4458-a181-96b4d02b87c0
# ╠═5011ae3d-80c7-41fc-8e8b-c503928e2bc3
# ╠═f773c395-0c68-4d1d-b0e4-48a3dfb6a9cb
# ╠═b61d6a4d-c2ca-436e-8bd9-f8ed79883021
# ╠═0c13e2ed-e0f4-4c6f-9849-ab281ac1c23b
