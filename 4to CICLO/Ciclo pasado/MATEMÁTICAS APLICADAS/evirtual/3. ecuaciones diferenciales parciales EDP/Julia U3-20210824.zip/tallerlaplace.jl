### A Pluto.jl notebook ###
# v0.14.7

using Markdown
using InteractiveUtils

# ╔═╡ 48977d80-d4ec-11eb-0c3f-df97496efa02
using Plots

# ╔═╡ fe863e92-496c-48d4-8a98-784237c0d0f4
begin
	c=1
	dt=0.05
	xs = range(0, stop=6*pi, length=1000)
end

# ╔═╡ 6059d786-5b77-4b0e-aa93-62d0aa248727
u(x) = x<0 ? 0 : 1

# ╔═╡ 0ef26b09-04f6-4442-9d02-21d55144e994
f(t) = t <= 2*pi ? ( t>= 0 ? sin(t) : 0) : 0

# ╔═╡ 9b0c2266-95b2-4217-b813-73db83278c89
function f2(t)
	if t>=0 && t<=2*pi
		return sin(t)
	else
		return 0
	end
end

# ╔═╡ e43a84e1-7a17-4b42-bb30-cda8ebc6f705
f2(pi/2)

# ╔═╡ 60e57b9a-5bea-492e-a521-9e20c3e5456a
w(x,t) = f(t-x/c)*u(t-x/c)

# ╔═╡ af3f7219-96b1-4ce5-8191-6c434d38e781
w(1,2)

# ╔═╡ 3dacf521-5450-4169-b1ea-c0740ae56403
begin
	value = 0
	a = Array{}[]
	t0=0
	for i in 1:500
		value = [w(x,t0) for x in xs]
		t0 += dt
		push!(a, value)
	end
end

# ╔═╡ 6f64e62e-8064-463f-96c8-236f99db93e8
plot(a[100])

# ╔═╡ 5bb3a112-cb68-46f7-a0f7-65d723b2f8fd
begin
	anim = Plots.Animation()
	for i in 1:length(a)
		plot(xs, a[i], legend=false, ylim=(-1.5,1.5), yticks=([-1,0,1]), xlabel="x", ylabel="u(x,t)")
		Plots.frame(anim)
	end
end

# ╔═╡ 2077dc5b-6673-4b19-8728-981a065d80fd
mp4(anim, "talleredplaplace.mp4", fps=1/dt)

# ╔═╡ e1a6f9e9-ec04-4860-be74-bc0ffa67c4da
begin
	ts = range(0, stop=20, length=100)
	z = Surface((x,t)->w(x,t), xs, ts)
	heatmap(xs, ts, z)
end

# ╔═╡ Cell order:
# ╠═48977d80-d4ec-11eb-0c3f-df97496efa02
# ╠═fe863e92-496c-48d4-8a98-784237c0d0f4
# ╠═6059d786-5b77-4b0e-aa93-62d0aa248727
# ╠═0ef26b09-04f6-4442-9d02-21d55144e994
# ╠═9b0c2266-95b2-4217-b813-73db83278c89
# ╠═e43a84e1-7a17-4b42-bb30-cda8ebc6f705
# ╠═60e57b9a-5bea-492e-a521-9e20c3e5456a
# ╠═af3f7219-96b1-4ce5-8191-6c434d38e781
# ╠═3dacf521-5450-4169-b1ea-c0740ae56403
# ╠═6f64e62e-8064-463f-96c8-236f99db93e8
# ╠═5bb3a112-cb68-46f7-a0f7-65d723b2f8fd
# ╠═2077dc5b-6673-4b19-8728-981a065d80fd
# ╠═e1a6f9e9-ec04-4860-be74-bc0ffa67c4da
