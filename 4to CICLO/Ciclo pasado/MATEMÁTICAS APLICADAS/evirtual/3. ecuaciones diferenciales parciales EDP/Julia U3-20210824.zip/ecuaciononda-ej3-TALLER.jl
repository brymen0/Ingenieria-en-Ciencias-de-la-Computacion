### A Pluto.jl notebook ###
# v0.14.7

using Markdown
using InteractiveUtils

# ╔═╡ 23e5ec1a-9629-4516-985a-14051b767038
using Plots

# ╔═╡ 9398066a-ae02-422e-89e7-684cdc00df8f
using QuadGK

# ╔═╡ a3c109f6-c9ef-11eb-13fd-51b3016825b8
md"**Ecuación Onda -- Solución d'Alembert**

$\begin{cases}
        u_{tt} = c^{2}u_{x x} \\
        u(x,0) = f(x) \\ 
        u_{t}(x,0) = g(x) \\
    \end{cases} \qquad u(x,t) = \frac{1}{2}\left[ f(x+ct)+f(x-ct) \right] + \frac{1}{2c} \int_{x-ct}^{x+ct} g(s) \,d s$

$u_{tt} = u_{x x}$
$u(x,0)=f(x) = 0$
$g(x) = \begin{cases}
        1 & \text{si } -1 \le x \le 1 \\
        0 & \text{caso contrario}\\ 
    \end{cases}$
"

# ╔═╡ 30bb0cf2-8bac-4013-a429-64e9690781d2
begin
	c = 1 # velocidad onda
	t = 0 # variable tiempo
	dt = 0.01 # incremento tiempo
	xs = range(-10, stop=10, length=1000)
	md"Variables"
end

# ╔═╡ 6e7fd235-0e31-4ca3-8ba0-fd14e644fbb1
f(x)=0

# ╔═╡ f1e543e6-8108-4d88-a79f-365ffbd9386c
g(x) = abs(x)<=1 ? 1 : 0

# ╔═╡ 24a7261b-588a-401f-90d7-f1b6556dcd31
h(x) = quadgk(x->g(x), 0, x)[1]

# ╔═╡ 29da151c-ad66-4da4-8ffb-f4a517c67def
h(.85)

# ╔═╡ bcda9686-4b04-4cd8-90ea-eb35ea8a8df1
u(x,t) = 1/2*h(x+c*t)-1/2*h(x-c*t)

# ╔═╡ 879e1afd-0ee6-4533-9b42-c275b9ea99d7
begin
	ys = Array{}[]
	value = 0
	for i in 1:500
		value = [u(x,t) for x in xs]
		#value = u.(xs,t)
		t += dt
		push!(ys, value)
	end
end

# ╔═╡ 4ff8b497-650b-45df-8b76-e6584f240145
plot(xs,ys[1], legend=false, ylim=(-1,2), color=:blue)

# ╔═╡ 99b1eacc-227c-4f8f-a79d-c93d57d1ef19
begin
	# animación
	anim = Plots.Animation()
	for i = 1:1:length(ys)
		plot(xs,ys[i], legend=false, ylim=(-1,2), color=:blue)
		Plots.frame(anim)
	end
	
	# video formato mp4
	mp4(anim, "ecuaciononda-ej3-TALLER.mp4")
	# gif animado
	#gif(anim, "ecuaciononda-ejercicio1-taller.gif")
	
end

# ╔═╡ 3df0d821-99a0-4b72-8e4d-c7dae4809388
begin
	ts = range(-5, stop=10, length=1000)
	z = Surface((x,t)->u(x,t),xs,ts);
	heatmap(xs, ts, z, xlabel="x", ylabel="t")
end

# ╔═╡ 9fea1569-201b-4d9b-952f-92d5ef50f56a
begin
	plotlyjs()
	surface(xs,ts,z,zlim=(-1,2),xlabel="x", ylabel="t",camera=(20,30), legend=false)
end

# ╔═╡ Cell order:
# ╟─a3c109f6-c9ef-11eb-13fd-51b3016825b8
# ╠═23e5ec1a-9629-4516-985a-14051b767038
# ╠═9398066a-ae02-422e-89e7-684cdc00df8f
# ╠═30bb0cf2-8bac-4013-a429-64e9690781d2
# ╠═6e7fd235-0e31-4ca3-8ba0-fd14e644fbb1
# ╠═f1e543e6-8108-4d88-a79f-365ffbd9386c
# ╠═24a7261b-588a-401f-90d7-f1b6556dcd31
# ╠═29da151c-ad66-4da4-8ffb-f4a517c67def
# ╠═bcda9686-4b04-4cd8-90ea-eb35ea8a8df1
# ╠═879e1afd-0ee6-4533-9b42-c275b9ea99d7
# ╠═4ff8b497-650b-45df-8b76-e6584f240145
# ╠═99b1eacc-227c-4f8f-a79d-c93d57d1ef19
# ╠═3df0d821-99a0-4b72-8e4d-c7dae4809388
# ╠═9fea1569-201b-4d9b-952f-92d5ef50f56a
