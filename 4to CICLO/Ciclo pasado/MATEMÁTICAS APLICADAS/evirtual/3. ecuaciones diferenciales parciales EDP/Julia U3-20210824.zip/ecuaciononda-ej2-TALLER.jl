### A Pluto.jl notebook ###
# v0.14.7

using Markdown
using InteractiveUtils

# ╔═╡ 122f6488-c9ed-11eb-17b8-bb52792c6923
using Plots

# ╔═╡ cebb21ed-d7bc-433e-b347-120a8e8d4eb4
md"**Ecuación Onda -- Solución d'Alembert**

$\begin{cases}
        u_{tt} = c^{2}u_{x x} \\
        u(x,0) = f(x) \\ 
        u_{t}(x,0) = g(x) \\
    \end{cases} \qquad u(x,t) = \frac{1}{2}\left[ f(x+ct)+f(x-ct) \right] + \frac{1}{2c} \int_{x-ct}^{x+ct} g(s) \,d s$

$u_{tt} = u_{x x}$
$u(x,0)=f(x) = \cos(x)$
$g(x)=0$
"

# ╔═╡ 3077df62-280b-4160-ba87-abe1cadeb8aa
begin
	c = 1 # velocidad onda
	t = 0 # variable tiempo
	dt = 0.01 # incremento tiempo
	xs = range(-3*pi, stop=3*pi, length=1000)
	md"Variables"
end

# ╔═╡ 4ee84e2f-0e38-456d-bbde-bed3ace86959
f(x) = cos(x)

# ╔═╡ 0607b203-57a2-4cb5-9d18-e2481c077ee7
u(x,t) = (1/2)*(f(x+c*t)+f(x-c*t))

# ╔═╡ bb2b2b3b-a7f7-412d-993f-1941691a1bef
begin
	ys = Array{}[]
	ondaderecha = Array{}[]
	ondaizquierda = Array{}[]
	value = 0
	for i in 1:500
		value = [u(x,t) for x in xs]
		push!(ys, value)
		value = [(1/2)*f(x-c*t) for x in xs]
		push!(ondaderecha, value)
		value = [(1/2)*f(x+c*t) for x in xs]
		push!(ondaizquierda,value)
		t += dt # t = t+dt
	end
end

# ╔═╡ bb5213ae-0909-45f6-a1fd-1ec5e4c8ba76
begin
	plot(xs, ys[1], legend=false, ylim=(-2,2), color=:blue)
	plot!(xs, ondaderecha[1])
	plot!(xs, ondaizquierda[1])
end

# ╔═╡ ccf57565-3c2d-4e87-8b45-a1296ecd17da
begin
	#animacion
	anim = Plots.Animation()
	for i = 1:1:length(ys)
		plot(xs, ys[i], legend=false, ylim=(-2,2), color=:blue)
		plot!(xs, ondaderecha[i], color=:red)
		plot!(xs, ondaizquierda[i], color=:green)
		Plots.frame(anim)
	end
	
	# video formato mp4
	mp4(anim, "ecuaciontransporte-ej2-TALLER.mp4")
	# gif animado
	#gif(anim, "ecuaciontransporte-ejercicio1-taller.gif")
end

# ╔═╡ cfd13c7d-5b9e-4693-af62-48581d83cdc2
begin
	ts = range(-5, stop=10, length=1000)
	z = Surface((x,t)->u(x,t),xs, ts)
	heatmap(xs, ts, z, xlabel="x", ylabel="t")
end

# ╔═╡ 5dd16f1a-0c48-45de-ba53-5332278462d8
begin
	plotlyjs()
	#gr()
	surface(xs, ts, z, zlim=(-1,2), xlabel="x", ylabel="t", zlabel="u(x,t)")
end

# ╔═╡ 98562cdf-6c7f-4e70-aa44-6ae7a0967435


# ╔═╡ Cell order:
# ╠═122f6488-c9ed-11eb-17b8-bb52792c6923
# ╟─cebb21ed-d7bc-433e-b347-120a8e8d4eb4
# ╠═3077df62-280b-4160-ba87-abe1cadeb8aa
# ╠═4ee84e2f-0e38-456d-bbde-bed3ace86959
# ╠═0607b203-57a2-4cb5-9d18-e2481c077ee7
# ╠═bb2b2b3b-a7f7-412d-993f-1941691a1bef
# ╠═bb5213ae-0909-45f6-a1fd-1ec5e4c8ba76
# ╠═ccf57565-3c2d-4e87-8b45-a1296ecd17da
# ╠═cfd13c7d-5b9e-4693-af62-48581d83cdc2
# ╠═5dd16f1a-0c48-45de-ba53-5332278462d8
# ╠═98562cdf-6c7f-4e70-aa44-6ae7a0967435
