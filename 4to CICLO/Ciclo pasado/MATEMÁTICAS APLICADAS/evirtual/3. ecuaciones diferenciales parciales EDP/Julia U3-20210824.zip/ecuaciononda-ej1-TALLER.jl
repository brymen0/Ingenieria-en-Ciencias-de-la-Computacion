### A Pluto.jl notebook ###
# v0.14.7

using Markdown
using InteractiveUtils

# ╔═╡ 00834a4e-c9eb-11eb-319d-0f9ba12b7829
using Plots

# ╔═╡ 729ba66b-9404-4a95-b7d1-dbcf8179d6ed
md"**Ecuación Onda -- Solución d'Alembert**

$\begin{cases}
        u_{tt} = c^{2}u_{x x} \\
        u(x,0) = f(x) \\ 
        u_{t}(x,0) = g(x) \\
    \end{cases} \qquad u(x,t) = \frac{1}{2}\left[ f(x+ct)+f(x-ct) \right] + \frac{1}{2c} \int_{x-ct}^{x+ct} g(s) \,d s$

$u_{tt} = u_{x x}$
$u(x,0)=f(x) = \begin{cases}
        1 & \text{si } -1 \le x \le 1 \\
        0 & \text{caso contrario}\\ 
    \end{cases}$
$g(x)=0$
"

# ╔═╡ f75673b4-225d-48b4-addd-7540c79c6e0e
begin
	c = 1 # velocidad onda
	t = 0 # variable tiempo
	dt = 0.01 # incremento tiempo
	xs = range(-10, stop=10, length=1000)
	md"Variables"
end

# ╔═╡ 914f79e6-3582-4853-8520-8bed97dce111
f(x) = abs(x)<=1 ? 1 : 0

# ╔═╡ 19ebc823-987a-4268-a683-27a6ad66664f
function u(x,t)
	return (1/2)*(f(x+c*t)+f(x-c*t))
end

# ╔═╡ b7bfc1c8-c7f8-44a3-ae66-7f0180811647
begin
	ys = Array{}[]
	value = 0
	for i in 1:500
		value = [u(x,t) for x in xs]
		t += dt # t = t+dt
		push!(ys, value)
	end
end

# ╔═╡ d52360d9-c2b3-4309-9a2c-c47c429cb36c
plot(xs, ys[1], legend=false, ylim=(-1,2), color=:blue)

# ╔═╡ 659fec4a-9b05-4bcc-a9f0-3f4e1c9d5fcb
begin
	#animacion
	anim = Plots.Animation()
	for i = 1:1:length(ys)
		plot(xs, ys[i], legend=false, ylim=(-1,2), color=:blue)
		Plots.frame(anim)
	end
	
	# video formato mp4
	mp4(anim, "ecuaciontransporte-ejercicio1-taller.mp4")
	# gif animado
	#gif(anim, "ecuaciontransporte-ejercicio1-taller.gif")
end

# ╔═╡ 73b6580f-9cc1-4069-a2a3-b1c02d13f421
begin
	ts = range(-5, stop=10, length=1000)
	z = Surface((x,t)->u(x,t),xs, ts)
	heatmap(xs, ts, z, xlabel="x", ylabel="t")
end

# ╔═╡ 38c86341-1ce9-4bd7-9528-541400e94604
begin
	plotlyjs()
	#gr()
	surface(xs, ts, z, zlim=(-1,2), xlabel="x", ylabel="t", zlabel="u(x,t)")
end

# ╔═╡ e4a8219d-29fe-4625-a44c-76b53bfb36d0


# ╔═╡ Cell order:
# ╠═00834a4e-c9eb-11eb-319d-0f9ba12b7829
# ╟─729ba66b-9404-4a95-b7d1-dbcf8179d6ed
# ╠═f75673b4-225d-48b4-addd-7540c79c6e0e
# ╠═914f79e6-3582-4853-8520-8bed97dce111
# ╠═19ebc823-987a-4268-a683-27a6ad66664f
# ╠═b7bfc1c8-c7f8-44a3-ae66-7f0180811647
# ╠═d52360d9-c2b3-4309-9a2c-c47c429cb36c
# ╠═659fec4a-9b05-4bcc-a9f0-3f4e1c9d5fcb
# ╠═73b6580f-9cc1-4069-a2a3-b1c02d13f421
# ╠═38c86341-1ce9-4bd7-9528-541400e94604
# ╠═e4a8219d-29fe-4625-a44c-76b53bfb36d0
