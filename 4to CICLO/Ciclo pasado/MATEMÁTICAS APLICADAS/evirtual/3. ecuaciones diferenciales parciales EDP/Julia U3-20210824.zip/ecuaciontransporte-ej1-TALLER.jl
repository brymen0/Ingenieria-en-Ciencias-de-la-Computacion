### A Pluto.jl notebook ###
# v0.14.7

using Markdown
using InteractiveUtils

# ╔═╡ 9e609b4c-c9e6-11eb-3287-7bab1b1f6abe
using Plots

# ╔═╡ 70d4e992-26a2-4cac-b0b6-1d8104c47333
md"**Ecuación Transporte**

$u_{t}+2u_{x}=0$
$u(x,0)=\frac{1}{1+x^2}=f(x)$
$u(x,t)=f(x-2t)$
$u(x,t)=\frac{1}{1+(x-2t)^2}$
"

# ╔═╡ 01938e5e-4119-4334-9d0d-61605de30dc7
begin
	c = 4 # velocidad onda
	t = 0 # variable tiempo
	dt = 0.01 # incremento tiempo
	xs = range(-5, stop=15, length=1000)
	md"Variables"
end

# ╔═╡ 98762092-a833-4b63-98bd-7d2c5cfdb0b1
f(x) = 1/(1+x^2)

# ╔═╡ 03b5b0fe-52d3-4549-b741-fd900c2cf9b9
function u(x,t)
	return f(x-c*t)
end

# ╔═╡ 716143a7-8363-4983-9571-a1a367e5a913
# generacion y=f(x) en cada instante de tiempo t=t+dt
begin
	ys = Array{}[]
	value = 0
	for i in 1:500
		value = [u(x,t) for x in xs]
		t += dt # t = t+dt
		push!(ys, value)
	end
end

# ╔═╡ 6256a11e-bf0b-44ba-a1f2-5c872cecf6e5
plot(xs, ys[1], legend=false, ylim=(-1,2), color=:blue)

# ╔═╡ 32814311-ed24-4a25-9de6-5584102d29d2
begin
	#animacion
	anim = Plots.Animation()
	for i = 1:1:length(ys)
		plot(xs, ys[i], legend=false, ylim=(-1,2), color=:blue)
		Plots.frame(anim)
	end
	
	# video formato mp4
	mp4(anim, "ecuaciontransporte-ejercicio1-taller.mp4")
	# gif animado
	#gif(anim, "ecuaciontransporte-ejercicio1-taller.gif")
end

# ╔═╡ 4c256282-abb6-4510-aafe-ede27ebfa24c
begin
	ts = range(-5, stop=10, length=1000)
	z = Surface((x,t)->u(x,t),xs, ts)
	heatmap(xs, ts, z, xlabel="x", ylabel="t")
end

# ╔═╡ fe7ede7a-196f-4159-94c3-5e9abbf12834
begin
	plotlyjs()
	surface(xs, ts, z, zlim=(-1,2), xlabel="x", ylabel="t", zlabel="u(x,t)")
end

# ╔═╡ Cell order:
# ╠═9e609b4c-c9e6-11eb-3287-7bab1b1f6abe
# ╟─70d4e992-26a2-4cac-b0b6-1d8104c47333
# ╠═01938e5e-4119-4334-9d0d-61605de30dc7
# ╠═98762092-a833-4b63-98bd-7d2c5cfdb0b1
# ╠═03b5b0fe-52d3-4549-b741-fd900c2cf9b9
# ╠═716143a7-8363-4983-9571-a1a367e5a913
# ╠═6256a11e-bf0b-44ba-a1f2-5c872cecf6e5
# ╠═32814311-ed24-4a25-9de6-5584102d29d2
# ╠═4c256282-abb6-4510-aafe-ede27ebfa24c
# ╠═fe7ede7a-196f-4159-94c3-5e9abbf12834
