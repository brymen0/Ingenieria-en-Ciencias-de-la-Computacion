### A Pluto.jl notebook ###
# v0.14.7

using Markdown
using InteractiveUtils

# ╔═╡ 9b455b1a-d4f1-11eb-1993-f77ad250e91e
using Plots

# ╔═╡ 70b58454-24be-4e92-857e-29acae117cc5
using SciPy

# ╔═╡ 5e12abea-2fcf-42fd-b5fb-5aa14282bc0f
tmp=SciPy.special.jn_zeros(0,10)

# ╔═╡ 75d4e671-2b97-4d99-bfe7-c1fc522091bc
SciPy.special.jv(0, tmp[6])

# ╔═╡ d7f3c50c-ad21-4d9c-94f3-a420150cddfe
begin
	N = 10
	R = 1
	rs = range(0, stop=R, length=100)
	θs = range(0, stop=2*pi, length=100)
	α = SciPy.special.jn_zeros(0,N)
	dt = 0.05
end

# ╔═╡ ec23759c-56d4-4ee2-a0ab-b9976ebae397
A(m) = 8/((α[m])^3*SciPy.special.jv(1,α[m]))

# ╔═╡ d39313c5-d4fb-42e9-907a-6cd3ba82bd94
function u(r,t, M=N)
	u = 0
	for m in 1:M
		u+= A(m)*cos(2*α[m])*SciPy.special.jv(0,α[m]*r)
	end
	return u
end

# ╔═╡ 737cc42a-5277-4faa-8a11-69e1f638f31d
begin
	XC(r, θ, z) = r*cos(θ)
	YC(r, θ, z) = r*sin(θ)
	ZC(r, θ, z) = z
end

# ╔═╡ a6c6b30f-ac09-4e8a-a151-97cc32dce4eb
begin
	t0=0
	xs = [XC(r,θ, u(r,t0)) for r in rs, θ in θs]
	ys = [YC(r,θ, u(r,t0)) for r in rs, θ in θs]
	zs = [ZC(r,θ, u(r,t0)) for r in rs, θ in θs]
end

# ╔═╡ 6ace4e91-dca6-4869-b2e3-fe8babe81a36
begin
	pyplot()
	surface(xs, ys, zs)
end

# ╔═╡ 999478cc-4378-4d63-af0c-6a7e0190f3eb
begin
	a = Array{Float64,2}[]
	for i in 1:500
		value = [ZC(r,θ,u(r,t0)) for r in rs, θ in θs]
		t0 += dt
		push!(a, value)
	end
end

# ╔═╡ e7bea169-5c22-426f-891b-2f0471bd684d
begin
	anim = Plots.Animation()
	for i = 1:1:length(a)
	    surface(xs,ys, a[i], xlim=(-1,1), ylim=(-1,1), zlim=(-1.5,1.5), clims=(-1,1), ticks=([-1,0,1]), c=:jet1, legend=false)
	    Plots.frame(anim)
	end
	mp4(anim, "tallermembranacircular.mp4", fps=1/dt)
end

# ╔═╡ Cell order:
# ╠═9b455b1a-d4f1-11eb-1993-f77ad250e91e
# ╠═70b58454-24be-4e92-857e-29acae117cc5
# ╠═5e12abea-2fcf-42fd-b5fb-5aa14282bc0f
# ╠═75d4e671-2b97-4d99-bfe7-c1fc522091bc
# ╠═d7f3c50c-ad21-4d9c-94f3-a420150cddfe
# ╠═ec23759c-56d4-4ee2-a0ab-b9976ebae397
# ╠═d39313c5-d4fb-42e9-907a-6cd3ba82bd94
# ╠═737cc42a-5277-4faa-8a11-69e1f638f31d
# ╠═a6c6b30f-ac09-4e8a-a151-97cc32dce4eb
# ╠═6ace4e91-dca6-4869-b2e3-fe8babe81a36
# ╠═999478cc-4378-4d63-af0c-6a7e0190f3eb
# ╠═e7bea169-5c22-426f-891b-2f0471bd684d
