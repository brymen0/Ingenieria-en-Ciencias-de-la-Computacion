### A Pluto.jl notebook ###
# v0.14.7

using Markdown
using InteractiveUtils

# ╔═╡ 693ff74e-d4ef-11eb-3992-a7254cab737c
using Plots

# ╔═╡ 68f6fc57-24b3-47f6-9705-f5d4a5112ffb
begin
	M = 10
	N = 10
	xs = range(0, stop=4, length=100)
	ys = range(0, stop=2, length=100)
	dt = 0.05
end

# ╔═╡ d9aa9e8a-f539-4f18-a9bf-72092cc18bfa
function u(x,y,t,I=M, J=N)
	u = 0
	for m in 1:I
		for n in 1:J
			u += 2048/(5*m^3*n^3*pi^6)*cos((sqrt(5)*pi/4)*sqrt(m^2+4*n^2)*t)*sin(m*pi*x/4)*sin(n*pi*y/2)
		end
	end
	return u
end

# ╔═╡ 43a0594d-a48b-403d-956d-177efcebd97b
begin
	a = Surface{Array{Float64,2}}[]
	t0 = 0
	for i in 1:500
		z = Surface((x,y)->u(x,y,t0), xs, ys)
		t0 += dt
		push!(a, z)
	end
end

# ╔═╡ 39bdebab-d9fe-48c3-9e59-1cdf08de1d19
begin
	anim = Plots.Animation()
	for i = 1:1:length(a)
	    surface(xs,ys, a[i], xlim=(0,4), ylim=(0,2), zlim=(-.5,.5), c=:jet1, legend=false)
	    Plots.frame(anim)
	end
end

# ╔═╡ b052bfba-63e5-4d52-a455-4a2dcd5094c9
typeof(a[2])

# ╔═╡ 797c537c-a070-4b00-bebe-7d08c9af062e
mp4(anim, "tallermembranarectangural.mp4")

# ╔═╡ e3762506-c9ac-4290-a6c9-34330d1a5964
heatmap(xs, ys, a[1], xlim=(0,4), ylim=(0,2), zlim=(-.5,.5), legend=false, c=:jet1)

# ╔═╡ 2a6e15c3-0e38-4029-bd98-fd36ea28e05b
surface(xs, ys, a[100], xlim=(0,4), ylim=(0,2), zlim=(-.5,.5), legend=false, c=:jet1)

# ╔═╡ Cell order:
# ╠═693ff74e-d4ef-11eb-3992-a7254cab737c
# ╠═68f6fc57-24b3-47f6-9705-f5d4a5112ffb
# ╠═d9aa9e8a-f539-4f18-a9bf-72092cc18bfa
# ╠═43a0594d-a48b-403d-956d-177efcebd97b
# ╠═39bdebab-d9fe-48c3-9e59-1cdf08de1d19
# ╠═b052bfba-63e5-4d52-a455-4a2dcd5094c9
# ╠═797c537c-a070-4b00-bebe-7d08c9af062e
# ╠═e3762506-c9ac-4290-a6c9-34330d1a5964
# ╠═2a6e15c3-0e38-4029-bd98-fd36ea28e05b
