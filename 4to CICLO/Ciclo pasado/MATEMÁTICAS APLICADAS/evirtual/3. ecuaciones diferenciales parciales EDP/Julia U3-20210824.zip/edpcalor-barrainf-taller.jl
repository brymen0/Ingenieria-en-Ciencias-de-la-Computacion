### A Pluto.jl notebook ###
# v0.14.7

using Markdown
using InteractiveUtils

# ╔═╡ ab5eae9c-cf6b-11eb-140f-11c59861456e
using Plots

# ╔═╡ 43c193cd-1d5b-4d3e-b920-1bc87cc3d76c
using SciPy

# ╔═╡ 1aa94751-3701-490a-914b-dc6192394c50
begin
	U0 = 100 # temperatura inicial
	c = 1 
	dt = 0.02
	xs = range(-3, stop=3, length=100)
	ts = range(0, stop=10, length=100)
end

# ╔═╡ 332dfed0-4b7a-40f2-abd7-55a0cdf77d4a
u(x,t) = (U0/2)*(SciPy.special.erf((1-x)/(2*c*sqrt(t))) + SciPy.special.erf((1+x)/(2*c*sqrt(t))))

# ╔═╡ 4dc49646-0fe5-4062-b158-8a47e344a198
begin
	t=0
	value=0
	a = Array{}[]
	for i in 1:500
		value = [u(x,t) for x in xs]
		t += dt
		push!(a, value)
	end
		
end

# ╔═╡ 12992278-105c-4d42-ab6c-3ff9f52eb2c9
plot(xs, a[20])

# ╔═╡ 05746e9c-fd37-47e1-a886-4e1adbf88441
begin
	anim = Plots.Animation()
	for i = 1:1:length(a)
		plot(xs, a[i], legend=false, ylim=(0,100), xlabel="x", ylabel="u(x,t)")
		Plots.frame(anim)
	end
	
	mp4(anim, "edpcalor-barrainf-taller.mp4", fps=1/dt)
end

# ╔═╡ 0d636e3b-36a5-47f4-95a9-ace33cb84ce6
z = Surface((x,t)->u(x,t), xs, ts)

# ╔═╡ b1d87de3-d094-4c2c-b482-03c470e1cf53
surface(xs, ts, z, xlabel="x", ylabel="t", zlabel="u(x,t)")

# ╔═╡ 8ab8fe8c-3e47-4bc0-a380-1904c248df31
heatmap(xs, ts, z, xlabel="x", ylabel="t", zlabel="u(x,t)")

# ╔═╡ Cell order:
# ╠═ab5eae9c-cf6b-11eb-140f-11c59861456e
# ╠═43c193cd-1d5b-4d3e-b920-1bc87cc3d76c
# ╠═1aa94751-3701-490a-914b-dc6192394c50
# ╠═332dfed0-4b7a-40f2-abd7-55a0cdf77d4a
# ╠═4dc49646-0fe5-4062-b158-8a47e344a198
# ╠═12992278-105c-4d42-ab6c-3ff9f52eb2c9
# ╠═05746e9c-fd37-47e1-a886-4e1adbf88441
# ╠═0d636e3b-36a5-47f4-95a9-ace33cb84ce6
# ╠═b1d87de3-d094-4c2c-b482-03c470e1cf53
# ╠═8ab8fe8c-3e47-4bc0-a380-1904c248df31
