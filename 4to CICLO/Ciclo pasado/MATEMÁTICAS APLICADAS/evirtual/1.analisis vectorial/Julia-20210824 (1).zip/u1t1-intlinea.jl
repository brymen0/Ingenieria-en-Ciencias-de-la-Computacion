### A Pluto.jl notebook ###
# v0.14.1

using Markdown
using InteractiveUtils

# ╔═╡ 10f26566-9865-11eb-2c68-1732c0d15414
begin
	using Plots
	plotlyjs()
	#gr
	#pyplot
end

# ╔═╡ f6ffeee3-8e17-4438-8b92-a25e35725f58
begin
	using LaTeXStrings
	latexstring("f(x,y)=\\frac{x^2+y^2}{4} + \\frac{xy}{2}")
end

# ╔═╡ e15f3999-53fc-4d95-958d-0eee9ed676f1
latexstring("C:\\; \\vec{r}(t) = 2\\cos(t)\\hat{\\imath} + 2\\sin(t)\\hat{\\jmath}")

# ╔═╡ d14b3b7e-f611-4a3e-8734-627a7fe1b0cf
begin
	xs=range(-2,stop=2, length=50)
	ys=range(-2,stop=2, length=50)
	f(x,y) = (x^2+y^2)/4 + (x*y)/2
	surface(xs,ys,f, opacity=.5)
	ts=range(0,stop=2pi,length=50)
	xs1=[2*cos(t) for t in ts]
	ys1=[2*sin(t) for t in ts]
	zs1=[0 for t in ts]
	plot!(xs1,ys1,zs1, label="C", color=:green, linewidth=4)
	
	xs1=[2*cos(t) for t in ts]
	ys1=[2*sin(t) for t in ts]
	#zs1=[f(2*cos(t),2*sin(t)) for t in ts]
	zs1=[1+sin(2*t) for t in ts]
	plot!(xs1,ys1,zs1, label="C", color=:green, linewidth=4)
end

# ╔═╡ bab82d7a-e20e-45dc-a549-afcb2fe93c97
begin
	XC(r,theta,z)=r*cos(theta)
	YC(r,theta,z)=r*sin(theta)
	ZC(r,theta,z)=z
end

# ╔═╡ b13c2f05-19e2-43f2-a567-c58625891be5
begin
	zs=range(0,stop=2,length=50)
	thetas=range(0,stop=2*pi,length=50)
	xs2=[XC(2,theta,z) for theta in thetas, z in zs]
	ys2=[YC(2,theta,z) for theta in thetas, z in zs]
	#zs2=[ZC(2,theta,z) for theta in thetas, z in zs]
	zs2=[ZC(2,theta,minimum([z,f(2*cos(theta),2*sin(theta))])) for theta in thetas, z in zs]
	#zs2=[ZC(2,theta,f(2*cos(theta),2*sin(theta))) for theta in thetas, z in zs]
	surface(xs2,ys2,zs2)
	plot!(xs1,ys1,zs1, label="C", color=:green, linewidth=8)
end

# ╔═╡ bc6bcef3-b7d6-4a99-9e0a-2972bde9e127


# ╔═╡ Cell order:
# ╠═10f26566-9865-11eb-2c68-1732c0d15414
# ╟─f6ffeee3-8e17-4438-8b92-a25e35725f58
# ╟─e15f3999-53fc-4d95-958d-0eee9ed676f1
# ╠═d14b3b7e-f611-4a3e-8734-627a7fe1b0cf
# ╠═bab82d7a-e20e-45dc-a549-afcb2fe93c97
# ╠═b13c2f05-19e2-43f2-a567-c58625891be5
# ╠═bc6bcef3-b7d6-4a99-9e0a-2972bde9e127
