### A Pluto.jl notebook ###
# v0.14.1

using Markdown
using InteractiveUtils

# ╔═╡ 1fd08584-986c-11eb-0cb7-d75a30e1f5e0
begin
	using Plots
	plotlyjs()
end

# ╔═╡ cbd6fa43-97d7-4292-9201-0360757abd43
begin
	using CalculusWithJulia
	F(u,v)=[cos(u+v),u]
	vectorfieldplot(F,xlim=(-5,5),ylim=(-5,5), nx=10, ny=10)
end

# ╔═╡ 12600d06-e58f-4849-8f32-789bd50d747a
f(x,y)=x^3-3x+y^2

# ╔═╡ 27c4b154-b5fd-4996-a27b-0390e0d9e10e
begin
	gr()
	X=range(-2,stop=2, length=100)
	Y=range(-2,stop=2, length=100)
	contour(X,Y,f)
	
    x = range(-2, stop=2, length=11)
    y = range(-2, stop=2, length=11)
    ∇f(x, y) = [3x^2 - 3, 2y] / 25
	
	quiver!(repeat(x,11), vec(repeat(y',11)), quiver=∇f, c=:blue)
	
	
end

# ╔═╡ Cell order:
# ╠═1fd08584-986c-11eb-0cb7-d75a30e1f5e0
# ╠═12600d06-e58f-4849-8f32-789bd50d747a
# ╠═27c4b154-b5fd-4996-a27b-0390e0d9e10e
# ╠═cbd6fa43-97d7-4292-9201-0360757abd43
