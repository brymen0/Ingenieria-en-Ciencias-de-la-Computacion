
public class Declaraciones_Operaciones2 {

	public static void main(String[] args) {
		final double apulgadas = 2.54;
		double cm = 6;
		double resultado = cm / apulgadas;
		System.out.println(apulgadas);
		System.out.println("En " + cm + " cm hay " + resultado + " pulgadas");
		

	}

}
