
public class Variables {

	public static void main(String[] args) {
		byte edad= 35;  //Declaracion e iniciacion de una variable en una sola linea 
		/* La siguiente instruccion imprime en la consola el
		 * valor de la variable edad
		 */
		System.out.println(edad);
		edad = 75;
		System.out.println(edad);

	}

}
