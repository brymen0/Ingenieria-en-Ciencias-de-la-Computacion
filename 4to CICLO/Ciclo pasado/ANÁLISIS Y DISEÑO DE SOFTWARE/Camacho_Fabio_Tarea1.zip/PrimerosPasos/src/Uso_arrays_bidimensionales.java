
public class Uso_arrays_bidimensionales {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][] matrix = new int [4][5];
		matrix[0][0]= 1;
		matrix[0][1]= 15;
		matrix[0][2]= 18;
		matrix[0][3]= 9;
		matrix[0][4]= 36;
		
		matrix[1][0]= 47;
		matrix[1][1]= 36;
		matrix[1][2]= 28;
		matrix[1][3]= 14;
		matrix[1][4]= 58;
		
		matrix[2][0]= 69;
		matrix[2][1]= 38;
		matrix[2][2]= 11;
		matrix[2][3]= 23;
		matrix[2][4]= 45;
		
		matrix[3][0]= 33;
		matrix[3][1]= 77;
		matrix[3][2]= 91;
		matrix[3][3]= 86;
		matrix[3][4]= 93;
		
		for (int i=0; i<4;i++) {
			System.out.println();
			for(int j=0; j<5; j++) {
				System.out.print(matrix[i][j]+" ");
			}
		}
		
		
		

	}

}
