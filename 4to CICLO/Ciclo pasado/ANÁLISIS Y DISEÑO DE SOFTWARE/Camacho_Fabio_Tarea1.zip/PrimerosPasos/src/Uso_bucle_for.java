
public class Uso_bucle_for {

	public static void main(String[] args) {
		for(int i=0; i<10; i++) {
			System.out.println("Fabio");
		}

	}

}
