
public class Declaraciones_Operadores {

	public static void main(String[] args) {
		double a = 5;
		double b;
		b = 10;
		double c = b / a;
		//c+=6;
		System.out.println(c);

	}

}
