import java.util.*;
public class Entrada_ejemplo1 {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		System.out.println("Introduce tu nombre: ");
		String nombreUsuario = entrada.nextLine();
		System.out.println("Introduzca su edad, por favor: ");
		int edad=entrada.nextInt();
		System.out.println("Hola "+ nombreUsuario+". El año que viene tendrás "+ (edad+1)+" años.");
	}

}
