
public class Manipula_Cadenas3 {

	public static void main(String[] args) {
		String alumno1, alumno2;
		alumno1 = "Fabio";
		alumno2 = "fabio";
		System.out.println(alumno1.equalsIgnoreCase(alumno2));

	}

}
