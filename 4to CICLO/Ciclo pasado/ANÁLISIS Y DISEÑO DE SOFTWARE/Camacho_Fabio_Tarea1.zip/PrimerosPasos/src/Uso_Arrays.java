
public class Uso_Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int mi_matriz[]= new int[5];
		mi_matriz[0]=5;
		mi_matriz[1]=35;
		mi_matriz[2]=76;
		mi_matriz[3]=43;
		mi_matriz[4]=21;
		for(int i=0; i<5; i++) {
			System.out.println("Valor de la posición "+i+": "+mi_matriz[i]);
		}
		

	}

}
