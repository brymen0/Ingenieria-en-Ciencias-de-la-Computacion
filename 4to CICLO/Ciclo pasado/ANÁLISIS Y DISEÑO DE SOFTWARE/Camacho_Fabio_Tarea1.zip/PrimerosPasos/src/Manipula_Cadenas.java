
public class Manipula_Cadenas {

	public static void main(String[] args) {
		String nombre = "Fabio";
		System.out.println("Mi nombre es: "+nombre);
		System.out.println("Mi nombre tiene: "+nombre.length()+" caracteres.");
		System.out.println("La primera letra de "+nombre+" es: "+nombre.charAt(0));
		int ultimaLetra;
		ultimaLetra = nombre.length();
		System.out.println("Y la ultima letra es la: "+nombre.charAt(ultimaLetra-1));
		

	}

}
