import javax.swing.*;
public class Entrada_Numeros {

	public static void main(String[] args) {
		String num1 = JOptionPane.showInputDialog("Introduce un número: ");
		double numUno = Double.parseDouble(num1);
		System.out.print("La raíz de "+numUno+" es: ");
		System.out.printf("%1.2f",Math.sqrt(numUno));
	}

}
