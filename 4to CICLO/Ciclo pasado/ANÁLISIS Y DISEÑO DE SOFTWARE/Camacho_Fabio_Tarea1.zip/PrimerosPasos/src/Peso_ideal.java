import javax.swing.*;
public class Peso_ideal {

	public static void main(String[] args) {
		String genero = "";
		do {
			genero = JOptionPane.showInputDialog("Introduce tu género (H/M): ");
			
		}while(genero.equalsIgnoreCase("H")==false && genero.equalsIgnoreCase("M")==false);
		int altura = Integer.parseInt(JOptionPane.showInputDialog("Introduce tu altura en centímetros: "));
		int pesoIdeal = 0;
		if(genero.equalsIgnoreCase("H")) {
			pesoIdeal = altura - 110;
			
		}else if(genero.equalsIgnoreCase("M")) {
			pesoIdeal = altura - 120;
		}
		System.out.println("Su peso ideal es: "+pesoIdeal+" Kilogramos.");
	}

}
