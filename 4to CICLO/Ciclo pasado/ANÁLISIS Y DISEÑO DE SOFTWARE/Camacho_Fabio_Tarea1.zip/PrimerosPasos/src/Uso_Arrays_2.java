import javax.swing.*;
public class Uso_Arrays_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String [] paises= new String[8];
		for(int i=0; i<8; i++) {
			paises[i]= JOptionPane.showInputDialog("Introduce el país "+(i+1));
		}
		/*paises[0] = "España";
		paises[1] = "Colombia";
		paises[2] = "Perú";
		paises[3] = "Chile";
		paises[4] = "Argentina";
		paises[5] = "Ecuador";
		paises[6] = "México";
		paises[7] = "Venezuela";*/
		
		/*for(int i = 0; i<paises.length;i++) {
			System.out.println("País "+(i+1)+" "+paises[i]);
		}*/
		for(String elemento: paises) {
			System.out.println("País: "+elemento);
		}

	}

}
