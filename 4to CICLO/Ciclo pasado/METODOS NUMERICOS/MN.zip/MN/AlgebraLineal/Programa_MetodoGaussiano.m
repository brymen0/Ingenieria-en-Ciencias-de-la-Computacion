
% Ejemplo de uso:
A = [2, -1, 1;
     1, 3, -2;
     2, 1, 3];
b = [-8;
     5;
     4];

function x = gaussian_elimination(A, b)
  n = size(A, 1);
  Ab = [A b];

  % Eliminación hacia adelante
  for k = 1:n-1
    % Pivoteo parcial
    [~, pivot_row] = max(abs(Ab(k:n, k)));
    pivot_row = pivot_row + k - 1;
    Ab([k, pivot_row], :) = Ab([pivot_row, k], :);

    for i = k+1:n
      factor = Ab(i, k) / Ab(k, k);
      Ab(i, k:n+1) = Ab(i, k:n+1) - factor * Ab(k, k:n+1);
    end
  end

  % Sustitución hacia atrás
  x = zeros(n, 1);
  x(n) = Ab(n, n+1) / Ab(n, n);

  for i = n-1:-1:1
    x(i) = (Ab(i, n+1) - Ab(i, i+1:n) * x(i+1:n)) / Ab(i, i);
  end
end


x = gaussian_elimination(A, b);
disp(x);

