clear;
clc;

A = [10, 1, 2; 4, 6, -1; -2, 3, 8];
b = [3; 9; 51];
x0 = [0; 0; 0];
tol = 1e-6;
max_iter = 100;


function [x, iter] = jacobi(A, b, x0, tol, max_iter)
    n = size(A, 1);
    x = x0;
    iter = 0;
    m = 6; %Ingrese m decimales significativos
    disp('MÉTODO JACOBI');
    disp('Iter   [x1;x2;x3]          Error');
    disp('--------------------------------');
    while true
        x_new = zeros(size(x));
        for i = 1:n
            sum = 0;
            for j = 1:n
                if j ~= i
                    sum = sum + A(i, j) * x(j);
                end
            end
            x_new(i) = (b(i) - sum) / A(i, i);
        end
        iter = iter + 1;
        error = norm(x_new - x);
        disp(sprintf('%3d    %s    %s', iter, mat2str(x_new, m), sprintf(['%.*f, '], m, error)));
        if error < tol || iter >= max_iter
          fprintf("El error no varía mucho, por lo que se detiene el procedimiento.\n");
          break;
        endif

        if error == 0
          fprintf("Se llegó al valor exacto, por lo que se detiene el procedimiento.\n");
          break;
        endif
        x = x_new;
    end
end


[x, iter] = jacobi(A, b, x0, tol, max_iter);
