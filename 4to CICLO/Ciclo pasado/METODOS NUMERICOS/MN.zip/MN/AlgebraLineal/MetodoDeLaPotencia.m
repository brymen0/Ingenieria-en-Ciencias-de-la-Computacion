clear;
clc;

function metodo_potencia(A, x0, tol, max_iterations, sig_digits)
    formato = strcat("%.", num2str(sig_digits), "f");
    iterations = 0;
    error=100;
    lambda = 0;
    v = x0;

    fprintf('Iter\tLambda\tVector Propio\tError\n');
    fprintf('---------------------------------------\n');

    while iterations < max_iterations
        iterations = iterations + 1;

        v_old=v;
        v = A * v_old;
        lambda_old = lambda;
        lambda = max(abs(v));

        v = v / lambda;
        error = abs((lambda - lambda_old)/lambda)*100;

        if error < tol
           break;
       end

        fprintf('%d\t%s\t[%s,%s]\t%s\n', iterations, sprintf(formato,lambda),sprintf(formato,v(1)),sprintf(formato,v(2)),sprintf(formato,error));
    end
end

% Definir la matriz A
A = [3, -2;1,0];

% Definir el vector inicial x0
x0 = [1; 0];

% Definir la tolerancia
tol = 0.05;

% Definir el número máximo de iteraciones
max_iterations = 20;

% Definir el número de cifras significativas a considerar (EN REALIDAD SOLO CONSIDERA LOS DECIMALES)
sig_digits = 3;

% Llamar a la función metodo_potencia
metodo_potencia(A, x0, tol, max_iterations, sig_digits);

