clear;
clc;

% Matriz de entrada
A = [2, 3, -1;
     -6, -6, 5;
     4, 18, 6;
     -2, -9, -3];

% Tamaño de la matriz
[m, n] = size(A);

% Verificar si la matriz es de tamaño 4x3
if m ~= 4 || n ~= 3
    disp('La matriz debe ser de tamaño 4x3');
    return;
end

% Inicializar matrices L y U
L = eye(m);  % Matriz identidad de tamaño 4x4
U = zeros(m, n);

% Descomposición LU
for i = 1:m
    for j = 1:n
        if j >= i
            U(i, j) = A(i, j) - L(i, 1:i-1) * U(1:i-1, j);
        else
            L(i, j) = (A(i, j) - L(i, 1:j-1) * U(1:j-1, j)) / U(j, j);
        end
    end
end

% Mostrar matrices L y U
disp('Matriz L:');
disp(L);
disp('Matriz U:');
disp(U);



