% Ejemplo de uso:
A = [1, 1, 1;
     1, -1, 2;
     1, -1, -3];
b = [6;
     5;
     -10];
function x = gauss_jordan(A, b)
  n = size(A, 1);
  Ab = [A b];

  % Eliminación hacia adelante
  for k = 1:n
    % Pivoteo parcial
    [~, pivot_row] = max(abs(Ab(k:n, k)));
    pivot_row = pivot_row + k - 1;
    Ab([k, pivot_row], :) = Ab([pivot_row, k], :);

    % Normalización del pivote
    Ab(k, :) = Ab(k, :) / Ab(k, k);

    % Eliminación en las filas restantes
    for i = 1:n
      if i ~= k
        factor = Ab(i, k);
        Ab(i, :) = Ab(i, :) - factor * Ab(k, :);
      end
    end
  end

  % Extraer la solución
  x = Ab(:, end);
end


x = gauss_jordan(A, b);
disp(x);

