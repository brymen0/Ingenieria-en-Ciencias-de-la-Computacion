clear;
clc;

function [L] = cholesky(A)
  n = size(A, 1);
  L = zeros(n, n);

  for i = 1:n
    for j = 1:i
      if i == j
        L(i, i) = sqrt(A(i, i) - sum(L(i, 1:i-1).^2));
      else
        L(i, j) = (A(i, j) - sum(L(i, 1:j-1) .* L(j, 1:j-1))) / L(j, j);
      end

      if isnan(L(i, j)) || isinf(L(i, j))
        error('La matriz no es positiva definida. No se puede realizar la descomposición de Cholesky.');
      end
    end

    if L(i, i) <= 0
      error('La matriz no es positiva definida. No se puede realizar la descomposición de Cholesky.');
    end
  end
end

% Solicitar al usuario el tamaño de la matriz
n = input('Ingrese el tamaño de la matriz cuadrada: ');

% Validar el tamaño de la matriz
if n <= 0
  error('El tamaño de la matriz debe ser mayor que cero.');
end

% Solicitar al usuario los elementos de la matriz
A = zeros(n, n);
for i = 1:n
  for j = 1:n
    A(i, j) = input(sprintf('Ingrese el elemento A(%d, %d): ', i, j));
  end
end

% Solicitar al usuario los elementos del vector de valores independientes
b = zeros(n, 1);
for i = 1:n
  b(i) = input(sprintf('Ingrese el valor independiente b(%d): ', i));
end

% Llamar a la función cholesky para obtener la descomposición
L = cholesky(A);

% Resolver el sistema de ecuaciones utilizando la descomposición de Cholesky
y = L \ b;                             % Resolver Ly = b
x = L' \ y;                            % Resolver L'x = y

% Mostrar la matriz L resultante
disp('La matriz L de la descomposición de Cholesky es:');
disp(L);

% Mostrar la solución del sistema de ecuaciones
disp('La solución del sistema de ecuaciones Ax = b es:');
disp(x);

