#MÉTODO DE JACOBI
#AUTORES: Renata Martínez - Jonnathan Aguilar
#FECHA: 18/07/2023

clear;
clc;

%---------------------------START FUNCTION 1-----------------------------------%
function iteraciones(A,b,x0,m)
  % Ingrese el número máx de las iteraciones
  max_iter = input('Ingrese el número de iteraciones: ');

  %Para obtener la cantidad de cifras significativas (después de la coma) que solicitó el usuario.
  formato = strcat("%.", num2str(m), "f");

  n = length(b);
  x = x0;

  fprintf("%s\t",'Iter.');
  for i=1:1:n
    fprintf("x%d\t",i);
  endfor
  fprintf("Error\n");

  error_a=100;
  converge=0;
  diverge=0;


  for k=1:1:max_iter
    x_prev = x;
    error_anterior=error_a;

    for i=1:1:n
      sigma = 0;
      sigma=sscanf(sprintf(sprintf("%%.%df", m), sigma), "%f");

      for j = 1:1:n
        if j ~= i
          sigma = sigma + A(i,j) * x_prev(j);
        endif
      endfor
      x(i) = (b(i) - sigma) / A(i, i);
      %x(i)= sscanf(sprintf(sprintf("%%.%df", m), x(i)), "%f");
    endfor

    norma = norm(x_prev - x);
    normaK = norm(x);

    error_a = (norma / normaK)*100;
    %error_a=sscanf(sprintf(sprintf("%%.%df", m), error_a), "%f");

    error_actual=error_a;

    %fprintf("\n%d || ",k);
    fprintf("%-6d", k);


    for i=1:1:n
      %fprintf("%s || ",i, sprintf(formato, x(i)));
      fprintf(" %-8s ", sprintf(formato, x(i)));
    endfor

    %fprintf("%s%%\n",sprintf(formato, error_a));
    fprintf(" %-10s\n", sprintf(formato, error_a));

    if(error_actual<error_anterior && error_actual<100) %La raíz converge o diverge dependiendo de los errores
        converge++;
      else
        diverge++;
     endif

      if(error_a==0)
         fprintf("Se llegó al valor exacto, por lo que se detiene el procedimiento\n");
        break;
      endif

      if(abs(error_actual-error_anterior)<0.001 && k>2)
        fprintf("El error no varía mucho, por lo que se detiene el procedimiento\n");
        break;
      endif

  endfor

    if(converge>diverge)
      for i=1:1:n
        fprintf("\nx(%d) = %s ",i,sprintf(formato, x(i)));
      endfor

      fprintf("\nEl error porcentual aproximado es: %s%%.\n", sprintf(formato, error_a));
    else
      fprintf("\nDiverge");
    endif

endfunction

%----------------------------END FUNCTION 1------------------------------------%

%---------------------------START FUNCTION 2-----------------------------------%
function umbral(A,b,x0,m)
  %Para obtener la cantidad de cifras significativas (después de la coma) que solicitó el usuario.
  formato = strcat("%.", num2str(m), "f");

  n = length(b);
  x = x0;

  % Tolerancia
  tol = 0.5 * 10^(2-m); %Definir el error significativo (umbral) y truncarlo en base a m cifras significativas.

  fprintf("%s\t",'Iter.');
  for i=1:1:n
    fprintf("x%d\t",i);
  endfor
  fprintf("Error\n");

  error_a=100;
  converge=0;
  diverge=0;

  k=1;
  while error_a > tol
    x_prev = x;
    error_anterior=error_a;

    for i=1:1:n
      sigma = 0;
      sigma=sscanf(sprintf(sprintf("%%.%df", m), sigma), "%f");

      for j = 1:1:n
        if j ~= i
          sigma = sigma + A(i,j) * x_prev(j);
        endif
      endfor
      x(i) = (b(i) - sigma) / A(i, i);

    endfor

    norma = norm(x_prev - x);
    normaK = norm(x);

    error_a = (norma / normaK)*100;


    error_actual=error_a;

    fprintf("%-6d", k);


    for i=1:1:n
      fprintf(" %-8s ", sprintf(formato, x(i)));
    endfor

    fprintf(" %-10s\n", sprintf(formato, error_a));

    if(error_actual<error_anterior && error_actual<100) %La raíz converge o diverge dependiendo de los errores
        converge++;
      else
        diverge++;
     endif

      if(error_a==0)
         fprintf("Se llegó al valor exacto, por lo que se detiene el procedimiento\n");
        break;
      endif

      if(abs(error_actual-error_anterior)<0.001 && k>2)
        fprintf("El error no varía mucho, por lo que se detiene el procedimiento\n");
        break;
      endif
  k++;
  endwhile

    if(converge>diverge)
      for i=1:1:n
        fprintf("\nx(%d) = %s ",i,sprintf(formato, x(i)));
      endfor

      fprintf("\nEl error porcentual aproximado es: %s%%.\n", sprintf(formato, error_a));
    else
      fprintf("\nDiverge");
    endif

endfunction

%----------------------------END FUNCTION 2------------------------------------%


%--------------------------START MAIN PROGRAM----------------------------------%
% Crear una matriz A - El ingreso de la matriz debe ser: [1 2 3; 4 5 6; 7 8 9]
A = input('Ingrese la matriz estrictamente diagonal dominante A: ');
% Mostrar la matriz ingresada por el usuario
disp("\nLa matriz A ingresada es:");
disp(A);

% Crear un vector b - El ingreso del vector debe ser: [10;11;12]
b = input('Ingrese el vector de términos independientes del sistema: ');
% Mostrar el vector ingresado por el usuario
disp("\nEl vector b de los términos independientes ingresado es:");
disp(b);

% Crear un vector x0  - El ingreso del vector  debe ser: [0;0;0]
x0 = input('Ingrese el vector inicial x0: ');
% Mostrar el vector ingresado por el usuario
disp("\nEl vector inicial x0 ingresado es:");
disp(x0);

cifras = input('Ingrese el número de cifras significativas: ');
clc; % Eliminar vista en consola para que no esté muy lleno la pantalla.

do
  %Menú para solicitar si desea ejecutar el método o salir.
  menu = "\nMENÚ\nDesea realizar por:\n1.Número de iteraciones\n2.Umbral\n3.Salir\nIngrese una opción <1-3>: ";
  opc = input(menu);

  switch(opc)
     case 1
        iteraciones(A,b,x0,cifras);

     case 2
        umbral(A,b,x0,cifras);

     case 3 %Salir
       fprintf("Saliendo...\n");

     otherwise
       fprintf("Error! Ingrese una opción válida <1-3>\n");
  endswitch

until(opc == 3);
%----------------------------END MAIN PROGRAM----------------------------------%

