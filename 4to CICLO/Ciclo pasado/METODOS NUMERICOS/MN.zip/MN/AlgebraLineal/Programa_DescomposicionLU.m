clear;
clc;

function [L, U, x] = luDecomposition(A, b)
    n = size(A, 1);
    L = eye(n);
    U = zeros(n);

    for k = 1:n
        U(k, k:n) = A(k, k:n) - L(k, 1:k-1) * U(1:k-1, k:n);
        L(k+1:n, k) = (A(k+1:n, k) - L(k+1:n, 1:k-1) * U(1:k-1, k)) / U(k, k);
    end

    y = forwardSubstitution(L, b);
    x = backwardSubstitution(U, y);
end

function x = forwardSubstitution(L, b)
    n = size(L, 1);
    x = zeros(n, 1);

    for k = 1:n
        x(k) = (b(k) - L(k, 1:k-1) * x(1:k-1)) / L(k, k);
    end
end

function x = backwardSubstitution(U, b)
    n = size(U, 1);
    x = zeros(n, 1);

    for k = n:-1:1
        x(k) = (b(k) - U(k, k+1:n) * x(k+1:n)) / U(k, k);
    end
end

function main()
    % Solicitar tamaño de la matriz
    n = input('Ingrese el tamaño de la matriz cuadrada: ');

    % Validar tamaño de la matriz
    if n <= 0
        error('El tamaño de la matriz debe ser un número entero positivo.');
    end

    % Solicitar matriz A
    disp('Ingrese los elementos de la matriz A:');
    A = zeros(n);
    for i = 1:n
        for j = 1:n
            A(i, j) = input(sprintf('A(%d, %d): ', i, j));
        end
    end

    % Validar matriz A
    if det(A) == 0
        error('La matriz A debe ser no singular (determinante diferente de cero).');
    end

    % Solicitar vector b
    disp('Ingrese los elementos del vector b:');
    b = zeros(n, 1);
    for i = 1:n
        b(i) = input(sprintf('b(%d): ', i));
    end

    % Realizar descomposición LU
    [L, U, x] = luDecomposition(A, b);

    % Mostrar resultados
    disp('Matriz L:');
    disp(L);
    disp('Matriz U:');
    disp(U);
    disp('Resultado final (vector x):');
    disp(x);
end

% Ejecutar la función principal
main();

