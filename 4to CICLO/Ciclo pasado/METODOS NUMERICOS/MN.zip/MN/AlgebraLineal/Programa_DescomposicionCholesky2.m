clear;
clc;
% Matriz de entrada
A = [1, -1, 1;
     -1, 5, -5;
     1, -5, 6];

% Descomposición de Cholesky
L = chol(A, 'lower');  % Matriz triangular inferior L

% Mostrar matrices L y L^T
disp('Matriz L:');
disp(L);
disp('Matriz L^T:');
disp(L');

