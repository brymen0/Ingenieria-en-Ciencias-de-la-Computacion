clear;
clc;

% Matriz de entrada
A = [2, 3, -1, 5;
     -6, -6, 5, -10;
     4, 18, 6, 12];

% Tamaño de la matriz
[m, n] = size(A);

% Verificar si la matriz es de tamaño 3x4
if m ~= 3 || n ~= 4
    disp('La matriz debe ser de tamaño 3x4');
    return;
end

% Inicializar matrices L y U
L = eye(m);  % Matriz identidad de tamaño 3x3
U = zeros(m, n);

% Descomposición LU
for j = 1:n
    for i = 1:m
        if i <= j
            U(i, j) = A(i, j) - L(i, 1:i-1) * U(1:i-1, j);
        else
            L(i, j) = (A(i, j) - L(i, 1:j-1) * U(1:j-1, j)) / U(j, j);
        end
    end
end

% Mostrar matrices L y U
disp('Matriz L:');
disp(L);
disp('Matriz U:');
disp(U);


