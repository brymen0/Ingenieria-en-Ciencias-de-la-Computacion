#MÉTODO DE GAUSS - SEIDEL
#AUTORES: Renata Martínez - Jonnathan Aguilar
#FECHA: 03/05/2023
clear;
clc;

%---------------------------START FUNCTION 1-----------------------------------%
function gaussSeidel(A, b, x0, tol, max_iter, m)
    % A: matriz de coeficientes del sistema de ecuaciones.
    % b: vector de términos independientes.
    % x0: aproximación inicial.
    % tol: tolerancia para el criterio de convergencia.
    % max_iter: número máximo de iteraciones.

    formato = strcat("%.", num2str(m), "f"); %Para obtener la cantidad de cifras significativas (después de la coma) que solicitó el usuario.

    n = length(b);
    x = x0;

    iter = 1;

    while iter <= max_iter
        x_prev = x;

        for i = 1:1:n
            sigma = A(i,1:i-1) * x(1:i-1) + A(i, i+1:n) * x(i+1:n);

            %{
            sigmaTruncado = sscanf(sprintf(sprintf("%%.%df", m), sigma), "%f");

            sprintf se utiliza para formatear el número de entrada sigma a un formato de cadena que incluye solo m cifras significativas.
            Luego, sscanf se utiliza para convertir la cadena truncada nuevamente en un número.
            %}

            x(i) = (b(i) - sigma) / A(i, i);
        endfor

        norma = norm(x_prev - x);
        normaK = norm(x);

        error_r = (norma / normaK)*100;

        if norma <= tol
          fprintf("\nEL MÉTODO CONVERGE\n");
          fprintf("\nLa solución en la iteración %d es: \n",iter);

          for i=1:1:n
            fprintf("\tx(%d) = %s     ||     ",i, sprintf(formato, x(i)));
          endfor
          fprintf("\tError = %s\n",sprintf(formato, error_r));
          centinela=2;
          break;

        else
          fprintf("\nPara la iteración %d: \n",iter);
          for i=1:1:n
            fprintf("\tx(%d) = %s     ||     ",i, sprintf(formato, x(i)));
          endfor
          fprintf("\tError = %s%%\n",sprintf(formato, error_r));
          centinela=1;

        endif
        iter = iter + 1;
    endwhile

    if(centinela==1)
      fprintf("\nEl método diverge en %d iteraciones posiblemente.\n",max_iter);
      fprintf("Debes dar un mayor número de iteraciones o este sistema diverge con este método.\n");
    endif

endfunction
%----------------------------END FUNCTION 1------------------------------------%


%--------------------------START MAIN PROGRAM----------------------------------%
% Solicitar tamaño de la matriz
tam = input("Ingrese el tamaño de la matriz: ");
fprintf("\nIngrese la matriz de coeficientes del sistema:\n");

% Crear una matriz vacía A
A = [];

% Solicitar los elementos de la matriz
for i = 1:tam
    row = [];
    for j = 1:tam
        element = input(sprintf("Ingrese el elemento A(%d,%d): ", i, j));
        row = [row, element];
    end
    A = [A; row];
end

% Mostrar la matriz ingresada por el usuario
disp("\nLa matriz A ingresada es:");
disp(A);

fprintf("\nIngrese el vector de términos independientes del sistema:\n");
% Crear un vector vacío
b = [];

% Solicitar los elementos del vector
for i = 1:tam
    element = input(sprintf("Ingrese el elemento b(%d): ", i));
    b = [b; element];
end

% Mostrar el vector ingresado por el usuario
disp("\nEl vector b de los términos independientes ingresado es:");
disp(b);

fprintf("\nIngrese el vector inicial:\n");
% Crear un vector vacío
x0 = [];

% Solicitar los elementos del vector
for i = 1:tam
    element = input(sprintf("Ingrese el elemento x(%d): ", i));
    x0 = [x0; element];
end

% Mostrar el vector ingresado por el usuario
disp("\nEl vector inicial x0 ingresado es:");
disp(x0);

clc; %Eliminar vista en consola para que no esté muy lleno la pantalla.

do

  %Menú para solicitar si desea por ejecutar el método o salir.
  menu = "\nMENÚ\n1.Ejecutar método Gauss-Seidel\n2.Salir\nIngrese una opción <1-2>: ";
  opc = input(menu);
  switch(opc)
     case 1 %Ejecución del método.

       %En base a las cifras significativas, se calcula la tolerancia.
        cifras = input('Ingrese el número de cifras significativas: ');

        % Tolerancia
        tol = 0.5 * 10^(2-cifras); %Definir el error significativo (umbral) y truncarlo en base a m cifras significativas.

        % Ingrese el número máx de las iteraciones
        max_iter = input('Ingrese el número de iteraciones: ');

        clc; %Eliminar vista en consola para que no esté muy lleno la pantalla.

       % Mostrar la matriz ingresada por el usuario.
        printf("A = \n");
        disp(A);
        gaussSeidel(A, b, x0, tol, max_iter, cifras); %Llamar al método.

     case 2 %Salir
       fprintf("Saliendo...\n");

     otherwise
       fprintf("Error! Ingrese una opción válida <1-2>\n");
  endswitch

until(opc == 2);
%----------------------------END MAIN PROGRAM----------------------------------%
