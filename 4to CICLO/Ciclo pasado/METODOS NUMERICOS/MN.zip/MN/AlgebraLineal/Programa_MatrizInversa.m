clc;
format rat

% Ejemplo de uso:
A = [4, 1, 3;
     2, 1, 4;
     0, 1, 2];

function A_inv = inverse_matrix(A)
  % Calcula el determinante
  det_A = det(A);
  disp("Determinante de la matriz:");
  disp(det_A);

  % Calcula la matriz transpuesta
  A_transpose = A';
  disp("Matriz transpuesta:");
  disp(A_transpose);

  % Calcula la matriz adjunta de la matriz transpuesta
  adj_A_transpose = adjugate_matrix(A_transpose);
  disp("Adjunta de la matriz transpuesta:");
  disp(adj_A_transpose);

  % Calcula la matriz inversa
  A_inv = adj_A_transpose / det_A;
  disp("Matriz inversa:");
  disp(A_inv);
end

% Función para calcular la matriz adjunta de una matriz
function adj = adjugate_matrix(A)
  [n, ~] = size(A);
  adj = zeros(n);

  for i = 1:n
    for j = 1:n
      minor = A;
      minor(i, :) = [];
      minor(:, j) = [];
      adj(i, j) = (-1)^(i+j) * det(minor);
    end
  end
end


A_inv = inverse_matrix(A);

