#MÉTODO DE GAUSS - SEIDEL
#AUTORES: Renata Martínez - Jonnathan Aguilar
#FECHA: 05/05/2023

clear;
clc;
%---------------------------START FUNCTION 1-----------------------------------%
function iteraciones(A,b,x0,m)
  % Ingrese el número máx de las iteraciones
  max_iter = input('Ingrese el número de iteraciones: ');

  %Para obtener la cantidad de cifras significativas (después de la coma) que solicitó el usuario.
  formato = strcat("%.", num2str(m), "f");

  n = length(b);
  x = x0;

  fprintf("%s\t",'Iter.');
  for i=1:1:n
    fprintf("x%d\t",i);
  endfor
  fprintf("Error\n");

  error_a=100;
  converge=0;
  diverge=0;


  for j=1:1:max_iter
    x_prev = x;
    error_anterior=error_a;

    for i=1:1:n
      sigma = A(i,1:i-1) * x(1:i-1) + A(i, i+1:n) * x(i+1:n);
      sigma=sscanf(sprintf(sprintf("%%.%df", m), sigma), "%f");

      x(i) = (b(i) - sigma) / A(i, i);
      x(i)= sscanf(sprintf(sprintf("%%.%df", m), x(i)), "%f");
    endfor

    norma = norm(x_prev - x);
    normaK = norm(x);

    error_a = (norma / normaK)*100;
    error_a=sscanf(sprintf(sprintf("%%.%df", m), error_a), "%f");

    error_actual=error_a;

    fprintf("\n%d || ",j);

    for i=1:1:n
       fprintf("%s || ",i, sprintf(formato, x(i)));
    endfor

    fprintf("%s%%\n",sprintf(formato, error_a));

    if(error_actual<error_anterior && error_actual<100) %La raíz converge o diverge dependiendo de los errores
        converge++;
      else
        diverge++;
     endif

      if(error_a==0)
         fprintf("Se llegó al valor exacto por lo que, se detiene el procedimiento\n");
        break;
      endif

      if(abs(error_actual-error_anterior)<0.001 && j>2)
        fprintf("El error no varia mucho por lo que, se detiene el procedimiento\n");
        break;
      endif

endfor

    if(converge>diverge)
      for i=1:1:n
        fprintf("\nx(%d)=%s ",i,sprintf(formato, x(i)));
      endfor

      fprintf("\nEl error porcentual aproximado es: %s%%.\n", sprintf(formato, error_a));
    else
      fprintf("\nDiverge");
    endif

endfunction

%----------------------------END FUNCTION 1------------------------------------%

%---------------------------START FUNCTION 2-----------------------------------%
function umbral(A, b, x0, m)

  %Para obtener la cantidad de cifras significativas (después de la coma) que solicitó el usuario.
  formato = strcat("%.", num2str(m), "f");

  n = length(b);
  x = x0;

  % Tolerancia
  tol = 0.5 * 10^(2-m); %Definir el error significativo (umbral) y truncarlo en base a m cifras significativas.

  fprintf("%s\t",'Iter.');
  for i=1:1:n
    fprintf("x%d\t",i);
  endfor
  fprintf("Error\n");

  error_a=100;
  converge=0;
  diverge=0;


  j=1;
  while error_a>tol
    x_prev = x;

    error_anterior=error_a;

    for i=1:1:n
      sigma = A(i,1:i-1) * x(1:i-1) + A(i, i+1:n) * x(i+1:n);
      sigma= sscanf(sprintf(sprintf("%%.%df", m), sigma), "%f");

      x(i) = (b(i) - sigma) / A(i, i);
      x(i)= sscanf(sprintf(sprintf("%%.%df", m), x(i)), "%f");
    endfor

    norma = norm(x_prev - x);
    normaK = norm(x);

    error_a = (norma / normaK)*100;
    error_a=sscanf(sprintf(sprintf("%%.%df", m), error_a), "%f");

    error_actual=error_a;

    fprintf("\n%d || ",j);

    for i=1:1:n
       fprintf(" %s || ",sprintf(formato, x(i)));
    endfor

    fprintf("%s%%\n",sprintf(formato, error_a));



    if(error_actual<error_anterior && error_actual<100) %La raíz converge o diverge dependiendo de los errores
        converge++;
      else
        diverge++;
      endif

      if(error_a==0)
         fprintf("\nSe llegó al valor exacto por lo que, se detiene el procedimiento.\n");
        break;
      endif

      if(abs(error_actual-error_anterior)<0.001 && j>2 && error_a<100)
        fprintf("\nEl error no varia mucho por lo que, se detiene el procedimiento.\n");
        break;
      endif

j++;
endwhile

    if(converge>diverge)
      for i=1:1:n
        fprintf("\nx(%d)=%s",i,sprintf(formato, x(i)));
      endfor

      fprintf("\nEl error porcentual aproximado es: %s%%.\n", sprintf(formato, error_a));
    else
      fprintf("\nDiverge\n");
    endif

endfunction
%----------------------------END FUNCTION 2------------------------------------%

%--------------------------START MAIN PROGRAM----------------------------------%
% Solicitar tamaño de la matriz
tam = input("Ingrese el tamaño de la matriz: ");
fprintf("\nIngrese la matriz de coeficientes del sistema:\n");

% Crear una matriz vacía A
A = [];

% Solicitar los elementos de la matriz
for i = 1:tam
    row = [];
    for j = 1:tam
        element = input(sprintf("Ingrese el elemento A(%d,%d): ", i, j));
        row = [row, element];
    end
    A = [A; row];
end

% Mostrar la matriz ingresada por el usuario
disp("\nLa matriz A ingresada es:");
disp(A);

fprintf("\nIngrese el vector de términos independientes del sistema:\n");
% Crear un vector vacío
b = [];

% Solicitar los elementos del vector
for i = 1:tam
    element = input(sprintf("Ingrese el elemento b(%d): ", i));
    b = [b; element];
endfor

% Mostrar el vector ingresado por el usuario
disp("\nEl vector b de los términos independientes ingresado es:");
disp(b);

fprintf("\nIngrese el vector inicial:\n");
% Crear un vector vacío
x0 = [];

% Solicitar los elementos del vector
for i = 1:tam
    element = input(sprintf("Ingrese el elemento x(%d): ", i));
    x0 = [x0; element];
end

% Mostrar el vector ingresado por el usuario
disp("\nEl vector inicial x0 ingresado es:");
disp(x0);

cifras = input('Ingrese el número de cifras significativas: ');
clc; % Eliminar vista en consola para que no esté muy lleno la pantalla.

do
  %Menú para solicitar si desea por ejecutar el método o salir.
  menu = "\nMENÚ\nDesea realizar por:\n1.Número de iteraciones\n2.Umbral\n3.Salir\nIngrese una opción <1-3>: ";
  opc = input(menu);

  switch(opc)
     case 1 %Ejecución del método por número de iteraciones.
        iteraciones(A,b,x0,cifras);

     case 2
        umbral(A,b,x0,cifras);

     case 3 %Salir
       fprintf("Saliendo...\n");

     otherwise
       fprintf("Error! Ingrese una opción válida <1-3>\n");
  endswitch

until(opc == 3);
%----------------------------END MAIN PROGRAM----------------------------------%
