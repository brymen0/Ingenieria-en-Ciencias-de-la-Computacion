clc;
clear;
close all;
pkg load symbolic
syms x

%% Función derivada
function fp_xireal=derivada(xi,f)
    syms x
    f(x)=expand(f(x));% Expande la función f(x)
    fp(x)=diff(f(x));% Aplica la derivada a la función f(x)
    fp(x)=expand(fp(x));% Expande la derivada
    fp_xireal=double(fp(xi));
    %                  Grafica la función y la derivada
    x=linspace(0,2,10000);
    figure()
    subplot(2,1,1)
    plot(x,f(x));
    title('Función')
    xlabel('x')
    ylabel('f(x)')
    subplot(2,1,2)
    plot(x,fp(x));
    title('Derivada')
    xlabel('x')
    ylabel('f(x)')
end

%% Cálculo de las diferencias finitas
xi=0.7;
h=[0.1 0.05 0.025 0.0125 0.00625];
steps_size=size(h,2);
f(x) = (x-1).^4 + 4.*(x-1).^3 + 1;
resultados=zeros(3,steps_size);
errores=zeros(3,steps_size);
fp_real=derivada(xi,f);

for i=1:steps_size
    fp_xi_aprox_ade=diferencia_adelante(xi,f,h(1,i));
    fp_xi_aprox_atr=diferencia_atras(xi,f,h(1,i));
    fp_xi_aprox_central=diferencia_central(xi,f,h(1,i));
    resultados(1,i)=fp_xi_aprox_ade;
    resultados(2,i)=fp_xi_aprox_atr;
    resultados(3,i)=fp_xi_aprox_central;
    errores(1,i)=abs(((fp_xi_aprox_ade-fp_real)/(fp_xi_aprox_ade))*100);
    errores(2,i)=abs(((fp_xi_aprox_atr-fp_real)/(fp_xi_aprox_atr))*100);
    errores(3,i)=abs(((fp_xi_aprox_central-fp_real)/(fp_xi_aprox_central))*100);
end

encabezados = strsplit(num2str(h));
filas_encabezados = {'adelante'; 'atras'; 'centrada'};
resultados=array2table(resultados,"VariableNames",encabezados,"RowNames",filas_encabezados);
errores=array2table(errores,"VariableNames",encabezados,"RowNames",filas_encabezados);

writetable(resultados,'Resultados.xlsx','Sheet','Prim_deri','WriteRowNames',true, 'WriteVariableNames',true);
writetable(errores,'Resultados.xlsx','Sheet','errores','WriteRowNames',true, 'WriteVariableNames',true);

%% Diferencia hacia adelante de dos puntos
function fp_xi_aprox_ade=diferencia_adelante(xi,f,h)
    syms x
    f(x)=expand(f(x));% Expande la función f(x)
    fp_xi_aprox_ade=double((f(xi+h)-f(xi))/h);%Aplicación de la fórmula
end

%% Diferencia hacia atrás de dos puntos
function fp_xi_aprox_atr=diferencia_atras(xi,f,h)
    syms x
    f(x)=expand(f(x));% Expande la función f(x)
    fp_xi_aprox_atr=double((f(xi)-f(xi-h))/h);%Aplicación de la fórmula
end

%% Diferencia central de dos puntos
function fp_xi_aprox_central=diferencia_central(xi,f,h)
    syms x
    f(x)=expand(f(x));% Expande la función f(x)
    fp_xi_aprox_central=double((f(xi+h)-f(xi-h))/(2*h));%Aplicación de la fórmula
end

