#!/usr/bin/env python
# coding: utf-8

# # Metodo de Runge-Kutta

# In[1]:


import math
import time


# In[2]:


f = lambda n,m : 4*math.exp(0.8*n) - 0.5*m


# In[3]:


def ruge_kutta_euler(xi, yi, h, pasos, f):
    for i in range(0, pasos):
        yi = yi + h*f(xi, yi)
        xi = xi + h
    return yi


# In[4]:


def ruge_kutta_Butcher(xi, yi, h, pasos, f):
    for i in range(0, pasos):
        k1 = f(xi, yi)
        k2 = f(xi + h/4, yi + k1*h/4)
        k3 = f(xi + h/4, yi + k1*h/8 + k2*h/8)
        k4 = f(xi + h/2, yi - k2*h/2 + k3*h)
        k5 = f(xi + 3*h/4 , yi + 3*k1*h/16 + 9*k4*h/16)
        k6 = f(xi + h, yi - 3*k1*h/7 + 2*k2*h/7 + 12*k3*h/7 - 12*k4*h/7 + 8*k5*h/7)
        y_aux = yi
        x_aux = xi
        yi = yi + (7*k1 + 32*k3 +12*k4 +32*k5 + 7*k6)*h/90
        xi = xi + h
    return yi


# In[1]:


def ruge_kutta_O4(xi, yi, h, pasos, f):
    for i in range(0, pasos):
        k1 = f(xi, yi)
        k2 = f(xi + h/2, yi + k1*h/2)
        k3 = f(xi + h/2, yi + k2*h/2)
        k4 = f(xi + h, yi + k3*h)
        yi = yi + (k1 + 2*k2 +2*k3 + k4)*h/6
        xi = xi + h
    return yi 


# In[6]:


def ruge_kutta_medio(xi, yi, h, pasos, f):
    for i in range(0, pasos):
        k1 = f(xi, yi)
        k2 = f(xi + h/2, yi + k1*h/2)
        yi = yi + k2*h
        xi = xi + h
        
    return yi


# In[7]:


def ruge_kutta_heun(xi, yi, h, pasos, f):
    for i in range(0, pasos):
        k1 = f(xi, yi)
        k2 = f(xi + h, yi + k1*h)
        yi = yi + (k2 + k1)*h/2
        xi = xi +h
    return yi


# In[8]:


xi = 0
yi = 2
x0 = 4
print(f"xi = {xi} , yi = {yi}, x0 = {x0}")
print("{:5s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s}".format("Pasos", "h", 
                                                                                    "Euler", "Error% euler ",
                                                                                    "Heun", "Err% Heun",
                                                                                    "Punto medio", "Err% Punt medio",
                                                                                    "Orden 4", "Err% Orden 4",
                                                                                    "Butcher", "Err% Butcher"))
error = 100
for i in range(1 , 41):
    yi_eu = ruge_kutta_euler(0, 2, (x0 - xi)/i, i, f)
    yi_pm = ruge_kutta_medio(0, 2, (x0 - xi)/i, i, f)
    yi_hn = ruge_kutta_heun(0, 2, (x0 - xi)/i, i, f)
    yi_o4 = ruge_kutta_O4(0, 2, (x0 - xi)/i, i, f)
    yi_bt = ruge_kutta_Butcher(0, 2, (x0 - xi)/i, i, f)
    if i == 1:
        print("{:5s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s}".format(str(i), str((x0 - xi)/i)[:14], 
                                                                 str(yi_eu)[:14], str(error)[:14], 
                                                                 str(yi_hn)[:14],  str(error)[:14],
                                                                 str(yi_pm)[:14], str(error)[:14], 
                                                                 str(yi_o4)[:14], str(error)[:14],
                                                                 str(yi_bt)[:14], str(error)[:14]                         ))
    else:
        print("{:5s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s} {:15s}".format(str(i), str(round((x0 - xi)/i, 13))[:14], 
                                                                 str(round(yi_eu, 13))[:14], str(round(abs(yi_eu - aux_eu)*100/yi_eu, 13))[:14],
                                                                 str(round(yi_hn, 13))[:14], str(round(abs(yi_hn - aux_hn)*100/yi_hn, 13))[:14],
                                                                 str(round(yi_pm, 13))[:14], str(round(abs(yi_pm - aux_pm)*100/yi_pm, 13))[:14],
                                                                 str(round(yi_o4, 13))[:14], str(round(abs(yi_o4 - aux_o4)*100/yi_o4, 13))[:14],
                                                                 str(round(yi_bt, 13))[:14], str(round(abs(yi_bt - aux_bt)*100/yi_bt, 13))[:14]))
    aux_eu = yi_eu
    aux_pm = yi_pm
    aux_hn = yi_hn
    aux_o4 = yi_o4
    aux_bt = yi_bt


# ## Euler

# In[9]:


pasos = 29696000 #int(5120000 *2*2*1.45 )
inicio = time.time()
print(f"x = 0, y = 2, h = {4/pasos}, pasos = {pasos}, y(4) = ",ruge_kutta_euler(0, 2, 4/pasos, pasos, f))
fin = time.time()
print(f"Tiempo: {fin-inicio}")


# ## Heun

# In[10]:


pasos = 4000
inicio = time.time()
print(f"x = 0, y = 2, h = {4/pasos}, pasos = {pasos}, y(4) = ",ruge_kutta_heun(0, 2, 4/pasos, pasos, f))
fin = time.time()
print(f"Tiempo: {fin-inicio}")


# ## Punto Medio

# In[11]:


pasos = 1550
inicio = time.time()
print(f"x = 0, y = 2, h = {4/pasos}, pasos = {pasos}, y(4) = ",ruge_kutta_medio(0, 2, 4/pasos, pasos, f))
fin = time.time()
print(f"Tiempo: {fin-inicio}")


# ## Orden 4

# In[12]:


pasos = 44
inicio = time.time()
print(f"x = 0, y = 2, h = {4/pasos}, pasos = {pasos}, y(4) = ",ruge_kutta_O4(0, 2, 4/pasos, pasos, f))
fin = time.time()
print(f"Tiempo: {fin-inicio}")


# ## Orden 5 Butcher
# 

# In[13]:


pasos = 11
inicio = time.time()
print(f"x = 0, y = 2, h = {4/pasos}, pasos = {pasos}, y(4) = ",ruge_kutta_Butcher(0, 2, 4/pasos, pasos, f))
fin = time.time()
print(f"Tiempo: {fin-inicio}")


# ## Valor real según Chapra : 75.33896
