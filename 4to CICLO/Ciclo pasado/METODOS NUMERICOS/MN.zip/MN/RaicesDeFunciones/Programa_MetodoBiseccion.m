#MÉTODO DE BISECCIÓN
#AUTORES: Renata Martínez - Jonnathan Aguilar
#FECHA: 05/05/2023

clc;
%---------------------------START FUNCTION 1-----------------------------------%
%Función para calcular la raíz mediante el número de iteraciones.
function iteraciones(f,a,b,m)
    x_inicial=a;
    x_final=b;
    formato = strcat("%.", num2str(m), "f"); %Para obtener la cantidad de cifras significativas (después de la coma) que solicitó el usuario.

    n = input('Ingrese el número de iteraciones: ');

    error_a= 100;
    converge=0;
    diverge=0;
    umbral_max_error=0.01;

    c = (a + b) / 2;
    x_list=[c];

    fprintf("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n", 'Iter.','x0','x1','x2','f(x0)','f(x1)','f(x2)','f(x0)*f(x2)','%Error');
    %Para la primera iteración.

    fprintf("%d\t",1);
    fprintf("%s\t",sprintf(formato, a));
    fprintf("%s\t",sprintf(formato, b));
    fprintf("%s\t",sprintf(formato, c));
    fprintf("%s\t",sprintf(formato, f(a)));
    fprintf("%s\t",sprintf(formato, f(b)));
    fprintf("%s\t",sprintf(formato, f(c)));
    fprintf("%s\t",sprintf(formato, f(a)*f(c)));
    fprintf("%s\t",sprintf(formato, error_a));
    fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.

    %A partir de la segunda iteración, para que nos guarde el valor anterior y poder calcular el error aproximado porcentual.
    for i = 2:1:n
      c_anterior = 0;
      error_anterior=error_a;
      if feval(f, a) * feval(f, c) > 0 %feval evalúa la función con el valor que se coloca o ingresa.
          a = c;
         c_anterior = c;
      elseif feval(f, a) * feval(f, c) < 0
          b = c;
          c_anterior = c;
      else
          fprintf("\nSe llegó al valor exacto de la raíz, con %d decimales en %d interaciones.\n",m,i);
          break;
      endif

      c = (a + b) / 2;

      x_list=[x_list,c];

      c=sscanf(sprintf(sprintf("%%.%df", m), c), "%f");

      error_a = abs((c - c_anterior)/c)*100;
      error_a=sscanf(sprintf(sprintf("%%.%df", m), error_a), "%f");

      error_actual=error_a;

      if(error_actual<error_anterior) %La raíz converge o diverge dependiendo de los errores
        converge++;
      else
        diverge++;
      endif

      if(abs(error_actual-error_anterior)<umbral_max_error && i!=2 || error_a==0) %si no existe variación del error
        fprintf("El error no tiene mucha variación en las últimas iteraciones, por lo que, se detiene el procedimiento.\n");
        break;
      endif

      fprintf("%d\t",i);
      fprintf("%s\t",sprintf(formato, a));
      fprintf("%s\t",sprintf(formato, b));
      fprintf("%s\t",sprintf(formato, c));
      fprintf("%s\t",sprintf(formato, f(a)));
      fprintf("%s\t",sprintf(formato, f(b)));
      fprintf("%s\t",sprintf(formato, f(c)));
      fprintf("%s\t",sprintf(formato, f(a)*f(c)));
      fprintf("%s\t",sprintf(formato, error_a));
      fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.
    endfor

    if(converge>diverge)
    % Imprimir la raíz y el error relativo porcentual aproximado en m cifras significativas.
      raiz = c;
      fprintf("La raíz aproximada con %d cifras significativas es: %s.\n", m, sprintf(formato, raiz));
      fprintf("El error porcentual aproximado es: %s%%.\n", sprintf(formato, error_a));
      fprintf("Se llegó a esa estimación de error aproximado con %d iteraciones.\n", i);
    else
      fprintf("La raíz diverge, o el punto dado no es el correcto.");
    endif

    grafica(f,x_list,x_inicial,x_final);


endfunction
%----------------------------END FUNCTION 1------------------------------------%


%---------------------------START FUNCTION 2-----------------------------------%
%Función para calcular la raíz mediante el umbral.
function umbral(f,a,b,m)
    x_inicial=a;
    x_final=b;

    formato = strcat("%.", num2str(m), "f"); %Para obtener la cantidad de cifras significativas (después de la coma) que solicitó el usuario.

    tol = 0.5 * 10^(2-m); %Definir el error significativo (umbral) y truncarlo en base a m cifras significativas.

    fprintf("El error preestablecido con %d cifras significativas es de %s%%.\n", m,sprintf(formato, tol));

    error_a = 100;
    converge=0;
    diverge=0;
    umbral_max_error=0.01;

    %Para la primera iteración.
    c = (a + b) / 2;

    x_list=[c];

    fprintf("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n", 'Iter.','x0','x1','x2','f(x0)','f(x1)','f(x2)','f(x0)*f(x2)','%Error');


    fprintf("%d\t",1);
    fprintf("%s\t",sprintf(formato, a));
    fprintf("%s\t",sprintf(formato, b));
    fprintf("%s\t",sprintf(formato, c));
    fprintf("%s\t",sprintf(formato, f(a)));
    fprintf("%s\t",sprintf(formato, f(b)));
    fprintf("%s\t",sprintf(formato, f(c)));
    fprintf("%s\t",sprintf(formato, f(a)*f(c)));
    fprintf("%s\t",sprintf(formato, error_a));
    fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.

    %A partir de la segunda iteración, para que nos guarde el valor anterior y poder calcular el error aproximado porcentual.
    i = 2;
    while error_a > tol %Iterar hasta que el nuevo error sea menor al umbral.
      c_anterior = 0;
      error_anterior=error_a;

      if feval(f, a) * feval(f, c) > 0 %feval evalúa la función con el valor que se coloca o ingresa.
          a = c;
          c_anterior = c;
      elseif feval(f, a) * feval(f, c) < 0
          b = c;
          c_anterior = c;
      else
          fprintf("\nSe llegó al valor exacto de la raíz, con %d interaciones.\n",i);
          break;
      endif
      c = (a + b) / 2;
      c=sscanf(sprintf(sprintf("%%.%df", m), c), "%f");

      x_list=[x_list,c];

      error_a = abs((c - c_anterior)/c)*100;
      error_a=sscanf(sprintf(sprintf("%%.%df", m), error_a), "%f");

      error_actual=error_a;

      if(error_actual<error_anterior) %La raíz converge o diverge dependiendo de los errores
        converge++;
      else
        diverge++;
      endif

      if(abs(error_actual-error_anterior)<umbral_max_error && i!=2|| error_a==0) %si no existe variación del error
        fprintf("El error no tiene mucha variación en las últimas iteraciones, por lo que, se detiene el procedimiento.\n");
        break;
      endif

      fprintf("%d\t",i);
      fprintf("%s\t",sprintf(formato, a));
      fprintf("%s\t",sprintf(formato, b));
      fprintf("%s\t",sprintf(formato, c));
      fprintf("%s\t",sprintf(formato, f(a)));
      fprintf("%s\t",sprintf(formato, f(b)));
      fprintf("%s\t",sprintf(formato, f(c)));
      fprintf("%s\t",sprintf(formato, f(a)*f(c)));
      fprintf("%s\t",sprintf(formato, error_a));
      fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.

      i++; % Aumentamos el contador de iteraciones
    endwhile

    if(converge>diverge)
    % Imprimir la raíz y el error relativo porcentual aproximado en m cifras significativas.
      raiz = c;
      fprintf("La raíz aproximada con %d cifras significativas es: %s.\n", m, sprintf(formato, raiz));
      fprintf("El error porcentual aproximado es: %s%%.\n", sprintf(formato, error_a));
      fprintf("Se llegó a esa estimación de error aproximado con %d iteraciones.\n", i-1);
    else
      fprintf("La raíz con el g(x) dado diverge, o el punto dado no es el correcto.");
    endif

    grafica(f,x_list,x_inicial,x_final);

endfunction
%----------------------------END FUNCTION 2------------------------------------%
%---------------------------START FUNCTION 3-----------------------------------%
function grafica(f,x_list,x0,x1)
% Graficar la función y la aproximación de la raíz
  xx = linspace(x0-1, x1+1, 1000);
  yy = f(xx);
  plot(xx, yy, 'LineWidth', 2);

  hold on;
    plot(x_list, f(x_list), 'ro', 'MarkerSize', 8);
    xlabel('x');
    ylabel('f(x)');
    legend('Función', 'Aproximaciones');
  grid on;
endfunction
%----------------------------END FUNCTION 3------------------------------------%

%--------------------------START MAIN PROGRAM----------------------------------%
do
  % Solicitar la función y los límites.
  f=input('Ingrese la funcion f(x): ','s');
  f=inline(f); %Definimos la función a partir de la cadena de entrada.

  %Validar que el intervalo esté separado máximo entre 10 unidades.
  do
    do %Validar que el limite inferior sea menor al limite superior.
      x0 = input('Ingrese el límite inferior: ');
      x1 = input('Ingrese el límite superior: ');

      if (x0 > x1)
        fprintf("Error! El límite inferior es mayor al límite superior. Vuelva a intentarlo\n\n");
      elseif (x0 == x1)
        fprintf("Error! Los límites son iguales. Vuelva a intentarlo\n\n");
      endif

    until (x0 < x1);

    max = x1 - x0;

    if max > 10
      fprintf("Error! El intervalo excede las 10 unidades permitidas\n");
      fprintf("Por favor, cambie el intervalo.\n\n");
    endif

  until (max <= 10);

  %Comprobamos que la función cambia de signo en el intervalo [x0,x1].
  if feval(f, x0) * feval(f, x1) > 0
      fprintf("Error! La función no cambia de signo en el intervalo [%d,%d].\n",x0,x1);
      fprintf("Vuelva a intentarlo con otro f(x), o ingrese nuevamente el f(x) y cambie el intervalo.\n\n");
  endif

until (feval(f,x0)*feval(f,x1)<=0);

  cifras = input('Ingrese el número de cifras significativas: ');

do
  %Menú para solicitar si desea por el número de iteraciones o calcular el umbral.
  menu = "\nMENÚ\nDesea calcular mediante:\n1.Número de iteraciones\n2.Umbral\n3.Salir\nIngrese una opción <1-3>: ";
  opc = input(menu);
  switch(opc)
     case 1 %Numero de iteraciones
       iteraciones(f,x0,x1,cifras);

     case 2 %Umbral
       umbral(f,x0,x1,cifras);

     case 3 %Salir
       fprintf("Saliendo...\n");

     otherwise
       fprintf("Error! Ingrese una opción válida <1-3>\n");
  endswitch

until(opc == 3);
%----------------------------END MAIN PROGRAM----------------------------------%
