%MÉTODO NEWTON-RAPHSON
%AUTORES: Renata Martínez - Jonnathan Aguilar
%FECHA: 05/05/2023
syms x
clear all;
clc;

%---------------------------START FUNCTION 1-----------------------------------%
%Función para calcular la raíz mediante el número de iteraciones.
function iteraciones(f,df,x0,m)
  x_inicial=x0;

  formato = strcat("%.", num2str(m), "f"); %Para obtener la cantidad de cifras significativas (después de la coma) que solicitó el usuario.
  n = input('Ingrese el número de iteraciones: ');

  converge=0;
  diverge=0;
  umbral_max_error=0.001;
  error_a=100;
  bandera=0;
  x1=x0-feval(f,x0)/feval(df,x0);

  x1=sscanf(sprintf(sprintf("%%.%df", m), x1), "%f"); %trunca los decimales de x1
  x_list=[x0,x1];

  fprintf("%s\t%s\t%s\t%s\n", 'Iter.','x0','f(x0)','Error');

  %Para la iteración cero.
    fprintf("%d || ",0);
    fprintf("%s || ",sprintf(formato, x0));
    fprintf("%s || ",sprintf(formato, f(x0)));
    fprintf("%s",sprintf(formato, error_a));
    fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.


    for i = 1:1:n-1
      if(feval(df,x0)==0)
        fprintf("No se puede encontrar la raíz");
        bandera=1;
        break;
      else
        x0=x1;
        x1=x0-feval(f,x0)/feval(df,x0);
        x1=sscanf(sprintf(sprintf("%%.%df", m), x1), "%f"); %trunca los decimales de x1
        x_list=[x_list,x1];
      endif

      error_anterior=error_a;

      if(x1!=0)
        error_a=abs((x1-x0)/x1)*100;
      endif
      error_a=sscanf(sprintf(sprintf("%%.%df", m), error_a), "%f"); %trunca los decimales del error
      error_actual=error_a;

      if(error_actual<error_anterior) %La raíz converge o diverge dependiendo de los errores
        converge++;
      else
        diverge++;
      endif


      fprintf("%d || ",i);
      fprintf("%s || ",sprintf(formato, x0));
      fprintf("%s || ",sprintf(formato, f(x0)));
      fprintf("%s",sprintf(formato, error_a));
      fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.


      if(abs(error_actual-error_anterior)<umbral_max_error || error_a==0)
        fprintf("El error no tiene mucha variación en las últimas iteraciones, por lo que, se detiene el procedimiento.\n");
        break;
      endif

      grafica_tangentes(f, df, x_list, x0, i);


    endfor

    if(converge>diverge && bandera!=1)
    % Imprimir la raíz y el error relativo porcentual aproximado en m cifras significativas.
      raiz = x1;
      fprintf("La raíz aproximada de f(x) con %d cifras significativas es: %s.\n", m, sprintf(formato, raiz));
      fprintf("El error relativo porcentual aproximado es: %s%%.\n", sprintf(formato, error_a));
    else
      fprintf("La raíz diverge, o los valores iniciales no son los correctos.");
    endif


endfunction
%----------------------------END FUNCTION 1------------------------------------%

%---------------------------START FUNCTION 2-----------------------------------%
%Función para calcular la raíz mediante el umbral.
function umbral(f,df,x0,m)
    x_inicial=x0;
    formato = strcat("%.", num2str(m), "f"); %Para obtener la cantidad de cifras significativas (después de la coma) que solicitó el usuario.

    tol = 0.5 * 10^(2-m); %Definir el error significativo (umbral) y truncarlo en base a m cifras significativas.


    fprintf("El error preestablecido con %d cifras significativas es de %s%%.\n", m,sprintf(formato, tol));


    umbral_max_error=0.001;
    error_a=100;
    converge=0;
    diverge=0;

    x1=x0-feval(f,x0)/feval(df,x0);

    x1=sscanf(sprintf(sprintf("%%.%df", m), x1), "%f"); %trunca los decimales de x1

    x_list=[x0,x1];

    fprintf("%s\t%s\t%s\t%s\n", 'Iter.','x0','f(x0)','Error');

    %Para la iteración cero.
    fprintf("%d || ",0);
    fprintf("%s || ",sprintf(formato, x0));
    fprintf("%s || ",sprintf(formato, f(x0)));
    fprintf("%s",sprintf(formato, error_a));
    fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.

    i=1;
    while(error_a>tol)
      if(feval(df,x0)==0)
        fprintf("No se puede encontrar la raíz");
        bandera=1;
        break;
      else
        x0=x1;
        x1=x0-feval(f,x0)/feval(df,x0);
        x1=sscanf(sprintf(sprintf("%%.%df", m), x1), "%f"); %trunca los decimales de x1
        x_list=[x_list,x1];
      endif

      error_anterior=error_a;

      if(x1!=0)
        error_a=abs((x1-x0)/x1)*100;
      endif

      error_a=sscanf(sprintf(sprintf("%%.%df", m), error_a), "%f"); %trunca los decimales del error
      error_actual=error_a;

      if(error_actual<error_anterior) %La raíz converge o diverge dependiendo de los errores
        converge++;
      else
        diverge++;
      endif


      fprintf("%d || ",i);
      fprintf("%s || ",sprintf(formato, x0));
      fprintf("%s || ",sprintf(formato, f(x0)));
      fprintf("%s",sprintf(formato, error_a));
      fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.


      if(abs(error_actual-error_anterior)<umbral_max_error || error_a==0)
        fprintf("El error no tiene mucha variación en las últimas iteraciones, o ya converge de acuerdo al umbral calculado, por lo que, se detiene el procedimiento.\n");
        break;
      endif
    grafica_tangentes(f, df, x_list, x0, i);
    i++;
    endwhile

    if(converge>diverge)
    % Imprimir la raíz y el error relativo porcentual aproximado en m cifras significativas.
      raiz = x1;
      fprintf("La raíz aproximada de f(x) con %d cifras significativas es: %s.\n", m, sprintf(formato, raiz));
      fprintf("El error porcentual aproximado es: %s%%.\n", sprintf(formato, error_a));
      fprintf("Se llegó a esa estimación de error aproximado con %d iteraciones.\n", i);
    else
      fprintf("La raíz diverge, o los valores iniciales no son los correctos.");
    endif


endfunction
%----------------------------END FUNCTION 2------------------------------------%

%---------------------------START FUNCTION 3-----------------------------------%

% Graficar la función y la aproximación de la raíz
function grafica_tangentes(f, df, x_list, x_inicial, iteracion)
    xx = linspace(x_inicial-1, x_inicial+1, 1000);
    yy = f(xx);
    plot(xx, yy, 'LineWidth', 2);
    hold on;

    for i = 1:iteracion
        tangent = df(x_list(i))*(xx-x_list(i)) + f(x_list(i));
        plot(xx, tangent, '--', 'Color', [0.5 0.5 0.5]);
        plot(x_list(i), f(x_list(i)), 'ro', 'MarkerSize', 8);
    end
    title('MÉTODO DE NEWTON-RAPHSON');
    xlabel('x');
    ylabel('f(x)');
    legend('Función', 'Aproximaciones', 'Tangentes');
    grid on;
endfunction

%----------------------------END FUNCTION 3------------------------------------%

%--------------------------START MAIN PROGRAM----------------------------------%

% Definir la función simbólica
syms x
f_sym = input("Ingrese la función: ");
f = function_handle(f_sym);

% Definir la derivada de la función
df_sym = diff(f_sym);
df = function_handle(df_sym);

do
  x0 = input('Ingrese x0: ');

  if(feval(df,x0)==0)
    fprintf("Valor inicial incorrecto. Elija otro.\n");
  endif

until(feval(df,x0)!=0);

  cifras = input('Ingrese el número de cifras significativas: ');

  do
    %Menú para solicitar si desea por el número de iteraciones o calcular el umbral.
    menu = "\nMENÚ\nDesea calcular mediante:\n1.Número de iteraciones\n2.Umbral\n3.Salir\nIngrese una opción <1-3>: ";
    opc = input(menu);
    switch(opc)
       case 1 %Numero de iteraciones
         iteraciones(f,df,x0,cifras);

       case 2 %Umbral
         umbral(f,df,x0,cifras);

       case 3 %Salir
         fprintf("Saliendo...\n");

       otherwise
         fprintf("Error! Ingrese una opción válida <1-3>\n");
    endswitch

  until(opc == 3);
%----------------------------END MAIN PROGRAM----------------------------------%
