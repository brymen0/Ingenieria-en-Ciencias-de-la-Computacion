%MÉTODO DE MULLER
%AUTORES: Renata Martínez - Jonnathan Aguilar
%FECHA: 05/05/2023

clear all;
clc;
%---------------------------START FUNCTION 1-----------------------------------%
%Función para calcular la raíz mediante el número de iteraciones.
function iteraciones(f,x0,x1,x2,m)
    x_inicial=x0;
    x_final=x2;

  formato = strcat("%.", num2str(m), "f"); %Para obtener la cantidad de cifras significativas (después de la coma) que solicitó el usuario.
  umbral_max_error=0.001;
  converge=0;
  diverge=0;
  error_a=100;
  n = input('Ingrese el número de iteraciones: ');

  %Para la iteración cero.
    fx0 = sscanf(sprintf(sprintf("%%.%df", m), feval(f,x0)), "%f");
    fx1 = sscanf(sprintf(sprintf("%%.%df", m), feval(f,x1)), "%f");
    fx2 = sscanf(sprintf(sprintf("%%.%df", m), feval(f,x2)), "%f");
    h0 = x1-x0;
    h1 = x2-x1;
    delta0 = sscanf(sprintf(sprintf("%%.%df", m), (fx1-fx0)/h0), "%f");
    delta1 = sscanf(sprintf(sprintf("%%.%df", m), (fx2-fx1)/h1), "%f");
    a = (delta1-delta0)/(h1+h0);
    b = a*h1+delta1;
    c = fx2;
    x3 = sscanf(sprintf(sprintf("%%.%df", m), x2-(2*c)/(b+sign(b)*sqrt(b^2-4*a*c))), "%f");

    x_list=[x3];

    fprintf("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",'Iter.','x0','x1','x2','f(x0)','f(x1)','f(x2)','x3','Error');

    fprintf("%d || ",0);
    fprintf("%s || ",sprintf(formato, x0));
    fprintf("%s || ",sprintf(formato, x1));
    fprintf("%s || ",sprintf(formato, x2));
    fprintf("%s || ",sprintf(formato, fx0));
    fprintf("%s || ",sprintf(formato, fx1));
    fprintf("%s || ",sprintf(formato, fx2));
    fprintf("%s || ",sprintf(formato, x3)); fprintf("%s",sprintf(formato, error_a));
    fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.

    x0 = x1;  x1 = x2;  x2 = x3;



    for i = 1:1:n-1

      fprintf("%d || ",i); %Se imprime para que no se modifiquen los primeros valores al momento de imprimir la tabla.
      fprintf("%s || ",sprintf(formato, x0)); fprintf("%s || ",sprintf(formato, x1)); fprintf("%s || ",sprintf(formato, x2));

      error_anterior=error_a;

      fx0 = sscanf(sprintf(sprintf("%%.%df", m), feval(f,x0)), "%f");
      fx1 = sscanf(sprintf(sprintf("%%.%df", m), feval(f,x1)), "%f");
      fx2 = sscanf(sprintf(sprintf("%%.%df", m), feval(f,x2)), "%f");
      h0 = x1-x0;
      h1 = x2-x1;
      delta0 = sscanf(sprintf(sprintf("%%.%df", m), (fx1-fx0)/h0), "%f");
      delta1 = sscanf(sprintf(sprintf("%%.%df", m), (fx2-fx1)/h1), "%f");
      a = (delta1-delta0)/(h1+h0);
      b = a*h1+delta1;
      c = fx2;
      x3 = sscanf(sprintf(sprintf("%%.%df", m), x2-(2*c)/(b+sign(b)*sqrt(b^2-4*a*c))), "%f");

      x_list=[x_list,x3];

      if(x3!=0)
        error_a=abs((x3-x2)/x3)*100;
      endif

      error_a=sscanf(sprintf(sprintf("%%.%df", m), error_a), "%f");

      x0 = x1;  x1 = x2;  x2 = x3;

      %Para que los valores ya salgan modificados.
      fprintf("%s || ",sprintf(formato, fx0));  fprintf("%s || ",sprintf(formato, fx1));  fprintf("%s || ",sprintf(formato, fx2));
      fprintf("%s || ",sprintf(formato, x3)); fprintf("%s",sprintf(formato, error_a));
      fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.


      error_actual=error_a;

      if(error_actual<error_anterior) %La raíz converge o diverge dependiendo de los errores
        converge++;
      else
        diverge++;
      endif

      if(abs(error_actual-error_anterior)<umbral_max_error || error_a==0)
        fprintf("El error no tiene mucha variación en las últimas iteraciones, por lo que, se detiene el procedimiento.\n");
        break;
      endif

    endfor

    if(converge>diverge)
    % Imprimir la raíz y el error relativo porcentual aproximado con m cifras significativas.
      raiz = x3;
      fprintf("La raíz aproximada de f(x) con %d cifras significativas es: %s.\n", m, sprintf(formato, raiz));
      fprintf("El error relativo porcentual aproximado es: %s%%.\n", sprintf(formato, error_a));
    else
      fprintf("La raíz diverge, o los valores iniciales no son los correctos.");
    endif

    grafica(f,x_list,x_inicial,x_final);


endfunction
%----------------------------END FUNCTION 1------------------------------------%


%---------------------------START FUNCTION 2-----------------------------------%
%Función para calcular la raíz mediante el umbral.
function umbral(f,x0,x1,x2,m)
    x_inicial=x0;
    x_final=x2;

    formato = strcat("%.", num2str(m), "f"); %Para obtener la cantidad de cifras significativas (después de la coma) que solicitó el usuario.

    tol = 0.5 * 10^(2-m); %Definir el error significativo (umbral) y truncarlo en base a m cifras significativas.

    fprintf("El error preestablecido con %d cifras significativas es de %s%%.\n", m,sprintf(formato, tol));

    umbral_max_error=0.001;
    converge=0;
    diverge=0;
    error_a=100;
    %Para la iteración cero.

    fx0 = sscanf(sprintf(sprintf("%%.%df", m), feval(f,x0)), "%f");
    fx1 = sscanf(sprintf(sprintf("%%.%df", m), feval(f,x1)), "%f");
    fx2 = sscanf(sprintf(sprintf("%%.%df", m), feval(f,x2)), "%f");
    h0 = x1-x0;
    h1 = x2-x1;
    delta0 = sscanf(sprintf(sprintf("%%.%df", m), (fx1-fx0)/h0), "%f");
    delta1 = sscanf(sprintf(sprintf("%%.%df", m), (fx2-fx1)/h1), "%f");
    a = (delta1-delta0)/(h1+h0);
    b = a*h1+delta1;
    c = fx2;
    x3 = sscanf(sprintf(sprintf("%%.%df", m), x2-(2*c)/(b+sign(b)*sqrt(b^2-4*a*c))), "%f");

    x_list=[x3];

    fprintf("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",'Iter.','x0','x1','x2','f(x0)','f(x1)','f(x2)','x3','Error');

    fprintf("%d || ",0);
    fprintf("%s || ",sprintf(formato, x0)); fprintf("%s || ",sprintf(formato, x1)); fprintf("%s || ",sprintf(formato, x2));
    fprintf("%s || ",sprintf(formato, fx0));  fprintf("%s || ",sprintf(formato, fx1));  fprintf("%s || ",sprintf(formato, fx2));
    fprintf("%s || ",sprintf(formato, x3)); fprintf("%s",sprintf(formato, error_a));
    fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.

    x0 = x1;  x1 = x2;  x2 = x3;


    i = 1;

    while ((error_a > tol)) %Iterar hasta que el nuevo error sea menor al umbral. Si la raíz divege se debe hacer un cierto número de iteraciones (i)

      fprintf("%d || ",i); %Se imprime para que no se modifiquen los primeros valores al momento de imprimir la tabla.
      fprintf("%s || ",sprintf(formato, x0)); fprintf("%s || ",sprintf(formato, x1)); fprintf("%s || ",sprintf(formato, x2));

      error_anterior=error_a;

      fx0 = sscanf(sprintf(sprintf("%%.%df", m), feval(f,x0)), "%f");
      fx1 = sscanf(sprintf(sprintf("%%.%df", m), feval(f,x1)), "%f");
      fx2 = sscanf(sprintf(sprintf("%%.%df", m), feval(f,x2)), "%f");
      h0 = x1-x0;
      h1 = x2-x1;
      delta0 = sscanf(sprintf(sprintf("%%.%df", m), (fx1-fx0)/h0), "%f");
      delta1 = sscanf(sprintf(sprintf("%%.%df", m), (fx2-fx1)/h1), "%f");
      a = (delta1-delta0)/(h1+h0);
      b = a*h1+delta1;
      c = fx2;
      x3 = sscanf(sprintf(sprintf("%%.%df", m), x2-(2*c)/(b+sign(b)*sqrt(b^2-4*a*c))), "%f");

      x_list=[x_list,x3];

      if(x3!=0)
        error_a=abs((x3-x2)/x3)*100;
      endif

      error_a=sscanf(sprintf(sprintf("%%.%df", m), error_a), "%f");

      x0 = x1;  x1 = x2;  x2 = x3;

      error_actual=error_a;

      if(error_actual<error_anterior) %La raíz converge o diverge dependiendo de los errores
        converge++;
      else
        diverge++;
      endif

      %Para que los valores ya salgan modificados.
      fprintf("%s || ",sprintf(formato, fx0));  fprintf("%s || ",sprintf(formato, fx1));  fprintf("%s || ",sprintf(formato, fx2));
      fprintf("%s || ",sprintf(formato, x3)); fprintf("%s",sprintf(formato, error_a));
      fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.

      if(abs(error_actual-error_anterior)<umbral_max_error || error_a==0)
        fprintf("El error no tiene mucha variación en las últimas iteraciones, o ya converge de acuerdo al umbral calculado, por lo que, se detiene el procedimiento.\n");
        break;
      endif

      i++;
    endwhile

    if(converge>diverge)
    % Imprimir la raíz y el error relativo porcentual aproximado con m cifras significativas.
      raiz = x3;
      fprintf("La raíz aproximada de f(x) con %d cifras significativas es: %s.\n", m, sprintf(formato, raiz));
      fprintf("El error relativo porcentual aproximado es: %s%%.\n", sprintf(formato, error_a));
      fprintf("Se llegó a esa estimación de error aproximado con %d iteraciones.\n", i+1);
    else
      fprintf("La raíz diverge, o los valores iniciales no son los correctos.");
    endif

    grafica(f,x_list,x_inicial,x_final);

endfunction
%----------------------------END FUNCTION 2------------------------------------%

%---------------------------START FUNCTION 3-----------------------------------%
function grafica(f,x_list,x0,x2)
% Graficar la función y la aproximación de la raíz
  xx = linspace(x0-1, x2+1, 1000);
  yy = f(xx);
  plot(xx, yy, 'LineWidth', 2);

  hold on;

  colors = jet(length(x_list));  % Generar una secuencia de colores

  for i = 1:length(x_list)
     scatter(x_list(i), f(x_list(i)), 50, colors(i, :), 'filled');  % Pintar cada punto con un color diferente
  end

  title('MÉTODO DE MULLER');
  xlabel('x');
  ylabel('f(x)');
  legend('Función', 'Aproximaciones');
  grid on;
endfunction

%----------------------------END FUNCTION 3------------------------------------%

%--------------------------START MAIN PROGRAM----------------------------------%
  % Solicitar la función y los límites.
  f=input('Ingrese la funcion f(x): ','s');
  f=inline(f); %Definimos la función a partir de la cadena de entrada.

  %Validar que el intervalo esté separado máximo entre 10 unidades.
  do
    do %Validar que el limite inferior sea menor al limite superior.
      x0 = input('Ingrese punto x0: ');
      x1 = input('Ingrese punto x1: ');
      x2 = input('Ingrese punto x2: ');


      if (x0 > x1 || x0>x2 || x1>x2)
        fprintf("Error! Límites incorrectos. Vuelva a intentarlo\n\n");
      elseif (x0 == x1 || x1==x2 || x0==x2 )
        fprintf("Error! Los límites son iguales. Vuelva a intentarlo\n\n");
      endif

    until (x0 < x1 && x0<x2 && x1<x2);

    max = x1 - x0;
    max2=x2-x1;

    if (max > 10 || max2>10)
      fprintf("Error! El intervalo excede las 10 unidades permitidas\n");
      fprintf("Por favor, cambie el intervalo.\n\n");
    endif

  until (max <= 10 && max2<=10 );


  cifras = input('Ingrese el número de cifras significativas: ');

  do
    %Menú para solicitar si desea por el número de iteraciones o calcular el umbral.
    menu = "\nMENÚ\nDesea calcular mediante:\n1.Número de iteraciones\n2.Umbral\n3.Salir\nIngrese una opción <1-3>: ";
    opc = input(menu);
    switch(opc)
       case {1} %Numero de iteraciones
         iteraciones(f,x0,x1,x2,cifras);

       case {2} %Umbral
         umbral(f,x0,x1,x2,cifras);

       case {3} %Salir
         fprintf("Saliendo...\n");

       otherwise
         fprintf("Error! Ingrese una opción válida <1-3>\n");
    endswitch

  until(opc == 3);
%----------------------------END MAIN PROGRAM----------------------------------%
