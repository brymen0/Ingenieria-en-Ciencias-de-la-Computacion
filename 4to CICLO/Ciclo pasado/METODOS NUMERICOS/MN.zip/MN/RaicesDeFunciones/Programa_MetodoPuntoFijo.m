%MÉTODO DE PUNTO FIJO
%AUTORES: Renata Martínez - Jonnathan Aguilar
%FECHA: 05/05/2023

clear all;
clc;

%---------------------------START FUNCTION 1-----------------------------------%
%Función para calcular la raíz mediante el número de iteraciones.
function iteraciones(f,g,x0,m)
  x_list=[x0];
  x_inicial=x0;

  formato = strcat("%.", num2str(m), "f"); %Para obtener la cantidad de cifras significativas (después de la coma) que solicitó el usuario.

  n = input('Ingrese el número de iteraciones: ');

  fprintf("%s\t%s\t%s\t%s\t%s\t%s", 'Iter.','x0','f(x0)','g(x0)','Error aproximado');
  fprintf("\n");

converge=0;
diverge=0;
error_a=100;
umbral_max_error=0.01;

    for i = 0:1:n-1
      xi=x0;
      x0= feval(g,xi);
      x0=sscanf(sprintf(sprintf("%%.%df", m), x0), "%f"); %trunca los decimales de x0

      x_list=[x_list,x0];

      if feval(f,x0)==Inf || feval(f,x0)==NaN
        fprintf("\nLa función Diverge");
        break;
      endif

      error_anterior=error_a;
      fprintf("%d ||",i);
      fprintf("%s ||",sprintf(formato, x0));
      fprintf("%s ||",sprintf(formato, feval(f,x0)));
      fprintf("%s ||",sprintf(formato, feval(g,x0)));
      fprintf("%s",sprintf(formato, error_a));
      fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.

      if(x0!=0)
        error_a=abs((x0-xi)/x0)*100;
        error_a=sscanf(sprintf(sprintf("%%.%df", m), error_a), "%f"); %trunca los decemales del error
      endif

      error_actual=error_a;

      if(error_actual<error_anterior) %La raíz converge o diverge dependiendo de los errores
        converge++;
      else
        diverge++;
      endif

      if(abs(error_actual-error_anterior)<umbral_max_error && i>1 || error_a==0) %si no existe variación del error
        fprintf("El error no tiene mucha variación en las últimas iteraciones, por lo que, se detiene el procedimiento.\n");
        break;
      endif
    endfor

    if(converge>diverge)
    % Imprimir la raíz y el error relativo porcentual aproximado en m cifras significativas.
      raiz = x0;
      fprintf("La raíz aproximada de f(x) con %d cifras significativas es: %s.\n", m, sprintf(formato, raiz));
      fprintf("El error porcentual aproximado es: %s%%.\n", sprintf(formato, error_a));
    else
      fprintf("La raíz con el g(x) dado diverge, o el punto dado no es el correcto.");
    endif

    grafica(f,x_list,x_inicial);

endfunction
%----------------------------END FUNCTION 1------------------------------------%

%---------------------------START FUNCTION 2-----------------------------------%
%Función para calcular la raíz mediante el umbral.
function umbral(f,g,x0,m)
    x_list=[x0];
    x_inicial=x0;

    formato = strcat("%.", num2str(m), "f"); %Para obtener la cantidad de cifras significativas (después de la coma) que solicitó el usuario.

    tol = 0.5 * 10^(2-m); %Definir el error significativo (umbral) y truncarlo en base a m cifras significativas.

    fprintf("El error preestablecido con %d cifras significativas es de %s%%.\n", m,sprintf(formato, tol));
    fprintf("%s\t%s\t%s\t%s\t%s\t%s", 'Iter.','x0','f(x0)','g(x0)','Error aproximado');
    fprintf("\n");

converge=0;
diverge=0;
error_a=100;
umbral_max_error=0.01;

    i = 0;
    while(error_a > tol) %Iterar hasta que el nuevo error sea menor al umbral. Si la raíz divege se debe hacer un cierto número de iteraciones (i)
      error_anterior=error_a;
      xi=x0;
      x0= feval(g,xi);
      x0=sscanf(sprintf(sprintf("%%.%df", m), x0), "%f"); %trunca x0 al numero de cigras significativas

      x_list=[x_list,x0];

      fprintf("%d ||",i);
      fprintf("%s ||",sprintf(formato, x0));
      fprintf("%s ||",sprintf(formato, feval(f,x0)));
      fprintf("%s ||",sprintf(formato, feval(g,x0)));
      fprintf("%s",sprintf(formato, error_a));
      fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.

      if(x0!=0)
        error_a=abs((x0-xi)/x0)*100;
        error_a=sscanf(sprintf(sprintf("%%.%df", m), error_a), "%f"); %trunca el error
      endif

      error_actual=error_a;

      if(error_actual<error_anterior)
        converge++;
      else
        diverge++;
      endif

      if(abs(error_actual-error_anterior)<umbral_max_error && i>0 || error_a==0)
        fprintf("El error no tiene mucha variación en las últimas iteraciones, por lo que, se detiene el procedimiento.\n");
        break;
      endif

      i++;
    endwhile

    if(converge>diverge)
    % Imprimir la raíz y el error relativo porcentual aproximado en m cifras significativas.
      raiz = x0;
      fprintf("La raíz aproximada con %d cifras significativas es: %s.\n", m, sprintf(formato, raiz));
      fprintf("El error porcentual aproximado es: %s%%.\n", sprintf(formato, error_a));
      fprintf("Se llegó a esa estimación de error aproximado con %d iteraciones.\n", i+1);
    else
      fprintf("La raíz con el g(x) dado diverge, o el punto dado no es el correcto.");
    endif

    %grafica(f,x_list,x_inicial);

endfunction
%----------------------------END FUNCTION 2------------------------------------%

%---------------------------START FUNCTION 3-----------------------------------%
function grafica(f,x_list,x0)
% Graficar la función y la aproximación de la raíz

  xx = linspace(x0-1, x0+1, 1000);
  yy = f(xx);
  plot(xx, yy, 'LineWidth', 2);

  hold on;
    plot(x_list, f(x_list), 'ro', 'MarkerSize', 8);
    xlabel('x');
    ylabel('f(x)');
    legend('Función', 'Aproximaciones');
  grid on;
endfunction
%----------------------------END FUNCTION 3------------------------------------%

%--------------------------START MAIN PROGRAM----------------------------------%

% Solicitar la función y los límites.
f=input('Ingrese la funcion f(x): ','s');

do

  opc=input("1. Generar función g(x).\n2. Escribir función g(x).\nEscoja una opcion <1-2>: ");
  switch(opc)
    case {1}
      g1=strcat(f,"+x");
      g2=strcat('(',f,")/x");
      g3=strcat(f,"-x");
      g4=strcat('(',f,")*x");

      fprintf("\nEscoja una g(x):\n1. %s\n2. %s\n3. %s\n4. %s\n",g1,g2,g3,g4);

      do
        opc2=input("Seleccione una opción <1-4>: ");
        switch(opc2)
          case {1}
            g=inline(g1);
          case {2}
            g=inline(g2);
          case {3}
            g=inline(g3);
          case {4}
            g=inline(g4);
          otherwise
            printf("Opcion incorrecta.\n");
        endswitch

      until (opc2 > 0 && opc2 < 5)

    case {2}
      g=input('Ingrese la funcion g(x). Para ello, f(x)=0 y despeje x: ','s');
      g=inline(g);

    otherwise
      printf("Opcion incorrecta, vuelva a intentarlo.\n");
  endswitch

until (opc == 1 || opc ==2);

  x0 = input('Ingrese el valor inicial: ');
  cifras = input('Ingrese el número de cifras significativas: ');
  f=inline(f);
do
  %Menú para solicitar si desea por el número de iteraciones o calcular el umbral.
  menu = "\nMENÚ\nDesea calcular mediante:\n1.Número de iteraciones\n2.Umbral\n3.Salir\nIngrese una opción <1-3>: ";
  opc = input(menu);

  switch(opc)
     case {1} %Numero de iteraciones
       iteraciones(f,g,x0,cifras);

     case {2} %Umbral
       umbral(f,g,x0,cifras);

     case {3} %Salir
       fprintf("Saliendo...\n");

     otherwise
       fprintf("Error! Ingrese una opción válida <1-3>\n");
  endswitch

until(opc == 3);

%----------------------------END MAIN PROGRAM----------------------------------%
