%MÉTODO DE LA SECANTE
%AUTORES: Renata Martínez - Jonnathan Aguilar
%FECHA: 05/05/2023

clear all;
clc;
%---------------------------START FUNCTION 1-----------------------------------%
%Función para calcular la raíz mediante el número de iteraciones.
function iteraciones(f,x0,x1,m)
  x_inicial=x0;
  x_final=x1;

  formato = strcat("%.", num2str(m+1), "f"); %Para obtener la cantidad de cifras significativas (después de la coma) que solicitó el usuario.
  n = input('Ingrese el número de iteraciones: ');

  umbral_max_error=0.001;
  converge=0;
  diverge=0;
  error_a=100;

  fprintf("%s\t%s\t%s\t%s\t%s\t%s\t%s\n", 'Iter.','x1','x0','f(xi)','f(x_i-1)','x2','Error');

    fx0=sscanf(sprintf(sprintf("%%.%df", m), feval(f,x0)), "%f");
    fx1=sscanf(sprintf(sprintf("%%.%df", m), feval(f,x1)), "%f");

    x2=x1-((fx1*(x0-x1))/(fx0-fx1));
    x2=sscanf(sprintf(sprintf("%%.%df", m), x2), "%f"); %trunca los decimales de x2
    x_list=[x2];

  %Para la iteración cero.
    fprintf("%d || ",0);
    fprintf("%s || ",sprintf(formato, x1));
    fprintf("%s || ",sprintf(formato, x0));
    fprintf("%s || ",sprintf(formato, f(x1)));
    fprintf("%s || ",sprintf(formato, f(x0)));
    fprintf("%s || ",sprintf(formato, x2));
    fprintf("%s",sprintf(formato, error_a));
    fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.

    for i = 1:1:n-1

      error_anterior=error_a;
      x0=x1;
      x0=sscanf(sprintf(sprintf("%%.%df", m), x0), "%f"); %trunca los decimales de x0
      x1=x2;
      x1=sscanf(sprintf(sprintf("%%.%df", m), x1), "%f"); %trunca los decimales de x1

      fx0=sscanf(sprintf(sprintf("%%.%df", m), feval(f,x0)), "%f");
      fx1=sscanf(sprintf(sprintf("%%.%df", m), feval(f,x1)), "%f");

      x2=x1-((fx1*(x0-x1))/(fx0-fx1));
      x2=sscanf(sprintf(sprintf("%%.%df", m), x2), "%f"); %trunca los decimales de x2
      x_list=[x_list,x2];


      if(x2!=0)
        error_a=abs((x2-x1)/x2)*100;
      endif

      error_a=sscanf(sprintf(sprintf("%%.%df", m), error_a), "%f"); %trunca los decimales del error
      error_actual=error_a;

      if(error_actual<error_anterior) %La raíz converge o diverge dependiendo de los errores
        converge++;
      else
        diverge++;
      endif

      fprintf("%d || ",i);
      fprintf("%s || ",sprintf(formato, x1));
      fprintf("%s || ",sprintf(formato, x0));
      fprintf("%s || ",sprintf(formato, f(x1)));
      fprintf("%s || ",sprintf(formato, f(x0)));
      fprintf("%s || ",sprintf(formato, x2));
      fprintf("%s",sprintf(formato, error_a));
      fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.

      if(abs(error_anterior-error_a)<umbral_max_error || error_a==0)
        fprintf("El error no tiene mucha variación en las últimas iteraciones, por lo que, se detiene el procedimiento.\n");
        fprintf("Se llegó a esa estimación de error aproximado con %d iteraciones.\n", i);
        break;
      endif

      grafica_secantes(f, x_list, x0, x1);

    endfor

    if(converge>diverge)
    % Imprimir la raíz y el error relativo porcentual aproximado en m cifras significativas.
      raiz = x2;
      fprintf("La raíz aproximada de f(x) con %d cifras significativas es: %s.\n", m, sprintf(formato, raiz));
      fprintf("El error relativo porcentual aproximado es: %s%%.\n", sprintf(formato, error_a));
    else
      fprintf("La raíz diverge, o los valores iniciales no son los correctos.");
    endif

endfunction
%----------------------------END FUNCTION 1------------------------------------%

%---------------------------START FUNCTION 2-----------------------------------%
%Función para calcular la raíz mediante el umbral.
function umbral(f,x0,x1,m)
    x_inicial=x0;
    x_final=x1;

    formato = strcat("%.", num2str(m), "f"); %Para obtener la cantidad de cifras significativas (después de la coma) que solicitó el usuario.

    tol = 0.5 * 10^(2-m); %Definir el error significativo (umbral) y truncarlo en base a m cifras significativas.
    umbral_max_error=0.00001;
    converge=0;
    diverge=0;
    error_a=100;

    fprintf("El error preestablecido con %d cifras significativas es de %s%%.\n", m,sprintf(formato, tol));

    fprintf("%s\t%s\t%s\t%s\t%s\t%s\t%s\n", 'Iter.','x1','x0','f(xi)','f(x_i-1)','x2','Error');

    fx0=sscanf(sprintf(sprintf("%%.%df", m), feval(f,x0)), "%f");
    fx1=sscanf(sprintf(sprintf("%%.%df", m), feval(f,x1)), "%f");

    x2=x1-((fx1*(x0-x1))/(fx0-fx1));
    x2=sscanf(sprintf(sprintf("%%.%df", m), x2), "%f"); %trunca los decimales de x2
    x_list=[x2];

    error_a=abs((x2-x1)/x2)*100;
    error_a=sscanf(sprintf(sprintf("%%.%df", m), error_a), "%f"); %trunca los decimales del error

    %Para la iteración cero.
    fprintf("%d || ",0);
    fprintf("%s || ",sprintf(formato, x1));
    fprintf("%s || ",sprintf(formato, x0));
    fprintf("%s || ",sprintf(formato, f(x1)));
    fprintf("%s || ",sprintf(formato, f(x0)));
    fprintf("%s || ",sprintf(formato, x2));
    fprintf("%s",sprintf(formato, error_a));
    fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.

    i = 1;
    while (error_a > tol) %Iterar hasta que el nuevo error sea menor al umbral.

      error_anterior=error_a;
      x0=x1;
      x0=sscanf(sprintf(sprintf("%%.%df", m), x0), "%f"); %trunca los decimales de x0
      x1=x2;
      x1=sscanf(sprintf(sprintf("%%.%df", m), x1), "%f"); %trunca los decimales de x1

      fx0=sscanf(sprintf(sprintf("%%.%df", m), feval(f,x0)), "%f");
      fx1=sscanf(sprintf(sprintf("%%.%df", m), feval(f,x1)), "%f");

      x2=x1-((fx1*(x0-x1))/(fx0-fx1));
      x2=sscanf(sprintf(sprintf("%%.%df", m), x2), "%f"); %trunca los decimales de x2
      x_list=[x_list,x2];

      if(x2!=0)
        error_a=abs((x2-x1)/x2)*100;
      endif

      error_actual=error_a;
      error_a=sscanf(sprintf(sprintf("%%.%df", m), error_a), "%f"); %trunca los decimales de error

      if(error_actual<error_anterior) %La raíz converge o diverge dependiendo de los errores
        converge++;
      else
        diverge++;
      endif

      if(abs(error_actual-error_anterior)<umbral_max_error)
        fprintf("El error no tiene mucha variación en las últimas iteraciones, por lo que, se detiene el procedimiento.\n");
        break;
      endif

      fprintf("%d || ",i);
      fprintf("%s || ",sprintf(formato, x1));
      fprintf("%s || ",sprintf(formato, x0));
      fprintf("%s || ",sprintf(formato, f(x1)));
      fprintf("%s || ",sprintf(formato, f(x0)));
      fprintf("%s || ",sprintf(formato, x2));
      fprintf("%s",sprintf(formato, error_a));
      fprintf("\n"); %Salto de línea para una mejor visualización de la tabla.

      if(abs(error_actual-error_anterior)<umbral_max_error || error_a==0)
        fprintf("El error no tiene mucha variación en las últimas iteraciones, o ya converge de acuerdo al umbral calculado, por lo que, se detiene el procedimiento.\n");
        break;
      endif

      grafica_secantes(f, x_list, x0, x1);
      i++;
    endwhile

    if(converge>diverge)
    % Imprimir la raíz y el error relativo porcentual aproximado en m cifras significativas.
      raiz = x2;
      fprintf("La raíz aproximada de f(x) con %d cifras significativas es: %s.\n", m, sprintf(formato, raiz));
      fprintf("El error relativo porcentual aproximado es: %s%%.\n", sprintf(formato, error_a));
      fprintf("Se llegó a esa estimación de error aproximado con %d iteraciones.\n", i);
    else
      fprintf("La raíz diverge, o los valores iniciales no son los correctos.");
    endif

endfunction
%----------------------------END FUNCTION 2------------------------------------%

%---------------------------START FUNCTION 3-----------------------------------%
function grafica_secantes(f, x_list, x_inicial, x_final)
    n = length(x_list);
    xx = linspace(x_inicial-0.5, x_final+0.5, 1000);
    yy = f(xx);
    plot(xx, yy, 'LineWidth', 2);

    hold on;
    for i = 1:n-1
        x_inicial_actual = x_list(i);
        x_final_actual = x_list(i+1);
        xx_secante = linspace(x_inicial_actual, x_final_actual, 100);
        yy_secante = f(xx_secante);
        plot(xx_secante, yy_secante, 'r--', 'LineWidth', 1);
        plot(x_inicial_actual, f(x_inicial_actual), 'ro', 'MarkerSize', 8);
    end
    title('MÉTODO DE LA SECANTE');
    xlabel('x');
    ylabel('f(x)');
    legend('Función', 'Secantes');
    grid on;
endfunction
%----------------------------END FUNCTION 3------------------------------------%

%--------------------------START MAIN PROGRAM----------------------------------%
do
  % Solicitar la función y los límites.
  f=input("Ingrese la funcion f(x): ","s");
  f=inline(f); %Definimos la función a partir de la cadena de entrada.

  %Validar que el intervalo esté separado máximo entre 10 unidades.
  do
    do %Validar que el limite inferior sea menor al limite superior.
      x0 = input('Ingrese x0: ');
      x1 = input('Ingrese x1: ');

      if (x0 > x1)
        fprintf("Error! El límite inferior es mayor al límite superior. Vuelva a intentarlo\n\n");
      elseif (x0 == x1)
        fprintf("Error! Los límites son iguales. Vuelva a intentarlo\n\n");
      endif

    until (x0 < x1);

    max = x1 - x0;

    if max > 10
      fprintf("Error! El intervalo excede las 10 unidades permitidas\n");
      fprintf("Por favor, cambie el intervalo.\n\n");
    endif

  until (max <= 10);

  %Comprobamos que que sea una función evaluable.
  if (feval(f, x0) * feval(f, x1) == 0)
      fprintf("Error! La función no se pude calcular.\n");
      fprintf("Vuelva a intentarlo con otro f(x).\n\n");
  endif

until (feval(f, x0) * feval(f, x1) != 0);

  cifras = input('Ingrese el número de cifras significativas: ');

  do
    %Menú para solicitar si desea por el número de iteraciones o calcular el umbral.
    menu = "\nMENÚ\nDesea calcular mediante:\n1.Número de iteraciones\n2.Umbral\n3.Salir\nIngrese una opción <1-3>: ";
    opc = input(menu);
    switch(opc)
       case {1} %Numero de iteraciones
         iteraciones(f,x0,x1,cifras);

       case {2} %Umbral
         umbral(f,x0,x1,cifras);

       case {3} %Salir
         fprintf("Saliendo...\n");

       otherwise
         fprintf("Error! Ingrese una opción válida <1-3>\n");
    endswitch

  until(opc == 3);
%----------------------------END MAIN PROGRAM----------------------------------%
