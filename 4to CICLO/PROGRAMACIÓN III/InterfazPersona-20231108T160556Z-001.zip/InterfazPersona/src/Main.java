import Controlador.CtrlPersona;
import Vista.PersonaGUI;

public class Main {
    public static void main(String [] args){
        PersonaGUI miVentana = new PersonaGUI();
        miVentana.pack();
        miVentana.setVisible(true);
        CtrlPersona ctrl = new CtrlPersona(miVentana);
    }
}
