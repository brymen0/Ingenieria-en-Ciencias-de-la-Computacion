package Modelo;

import Controlador.CtrlPersona;

import java.util.*;

public class ManejoPersona {
    //Persona vectorPersona[];
    public ArrayList<Persona> vectorPersona;
    int n;
    public ManejoPersona(){
        vectorPersona = new ArrayList<Persona>();
        n=0;
    }

    public ArrayList<Persona> listaPersonas(){
        return vectorPersona;
    }
    public void Ordenar(int campo, ArrayList<Persona>vectorPersona){
        switch(campo){
            case 0:
                Collections.sort(vectorPersona);
                vectorPersona.forEach(i -> System.out.println(i));
                break;
            case 1:
                Collections.sort(vectorPersona, new Comparator<Persona>() {
                    @Override
                    public int compare(Persona p1, Persona p2) {
                        return p1.getNombre().compareToIgnoreCase(p2.getNombre());
                    }
                });
                vectorPersona.forEach(i -> System.out.println(i));
                break;
            case 2:
                Collections.sort(vectorPersona, new Comparator<Persona>() {
                    @Override
                    public int compare(Persona p1, Persona p2) {
                        return p1.getTelefono().compareToIgnoreCase(p2.getTelefono());
                    }
                });
                vectorPersona.forEach(i -> System.out.println(i));
                break;
        }
    }

    public int buscarAd(String cedula){
        for(int i=0;i<vectorPersona.size();i++){
            if(cedula.equals(vectorPersona.get(i).getCedula()))
                return i;
        }
        return -1;
    }
    public void eliminarPersona(int posicion) {
        System.out.print("Persona ");
        mostrarPersona(posicion);
        System.out.println(" eliminada con exito");
        vectorPersona.remove(posicion);
        /*for (int i = posicion; i < (n - 1); i++) {
            vectorPersona.set(i, vectorPersona.get(i+1));
        }*/
        n--; // Reducir la cantidad de personas en el arreglo
    }

    public void ingresarPersona(String nombre, String cedula, String  telefono){
        vectorPersona.add(new Persona(nombre, cedula, telefono));
        n++;
    }

    public boolean valida_nombre(String nombre) {
        if (nombre.length() > 20)
            System.out.println("ERROR: La extension del nombre no puede sobrepasar los 20 caracteres");
        if (!(nombre.matches("^[a-zA-Z ]+$")))
            System.out.println("ERROR: El nombre solo puede contener letras");
        if (nombre.length() < 20 && nombre.matches("^[a-zA-Z ]+$")) return true;
        return false;
    }

    public boolean validaTelefono(String telefono){
        if(!(telefono.matches("\\d+"))){
            System.out.println("ERROR: El telefono solo debe contener numeros");
            return false;
        }
        return true;
    }
    public boolean validaCedula(String cedula) {
        int n = 0, res, sumDig = 0, sobrante, verificador, aux;
        if(cedula.length() != 10){
            System.out.println("ERROR: La cedula debe contener 10 digitos");
            return false;
        }
        for (int i = 0; i < cedula.length(); i++) {
            char c = cedula.charAt(i);
            n = Character.getNumericValue(c);

            if (i % 2 == 0) {
                res = n * 2;
                if (res >= 10) res = res - 9;
            } else res = n * 1;

            sumDig += res;
        }

        aux = sumDig - Character.getNumericValue(cedula.charAt(9));
        sobrante = aux % 10;

        if (sobrante == 0) verificador = 0;
        else verificador = 10 - sobrante;

        if (verificador == Character.getNumericValue(cedula.charAt(9))) return true;
        else {
            System.out.println("ERROR: La cédula " + cedula + " no es válida");
            return false;
        }
    }

    public void mostrarPersona(int i){
            System.out.println(vectorPersona.get(i));
    }

    public int buscarPersona(String valor, int campo){
        int posicion = -1;
        for(int i=0;i<n; i++){
            switch (campo){
                case 0:
                    if(valor.equals(vectorPersona.get(i).getCedula()))
                        posicion = i;
                    break;
                case 1:
                    if(valor.equals(vectorPersona.get(i).getNombre()))
                        posicion = i;
                    break;
                case 2:
                    if(valor.equals(vectorPersona.get(i).getTelefono()))
                        posicion = i;
                    break;
            }
        }
        return posicion;
    }

    public void modificaPersona(String valor, int campo, int posicion){
        boolean hecho = false;
        switch (campo){
            case 0: vectorPersona.get(posicion).setCedula(valor); hecho=true; break;
            case 1: vectorPersona.get(posicion).setNombre(valor); hecho=true; break;
            case 2: vectorPersona.get(posicion).setTelefono(valor); hecho=true; break;
        }
        if(hecho) System.out.println("Se ha realizado el cambio con exito");
    }
    public void modificarPersona(String valor, int campo, int posicion){
        boolean hecho = false;
        switch (campo){
            case 0: vectorPersona.get(posicion).setCedula(valor); hecho=true; break;
            case 1: vectorPersona.get(posicion).setNombre(valor); hecho=true; break;
            case 2: vectorPersona.get(posicion).setTelefono(valor); hecho=true; break;
        }
        if(hecho) System.out.println("Se ha realizado el cambio con exito");
        else System.out.println("No se ha encontrado  el dato: "+valor);
    }

}