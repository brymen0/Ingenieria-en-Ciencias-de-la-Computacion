package Controlador;

import Modelo.ManejoPersona;
import Modelo.Persona;
import Vista.PersonaGUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CtrlPersona implements ActionListener {
    PersonaGUI vista;
    ManejoPersona modelo;
    private DefaultTableModel modelTabla;
    public CtrlPersona(PersonaGUI vista) {
        this.vista = vista;
        //vista.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.vista.buttonOK.addActionListener(this);
        this.vista.buttonCancel.addActionListener(this);
        this.vista.buttonBuscar.addActionListener(this);
        this.vista.buttonEliminar.addActionListener(this);
        this.vista.buttonModificar.addActionListener(this);
        modelo = new ManejoPersona();
        mostrarTabla();
    }

    public void mostrarTabla(){
        String data[][] = {};
        String col [] = {"CEDULA", "NOMBRES", "TELEFONO"};
        modelTabla = new DefaultTableModel(data, col);
        vista.Tabla.setModel(modelTabla);
        //vista.Tabla.getColumn(vista.Tabla.getColumnName(0)).setHeaderValue();
    }

    public void borrarEntradas(){
        vista.setTfCedula("");
        vista.setTfNombre("");
        vista.setTfTelefono("");
    }

    public void cargarTabla(){
        for(Persona e: modelo.listaPersonas()){
            Object [] fila = {e.getNombre(), e.getCedula(), e.getTelefono()};
            modelTabla.addRow(fila);
        }
        vista.Tabla.setModel(modelTabla);
    }
    
    public void actionPerformed(ActionEvent e){
       if(e.getSource() == vista.buttonOK){
           modelo.ingresarPersona(vista.getTfNombre(), vista.getTfCedula(), vista.getTfTelefono());
           modelTabla.insertRow(modelTabla.getRowCount(), new Object[]{});
           modelTabla.setValueAt(vista.getTfNombre(), modelTabla.getRowCount()-1,0);
           modelTabla.setValueAt(vista.getTfCedula(), modelTabla.getRowCount()-1,1);
           modelTabla.setValueAt(vista.getTfTelefono(), modelTabla.getRowCount()-1, 2);
           JOptionPane.showMessageDialog(null,"Persona ingresada");
           borrarEntradas();
       }
       if(e.getSource() == vista.buttonCancel){
           borrarEntradas();
          // System.exit(0);
       }
       if(e.getSource() == vista.buttonBuscar){
           //String ced = JOptionPane.showInputDialog(null,"Ingrese la cedula a buscar");
           int p = modelo.buscarAd(vista.getTfCedula());
           if(p!= -1) {
               JOptionPane.showMessageDialog(null,"Se ha encontrado a la persona");
               modelo.mostrarPersona(p);
           }
           else JOptionPane.showMessageDialog(null,"No existe la persona con cedula " + vista.getTfCedula());
       }
       if(e.getSource() == vista.buttonEliminar){
           int p = modelo.buscarAd(vista.getTfCedula());
           if(p!= -1) {
               modelo.eliminarPersona(p);
               modelTabla.setRowCount(0);
               cargarTabla();
           }
           else JOptionPane.showMessageDialog(null,"No existe la persona con cedula " + vista.getTfCedula());
       }
       if(e.getSource() == vista.buttonModificar){
           String ced = JOptionPane.showInputDialog(null,"Ingrese la cedula de la persona que desea buscar");
           int p = modelo.buscarAd(ced);
           if(p!= -1) {
               String nom = JOptionPane.showInputDialog(null,"Ingrese el nuevo nombre");
               modelo.modificaPersona(nom,1,p);
               String telf = JOptionPane.showInputDialog(null,"Ingrese el nuevo telefono");
               modelo.modificaPersona(telf,2,p);
               modelTabla.setRowCount(0); //borra la tabla
               cargarTabla(); //carga la tabla con llos datos actualizados
           }
           else System.out.println("No existe la persona con cedula " + ced);
       }
        borrarEntradas();
    }
}
