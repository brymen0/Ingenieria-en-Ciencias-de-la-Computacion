package Modelo;

public class Intentos {
    private String nombre;
    private String letra;
    private boolean acierto;

    public Intentos(String nombre, String letra, boolean acierto) {
        this.nombre = nombre;
        this.letra = letra;
        this.acierto = acierto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLetra() {
        return letra;
    }

    public void setLetra(String letra) {
        this.letra = letra;
    }

    public boolean isAcierto() {
        return acierto;
    }

    public void setAcierto(boolean acierto) {
        this.acierto = acierto;
    }
}
