package Modelo;

import Controlador.CtrlAhorcado;
import Vista.AhorcadoGUI;
import javax.swing.*;
import java.io.*;
import java.util.*;

public class Ahorcado {
  //  private String palabraSecreta = this.obtenerPalabraSecreta();
    private String palabraSecreta;
    private Set<Character> letrasAdivinadas = new HashSet();
    private Set<Character> letrasIncorrectas = new HashSet();
    public ArrayList<Intentos> intentos;
    private int intentosRestantes = 8;
    public Ahorcado(boolean palabra) {
        intentos = new ArrayList<>();
        palabraSecreta = obtenerPalabraSecreta(palabra);
    }

    public void registrarIntento(String nombre,String letra, boolean acierto,int j){
        intentos.add(new Intentos(nombre,letra,acierto));
        PrintWriter archivo = null;
        try {
            archivo = new PrintWriter(new FileOutputStream("Intentos.txt"));
            archivo.println("Intento    Nombre     Acierto     Error");
            for(Intentos e:intentos){
                if(acierto){
                    archivo.println(j+"     "+e.getNombre()+"     "+e.getLetra());
                }else archivo.println(j+"       "+e.getNombre()+"                         "+e.getLetra());
            }
            archivo.flush();
            archivo.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear el archivo");
        }
    }

    public void CarchivoPalabras(){
        String[] palabras = new String[]{"ESTUDIO", "JAVA", "UNIVERSIDAD"};
        try {  // serializa la lista de figuras
            ObjectOutputStream archivo=new ObjectOutputStream(new FileOutputStream("PalabrasAhorcado"));
            archivo.writeObject(palabras);
            archivo.flush();
            archivo.close();
            //JOptionPane.showMessageDialog(null,"Archivo Comprimido con éxito");
        }catch (IOException e){
            e.getMessage();
        }
    }

    public String[] LPalabras(){
        String []palabras = new String[3];
        try {  // recupera la lista de figuras
            ObjectInputStream archivo;
            File path=new File("PalabrasAhorcado");
            if (path.exists()) {
                archivo=new ObjectInputStream(new FileInputStream("PalabrasAhorcado"));
                palabras=(String[])archivo.readObject();
             //   diccionario=(Map<String, Character>)archivo.readObject();
                archivo.close();
              //  JOptionPane.showMessageDialog(null,"Archivo Descomprimido con éxito");
            }
        }catch(ClassNotFoundException | IOException e){
            e.getMessage();
        }
        return palabras;
    }

    public String[] LFrases(){
        String []frases = new String[3];
        try {  // recupera la lista de figuras
            ObjectInputStream archivo;
            File path=new File("FrasesAhorcado");
            if (path.exists()) {
                archivo=new ObjectInputStream(new FileInputStream("FrasesAhorcado"));
                frases=(String[])archivo.readObject();
                //   diccionario=(Map<String, Character>)archivo.readObject();
                archivo.close();
               // JOptionPane.showMessageDialog(null,"Archivo Descomprimido con éxito");
            }
        }catch(ClassNotFoundException | IOException e){
            e.getMessage();
        }
        return frases;
    }

    public void CarchivoFrases(){
        String[] frases = new String[]{"HOY ES UN BUEN DIA", "ARROZ CON POLLO", "AYER FUE MARTES"};
        try {  // serializa la lista de figuras
            ObjectOutputStream archivo=new ObjectOutputStream(new FileOutputStream("FrasesAhorcado"));
            archivo.writeObject(frases);
            archivo.flush();
            archivo.close();
            //JOptionPane.showMessageDialog(null,"Archivo Comprimido con éxito");
        }catch (IOException e){
            e.getMessage();
        }
    }

    private String obtenerPalabraSecreta(boolean palabra) {
        String []palabras;
        if(palabra){
            CarchivoPalabras();
            palabras = LPalabras();
        }else{
            CarchivoFrases();
            palabras = LFrases();
        }
        Random random = new Random();
        return palabras[random.nextInt(palabras.length)];
    }

    public String getPalabraGuiones() {
        StringBuilder palabraGuiones = new StringBuilder();
        char[] var2 = this.palabraSecreta.toCharArray();
        int var3 = var2.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            char letra = var2[var4];
            if (!this.letrasAdivinadas.contains(letra) && Character.isLetter(letra)) {
                palabraGuiones.append("_");
            } else {
                palabraGuiones.append(letra);
            }

            palabraGuiones.append(" ");
        }

        return palabraGuiones.toString().trim();
    }

    public boolean intento(char letra) {
        letra = Character.toUpperCase(letra);
        if (!this.letrasAdivinadas.contains(letra) && !this.letrasIncorrectas.contains(letra)) {
            if (this.palabraSecreta.contains(String.valueOf(letra))) {
                this.letrasAdivinadas.add(letra);
                return true;
            } else {
                this.letrasIncorrectas.add(letra);
                --this.intentosRestantes;
                return false;
            }
        } else {
            return false;
        }
    }

    public boolean juegoTerminado() {
        return this.intentosRestantes == 0 || this.palabraDescubierta();
    }

    public boolean palabraDescubierta() {
        char[] var1 = this.palabraSecreta.toCharArray();
        int var2 = var1.length;

        for(int var3 = 0; var3 < var2; ++var3) {
            char letra = var1[var3];
            if (!this.letrasAdivinadas.contains(letra)) {
                return false;
            }
        }

        return true;
    }

    public Set<Character> getLetrasAdivinadas() {
        return this.letrasAdivinadas;
    }

    public Set<Character> getLetrasIncorrectas() {
        return this.letrasIncorrectas;
    }

    public int getIntentosRestantes() {
        return this.intentosRestantes;
    }

    public String getPalabraSecreta() {
        return this.palabraSecreta;
    }
}
