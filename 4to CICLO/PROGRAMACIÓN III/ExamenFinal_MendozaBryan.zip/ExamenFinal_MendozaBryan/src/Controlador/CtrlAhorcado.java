package Controlador;

import Modelo.Ahorcado;
import Vista.AhorcadoGUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileReader;
import java.io.IOException;

public class CtrlAhorcado implements ActionListener {
    AhorcadoGUI vista;
    Ahorcado modelo;
    boolean jugar = false;
    String []names;
    int n=0;
    public CtrlAhorcado(){
        vista = new AhorcadoGUI();
        modelo = new Ahorcado(!vista.palabraRadioButton.isSelected());

        vista.empezarAJugarButton.addActionListener(this);
        vista.fraseRadioButton.addActionListener(this);
        vista.palabraRadioButton.addActionListener(this);
        vista.noRadioButton.addActionListener(this);
        vista.siRadioButton.addActionListener(this);
        vista.probarLetraButton.addActionListener(this);
        vista.rendirseButton.addActionListener(this);
        vista.cargarResultadosButton.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int i=0,j=0;
        if(!modelo.juegoTerminado()){
            if(e.getSource() == vista.rendirseButton){
                if(jugar){
                    JOptionPane.showMessageDialog((Component)null, "Perdiste la partida. La palabra era: " + modelo.getPalabraSecreta());
                    System.exit(0);
                }else{
                    JOptionPane.showMessageDialog(null,"Todavia no ha iniciado el juego");
                }
                jugar = false;
            }

            if(e.getSource() == vista.probarLetraButton){
                if(jugar){
                    //System.out.println(names);
                   // System.out.println(n);
                    String letraIngresada = vista.getTextLetra();
                    if (letraIngresada.length() == 1 && Character.isLetter(letraIngresada.charAt(0))) {
                        if(i>n) i=0;
                        char letra = letraIngresada.charAt(0);
                        boolean validaLetra = modelo.intento(letra);
                        if (validaLetra) {
                            JOptionPane.showMessageDialog(null, "Correcto, la letra está en la palabra.");
                            modelo.registrarIntento(names[i],letraIngresada,validaLetra,j);
                            j++;
                        } else {
                            JOptionPane.showMessageDialog(null, "Incorrecto, la letra no está en la palabra.");
                            modelo.registrarIntento(names[i],letraIngresada,validaLetra,j);
                            j++;
                        }
                        vista.setTextLetra("");
                        this.actualizarMuneco();
                        vista.setTxtTurno("Turno: "+names[i]);
                        i++;
                    } else {
                        JOptionPane.showMessageDialog((Component)null, "Ingrese una letra válida.");
                    }
                }else{
                    JOptionPane.showMessageDialog(null,"Todavia no ha iniciado el juego");
                }
            }
        }else{
            if (modelo.palabraDescubierta()) {
                JOptionPane.showMessageDialog((Component)null, "Ganaste la partida. La palabra es: " + modelo.getPalabraSecreta());
            } else {
                JOptionPane.showMessageDialog((Component)null, "Perdiste la partida. La palabra era: " + modelo.getPalabraSecreta());
            }
        }
        if(e.getSource() == vista.cargarResultadosButton){
            JFileChooser archi = new JFileChooser("./"); //para seleccionar el nombre del archivo en grabae y recuperar
            archi.setFileSelectionMode(JFileChooser.FILES_ONLY);
                try {
                    int valor = archi.showDialog(vista, "Seleccionar");
                    if (valor == JFileChooser.APPROVE_OPTION) {
                        FileReader entrada = new FileReader(archi.getSelectedFile());
                        StringBuilder resultados = new StringBuilder();
                        int c;
                        while ((c=entrada.read()) != -1) {
                            resultados.append((char)c);
                        }
                        entrada.close();
                        vista.setTextAreaMostrar(String.valueOf(resultados));
                    } else {
                        JOptionPane.showMessageDialog(vista, "No se ha podido cargar el archivo", "Error!", JOptionPane.WARNING_MESSAGE);
                    }
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
        }

        if(e.getSource() == vista.empezarAJugarButton){
            if(validarConfJuego(vista.getTextNombres())){
                JOptionPane.showMessageDialog(null,"El juego ha empezado");
                jugar = true;
                n = Integer.parseInt(vista.getTextNumPersonas());
                vista.setTxtTurno("Turno: "+names[0]);
                i++;
            }
        }
    }

    public void actualizarMuneco() {
        vista.setTxtPalabraAdivinar(modelo.getPalabraGuiones());
        vista.setTextAreaDibujo(obtenerRepresentacionPersonaAhorcada(modelo.getIntentosRestantes()));
    }

    public boolean validarConfJuego(String nombres){
        names = nombres.split(",");
        boolean valido = true;
        if(nombres.isEmpty()){
            JOptionPane.showMessageDialog(null,"Debe imgresar los nombres de los jugadores");
            valido = false;
        }
        if(vista.getTextNumPersonas().isEmpty()){
            JOptionPane.showMessageDialog(null,"Debe ingresar un numeor de jugadores");
            valido = false;
        }
        int num = Integer.parseInt(vista.getTextNumPersonas());
        if(num<1 || num>3){
            JOptionPane.showMessageDialog(null,"El numero de participantes debe estar entre 1 y 3");
            valido = false;
        }
        if(names.length != num){
            JOptionPane.showMessageDialog(null,"Revise la cantidad de nombres respecto a los jugadores ingresados");
            valido = false;
        }
        if(!vista.siRadioButton.isSelected() && !vista.noRadioButton.isSelected()){
            JOptionPane.showMessageDialog(null,"Seleccione si quiere ayuda inicial");
            valido = false;
        }
        if(!vista.palabraRadioButton.isSelected() && !vista.fraseRadioButton.isSelected()){
            JOptionPane.showMessageDialog(null,"Seleccione si quiere jugar con palabras o frases");
            valido = false;
        }
        return valido;
    }

    private String obtenerRepresentacionPersonaAhorcada(int intentosRestantes) {
        switch (intentosRestantes) {
            case 0:
                return "_________\n|              |\n|              L\n|             O\n|             /|\\\n|             / \\\n|\n¡Has sido ahorcado!";
            case 1:
                return "_________\n|              |\n|              O\n|             /|\\\n|             / \\\n|               \n|\n¡Estás a punto de ser ahorcado!";
            case 2:
                return "_________\n|              |\n|              O\n|             /|\\\n|             / \\\n|               \n|";
            case 3:
                return "_________\n|              |\n|              O\n|             /|\\\n|             /\n|               \n|";
            case 4:
                return "_________\n|              |\n|              O\n|             /|\\\n|               \n|               \n|";
            case 5:
                return "_________\n|              |\n|              O\n|             /|\n|               \n|               \n|";
            case 6:
                return "_________\n|              |\n|              O\n|              |\n|               \n|               \n|";
            case 7:
                return "_________\n|              |\n|              O\n|               \n|               \n|               \n|";
            case 8:
                return "_________\n|              |\n|              \n|               \n|               \n|               \n|";
            default:
                return "_________\n|              |\n|              L\n|              \n|               \n|               \n|";
        }
    }

}
