package Vista;

import javax.swing.*;

public class AhorcadoGUI extends JFrame {

    private JPanel panelPrincipal;
    private JTextArea textAreaDibujo;
    private JLabel txtPalabraAdivinar;
    private JTextField textLetra;
    public JButton probarLetraButton;
    public JRadioButton palabraRadioButton;
    public JRadioButton fraseRadioButton;
    public JButton rendirseButton;
    private JLabel txtTurno;
    public JPanel panelJuego;
    private JPanel panelConfiguracion;
    public JPanel panelMostrar;
    private JTextArea textAreaMostrar;
    private JTextField textNumPersonas;
    private JTextField textNombres;
    public JRadioButton siRadioButton;
    public JRadioButton noRadioButton;
    public JButton empezarAJugarButton;
    public JButton cargarResultadosButton;

    public AhorcadoGUI(){
        pack();
        setVisible(true);
        setContentPane(panelPrincipal);
        setBounds(200,100,800,900);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public String getTextNombres() {
        return textNombres.getText();
    }

    public void setTextNombres(String textNombres) {
        this.textNombres.setText(textNombres);
    }

    public String getTextAreaDibujo() {
        return textAreaDibujo.getText();
    }

    public void setTextAreaDibujo(String textAreaDibujo) {
        this.textAreaDibujo.setText(textAreaDibujo);
    }

    public String getTxtPalabraAdivinar() {
        return txtPalabraAdivinar.getText();
    }

    public void setTxtPalabraAdivinar(String  txtPalabraAdivinar) {
        this.txtPalabraAdivinar.setText(txtPalabraAdivinar);
    }

    public String  getTextLetra() {
        return textLetra.getText();
    }

    public void setTextLetra(String  textLetra) {
        this.textLetra.setText(textLetra);
    }

    public String getTxtTurno() {
        return txtTurno.getText();
    }

    public void setTxtTurno(String txtTurno) {
        this.txtTurno.setText(txtTurno);
    }

    public String getTextAreaMostrar() {
        return textAreaMostrar.getText();
    }

    public void setTextAreaMostrar(String textAreaMostrar) {
        this.textAreaMostrar.setText(textAreaMostrar);
    }

    public String getTextNumPersonas() {
        return textNumPersonas.getText();
    }

    public void setTextNumPersonas(String textNumPersonas) {
        this.textNumPersonas.setText(textNumPersonas);
    }
}
