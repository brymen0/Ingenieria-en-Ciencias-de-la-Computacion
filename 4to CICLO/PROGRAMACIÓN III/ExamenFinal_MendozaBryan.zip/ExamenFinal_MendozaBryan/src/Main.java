import Controlador.CtrlAhorcado;
import Vista.AhorcadoGUI;

public class Main {
    public static void main(String[] args) {
      //  AhorcadoGUI vi = new AhorcadoGUI();
        CtrlAhorcado n = new CtrlAhorcado();
    }
}