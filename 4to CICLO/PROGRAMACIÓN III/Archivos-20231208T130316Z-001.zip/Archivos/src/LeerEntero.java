import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class LeerEntero {
    public static void main(String []args){
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String s= "";
        int edad = 0;
        System.out.println("Escriba su edad: ");
        try{
            edad  = Integer.parseInt(in.readLine().trim());
        } catch (NumberFormatException e){
            System.out.println("No es un entero");
        } catch (IOException e){
            System.out.println("Error.");
        }
        System.out.println("Su edad es: "+edad);
    }
}
