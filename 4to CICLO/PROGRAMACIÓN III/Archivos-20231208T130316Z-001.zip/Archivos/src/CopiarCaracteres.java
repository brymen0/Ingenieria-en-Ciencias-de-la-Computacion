import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopiarCaracteres {
    public static void main(String []args) throws IOException{
        FileReader entrada = null;
        FileWriter salida = null;

        try{
            entrada = new FileReader("entrada.txt");
            salida = new FileWriter("salida_car.txt");
            int c;
            while((c=entrada.read()) != -1){
                salida.write(c);
            }
        }catch(IOException e){
            System.out.println(e.getMessage());
        } finally {
            if(entrada != null) entrada.close();
            if(salida != null) salida.close();
        }
    }
}
