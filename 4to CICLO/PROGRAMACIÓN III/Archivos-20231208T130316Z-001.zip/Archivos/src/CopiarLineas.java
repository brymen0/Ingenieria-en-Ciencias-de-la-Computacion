import java.io.*;

public class CopiarLineas {
    public static void main(String[]args) throws IOException {
        BufferedReader entrada = null;
        PrintWriter salida = null;
        try{
            entrada = new BufferedReader(new FileReader("entrada.txt"));
            salida = new PrintWriter(new FileWriter("salida_lin.txt"));
            String l;
            while ((l = entrada.readLine()) != null){
                salida.println(l);
            }
        }catch(IOException e){
            System.out.println(e.getMessage());
        }finally{
            if(entrada != null) entrada.close();
            if(salida != null) salida.close();
        }
    }
}
