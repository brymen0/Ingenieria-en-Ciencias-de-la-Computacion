import java.io.BufferedReader;
import java.io.InputStreamReader;

public class LeerCadena {
    public static void main(String[]args){
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String s ="";
        System.out.println("Escriba su nombre: ");

        try{
            s = in.readLine();
        } catch (Exception E){
            s = "";
        }
        System.out.println("Su nombre es: "+s);
    }
}
