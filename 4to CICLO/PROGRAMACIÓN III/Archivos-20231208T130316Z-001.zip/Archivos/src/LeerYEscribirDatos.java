import java.io.*;

public class LeerYEscribirDatos {
    static void escribirFichero (String nombreFich, String nomb[], int ed[]) throws IOException {
        DataOutputStream salida = null;
        try {
            salida = new DataOutputStream(new FileOutputStream(nombreFich));
            for (int i =0; i< nomb.length; i++) {
                salida.writeUTF(nomb[i]+'\n');
                salida.writeInt(ed[i]);
            }
            salida.close();
        }
        catch (FileNotFoundException e) {
            System.out.printf("No se puede crear el fichero" );
            System.exit(-1);
        }
        catch (IOException e) {
            System.out.println(e.getMessage());
            System.exit(-1);
        }
        finally {
            if (salida!= null) salida.close();
        }
    }

    static void leerFichero (String nombreFich)
            throws IOException {
        DataInputStream entrada = null;

        try{
            entrada =
                    new DataInputStream (new FileInputStream (nombreFich));
            while (true) {
                System.out.println("Nombre: " + entrada.readUTF() +
                        "Edad: " + entrada.readInt());
            }
        }
        catch (EOFException e) {
            System.out.println("Fin de archivo.");
        }
        catch (FileNotFoundException e) {
            System.out.println("No se puede abrir el fichero");
            System.exit(-1);
        }
        catch (IOException e){
            System.out.println(e.getMessage());
            System.exit(-1);
        }
        finally{
            if(entrada!=null)entrada.close();
        }
    }

    public static void main(String[] args) throws IOException {
        String nombres[] ={"Pepe", "Ana", "Laura", "Toni"};
        int edades[] = {21,23, 22, 21};
        //escribirFichero("datos", nombres, edades) ;
       // leerFichero("datos");
        escribirFichero("datos.txt", nombres, edades) ;
        leerFichero("datos.txt");
    }

}