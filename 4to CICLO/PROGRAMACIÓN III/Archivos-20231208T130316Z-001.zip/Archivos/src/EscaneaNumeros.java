import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class EscaneaNumeros {
    public static void main(String[]args){
        Scanner s = null;
        double suma=0,n;

        try{
            s = new Scanner(new BufferedReader(new FileReader("numeros.txt")));
            while(s.hasNext()){
                if(s.hasNextDouble()){
                    n = s.nextDouble();
                    suma += n;
                }else System.out.println(s.next());
            }
        } catch (IOException e){
            System.out.println(e.getMessage());
        } finally {
            if(s != null) s.close();
        }
        System.out.println("Total= "+suma);
    }
}
