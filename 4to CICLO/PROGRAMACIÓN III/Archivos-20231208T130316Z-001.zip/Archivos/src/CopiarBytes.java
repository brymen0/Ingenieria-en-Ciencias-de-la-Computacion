import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopiarBytes {
    public  static void main(String[]args) throws IOException{
        FileInputStream entrada = null;
        FileOutputStream salida = null;
        try{
            entrada = new FileInputStream("entrada.txt");
            salida = new FileOutputStream("salida.txt");
            int c;
            while((c = entrada.read()) != -1){
                salida.write(c);
            }
        } catch(IOException e){
            System.out.println(e.getMessage());
        } finally {
            if(entrada != null) entrada.close();
            if(salida != null) salida.close();
        }
    }
}
