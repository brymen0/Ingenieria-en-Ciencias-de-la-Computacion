package Controlador;

import Modelo.ListaFormas;
import Vista.Ventana;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class ControladorHacerFormas implements ActionListener, MouseListener {
    private Ventana vista;
    private ListaFormas formas;
    private Point punto;
    private Color color;

    public ControladorHacerFormas(){
        this.formas = new ListaFormas();
        this.vista = new Ventana();
        vista.colorFiguraButton.addActionListener(this);
        vista.grabarButton.addActionListener(this);
        vista.limpiarButton.addActionListener(this);
        vista.restaurarButton.addActionListener(this);
        vista.DibujarPanel.addMouseListener(this);
        iniciar();
    }

    public void iniciar(){
        vista.setTitle("Gestión de Formas");
        vista.setLocationRelativeTo(null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JFileChooser archi = new JFileChooser("./"); //para seleccionar el nombre del archivo en grabae y recuperar
        archi.setFileSelectionMode(JFileChooser.FILES_ONLY);
        if(e.getSource() == vista.grabarButton){
            int returnVal = archi.showDialog(vista,"Grabar");

            if(returnVal == JFileChooser.APPROVE_OPTION){ //si  no se cancela la selección del archivo
                formas.grabar(archi.getSelectedFile().getAbsoluteFile().getPath());
                JOptionPane.showMessageDialog(null,"Figuras grabadas");
            }
        }
        if(e.getSource() == vista.restaurarButton){
            formas.borrarTodos();
            vista.DibujarPanel.repaint();

            int returnVal = archi.showDialog(vista,"Seleccionar");
            if(returnVal == JFileChooser.APPROVE_OPTION){
                formas.recuperar(archi.getSelectedFile().getAbsoluteFile().getPath());
                formas.dibujarFiguras(vista.DibujarPanel.getGraphics());
                JOptionPane.showMessageDialog(null,"Figuras Recuperadas");
            }
        }
        if(e.getSource() == vista.colorFiguraButton){
            color = JColorChooser.showDialog(vista,"Escoja el color de la figura",null);
        }
        if(e.getSource() == vista.limpiarButton){
            vista.DibujarPanel.repaint();
            formas.borrarTodos();
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        punto = e.getPoint().getLocation();
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        Point p = e.getPoint().getLocation();
        formas.agregar((String) vista.tipoFigura.getSelectedItem(),
                color,
                vista.conRellenoRadioButton.isSelected(),
                vista.DibujarPanel.getGraphics(),
                punto,
                Math.abs(p.x-punto.x),
                Math.abs(p.y-punto.y));
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
