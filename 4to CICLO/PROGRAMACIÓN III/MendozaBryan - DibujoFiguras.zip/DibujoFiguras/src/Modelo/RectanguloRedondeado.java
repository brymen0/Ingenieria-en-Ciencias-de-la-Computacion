package Modelo;

import java.awt.*;

public class RectanguloRedondeado extends Forma{
    public RectanguloRedondeado (Point p, int w, int h, boolean fill, Color color){
        setPunto(p); setAncho (w); setAlto(h); setTieneRelleno (fill); setColor (color);}

    @Override
    public void Dibujar (Graphics g) {
        g.setColor(getColor());

        if (getTieneRelleno())
            g.fillRoundRect(getPunto().x, getPunto().y, getAncho(), getAlto(),20,20);
        else
            g.drawRoundRect(getPunto().x, getPunto().y, getAncho(), getAlto(),20,20);
    }
}
