package Modelo;

import java.awt.*;

public class Rectangulo extends Forma{
    public Rectangulo (Point p, int w, int h, boolean fill, Color color){
        setPunto(p); setAncho (w); setAlto(h); setTieneRelleno (fill); setColor (color);}

    @Override
    public void Dibujar (Graphics g) {
        g.setColor(getColor());

        if (getTieneRelleno())
            g.fillRect(getPunto().x, getPunto().y, getAncho(), getAlto());
        else
            g.drawRect(getPunto().x, getPunto().y, getAncho(), getAlto());
    }
}
