package Modelo;

import java.awt.*;

public class Ovalo extends Forma{
    public Ovalo (Point p, int w, int h, boolean fill, Color color){
        setPunto(p); setAncho (w); setAlto(h); setTieneRelleno (fill); setColor (color);}

    @Override
    public void Dibujar (Graphics g) {
        g.setColor(getColor());

        if (getTieneRelleno())
            g.fillOval(getPunto().x, getPunto().y, getAncho(), getAlto());
        else
            g.drawOval(getPunto().x, getPunto().y, getAncho(), getAlto());
    }
}