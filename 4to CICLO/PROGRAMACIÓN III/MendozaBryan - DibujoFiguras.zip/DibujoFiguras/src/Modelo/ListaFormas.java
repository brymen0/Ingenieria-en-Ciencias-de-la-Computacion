package Modelo;

import java.awt.*;
import java.io.*;
import java.util.LinkedList;

public class ListaFormas {
    private LinkedList<Forma> figuras;
    public ListaFormas(){
        figuras = new LinkedList<>();
    }

    public void agregar(String tipo, Color color, boolean relleno, Graphics g, Point p, int ancho, int alto){
        Forma f = null;
        //de acuerod al tipo agrega la figura
        if(tipo.equals("Rectángulo")){
            f = new Rectangulo(p, ancho, alto, relleno,color);
            f.Dibujar(g);
        }
        if(tipo.equals("Ovalo")){
            f = new Ovalo(p, ancho, alto, relleno,color);
            f.Dibujar(g);
        }
        if(tipo.equals("Rectángulo Redondeado")){
            f = new RectanguloRedondeado(p, ancho, alto, relleno,color);
            f.Dibujar(g);
        }
        figuras.add(f); //solo cuando tiene que grabar caso contrario solo grafica
    }

    public void grabar(String nombreArchivo){
        try{
            ObjectOutputStream archivo = new ObjectOutputStream(new FileOutputStream(nombreArchivo));
            archivo.writeObject(figuras);
            archivo.flush();
            archivo.close();
        }catch (IOException e){
            e.getMessage();
        }
    }

    public void recuperar(String nombreArchivo){
        try{
            ObjectInputStream archivo;
            File path = new File(nombreArchivo);
            if(path.exists()){
                archivo = new ObjectInputStream(new FileInputStream(nombreArchivo));
                figuras = (LinkedList<Forma>) archivo.readObject();
                archivo.close();
            }
        }catch (ClassNotFoundException | IOException exception){
            exception.getMessage();
        }
    }

    public void dibujarFiguras(Graphics g){
        for(int i=0; i<figuras.size(); i++){
            figuras.get(i).Dibujar(g);
        }
    }

    public void borrarTodos(){
        figuras.clear();
    }
}
