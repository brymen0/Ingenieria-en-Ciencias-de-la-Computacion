import Controlador.ControladorHacerFormas;

public class Main {
    public static void main(String []args){
        //Autor: Bryan Mendoza
        ControladorHacerFormas n = new ControladorHacerFormas();
    }
}
