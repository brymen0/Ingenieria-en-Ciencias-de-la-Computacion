package Vista;

import javax.swing.*;

public class Ventana extends JFrame {
    private JPanel contentPane;
    private JPanel InformacionPanel;
    private JPanel BotonesPanel;
    public JPanel DibujarPanel;
    public JComboBox tipoFigura;
    private JRadioButton contornoRadioButton;
    public JRadioButton conRellenoRadioButton;
    public JButton limpiarButton;
    public JButton grabarButton;
    public JButton restaurarButton;
    public JButton colorFiguraButton;

    public Ventana() {
        pack();
        setVisible(true);
        setSize(700,500);
        setContentPane(contentPane);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
