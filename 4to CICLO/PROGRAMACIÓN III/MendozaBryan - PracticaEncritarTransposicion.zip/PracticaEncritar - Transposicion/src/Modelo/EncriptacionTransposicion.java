package Modelo;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Scanner;

public class EncriptacionTransposicion {
    public void grabar(String nombreArchivo, String frase){
        PrintWriter salida = null;
        try{
            salida = new PrintWriter(new FileWriter(nombreArchivo+".txt"));
            String l;
            salida.print(frase);
            JOptionPane.showMessageDialog(null,"Archivo Grabado");
        }catch(IOException e){
            System.out.println(e.getMessage());
        }finally{
            if(salida != null) salida.close();
        }
    }

    public String recuperar(String nombreArchivo){
        String frase = "";
        FileReader entrada = null;

        try{
            entrada = new FileReader(nombreArchivo);
            int c;
            while((c=entrada.read()) != -1){
                frase += (char)c;
            }
            JOptionPane.showMessageDialog(null,"Archivo recuperado");
        }catch(IOException e){
            System.out.println(e.getMessage());
        } finally {
            try {
                if (entrada != null) {
                    entrada.close();
                }
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }
        return frase;
    }
    public char[][] realizaMatriz(String frase, String palabraClave){
        String palClave = palabraClave.toUpperCase();
        int columnas = palabraClave.length();
        double div = frase.length() / (double)columnas;
        int filas = (int) Math.ceil(div) + 2;
        int k = 0;
        char[][] matriz = new char[filas][columnas];
        char[] palabraClaveDividida = palClave.toCharArray();
        char[] fraseDividida = frase.toCharArray();

        matriz[0] = palabraClaveDividida;
        matriz[1] = obtenerPosicionEnAlfabeto(palabraClaveDividida.clone());

        for(int i = 2;i < filas; i++){
            for(int j = 0; j < columnas; j++){
                if(k > frase.length()-1) matriz[i][j] = ' ';
                else matriz[i][j] = fraseDividida[k];
                k++;
            }
        }

        return matriz;
    }

    public char[][] realizaMatrizDesencriptar(String fraseEncriptada, String palabraClave){
        String palClave = palabraClave.toUpperCase();
        int columnas = palClave.length();
        double div = fraseEncriptada.length() / (double)columnas;
        int filas = (int) Math.ceil(div) + 2;
        int k = 1,l=0;
        char[][] matriz = new char[filas][columnas];
        char[] palabraClaveDividida = palClave.toCharArray();
        char[] fraseEncripDividida = fraseEncriptada.toCharArray();
        //for(int i=0;i<fraseEncripDividida.length;i++) System.out.print(fraseEncripDividida[i]);
        matriz[0] = palabraClaveDividida;
        matriz[1] = obtenerPosicionEnAlfabeto(palabraClaveDividida.clone());

        while(k <= palabraClave.length()){
            for(int j = 0; j < columnas; j++){
                if(matriz[1][j] == (char)('0'+k)){
                    for(int i = 2; i < matriz.length; i++){
                        if(l > fraseEncriptada.length() - 1) matriz[i][j] = ' ';
                        else matriz[i][j] = fraseEncripDividida[l];
                        l++;
                    }
                    k++;
                }
            }
        }
        return matriz;
    }

    public String fraseDesencriptada(char [][]matriz){
        String fraseD = "";
        for(int i=2; i<matriz.length; i++){
            for(int j = 0; j<matriz[0].length; j++){
                fraseD += matriz[i][j];
            }
        }
        return fraseD;
    }

    public String imprimeMatriz(char[][]matriz){
        String matrizText="";
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++)
                matrizText += matriz[i][j]+" ";
            matrizText += "\n";
        }

        return matrizText;
    }
    public String fraseEncriptada(char[][]matriz, int extension){
        String fraseE="";
        int k = 1;
        char indice;

        while(k <= extension){
            for(int j = 0; j<matriz[0].length; j++){
                indice = (char)('0'+k);
                if(matriz[1][j] == indice) {
                    for(int i = 2; i<matriz.length; i++){
                        fraseE += matriz[i][j];
                    }
                    k++;
                }
            }
        }
        return fraseE;
    }
    public char[] obtenerPosicionEnAlfabeto(char[] palabra) {
        char[]copia = palabra.clone();
        Arrays.sort(palabra);
        char[]indices = new char[palabra.length];

        for(int i=0;i<palabra.length;i++){
            for(int j=0; j<copia.length;j++) {
                if(copia[i] == palabra[j]){
                    indices[i] = (char)('0'+(j+1));
                    break;
                }
            }
        }
        return indices;
    }
}
