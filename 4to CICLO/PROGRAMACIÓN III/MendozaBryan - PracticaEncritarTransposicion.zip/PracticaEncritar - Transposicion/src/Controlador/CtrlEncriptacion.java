package Controlador;

import Modelo.EncriptacionTransposicion;
import Vista.EncriparTransposicionGUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CtrlEncriptacion implements ActionListener {
    EncriparTransposicionGUI vista;
    EncriptacionTransposicion modelo;
    public CtrlEncriptacion(){
        vista = new EncriparTransposicionGUI();
        modelo = new EncriptacionTransposicion();

        vista.encriptarButton.addActionListener(this);
        vista.desencriptarButton.addActionListener(this);
        vista.limpiarButton.addActionListener(this);
        vista.grabarButton.addActionListener(this);
        vista.recuperarButton.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == vista.encriptarButton){
            char[][]matriz = modelo.realizaMatriz(vista.getTextAFrase(), vista.getTextPalabraClave());
            vista.setTextAMatriz(modelo.imprimeMatriz(matriz));
            vista.setTextAFraseEncriptada(modelo.fraseEncriptada(matriz,vista.getTextPalabraClave().length()));
        }
        if(e.getSource() == vista.desencriptarButton){
            vista.setLabelMatriz("Desencriptación");
            vista.setLabelFrase("Desencriptada");
            char[][]matriz = modelo.realizaMatrizDesencriptar(vista.getTextAFrase(), vista.getTextPalabraClave());
            vista.setTextAMatriz(modelo.imprimeMatriz(matriz));
            vista.setTextAFraseEncriptada(modelo.fraseDesencriptada(matriz));
        }
        if(e.getSource() == vista.limpiarButton){
            vista.setTextAFrase("");
            vista.setLabelFrase("");
            vista.setTextAMatriz("");
            vista.setTextAFraseEncriptada("");
            vista.setTextPalabraClave("");
        }
        JFileChooser archi = new JFileChooser("./"); //para seleccionar el nombre del archivo en grabae y recuperar
        archi.setFileSelectionMode(JFileChooser.FILES_ONLY);
        if(e.getSource() == vista.grabarButton){
            int returnVal = archi.showDialog(vista,"Grabar");

            if(returnVal == JFileChooser.APPROVE_OPTION){ //si  no se cancela la selección del archivo
                modelo.grabar(archi.getSelectedFile().getAbsoluteFile().getPath(),vista.getTextAFraseEncriptada());
            }
        }
        if(e.getSource() == vista.recuperarButton){
            int returnVal = archi.showDialog(vista,"Recuperar");

            if(returnVal == JFileChooser.APPROVE_OPTION){ //si  no se cancela la selección del archivo
                String frase = modelo.recuperar(archi.getSelectedFile().getAbsoluteFile().getPath());
                if(!frase.equals("")) vista.setTextAFrase(frase);
            }
        }
    }
}
