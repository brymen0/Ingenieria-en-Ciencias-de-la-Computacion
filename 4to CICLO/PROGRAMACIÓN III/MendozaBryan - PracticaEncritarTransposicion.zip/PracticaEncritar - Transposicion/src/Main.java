import Controlador.CtrlEncriptacion;

public class Main {
    public static void main(String[] args) {
        CtrlEncriptacion n = new CtrlEncriptacion();
    }
}
