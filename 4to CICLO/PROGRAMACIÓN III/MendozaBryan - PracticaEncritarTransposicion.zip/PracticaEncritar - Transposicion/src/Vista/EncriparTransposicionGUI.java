package Vista;

import javax.swing.*;

public class EncriparTransposicionGUI extends JFrame{
    private JPanel contentPane;
    private JTextArea textAFrase;
    public JButton encriptarButton;
    private JTextArea textAMatriz;
    private JTextArea textAFraseEncriptada;
    private JTextField textPalabraClave;
    public JButton desencriptarButton;
    private JLabel labelMatriz;
    private JLabel labelFrase;
    public JButton limpiarButton;
    public JButton recuperarButton;
    public JButton grabarButton;

    public void setLabelMatriz(String palabra){
        labelMatriz.setText("Matriz de "+palabra);
    }

    public void setLabelFrase(String palabra){
        labelFrase.setText("La frase "+palabra+" es:");
    }
    public String  getTextAFrase() {
        return textAFrase.getText();
    }

    public String  getTextPalabraClave() {
        return textPalabraClave.getText();
    }

    public void setTextPalabraClave(String textPalabraClave) {
        this.textPalabraClave.setText(textPalabraClave);
    }

    public void setTextAFrase(String textAFrase) {
        this.textAFrase.setText(textAFrase);
    }

    public String getTextAMatriz() {
        return textAMatriz.getText();
    }

    public void setTextAMatriz(String textAMatriz) {
        this.textAMatriz.setText(textAMatriz);
    }

    public String getTextAFraseEncriptada() {
        return textAFraseEncriptada.getText();
    }

    public void setTextAFraseEncriptada(String textAFraseEncriptada) {
        this.textAFraseEncriptada.setText(textAFraseEncriptada);
    }

    public EncriparTransposicionGUI() {
        setContentPane(contentPane);
        pack();
        setVisible(true);
        setSize(700,700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
