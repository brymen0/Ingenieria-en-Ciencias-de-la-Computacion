import Controlador.CtrlEncriptar;

public class Main {
    public static void main(String[] args) {
        CtrlEncriptar n = new CtrlEncriptar();
    }
}