package Vista;

import javax.swing.*;

public class EncripGUI extends JFrame{
    private JTextField textnameFile;
    private JTextField textW;
    private JTextField textFraseDesencriptada;
    private JTextField textFrase;
    public JButton encriptarButton;
    public JButton desencriptarButton;
    private JPanel panelPrincipal;
    private JTextField textEncriptada;
    public JButton limpiarButton;
    private JTextArea TextFraseEncriptada;

    public String getTextW() {
        return textW.getText();
    }

    public void setTextW(String textW) {
        this.textW.setText(textW);
    }

    public String getTextFraseDesencriptada() {
        return textFraseDesencriptada.getText();
    }

    public void setTextFraseDesencriptada(String  textFraseDesencriptada) {
        this.textFraseDesencriptada.setText(textFraseDesencriptada);
    }

    public String getTextFrase() {
        return textFrase.getText();
    }

    public void setTextFrase(String textFrase) {
        this.textFrase.setText(textFrase);
    }

    public String getTextEncriptada() {
        return textEncriptada.getText();
    }

    public void setTextEncriptada(String textEncriptada) {
        this.textEncriptada.setText(textEncriptada);
    }

    public String getTextFraseEncriptada() {
        return TextFraseEncriptada.getText();
    }

    public void setTextFraseEncriptada(String textFraseEncriptada) {
        TextFraseEncriptada.setText(textFraseEncriptada);
    }

    public EncripGUI(){
        setContentPane(panelPrincipal);
        pack();
        setVisible(true);
        setLocationRelativeTo(null);
        setSize(500,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
