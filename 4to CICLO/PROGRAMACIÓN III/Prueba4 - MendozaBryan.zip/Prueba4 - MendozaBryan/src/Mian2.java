import Controlador.CtrlEncriptar;

import java.util.Stack;

public class Mian2 {
    public static void main(String[] args) {
        String frase = "Hola que tal";
        char []letras = frase.toCharArray();
        String clave = "oculto";
        char[]Sclave = clave.toCharArray();
        //System.out.println(TranformaBinario('a'));
       /* char letra = 'H';
        int num = (int)letra;
        String binario = Integer.toBinaryString(num);
        System.out.println(binario);*/
        String claveBinario = TranformaBinario(Sclave);
        String fraseBinario = TranformaBinario(letras);
        System.out.println(fraseBinario);
        System.out.println(claveBinario);
        String claveCompletada = completaClaveBinario(claveBinario,fraseBinario);
        String fraseEncriptada = realizaXor(claveCompletada,fraseBinario);
        System.out.println(completaClaveBinario(claveBinario,fraseBinario));
        System.out.println(fraseEncriptada);
    }
    public static String TranformaBinario(char[] letras){
        String binario="";
        int ascii;
        int i=0;
        for(char e: letras){
            ascii = (int)letras[i];
            binario += '0'+Integer.toBinaryString(ascii)+' ';
            i++;
        }
        return binario;
    }

    public static String desencripta(String binario){
        int decimal = Integer.parseInt(binario,2);
        char caracter = (char)decimal;
        String fraseDesencriptada = "";
        System.out.println(caracter);
        return fraseDesencriptada;
    }

    public static String completaClaveBinario(String claveBinario, String fraseBinario){
        String claveCompleta = claveBinario;
        int i = 0;

        while(claveCompleta.length() < fraseBinario.length()) {
            claveCompleta += fraseBinario.charAt(i);
            i++;
        }
        return claveCompleta;
    }

    public static String realizaXor(String claveCompletadaBinario, String fraseBinario){
        String fraseEncriptada = "";
        for(int i=0; i<claveCompletadaBinario.length();i++){
            if(fraseBinario.charAt(i) == ' '){
                fraseEncriptada += ' ';
            } else{
                if(claveCompletadaBinario.charAt(i) == '0' && fraseBinario.charAt(i)=='0'){
                    fraseEncriptada += '0';
                }else if(claveCompletadaBinario.charAt(i) == '1' && fraseBinario.charAt(i)=='1'){
                    fraseEncriptada += '0';
                }else{
                    fraseEncriptada += '1';
                }
            }
        }
        return fraseEncriptada;
    }
}
