package Controlador;

import Modelo.Encriptacion;
import Vista.EncripGUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CtrlEncriptar implements ActionListener {
    Encriptacion modelo;
    EncripGUI vista;

    public CtrlEncriptar(){
        modelo = new Encriptacion();
        vista = new EncripGUI();

        vista.encriptarButton.addActionListener(this);
        vista.desencriptarButton.addActionListener(this);
        vista.limpiarButton.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource() == vista.limpiarButton){
            borrarEntradas();
        }
        if(e.getSource() == vista.desencriptarButton){
            /*String frase = vista.getTextFrase();
            char []letras = frase.toCharArray();
            String clave = vista.getTextW();
            char[]Sclave = clave.toCharArray();
            String claveBinario = modelo.TranformaBinario(Sclave);
            String fraseBinario = modelo.TranformaBinario(letras);
            System.out.println(fraseBinario);
            System.out.println(claveBinario);
            String claveCompletada = modelo.completaClaveBinario(claveBinario,fraseBinario);
            String fraseEncriptada = modelo.realizaXor(claveCompletada,fraseBinario);
            // System.out.println(completaClaveBinario(claveBinario,fraseBinario));
            String as = modelo.muestraASCII(fraseEncriptada);
            System.out.println(as);
            vista.setTextFraseDesencriptada(fraseEncriptada);*/
            String fraseBinario = vista.getTextFrase();
            String clave = vista.getTextW();
            char[]Sclave = clave.toCharArray();
            String claveBinario = modelo.TranformaBinario(Sclave);
            System.out.println(fraseBinario);
            System.out.println(claveBinario);
            String claveCompletada = modelo.completaClaveBinario(claveBinario,fraseBinario);
            String fraseEncriptada = modelo.realizaXor(claveCompletada,fraseBinario);
            String fraseDesencriptada = modelo.desencripta(fraseEncriptada);
            // System.out.println(completaClaveBinario(claveBinario,fraseBinario));
            vista.setTextFraseDesencriptada(fraseDesencriptada);
            String ascii = modelo.muestraASCII(fraseEncriptada);

        }

        if(e.getSource() == vista.encriptarButton){
            String frase = vista.getTextFrase();
            char []letras = frase.toCharArray();
            String clave = vista.getTextW();
            char[]Sclave = clave.toCharArray();
            String claveBinario = modelo.TranformaBinario(Sclave);
            String fraseBinario = modelo.TranformaBinario(letras);
            System.out.println(fraseBinario);
            System.out.println(claveBinario);
            String claveCompletada = modelo.completaClaveBinario(claveBinario,fraseBinario);
            String fraseEncriptada = modelo.realizaXor(claveCompletada,fraseBinario);
           // System.out.println(completaClaveBinario(claveBinario,fraseBinario));
            String ascii = modelo.muestraASCII(fraseEncriptada);
            String info = "Frase Encriptada Binario:\n"+fraseEncriptada+"\nASCII: "+ascii;
            vista.setTextFraseEncriptada(info);

        //    System.out.println(ascii);
        }
    }

    public void borrarEntradas(){
        vista.setTextFrase("");
        vista.setTextFraseEncriptada("");
        vista.setTextW("");
        vista.setTextFraseDesencriptada("");
    }
}
