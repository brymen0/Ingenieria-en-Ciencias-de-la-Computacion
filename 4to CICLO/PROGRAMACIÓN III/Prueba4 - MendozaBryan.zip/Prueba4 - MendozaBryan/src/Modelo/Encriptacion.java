package Modelo;

public class Encriptacion {
    public static String TranformaBinario(char[] letras){
        String binario="";
        int ascii;
        int i=0;
        for(char e: letras){
            ascii = (int)letras[i];
            binario += '0'+Integer.toBinaryString(ascii)+' ';
            i++;
        }
        return binario;
    }

    public String muestraASCII(String fraseBinario){
        String ascii="";
        String[]palabras = fraseBinario.split(" ");
        int decimal;
        char caracter;
        for(String e: palabras){
            decimal = Integer.parseInt(e,2);
            caracter = (char)decimal;
            ascii += caracter;
        }
        return ascii;
    }

    public String muestraASCII2(String fraseBinario){
        String ascii="";
        String[]palabras = fraseBinario.split(" ");
        int decimal;
        char caracter;
        for(String e: palabras){
            decimal = Integer.parseInt(e,10);
            caracter = (char)decimal;
            ascii += caracter;
        }
        return ascii;
    }

    public String desencripta(String binario){
        String fraseDesencriptada = "";
        String[]palabrasBinario = binario.split(" ");
        int decimal ;
        char caracter;
        for(String e: palabrasBinario){
            decimal = Integer.parseInt(e,2);
            caracter = (char)decimal;
            fraseDesencriptada += caracter;
            //System.out.println(caracter);
        }
        return fraseDesencriptada;
    }

    public static String completaClaveBinario(String claveBinario, String fraseBinario){
        String claveCompleta = claveBinario;
        int i = 0;

        while(claveCompleta.length() < fraseBinario.length()) {
            claveCompleta += fraseBinario.charAt(i);
            i++;
        }
        return claveCompleta;
    }

    public static String realizaXor(String claveCompletadaBinario, String fraseBinario){
        String fraseEncriptada = "";
        for(int i=0; i<claveCompletadaBinario.length();i++){
            if(fraseBinario.charAt(i) == ' '){
                fraseEncriptada += ' ';
            } else{
                if(claveCompletadaBinario.charAt(i) == '0' && fraseBinario.charAt(i)=='0'){
                    fraseEncriptada += '0';
                }else if(claveCompletadaBinario.charAt(i) == '1' && fraseBinario.charAt(i)=='1'){
                    fraseEncriptada += '0';
                }else{
                    fraseEncriptada += '1';
                }
            }
        }
        return fraseEncriptada;
    }

    public String Descifrar(String mensajeEncriptado, String clave) {
        StringBuilder decryptedMessage = new StringBuilder();

        for (int i = 0; i < mensajeEncriptado.length(); i += 8) {
            String binaryChunk = mensajeEncriptado.substring(i, i + 8);
            int encryptedBinary = Integer.parseInt(binaryChunk, 2);

            char keyChar = clave.charAt(i / 8 % clave.length());

            int keyBinary = keyChar;

            int decryptedBinary = encryptedBinary ^ keyBinary;

            decryptedMessage.append((char) decryptedBinary);
        }

        return decryptedMessage.toString();
    }
}
