package controlador;

import modelo.Laberinto;
import vista.laberintoGUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public class CtrlLaberinto implements ActionListener {
    laberintoGUI vista;
    Laberinto modelo;

    public CtrlLaberinto () {
        vista = new laberintoGUI();
        vista.setLocationRelativeTo(null);
        vista.cargarLaberintoButton.addActionListener(this);
        vista.guardarSolucionButton.addActionListener(this);
        modelo = new Laberinto();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JFileChooser archivo = new JFileChooser("./");
        archivo.setFileSelectionMode(JFileChooser.FILES_ONLY);
        if (e.getSource() == vista.cargarLaberintoButton) {
            try {
                int valor = archivo.showDialog(vista, "Seleccionar");
                if (valor == JFileChooser.APPROVE_OPTION) {
                    FileReader entrada = new FileReader(archivo.getSelectedFile());
                    StringBuilder laberinto = new StringBuilder();
                    int c;
                    while ((c=entrada.read()) != -1) {
                        laberinto.append((char)c);
                    }
                    entrada.close();
                    System.out.println(laberinto);
                    vista.txtLaberintoCargado.setText(laberinto.toString());
                    modelo.ingresarLaberinto(laberinto.toString());
                    vista.txtLaberintoSolucionado.setText(modelo.getSolucion());
                } else {
                    JOptionPane.showMessageDialog(vista, "No se ha podido cargar el archivo", "Error!", JOptionPane.WARNING_MESSAGE);
                }
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }

        if (e.getSource() == vista.guardarSolucionButton)  {
            try {
                int valor = archivo.showDialog(vista, "Seleccionar");
                if (valor == JFileChooser.APPROVE_OPTION) {
                    Files.write(Path.of(archivo.getSelectedFile().getPath()), modelo.getSolucion().getBytes(StandardCharsets.UTF_8));
                } else {
                    JOptionPane.showMessageDialog(vista, "No se ha podido guardar el archivo", "Error!", JOptionPane.WARNING_MESSAGE);
                }
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }
    }
}
