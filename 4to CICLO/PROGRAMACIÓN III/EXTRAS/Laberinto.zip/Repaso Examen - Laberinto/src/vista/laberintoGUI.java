package vista;

import javax.swing.*;
import java.awt.*;

public class laberintoGUI extends JFrame {
    private javax.swing.JPanel panelPrincipal;
    private JPanel panelTitulo;
    private JPanel panelFunciones;
    private JPanel panelBotones;
    public JButton cargarLaberintoButton;
    private JPanel panelLaberintoCargado;
    public JTextArea txtLaberintoCargado;
    private JPanel panelLaberintoSolucionado;
    public JTextArea txtLaberintoSolucionado;
    public JButton guardarSolucionButton;

    public laberintoGUI() {
        setContentPane(panelPrincipal);
        pack();
        setVisible(true);
        setSize(500, 500);
        setTitle("Laberinto");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        txtLaberintoCargado.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        txtLaberintoSolucionado.setBorder(BorderFactory.createLineBorder(Color.BLACK));
    }
}
