import controlador.CtrlLaberinto;

public class Main {
    public static void main(String[] args) {
        CtrlLaberinto laberinto = new CtrlLaberinto();
    }
}