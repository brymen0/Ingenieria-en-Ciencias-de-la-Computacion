package modelo;

import java.util.Arrays;

public class Laberinto {

    private String solucion;

    public Laberinto () {

    }

    public void ingresarLaberinto (String texto) {
        String [] filas = texto.split("\n");
        int nFilas = filas.length;
        int nColumnas = filas[0].length()-1;
        char [][] laberinto = new char[nFilas][nColumnas];
        for (int i=0; i<nFilas; i++) {
            for (int j=0; j<nColumnas; j++) {
                laberinto [i][j] = filas[i].charAt(j);
            }
        }
        resolverLaberinto(laberinto, nFilas, nColumnas);
    }

    private void resolverLaberinto (char [][] laberinto, int nFilas, int nColumnas) {
        StringBuilder solucion = new StringBuilder();
        //se obtiene la posicion inicial
        int [] posicionInicial = new int[2];
        for (int i=0; i<nFilas; i++) {
            for (int j=0; j<nColumnas; j++) {
                if (laberinto[i][j] == 's') {
                    posicionInicial[0] = i;
                    posicionInicial[1] = j;
                }
            }
        }

        // el metodo para resolver el laberinto sera pegarnos a una pared y recorrer hasta llegar a la meta
        int [] posicion = new int[2];
        posicion = posicionInicial;
        //el bucle se repetira mientras la posicion no este en f
        while (laberinto[posicion[0]][posicion[1]]!='f') {
            //primero intenta bajar todo lo que puede
            if (laberinto[posicion[0]][posicion[1]] == 's') {
                while (laberinto[posicion[0]+1][posicion[1]]!='#') {
                    if (laberinto[posicion[0]+1][posicion[1]]=='f') {
                        for (int i=0; i<nFilas; i++) {
                            for (int j=0; j<nColumnas; j++) {
                                solucion.append(laberinto[i][j]);
                            }
                            solucion.append("\n");
                        }
                        this.solucion = solucion.deleteCharAt(solucion.length()-1).toString();
                        return;
                    }
                    posicion [0] = (posicion[0]+1);
                    laberinto[posicion[0]][posicion[1]] = '.';
                    for (int i=0; i<nFilas; i++) {
                        for (int j=0; j<nColumnas; j++) {
                            System.out.print(laberinto[i][j]);
                        }
                        System.out.println();
                    }
                    System.out.println("\n\n");
                }
            }
            //prioriza ir derecha-abajo para rodear las paredes del laberinto
            while (laberinto[posicion[0]][posicion[1]+1]!='#' || laberinto[posicion[0]+1][posicion[1]]!='#') {
                if (laberinto[posicion[0]+1][posicion[1]]!=' ' && laberinto[posicion[0]][posicion[1]+1]==' ') {
                    if (laberinto[posicion[0]+1][posicion[1]]=='f') {
                        for (int i=0; i<nFilas; i++) {
                            for (int j=0; j<nColumnas; j++) {
                                solucion.append(laberinto[i][j]);
                            }
                            solucion.append("\n");
                        }
                        this.solucion = solucion.deleteCharAt(solucion.length()-1).toString();
                        return;
                    }
                    posicion [1] = (posicion[1]+1);
                    laberinto[posicion[0]][posicion[1]] = '.';
                    for (int i=0; i<nFilas; i++) {
                        for (int j=0; j<nColumnas; j++) {
                            System.out.print(laberinto[i][j]);
                        }
                        System.out.println();
                    }
                    System.out.println("\n\n");
                } else {
                    if (laberinto[posicion[0]][posicion[1]+1]=='f') {
                        for (int i=0; i<nFilas; i++) {
                            for (int j=0; j<nColumnas; j++) {
                                solucion.append(laberinto[i][j]);
                            }
                            solucion.append("\n");
                        }
                        this.solucion = solucion.deleteCharAt(solucion.length()-1).toString();
                        return;
                    }
                    if (laberinto[posicion[0]+1][posicion[1]]==' ') {
                        posicion [0] = (posicion[0]+1);
                        laberinto[posicion[0]][posicion[1]] = '.';
                        for (int i=0; i<nFilas; i++) {
                            for (int j=0; j<nColumnas; j++) {
                                System.out.print(laberinto[i][j]);
                            }
                            System.out.println();
                        }
                        System.out.println("\n\n");
                    }
                }
                if (laberinto[posicion[0]+1][posicion[1]]=='.') {
                    posicion [0] = (posicion[0]+1);
                    laberinto[posicion[0]][posicion[1]] = '.';
                    for (int i=0; i<nFilas; i++) {
                        for (int j=0; j<nColumnas; j++) {
                            System.out.print(laberinto[i][j]);
                        }
                        System.out.println();
                    }
                    System.out.println("\n\n");
                } else if (laberinto[posicion[0]][posicion[1]+1]=='.') {
                    posicion[1] = (posicion[1] + 1);
                    laberinto[posicion[0]][posicion[1]] = '.';
                    for (int i = 0; i < nFilas; i++) {
                        for (int j = 0; j < nColumnas; j++) {
                            System.out.print(laberinto[i][j]);
                        }
                        System.out.println();
                    }
                    System.out.println("\n\n");
                }
            }

            //si se esta volviendo y se topa con una esquina
            if (laberinto[posicion[0]][posicion[1]-1]=='.' && laberinto[posicion[0]-1][posicion[1]]=='.') {
                while ((laberinto[posicion[0]-1][posicion[1]]=='.' && laberinto[posicion[0]][posicion[1]+1]=='#')) {
                    posicion[0] = (posicion[0] - 1);
                    laberinto[posicion[0]][posicion[1]] = '.';
                    for (int i = 0; i < nFilas; i++) {
                        for (int j = 0; j < nColumnas; j++) {
                            System.out.print(laberinto[i][j]);
                        }
                        System.out.println();
                    }
                    System.out.println("\n\n");
                }
            }

            //si no puede ir a la derecha o abajo prioriza ir izquierda-arriba para seguir rodeando
            while (laberinto[posicion[0]][posicion[1]-1]==' ' || laberinto[posicion[0]-1][posicion[1]]==' ') {
                //avanza arriba o izquirda dependiendo de donde viene
                System.out.println("entra aca izquierda-arriba");
                if (laberinto[posicion[0]-1][posicion[1]]=='.' && laberinto[posicion[0]][posicion[1]-1]==' ') {
                    posicion [1] = (posicion[1]-1);
                    laberinto[posicion[0]][posicion[1]] = '.';
                    for (int i=0; i<nFilas; i++) {
                        for (int j=0; j<nColumnas; j++) {
                            System.out.print(laberinto[i][j]);
                        }
                        System.out.println();
                    }
                    System.out.println("\n\n");
                } else if (laberinto[posicion[0]][posicion[1]-1]=='.' && laberinto[posicion[0]][posicion[1]+1]!='.') {
                    posicion [0] = (posicion[0]-1);
                    laberinto[posicion[0]][posicion[1]] = '.';
                    for (int i=0; i<nFilas; i++) {
                        for (int j=0; j<nColumnas; j++) {
                            System.out.print(laberinto[i][j]);
                        }
                        System.out.println();
                    }
                    System.out.println("\n\n");
                }

                if (laberinto[posicion[0]-1][posicion[1]]!=' ' && laberinto[posicion[0]][posicion[1]-1]==' ') {
                    posicion [1] = (posicion[1]-1);
                    laberinto[posicion[0]][posicion[1]] = '.';
                    for (int i=0; i<nFilas; i++) {
                        for (int j=0; j<nColumnas; j++) {
                            System.out.print(laberinto[i][j]);
                        }
                        System.out.println();
                    }
                    System.out.println("\n\n");
                }
                else {
                    if (laberinto[posicion[0]-1][posicion[1]]==' ') {
                        posicion [0] = (posicion[0]-1);
                        laberinto[posicion[0]][posicion[1]] = '.';
                        for (int i=0; i<nFilas; i++) {
                            for (int j=0; j<nColumnas; j++) {
                                System.out.print(laberinto[i][j]);
                            }
                            System.out.println();
                        }
                        System.out.println("\n\n");
                    }
                }
                if (laberinto[posicion[0]-1][posicion[1]]=='f' || laberinto[posicion[0]][posicion[1]-1]=='f') {
                    for (int i=0; i<nFilas; i++) {
                        for (int j=0; j<nColumnas; j++) {
                            solucion.append(laberinto[i][j]);
                        }
                        solucion.append("\n");
                    }
                    this.solucion = solucion.deleteCharAt(solucion.length()-1).toString();
                    return;
                }
            }
        }
    }

    public String getSolucion() {
        return solucion;
    }
}