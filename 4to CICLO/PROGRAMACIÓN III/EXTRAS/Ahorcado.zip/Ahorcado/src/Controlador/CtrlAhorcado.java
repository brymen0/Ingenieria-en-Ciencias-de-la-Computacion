package Controlador;

import Modelo.ModeloAhorcado;
import Vista.VistaAhorcado;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CtrlAhorcado implements ActionListener {

    private VistaAhorcado vistaAhorcado;
    private ModeloAhorcado modeloAhorcado;

    public CtrlAhorcado(VistaAhorcado vistaAhorcado) {
        this.vistaAhorcado = vistaAhorcado;
        this.modeloAhorcado = new ModeloAhorcado();
        setListeners();
        iniciarJuego();
    }

    private void setListeners() {
        vistaAhorcado.buttonComprobar.addActionListener(this);
        vistaAhorcado.buttonCancel.addActionListener(this);
    }

    private void iniciarJuego() {
        // Puedes agregar lógica de inicio del juego aquí si es necesario
        actualizarVista();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!modeloAhorcado.juegoTerminado()) {
            if (e.getSource() == vistaAhorcado.buttonComprobar) {
                String letraIngresada = vistaAhorcado.getTxtLetra();

                if (letraIngresada.length() == 1 && Character.isLetter(letraIngresada.charAt(0))) {
                    char letra = letraIngresada.charAt(0);

                    if (modeloAhorcado.intento(letra)) {
                        // Acierto
                        JOptionPane.showMessageDialog(null, "¡Acierto! La letra está en la palabra.");
                    } else {
                        // Error
                        JOptionPane.showMessageDialog(null, "¡Error! La letra no está en la palabra.");
                    }

                    vistaAhorcado.setTxtLetra("");
                    actualizarVista();
                } else {
                    JOptionPane.showMessageDialog(null, "Ingrese una letra válida.");
                }
            } else if (e.getSource() == vistaAhorcado.buttonCancel) {
                System.exit(0);
            }
        } else {
            // Juego terminado
            if (modeloAhorcado.palabraDescubierta()) {
                // Ganaste
                JOptionPane.showMessageDialog(null, "¡Felicidades! Ganaste la partida. La palabra es: " + modeloAhorcado.getPalabraSecreta());
            } else {
                // Perdiste
                JOptionPane.showMessageDialog(null, "¡Oh no! Perdiste la partida. La palabra era: " + modeloAhorcado.getPalabraSecreta());
            }
            System.exit(0);
        }
    }

    private void actualizarVista() {
        vistaAhorcado.setTxtPalabra(modeloAhorcado.getPalabraGuiones());
        vistaAhorcado.setTxtPesonaArea(obtenerRepresentacionPersonaAhorcada(modeloAhorcado.getIntentosRestantes()));
    }

    private String obtenerRepresentacionPersonaAhorcada(int intentosRestantes) {
        switch (intentosRestantes) {
            case 8:
                return "_________\n|              |\n|              \n|               \n|               \n|               \n|";
            case 7:
                return "_________\n|              |\n|              O\n|               \n|               \n|               \n|";
            case 6:
                return "_________\n|              |\n|              O\n|              |\n|               \n|               \n|";
            case 5:
                return "_________\n|              |\n|              O\n|             /|\n|               \n|               \n|";
            case 4:
                return "_________\n|              |\n|              O\n|             /|\\\n|               \n|               \n|";
            case 3:
                return "_________\n|              |\n|              O\n|             /|\\\n|             /\n|               \n|";
            case 2:
                return "_________\n|              |\n|              O\n|             /|\\\n|             / \\\n|               \n|";
            case 1:
                return "_________\n|              |\n|              O\n|             /|\\\n|             / \\\n|               \n|\n¡Estás a punto de ser ahorcado!";
            case 0:
                return "_________\n|              |\n|              L\n|             O\n|             /|\\\n|             / \\\n|\n¡Has sido ahorcado!";
            default:
                return "_________\n|              |\n|              L\n|              \n|               \n|               \n|";
        }
    }



}
