package Modelo;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class ModeloAhorcado {

    private String palabraSecreta;
    private Set<Character> letrasAdivinadas;
    private Set<Character> letrasIncorrectas;
    private int intentosRestantes;

    public ModeloAhorcado() {
        letrasAdivinadas = new HashSet<>();
        letrasIncorrectas = new HashSet<>();
        intentosRestantes = 8; // Número máximo de intentos
        palabraSecreta = obtenerPalabraSecreta();
    }

    private String obtenerPalabraSecreta() {
        String[] palabras = {"HANGMAN", "JAVA", "PROGRAMMING"};
        Random random = new Random();
        return palabras[random.nextInt(palabras.length)];
    }

    public String getPalabraGuiones() {
        StringBuilder palabraGuiones = new StringBuilder();

        for (char letra : palabraSecreta.toCharArray()) {
            if (letrasAdivinadas.contains(letra) || !Character.isLetter(letra)) {
                palabraGuiones.append(letra);
            } else {
                palabraGuiones.append("_");
            }

            palabraGuiones.append(" ");
        }

        return palabraGuiones.toString().trim();
    }



    public boolean intento(char letra) {
        letra = Character.toUpperCase(letra);

        if (letrasAdivinadas.contains(letra) || letrasIncorrectas.contains(letra)) {
            return false; // La letra ya se ha intentado antes
        }

        if (palabraSecreta.contains(String.valueOf(letra))) {
            letrasAdivinadas.add(letra);
            return true; // Acierto
        } else {
            letrasIncorrectas.add(letra);
            intentosRestantes--;
            return false; // Error
        }
    }

    public boolean juegoTerminado() {
        return intentosRestantes == 0 || palabraDescubierta();
    }

    public boolean palabraDescubierta() {
        for (char letra : palabraSecreta.toCharArray()) {
            if (!letrasAdivinadas.contains(letra)) {
                return false;
            }
        }
        return true;
    }

    public Set<Character> getLetrasAdivinadas() {
        return letrasAdivinadas;
    }

    public Set<Character> getLetrasIncorrectas() {
        return letrasIncorrectas;
    }

    public int getIntentosRestantes() {
        return intentosRestantes;
    }

    public String getPalabraSecreta() {
        return palabraSecreta;
    }

}
