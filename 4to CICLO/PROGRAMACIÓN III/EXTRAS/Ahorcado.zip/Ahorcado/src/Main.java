import Controlador.CtrlAhorcado;
import Vista.VistaAhorcado;

public class Main {
    public static void main(String[] args) {

        VistaAhorcado vistaAhorcado = new VistaAhorcado();
        CtrlAhorcado ctrlAhorcado = new CtrlAhorcado(vistaAhorcado);

    }
}