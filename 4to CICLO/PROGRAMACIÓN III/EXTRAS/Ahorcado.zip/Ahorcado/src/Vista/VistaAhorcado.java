package Vista;

import javax.swing.*;

public class VistaAhorcado extends JFrame {
    private JPanel contentPane;
    public JButton buttonComprobar;
    public JButton buttonCancel;
    private JTextField txtPalabra;
    private JTextArea txtPesonaArea;
    private JTextField txtLetra;


    public VistaAhorcado(){

        setTitle("Ahorcado");
        setVisible(true);
        pack();
        setContentPane(contentPane);
        setSize(650,500);
        setLocationRelativeTo(null); // Para centrar la ventana en la pantalla
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }


    public String getTxtPalabra() {
        return txtPalabra.getText();
    }

    public void setTxtPalabra(String txtPalabra) {
        this.txtPalabra.setText(txtPalabra);
    }

    public String getTxtPesonaArea() {
        return txtPesonaArea.getText();
    }

    public void setTxtPesonaArea(String txtPesonaArea) {
        this.txtPesonaArea.setText(txtPesonaArea);
    }

    public String getTxtLetra() {
        return txtLetra.getText();
    }

    public void setTxtLetra(String txtLetra) {
        this.txtLetra.setText(txtLetra);
    }
}
