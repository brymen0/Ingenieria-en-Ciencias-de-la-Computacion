package Vista;

import javax.swing.*;

public class PideArchivosGUI extends JFrame {
    private JPanel contentPane;
    public JButton comprimirButton;
    public JButton descomprimirButton;
    private JTextArea textInfo;

    public PideArchivosGUI() {
        pack();
        setVisible(true);
        setContentPane(contentPane);
        setSize(400,250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public String getTextInfo() {
        return textInfo.getText();
    }

    public void setTextInfo(String textInfo) {
        this.textInfo.setText(textInfo);
    }
}
