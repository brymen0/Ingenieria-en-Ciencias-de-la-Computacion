package Controlador;

import Modelo.ArbolHuffman;
import Vista.PideArchivosGUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CtrlHuffman implements ActionListener {
    ArbolHuffman modelo;
    PideArchivosGUI vista;

    public CtrlHuffman(){
        this.modelo = new ArbolHuffman();
        this.vista = new PideArchivosGUI();
        this.vista.descomprimirButton.addActionListener(this);
        this.vista.comprimirButton.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JFileChooser archi = new JFileChooser("./"); //para seleccionar el nombre del archivo en grabae y recuperar
        archi.setFileSelectionMode(JFileChooser.FILES_ONLY);
        if(e.getSource() == vista.comprimirButton){
            int returnVal = archi.showDialog(vista,"Comprimir");
            if(returnVal == JFileChooser.APPROVE_OPTION){ //si  no se cancela la selección del archivo
                modelo.ComprimeTexto(archi.getSelectedFile().getAbsoluteFile().getPath(),vista.getTextInfo());
            }
            vista.setTextInfo("");
        }
        if(e.getSource() == vista.descomprimirButton){
            int returnVal = archi.showDialog(vista,"Seleccionar");
            if(returnVal == JFileChooser.APPROVE_OPTION){
                vista.setTextInfo(modelo.DescomprimeTexto(archi.getSelectedFile().getAbsoluteFile().getPath()));
            }
        }
    }

}
