import Controlador.CtrlHuffman;

public class Main {
    public static void main(String[]args){
        CtrlHuffman n = new CtrlHuffman();
    }
}
