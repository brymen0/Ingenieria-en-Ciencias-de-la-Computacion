package Vista;

import javax.swing.*;

public class GraficasGUI extends JFrame {
    private JPanel contentPane;
    public JComboBox cmbGrafico;
    private JRadioButton a3DRadioButton;
    private JRadioButton a2DRadioButton;
    public JPanel DrawnPanel;
    public JButton graficarButton;
    public JRadioButton horizontalRadioButton;
    public JRadioButton verticalRadioButton;

    public String getOrientacion(){
       if(horizontalRadioButton.isSelected())
        return "Horizontal";
       else return "Vertical";
    }
    public void deshabilitarButtonsOrientacion(){
        horizontalRadioButton.setEnabled(false);
        verticalRadioButton.setEnabled(false);
    }

    public void habilitarButtonsOrientacion(){
        horizontalRadioButton.setEnabled(true);
        verticalRadioButton.setEnabled(true);
    }
    public String getGrafico(){
        return (String) cmbGrafico.getSelectedItem();
    }

    public boolean selectButton3D(){
        return a3DRadioButton.isSelected();
    }
    public GraficasGUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(contentPane);
        pack();
        setVisible(true);
        setBounds(350,100,500,500);
    }

}
