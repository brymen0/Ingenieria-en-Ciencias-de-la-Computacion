import Controlador.CtrlGraficar;

public class Main {
    public static void main(String []args){
        //Autor: Bryan Mendoza
        CtrlGraficar n = new CtrlGraficar();
    }
}
