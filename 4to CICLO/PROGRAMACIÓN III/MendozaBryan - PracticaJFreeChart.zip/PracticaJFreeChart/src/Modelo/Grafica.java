package Modelo;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.general.DefaultPieDataset;

public class Grafica {

    public ChartPanel graficaLineal2D(String orientacion){
        DefaultCategoryDataset dtsc = new DefaultCategoryDataset();
        JFreeChart ch;
        dtsc.addValue(10, "Hombres", "Grupo 1");
        dtsc.addValue(20, "Mujeres", "Grupo 1");
        dtsc.addValue(15, "Hombres", "Grupo 2");
        dtsc.addValue(25, "Mujeres", "Grupo 2");
        dtsc.addValue(9, "Mujeres", "Grupo 3");
        dtsc.addValue(21, "Hombres", "Grupo 3");
        dtsc.addValue(7, "Mujeres", "Grupo 3");
        if(orientacion.equals("Horizontal")) {
            ch = ChartFactory.createLineChart("Grafica Lineal 2D","Grupo","Cantidad",dtsc,PlotOrientation.HORIZONTAL,true,true,false);
        } else{
            ch = ChartFactory.createLineChart("Grafica Lineal 2D","Grupo","Cantidad",dtsc,PlotOrientation.VERTICAL,true,true,false);
        }
        ChartPanel cp = new ChartPanel(ch);
        return cp;
    }

    public ChartPanel graficaLineal3D(String orientacion){
        DefaultCategoryDataset dtsc = new DefaultCategoryDataset();
        JFreeChart ch;
        dtsc.addValue(10, "Hombres", "Grupo 1");
        dtsc.addValue(20, "Mujeres", "Grupo 1");
        dtsc.addValue(15, "Hombres", "Grupo 2");
        dtsc.addValue(25, "Mujeres", "Grupo 2");
        dtsc.addValue(9, "Mujeres", "Grupo 3");
        dtsc.addValue(21, "Hombres", "Grupo 3");
        dtsc.addValue(7, "Mujeres", "Grupo 3");
        if(orientacion.equals("Horizontal")) {
            ch = ChartFactory.createLineChart3D("Grafica Lineal 3D","Grupo","Cantidad",dtsc,PlotOrientation.HORIZONTAL,true,true,false);
        } else{
            ch = ChartFactory.createLineChart3D("Grafica Lineal 3D","Grupo","Cantidad",dtsc,PlotOrientation.VERTICAL,true,true,false);
        }
        ChartPanel cp = new ChartPanel(ch);
        return cp;
    }
    public ChartPanel graficaBarras3D(String orientacion){
        DefaultCategoryDataset dtsc = new DefaultCategoryDataset();
        JFreeChart ch;
        dtsc.addValue(10, "Hombres", "Grupo 1");
        dtsc.addValue(20, "Mujeres", "Grupo 1");
        dtsc.addValue(15, "Hombres", "Grupo 2");
        dtsc.addValue(25, "Mujeres", "Grupo 2");
        dtsc.addValue(9, "Mujeres", "Grupo 3");
        dtsc.addValue(21, "Hombres", "Grupo 3");
        dtsc.addValue(7, "Mujeres", "Grupo 3");
        if(orientacion.equals("Horizontal")) {
            ch = ChartFactory.createBarChart3D("Grafica de barras 3D", "Grupo", "Cantidad", dtsc,PlotOrientation.HORIZONTAL, true, true, false);
        } else{
            ch = ChartFactory.createBarChart3D("Grafica de barras 3D", "Grupo", "Cantidad", dtsc,PlotOrientation.VERTICAL, true, true, false);
        }
        ChartPanel cp = new ChartPanel(ch);
        return cp;
    }

    public ChartPanel graficaBarras2D(String orientacion){
        DefaultCategoryDataset dtsc = new DefaultCategoryDataset();
        JFreeChart ch;
        dtsc.addValue(10, "Hombres", "Grupo 1");
        dtsc.addValue(20, "Mujeres", "Grupo 1");
        dtsc.addValue(15, "Hombres", "Grupo 2");
        dtsc.addValue(25, "Mujeres", "Grupo 3");
        dtsc.addValue(10, "Hombres", "Grupo 1");
        dtsc.addValue(20, "Mujeres", "Grupo 5");
        dtsc.addValue(15, "Hombres", "Grupo 4");
        dtsc.addValue(25, "Mujeres", "Grupo 2");
        if(orientacion.equals("Horizontal")) {
            ch = ChartFactory.createBarChart("Grafica de barras 3D", "Grupo", "Cantidad", dtsc,PlotOrientation.HORIZONTAL, true, true, false);
        } else{
            ch = ChartFactory.createBarChart("Grafica de barras 3D", "Grupo", "Cantidad", dtsc,PlotOrientation.VERTICAL, true, true, false);
        }
        ChartPanel cp = new ChartPanel(ch);
        return cp;
    }

    public ChartPanel graficaCircular2D(){
        DefaultPieDataset dtsc = new DefaultPieDataset();
        dtsc.setValue("Bajo", 7);
        dtsc.setValue("Medio", 15);
        dtsc.setValue("Medio - Bajo", 25);
        dtsc.setValue("Medio - Alto", 30);
        dtsc.setValue("Alto", 23);
        JFreeChart ch = ChartFactory.createPieChart("Grafica Circular 2D", dtsc,true, true, false);
        ChartPanel cp = new ChartPanel(ch);
        //add(cp);
      //  cp.setBounds(500,40,500,400);
        return cp;
    }

    public ChartPanel graficaArea() {
        DefaultPieDataset dtsc = new DefaultPieDataset();
        dtsc.setValue("Hombres", 45);
        dtsc.setValue("Mujeres", 40);
        dtsc.setValue("No definido", 5);

        // Utilizando un conjunto de datos de categoría
        CategoryDataset categoryDataset = DatasetUtilities.createCategoryDataset(
                "Sexo", dtsc);

        JFreeChart ch = ChartFactory.createAreaChart("Grafica de Área", "Sexo", "Cantidad", categoryDataset, PlotOrientation.VERTICAL, true, true, false);
        ChartPanel cp = new ChartPanel(ch);
        return cp;
    }

    public ChartPanel graficaCircular3D(){
        DefaultPieDataset dtsc = new DefaultPieDataset();
        dtsc.setValue("Hombres", 45);
        dtsc.setValue("Mujeres", 50);
        dtsc.setValue("No definido", 5);
        JFreeChart ch = ChartFactory.createPieChart3D("Grafica Circular 3D", dtsc,true, true, false);
        ChartPanel cp = new ChartPanel(ch);
        return cp;
    }
}
