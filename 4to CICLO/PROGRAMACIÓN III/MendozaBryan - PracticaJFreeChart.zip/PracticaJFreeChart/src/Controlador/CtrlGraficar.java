package Controlador;

import Modelo.Grafica;
import Vista.GraficasGUI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CtrlGraficar implements ActionListener {
    GraficasGUI vista;
    Grafica modelo;
    public CtrlGraficar(){
        vista = new GraficasGUI();
        modelo = new Grafica();

        vista.graficarButton.addActionListener(this);
        vista.horizontalRadioButton.addActionListener(this);
        vista.verticalRadioButton.addActionListener(this);
        vista.cmbGrafico.addActionListener(this);
    }

    public void limpiar(){
        vista.DrawnPanel.removeAll();
        vista.DrawnPanel.revalidate();
        vista.DrawnPanel.repaint();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == vista.cmbGrafico){
            if(!vista.getGrafico().equals("Barras") && !vista.getGrafico().equals("Lineal")) vista.deshabilitarButtonsOrientacion();
            else vista.habilitarButtonsOrientacion();
        }
        if(e.getSource() == vista.graficarButton){
            limpiar();
            vista.DrawnPanel.setLayout(new BorderLayout());
            if(vista.selectButton3D() && vista.getGrafico().equals("Barras")){
                vista.DrawnPanel.add(modelo.graficaBarras3D(vista.getOrientacion()));
            } else if(!vista.selectButton3D() && vista.getGrafico().equals("Barras")){
                vista.DrawnPanel.add(modelo.graficaBarras2D(vista.getOrientacion()));
            } else if(vista.selectButton3D() && vista.getGrafico().equals("Circular")){
                vista.DrawnPanel.add(modelo.graficaCircular3D());
            } else if(!vista.selectButton3D() && vista.getGrafico().equals("Circular")){
                vista.DrawnPanel.add(modelo.graficaCircular2D());
            } else if(vista.getGrafico().equals("Area")){
                vista.DrawnPanel.add(modelo.graficaArea());
            } else if(vista.selectButton3D() && vista.getGrafico().equals("Lineal")){
                vista.DrawnPanel.add(modelo.graficaLineal3D(vista.getOrientacion()));
            } else {
                vista.DrawnPanel.add(modelo.graficaLineal2D(vista.getOrientacion()));
            }
        }
    }
}
