import numpy as np

class HopfieldNetwork():
    # Crear matriz de pesos con regla de Hebb
    def calculate_w(self, img: np.ndarray) -> np.ndarray:
        """
        Calcula la matriz de pesos usando la regla de Hebb.

        Parámetros:
        - img (np.ndarray): Vector unidimensional que representa la imagen.

        Retorna:
        - np.ndarray: Matriz cuadrada de tamaño `(n, n)` con los pesos calculados.
        """
        return np.outer(img, img)  # Producto externo de la imagen consigo misma es decir vT * v
  
    def rebuild(self, model: np.ndarray, state: np.ndarray, max_iterations: int = 100) -> np.ndarray:
        """
        Reconstruye una imagen utilizando la red Hopfield.

        Parámetros:
        - state (np.ndarray): Vector unidimensional del estado inicial (imagen con ruido).
        - max_iterations (int): Número máximo de iteraciones para la reconstrucción.

        Retorna:
        - np.ndarray: Vector unidimensional reconstruido.
        """
        w: np.ndarray = model

        for _ in range(max_iterations):
            # Actualización en paralelo de todas las neuronas
            state = np.sign(np.dot(w, state))  # Aplicar la función de activación simultáneamente a todas las neuronas
        return state
    

    def train(self, training: list[np.ndarray]) -> np.ndarray:
        """
        Entrena la red de Hopfield y devuelve la matriz de pesos.

        Parámetros:
        - training (list): Lista de vectores unidimensionales de imágenes (entrenamiento).

        Retorna:
        - np.ndarray: Matriz de pesos acumulada.
        """
        n: int = training[0].size  # Número total de píxeles

        w: np.ndarray = np.zeros((n, n))  # Inicializar matriz de pesos en ceros
        for img in training:
            # Asegurarse de que las imágenes estén normalizadas en [-1, 1]
            img = np.where(img == 0, -1, img)  # Convertir todos los 0 a -1
            w += self.calculate_w(img)  # Sumar pesos para cada imagen
        np.fill_diagonal(w, 0)  # Evitar auto-conexiones (pesos en la diagonal)

        return w
