import os
import glob
import numpy as np
import matplotlib.pyplot as plt
from ImagesUtilities import ImagesUtilities
from HopfieldNetwork import HopfieldNetwork

#Instalar algunas librerias
#pip install pillow
#pip install numpy
#pip install matplotlib
#pip install opencv-python


size:int = 64
imagesUtilities:ImagesUtilities = ImagesUtilities()
hopfieldNetwork:HopfieldNetwork = HopfieldNetwork()

#Modicar placa introducir ruido
img_test:np.ndarray = imagesUtilities.modify_img(path= './assets/plate_1.png')
#Proceso de segmentacion
img_test_segmentation: list[np.ndarray] = imagesUtilities.image_segmentation(img= img_test)

#Visualizar como se esta segmentando la imagen
for i, char in enumerate(img_test_segmentation):
    plt.imshow(char, cmap='gray')
    plt.title(f'Caracter {i+1}')
    plt.axis('off')
    plt.show()

#Procesar los segmentos a formato utilizado
test_image_segmentation_format: list[np.ndarray] = [imagesUtilities.process_img(img= segment, size= size) for segment in img_test_segmentation]

#Tener los paths de digits y letters en una lista
digits_paths = glob.glob(os.path.join('./digits', "*.png"))
letters_paths = glob.glob(os.path.join('./letters', "*.png"))

#Obtener lista de arreglos unidimensionales de digitos y letras
digits: list[np.ndarray] = [imagesUtilities.load_img(path= path, size= size) for path in digits_paths]
letters: list[np.ndarray] = [imagesUtilities.load_img(path= path, size= size) for path in letters_paths]

#Entrenar cada red de Hopfield
digits_net = hopfieldNetwork.train(training= digits)
letters_net = hopfieldNetwork.train(training= letters)

#Reconstruir segmentos
#Reconstruccion de letras
letters_rebuild: list[np.ndarray] = [hopfieldNetwork.rebuild(model= letters_net, state= segment) for segment in test_image_segmentation_format[:3]]
#Reconstruccion de digitos
digits_rebuild: list[np.ndarray] = [hopfieldNetwork.rebuild(model= digits_net, state= segment) for segment in test_image_segmentation_format[4:]]
#Guion
dash:list [np.ndarray] = [test_image_segmentation_format[3]]

#Mostrar letras
for letter in letters_rebuild:
    imagesUtilities.show_img_by_array(img_array= letter)

#Mostrar digitos
for digit in digits_rebuild:
    imagesUtilities.show_img_by_array(img_array= digit)