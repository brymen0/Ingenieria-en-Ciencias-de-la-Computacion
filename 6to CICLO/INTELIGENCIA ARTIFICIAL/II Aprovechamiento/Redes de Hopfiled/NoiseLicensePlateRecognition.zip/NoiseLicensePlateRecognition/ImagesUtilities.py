import cv2
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt

class ImagesUtilities():
    # Cargar y procesar imágenes en una matriz binaria (-1, 1)
    def load_img(self, path: str, size:int = 64) -> np.ndarray:
        """
        Carga una imagen desde la ruta especificada, la convierte a blanco y negro,
        y devuelve un vector unidimensional con valores -1 y 1.
        
        Parámetros:
        - path (str): Ruta de la imagen a cargar.
        - size (int): Dimensión del lado de la imagen cuadrada.

        Retorna:
        - np.ndarray: Vector unidimensional de tamaño `side^2` con valores -1 y 1.
        """
        img = Image.open(path)
        img = img.resize((size, size))  # Redefinir tamaño de la imagen
        img = img.convert(mode='1')    # Convertir a blanco y negro
        img = 2 * np.array(img, int) - 1  # Escalar la matriz a valores -1 y 1
        return img.flatten()  # Convertir la matriz en un vector unidimensional(aplanado)

    def process_img(self, img: np.ndarray, size:int = 64) -> np.ndarray:
        """
        Carga una imagen desde la ruta especificada, la convierte a blanco y negro,
        y devuelve un vector unidimensional con valores -1 y 1.
        
        Parámetros:
        - path (str): Ruta de la imagen a cargar.
        - size (int): Dimensión del lado de la imagen cuadrada.

        Retorna:
        - np.ndarray: Vector unidimensional de tamaño `side^2` con valores -1 y 1.
        """
        img = Image.fromarray(img)
        img = img.resize((size, size))  # Redefinir tamaño de la imagen
        img = img.convert(mode='1')    # Convertir a blanco y negro
        img = 2 * np.array(img, int) - 1  # Escalar la matriz a valores -1 y 1
        return img.flatten()  # Convertir la matriz en un vector unidimensional(aplanado)

    # Mostrar una imagen a partir de un arreglo unidimensional
    def show_img_by_array(self, img_array: np.ndarray) -> None:
        """
        Muestra una imagen a partir de un vector unidimensional.

        Parámetros:
        - img_array (np.ndarray): Vector unidimensional que representa la imagen.

        Retorna:
        - None
        """
        side = int(np.sqrt(img_array.shape[0]))  # Calcular la dimensión del lado
        img_array = img_array.reshape((side, side))  # Convertir el vector en matriz
        plt.imshow(img_array, cmap='gray')  # Mostrar la imagen en escala de grises
        plt.axis('off')  # Ocultar ejes
        plt.show()


    # Introducir ruido en una imagen
    def modify_img(self, path: str) -> np.ndarray:
        """
        Introduce ruido en una imagen, cambiando de signo un porcentaje de píxeles.

        Parámetros:
        - img (np.ndarray): Vector unidimensional que representa la imagen.
        - noise_ratio (float): Proporción de píxeles a alterar (entre 0 y 1).

        Retorna:
        - np.ndarray: Vector unidimensional con ruido añadido.
        """
        image = cv2.imread(path)
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        # Introduce ruido gaussiano
        mean = 0
        stddev = 25  # Ajusta la desviación estándar según el nivel de ruido deseado
        noise = np.random.normal(mean, stddev, gray_image.shape).astype(np.int16)
        
        # Agrega el ruido a la imagen
        noisy_img = gray_image.astype(np.int16) + noise

        # Asegúrate de que los valores estén dentro del rango [0, 255]
        noisy_img = np.clip(noisy_img, 0, 255).astype(np.uint8)

        return noisy_img
    
    def sort_contours(self, cnts):
        """
        Ordena los contornos de izquierda a derecha y, si están en filas,
        de arriba hacia abajo.
        
        Parámetro:
        - cnts: Lista de contornos.
        
        Retorna:
        - Contornos ordenados.
        """
        bounding_boxes = [cv2.boundingRect(c) for c in cnts]
        # Ordenar primero por `x` (de izquierda a derecha)
        cnts, _ = zip(*sorted(zip(cnts, bounding_boxes), key=lambda b: b[1][0]))
        return cnts

    def image_segmentation(self, img: np.ndarray)-> list[np.ndarray]:
        # Binariza la imagen (ajuste de umbral si es necesario)
        _, thresh = cv2.threshold(img, 150, 255, cv2.THRESH_BINARY_INV)

        # Encuentra los contornos de los caracteres
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # Ordena los contornos de izquierda a derecha y de arriba hacia abajo
        sorted_contours = self.sort_contours(contours)

        # Después de ordenar los contornos, puedes verificar y ajustar
        # para colocar el guion en la posición correcta si es necesario
        # Lista para almacenar los caracteres segmentados
        segmented_characters = []

        # Itera sobre los contornos ordenados
        for contour in sorted_contours:
            # Obtiene el rectángulo delimitador del contorno
            x, y, w, h = cv2.boundingRect(contour)

            # Filtra contornos pequeños (ruido)
            if w > 10 and h > 10:
                # Recorta el carácter
                char_image = img[y:y+h, x:x+w]

                # Agrega el carácter segmentado a la lista
                segmented_characters.append(char_image)
        
        return segmented_characters