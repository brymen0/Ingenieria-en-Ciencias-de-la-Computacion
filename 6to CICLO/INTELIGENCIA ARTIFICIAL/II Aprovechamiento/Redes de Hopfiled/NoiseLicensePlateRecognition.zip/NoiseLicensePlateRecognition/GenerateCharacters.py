import random
import string
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance, ImageOps

def apply_random_transformations(img: Image) -> Image:
    """
    Aplica transformaciones aleatorias a la imagen.

    Parámetros:
    - img (Image): La imagen a la que se le aplicarán las transformaciones.

    Retorna:
    - Image: La imagen transformada.
    """
    # Escala aleatoria
    scale_factor = random.uniform(0.8, 1.2)
    img = img.resize((int(img.width * scale_factor), int(img.height * scale_factor)))

    # Rotación aleatoria
    rotation_angle = random.randint(-15, 15)  # Rango de -15 a 15 grados
    img = img.rotate(rotation_angle, resample=Image.BICUBIC, expand=True)

    # Desplazamiento aleatorio
    max_translation = 5  # Desplazamiento máximo en píxeles
    x_translation = random.randint(-max_translation, max_translation)
    y_translation = random.randint(-max_translation, max_translation)
    img = img.transform(img.size, Image.AFFINE, (1, 0, x_translation, 0, 1, y_translation))

    # Aplicar algún filtro para variación
    if random.random() > 0.5:  # Con un 50% de probabilidad
        img = img.filter(ImageFilter.GaussianBlur(radius=random.uniform(0, 2)))

    # Ajuste de brillo aleatorio
    enhancer = ImageEnhance.Brightness(img)
    img = enhancer.enhance(random.uniform(0.7, 1.3))  # Cambiar el brillo entre 70% y 130%

    return img


def generate_plate(output_path: str, letters: str, size: tuple[int, int] = (512, 128), font_size: int = 90):
    """
    Genera placas sintéticas con variaciones de letras y números, y las guarda en una carpeta.

    Parámetros:
    - output_path (str): Ruta donde se guardarán las placas generadas.
    - letters (str): Letras o dígitos a usar en las placas.
    - size (tuple[int, int]): Tamaño de la imagen (ancho, alto).
    - font_size (int): Tamaño de la fuente.

    Retorna:
    - None
    """
    count = 0
    font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"  # Cambia por una ruta válida
    font = ImageFont.truetype(font_path, font_size)

    for char in letters:
        for _ in range(10):  # Generar 10 variaciones por cada letra
            # Crear imagen con fondo negro
            background_color = (0, 0, 0)  # Fondo negro
            plate_img = Image.new("RGB", size, background_color)
            draw = ImageDraw.Draw(plate_img)

            # Calcular posición para centrar el texto
            text_bbox = draw.textbbox((0, 0), char, font=font)
            text_width = text_bbox[2] - text_bbox[0]
            text_height = text_bbox[3] - text_bbox[1]
            text_x = (size[0] - text_width) // 2
            text_y = (size[1] - text_height) // 2

            # Dibujar el texto en blanco
            draw.text((text_x, text_y), char, font=font, fill="white")

            # Aplicar transformaciones aleatorias
            plate_img = apply_random_transformations(plate_img)

            # Convertir la imagen a escala de grises
            plate_img = plate_img.convert("L")

            # Invertir colores (BINARY_INV)
            plate_img = ImageOps.invert(plate_img)

            # Guardar la imagen
            plate_img.save(f'{output_path}_{count}.png')
            count += 1


# Letras del alfabeto
letters = string.ascii_uppercase  # 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

# Dígitos del 0 al 9
digits = string.digits  # '0123456789'

# Generar placas para letras
generate_plate(output_path='./letters/letter', letters=letters, size=(64, 64), font_size=50)

# Generar placas para dígitos
generate_plate(output_path='./digits/digit', letters=digits, size=(64, 64), font_size=50)

