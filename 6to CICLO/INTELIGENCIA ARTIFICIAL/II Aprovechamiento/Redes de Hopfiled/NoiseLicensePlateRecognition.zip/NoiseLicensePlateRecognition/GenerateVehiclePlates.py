import random
import string
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
import os


def generate_plate(output_path: str, size: tuple[int, int] = (512, 128), font_size: int = 90):
    """
    Genera una placa sintética con un fondo gris aleatorio, texto centrado y efecto de desenfoque opcional.

    Parámetros:
    - output_path (str): Ruta donde se guardará la placa generada.
    - size (tuple[int, int]): Tamaño de la imagen (ancho, alto).
    - font_size (int): Tamaño de la fuente.

    Retorna:
    - None
    """
    # Esquema: 3 letras - 4 dígitos (e.g., ABC-1234)
    letters = ''.join(random.choices(string.ascii_uppercase, k=3))
    digits = ''.join(random.choices(string.digits, k=4))
    plate_text = f"{letters}-{digits}"

    background_color = (255, 255, 255)
    plate_img = Image.new("RGB", size, background_color)
    draw = ImageDraw.Draw(plate_img)

    # Seleccionar fuente
    font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"  # Cambia por una ruta válida
    try:
        font = ImageFont.truetype(font_path, font_size)
    except IOError:
        raise FileNotFoundError(f"No se pudo cargar la fuente en: {font_path}")

    # Calcular posición para centrar el texto
    text_bbox = draw.textbbox((0, 0), plate_text, font=font)
    text_width = text_bbox[2] - text_bbox[0]
    text_height = text_bbox[3] - text_bbox[1]
    text_x = (size[0] - text_width) // 2
    text_y = (size[1] - text_height) // 2

    # Dibujar el texto en la placa
    draw.text((text_x, text_y), plate_text, font=font, fill="black")

    # Aplicar blur para simular desenfoque
    if random.random() < 0.5:  # Probabilidad de aplicar desenfoque
        plate_img = plate_img.filter(ImageFilter.GaussianBlur(radius=random.uniform(0.1, 2)))

    # Ajustar brillo y contraste para mayor realismo
    enhancer = ImageEnhance.Brightness(plate_img)
    plate_img = enhancer.enhance(random.uniform(0.8, 1.2))  # Rango de brillo
    enhancer = ImageEnhance.Contrast(plate_img)
    plate_img = enhancer.enhance(random.uniform(0.8, 1.2))  # Rango de contraste

    # Guardar la imagen
    plate_img.save(output_path)


def generate_multiple_plates(output_dir: str, num_plates: int = 10):
    """
    Genera múltiples placas sintéticas y las guarda en un directorio.

    Parámetros:
    - output_dir (str): Directorio donde se guardarán las placas generadas.
    - num_plates (int): Número de placas a generar.

    Retorna:
    - None
    """
    os.makedirs(output_dir, exist_ok=True)
    for i in range(num_plates):
        output_path = os.path.join(output_dir, f"plate_{i + 1}.png")
        generate_plate(output_path)
    print(f"{num_plates} placas generadas en el directorio: {output_dir}")


# Generar 100 placas sintéticas en la carpeta "assetsModel"
generate_multiple_plates(output_dir="./assets", num_plates=10)






