import os
import glob
import numpy as np
import matplotlib.pyplot as plt
from ImagesUtilities import ImagesUtilities
from neupy.algorithms import DiscreteHopfieldNetwork

#Instalar algunas librerias
#pip install neupy
#pip install opencv-python

size:int = 64
imagesUtilities:ImagesUtilities = ImagesUtilities()
hopfieldNetworkDigits:DiscreteHopfieldNetwork = DiscreteHopfieldNetwork(mode= 'async')
hopfieldNetworkLetters:DiscreteHopfieldNetwork = DiscreteHopfieldNetwork(mode= 'async')

#Modicar placa introducir ruido
img_test:np.ndarray = imagesUtilities.modify_img(path= './assets/plate_1.png')
#Proceso de segmentacion
img_test_segmentation: list = imagesUtilities.image_segmentation(img= img_test)

#Visualizar como se esta segmentando la imagen
for i, char in enumerate(img_test_segmentation):
    plt.imshow(char, cmap='gray')
    plt.title(f'Caracter {i+1}')
    plt.axis('off')
    plt.show()

#Procesar los segmentos a formato utilizado
test_image_segmentation_format: list = [imagesUtilities.process_img(img= segment, size= size) for segment in img_test_segmentation]

#Tener los paths de digits y letters en una lista
digits_paths = glob.glob(os.path.join('./digits', "*.png"))
letters_paths = glob.glob(os.path.join('./letters', "*.png"))

#Obtener lista de arreglos unidimensionales de digitos y letras
digits: list = [imagesUtilities.load_img(path= path, size= size) for path in digits_paths]
letters: list = [imagesUtilities.load_img(path= path, size= size) for path in letters_paths]

#Entrenar cada red de Hopfield
hopfieldNetworkDigits.train(X_bin= np.array(digits))
hopfieldNetworkLetters.train(X_bin= np.array(letters))

#Reconstruir segmentos
#Reconstruccion de letras
letters_rebuild: list = [hopfieldNetworkLetters.predict(X_bin= np.array(segment)) for segment in test_image_segmentation_format[:3]]
#Reconstruccion de digitos
digits_rebuild: list = [hopfieldNetworkDigits.predict(X_bin= np.array(segment)) for segment in test_image_segmentation_format[4:]]

print(letters_rebuild)
print(digits_rebuild)


#Mostrar letras
for letter in letters_rebuild:
    imagesUtilities.show_img_by_array(img_array= letter[0])

#Mostrar digitos
for digit in digits_rebuild:
    imagesUtilities.show_img_by_array(img_array= digit[0])