package modelo

class Libro (val ISBN:String,
             val titulo:String,
             val precioVenta:Float,
             val precioCompra:Float,
             val cantidad:Int,
             val rutaImagen:String)
  extends Serializable