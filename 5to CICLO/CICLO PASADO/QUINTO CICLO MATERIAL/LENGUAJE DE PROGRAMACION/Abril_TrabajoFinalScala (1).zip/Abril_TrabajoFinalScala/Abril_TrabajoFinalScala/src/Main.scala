import controlador.ControladorInicio
import modelo.{ContenedorCliente, Persona}
import vista.VistaInicio

object Main {
  def main(args: Array[String]): Unit = {
    val view = new VistaInicio()
    val controlador = new ControladorInicio(view)
    controlador.init()
  }
}