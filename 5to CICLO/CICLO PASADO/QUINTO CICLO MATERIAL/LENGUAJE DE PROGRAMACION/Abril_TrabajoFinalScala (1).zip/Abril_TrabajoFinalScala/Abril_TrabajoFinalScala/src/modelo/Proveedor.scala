package modelo

class Proveedor( ccedula:String,  cnombre:String, cdireccion:String, ctelefono:String,  ccorreo:String)
  extends Persona(ccedula, cnombre, cdireccion, ctelefono, ccorreo)
