package modelo

class ItemFactura (val cantLibro:Int, val ISBN:String, val iva:Double) extends Serializable
