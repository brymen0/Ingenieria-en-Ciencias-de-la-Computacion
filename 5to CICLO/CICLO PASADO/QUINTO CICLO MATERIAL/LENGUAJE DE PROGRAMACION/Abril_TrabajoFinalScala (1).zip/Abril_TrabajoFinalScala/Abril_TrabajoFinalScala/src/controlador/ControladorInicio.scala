package controlador

import modelo.{ContenedorCliente, ContenedorFactura, ContenedorLibro, ContenedorProveedor, Factura, ImageRenderer, Libro}
import vista.VistaInicio

import java.awt.{Image, Label}
import java.awt.event.ActionListener
import java.io.{File, IOException}
import java.nio.file.{Files, Path, Paths, StandardCopyOption}
import javax.swing.{ImageIcon, JFileChooser, JOptionPane}
import javax.swing.table.DefaultTableModel
import scala.language.postfixOps
import javax.imageio.ImageIO
import scala.collection.mutable.ArrayBuffer
import java.awt.event.ActionEvent
import java.util.Date
import javax.swing.event.{ListSelectionEvent, ListSelectionListener}

class ControladorInicio (cVistaInicio: VistaInicio) extends ActionListener{
  val view : VistaInicio = cVistaInicio
  var dirImagen: File = null
  var rutaDestino:String = ""
  var facturaTemp: Factura = null
  view.btnAgregarCliente.addActionListener(this)
  view.btnModificarCliente.addActionListener(this)
  view.btnEliminarCliente.addActionListener(this)
  view.btnBuscarCliente.addActionListener(this)
  view.btnMostrarClientes.addActionListener(this)
  view.btnOrdenarAscClientes.addActionListener(this)
  view.btnOrdenarDescClientes.addActionListener(this)
  view.btnAgregarProveedor.addActionListener(this)
  view.btnModificarProveedor.addActionListener(this)
  view.btnEliminarProveedor.addActionListener(this)
  view.btnBuscarProveedor.addActionListener(this)
  view.btnMostrarProveedores.addActionListener(this)
  view.btnOrdenarAscProveedores.addActionListener(this)
  view.btnOrdenarDescProveedores.addActionListener(this)
  view.btnSeleccionarImagen.addActionListener(this)
  view.btnAgregarLibro.addActionListener(this)
  view.btnModificarLibro.addActionListener(this)
  view.btnEliminarLibros.addActionListener(this)
  view.btnMasCostoso.addActionListener(this)
  view.btnMenosCostoso.addActionListener(this)
  view.btnMasVendido.addActionListener(this)
  view.btnMenosVendido.addActionListener(this)
  view.btnBuscarLibro.addActionListener(this)
  view.btnMostrarLibros.addActionListener(this)
  view.btnOrdenarAscLibros.addActionListener(this)
  view.btnOrdenarDescLibros.addActionListener(this)
  view.btnBuscarCedulaFactura.addActionListener(this)
  view.btnAgregarItem.addActionListener(this)
  view.btnEliminarItem.addActionListener(this)
  view.btnEliminarItem.setEnabled(false)
  view.tablaAgregarItem.getSelectionModel.addListSelectionListener(new SelectionChanged())
  view.btnAgregarFactura.addActionListener(this)
  view.btnBuscarFactura.addActionListener(this)
  view.btnEliminarFactura.addActionListener(this)
  view.btnMostrarFacturas.addActionListener(this)
  view.btnOrdenarAscFacturas.addActionListener(this)
  view.btnOrdenarDescFacturas.addActionListener(this)
  view.btnReiniciarFactura.addActionListener(this)
  val modeloCliente = new ContenedorCliente
  val modeloProveedor = new ContenedorProveedor
  val modeloLibro = new ContenedorLibro
  val modeloFactura = new ContenedorFactura
  init()
  def init(): Unit ={
    view.PanelTrans.setVisible(false)
    view.PanelLibros.setVisible(false)
    view.PanelClientes.setVisible(false)
    view.PanelProveedores.setVisible(false)
    view.PanelInicio.setVisible(true)
    view.setVisible(true)
    view.setLocationRelativeTo(null)
    modeloCliente.cargarClientes()
    modeloProveedor.cargarProveedores()
    modeloLibro.cargarLibros()
    modeloFactura.cargarFacturas()
    cargarCbLibros()
    cargarnumFactura()
    obtenerCaja()
  }

  def limpiarCliente():Unit = {
    view.txtCedulaCliente.setText("")
    view.txtCorreoCliente.setText("")
    view.txtDireccionCliente.setText("")
    view.txtNombreCliente.setText("")
    view.txtTelefonoCliente.setText("")

  }

  def limpiarProveedor(): Unit = {
    view.txtCedulaProveedor.setText("")
    view.txtCorreoProveedor.setText("")
    view.txtDireccionProveedor.setText("")
    view.txtNombreProveedor.setText("")
    view.txtTelefonoProveedor.setText("")
  }

  def verificarEntero(num:String):Int = {
    if (scala.util.Try(num.toInt).isSuccess) {
      return num.toInt
    }
    return -1
  }

  def verificarFloat(num:String):Float = {
    if(scala.util.Try(num.toFloat).isSuccess){
      return num.toFloat
    }
    return -1
  }

  def validarCedula(cedula: String): Boolean = {
    var estado = false
    try ///Restricción 1
      if (cedula.length == 10) { ///Restricción 3
        if ((cedula.substring(0, 2).toInt <= 24) || (cedula.substring(0, 2).toInt == 30)) {
          val coeficientes = Array(2, 1, 2, 1, 2, 1, 2, 1, 2)
          val digitoVerificador = cedula.substring(cedula.length - 1, cedula.length).toInt
          var suma = 0
          var digitoXcoeficiente = 0
          var modulo = 0
          ///Restricción 4
          var i = 0
          while ( {
            i < cedula.length - 1
          }) { ///Paso 1
            digitoXcoeficiente = cedula.substring(i, i + 1).toInt * coeficientes(i)
            ///Paso 2
            if (digitoXcoeficiente > 9) {digitoXcoeficiente -= 9}
            else digitoXcoeficiente
            ///Paso 3
            suma += digitoXcoeficiente

            i += 1
          }
          ///Paso 4
          modulo = suma % 10
          ///Paso 5
          if ((10 - modulo) == digitoVerificador) estado = true
          if (modulo == 0 & modulo == digitoVerificador) estado = true
        }
        else { ///Fin Restricción 3
          estado = false
          //System.out.println("Su cédula no pertenece a ecuador")
        }
      }
      else { ///Fin Restricción 1
        estado = false
        //System.out.println("Tiene menos o más de 10 cracteres")
      }
    catch {
      case e: NumberFormatException =>
        estado = false
        System.out.println("Error al intentar validar")
    }
    return estado
  }

  def validarRUC(ruc: String): Boolean = {
    if (ruc.length != 13) return false
    val coeficientes = Array(4, 3, 2, 7, 6, 5, 4, 3, 2)
    var suma = 0
    if (ruc(1) != '9') return false
    for (i <- 0 until 9) {
      suma += (ruc(i).asDigit * coeficientes(i))
    }
    val residuo = suma % 11
    val digitoVerificador = if (residuo == 0) 0 else 11 - residuo
    println(digitoVerificador==ruc(9).asDigit)
    return digitoVerificador == ruc(9).asDigit
  }

  def agregarCliente():Unit = {
    var k:Boolean=false
    if (!view.txtCedulaCliente.getText().equals("") && !view.txtNombreCliente.getText().equals("") && !view.txtDireccionCliente.getText().equals("") && !view.txtTelefonoCliente.getText().equals("") && !view.txtCorreoCliente.getText().equals("")) {
      val telf = verificarEntero(view.txtTelefonoCliente.getText())
      if (telf != -1) {
        if (view.txtCedulaCliente.getText().length > 10) {
          k = validarRUC(view.txtCedulaCliente.getText())
        }
        else {
          k = validarCedula(view.txtCedulaCliente.getText())
        }
        if (k != false) {
          if (ContenedorCliente.buscarCliente(view.txtCedulaCliente.getText(), modeloCliente.ListaClientes) == -1) {
            modeloCliente.agregarCliente(view.txtCedulaCliente.getText(),
              view.txtNombreCliente.getText(),
              view.txtDireccionCliente.getText(),
              telf.toString,
              view.txtCorreoCliente.getText())
            modeloCliente.guardarClientes()
            limpiarCliente()
          }
          else {
            JOptionPane.showMessageDialog(null, "CLIENTE YA INGRESADO", "ERROR", JOptionPane.ERROR_MESSAGE)
          }
        }
        else {
          JOptionPane.showMessageDialog(null, "CEDULA/RUC INVALIDA", "ERROR", JOptionPane.ERROR_MESSAGE)
        }
      }
      else {
        JOptionPane.showMessageDialog(null, "Telefono debe ser un valor numerico", "ERROR", JOptionPane.ERROR_MESSAGE)
      }
    }
    else{ JOptionPane.showMessageDialog(null, "INGRESE TODOS LOS DATOS", "ERROR", JOptionPane.ERROR_MESSAGE)}
  }

  def buscarCliente():Unit = {
    val k = ContenedorCliente.buscarCliente(view.txtCedulaCliente.getText, modeloCliente.ListaClientes)
    if(k!= -1){
      view.txtNombreCliente.setText(modeloCliente.ListaClientes(k).nombre)
      view.txtDireccionCliente.setText(modeloCliente.ListaClientes(k).direccion)
      view.txtTelefonoCliente.setText(modeloCliente.ListaClientes(k).telefono)
      view.txtCorreoCliente.setText(modeloCliente.ListaClientes(k).correo)
    }else{
      JOptionPane.showMessageDialog(null, "CEDULA/RUC NO ENCONTRADA", "ERROR", JOptionPane.ERROR_MESSAGE)
    }
  }

  def modificarCliente():Unit = {
    var k: Boolean = false
    if (!view.txtCedulaCliente.getText().equals("") && !view.txtNombreCliente.getText().equals("") && !view.txtDireccionCliente.getText().equals("") && !view.txtTelefonoCliente.getText().equals("") && !view.txtCorreoCliente.getText().equals("")) {
      val telf = verificarEntero(view.txtTelefonoCliente.getText())
      if (telf != -1) {
        if (view.txtCedulaCliente.getText().length > 10) {
          k = validarRUC(view.txtCedulaCliente.getText())
        }
        else {
          k = validarCedula(view.txtCedulaCliente.getText())
        }
        if (k != false) {
          val x = ContenedorCliente.buscarCliente(view.txtCedulaCliente.getText(), modeloCliente.ListaClientes)
          if ( x != -1) {
            modeloCliente.modificarCliente(view.txtCedulaCliente.getText(),
              view.txtNombreCliente.getText(),
              view.txtDireccionCliente.getText(),
              telf.toString,
              view.txtCorreoCliente.getText(), x)
            modeloCliente.guardarClientes()
            limpiarCliente()
          }
          else {
            JOptionPane.showMessageDialog(null, "CLIENTE NO EXISTE", "ERROR", JOptionPane.ERROR_MESSAGE)
          }
        }
        else {
          JOptionPane.showMessageDialog(null, "CEDULA/RUC INVALIDA", "ERROR", JOptionPane.ERROR_MESSAGE)
        }
      }
      else {
        JOptionPane.showMessageDialog(null, "Telefono debe ser un valor numerico", "ERROR", JOptionPane.ERROR_MESSAGE)
      }
    }
    else {
      JOptionPane.showMessageDialog(null, "INGRESE TODOS LOS DATOS", "ERROR", JOptionPane.ERROR_MESSAGE)
    }
  }

  def eliminarCliente():Unit = {
    var k: Boolean = false
    if (!view.txtCedulaCliente.getText().equals("")) {
          val x = ContenedorCliente.buscarCliente(view.txtCedulaCliente.getText(), modeloCliente.ListaClientes)
          if (x != -1) {
            modeloCliente.eliminarCliente(x)
            modeloCliente.guardarClientes()
            limpiarCliente()
          }
          else {
            JOptionPane.showMessageDialog(null, "CLIENTE NO EXISTE", "ERROR", JOptionPane.ERROR_MESSAGE)
          }
    }
    else {
      JOptionPane.showMessageDialog(null, "INGRESE CEDULA", "ERROR", JOptionPane.ERROR_MESSAGE)
    }
  }

  def mostrarCliente():Unit = {
    var i = 0
    val modelo = new DefaultTableModel()
    modelo.addColumn("CEDULA/RUC")
    modelo.addColumn("NOMBRE")
    modelo.addColumn("DIRECCION")
    modelo.addColumn("TELEFONO")
    modelo.addColumn("CORREO")
    view.tablaClientes.setModel(modelo)
    for (i <- 0 until modeloCliente.ListaClientes.length){
      modelo.insertRow(modelo.getRowCount, new Array[AnyRef](modeloCliente.ListaClientes.length))
      modelo.setValueAt(modeloCliente.ListaClientes(i).cedula, modelo.getRowCount - 1, 0)
      modelo.setValueAt(modeloCliente.ListaClientes(i).nombre, modelo.getRowCount - 1, 1)
      modelo.setValueAt(modeloCliente.ListaClientes(i).direccion, modelo.getRowCount - 1, 2)
      modelo.setValueAt(modeloCliente.ListaClientes(i).telefono, modelo.getRowCount - 1, 3)
      modelo.setValueAt(modeloCliente.ListaClientes(i).correo, modelo.getRowCount - 1, 4)
    }
  }

  def ordenarClienteAsc():Unit = {
    val sort = modeloCliente.ListaClientes.sortBy(Cliente => Cliente.nombre)
    var i = 0
    val modelo = new DefaultTableModel()
    modelo.addColumn("CEDULA/RUC")
    modelo.addColumn("NOMBRE")
    modelo.addColumn("DIRECCION")
    modelo.addColumn("TELEFONO")
    modelo.addColumn("CORREO")
    view.tablaClientes.setModel(modelo)
    for (i <- 0 until sort.length) {
      modelo.insertRow(modelo.getRowCount, new Array[AnyRef](sort.length))
      modelo.setValueAt(sort(i).cedula, modelo.getRowCount - 1, 0)
      modelo.setValueAt(sort(i).nombre, modelo.getRowCount - 1, 1)
      modelo.setValueAt(sort(i).direccion, modelo.getRowCount - 1, 2)
      modelo.setValueAt(sort(i).telefono, modelo.getRowCount - 1, 3)
      modelo.setValueAt(sort(i).correo, modelo.getRowCount - 1, 4)
    }
  }

  def ordenarClienteDesc(): Unit = {
    val sort = modeloCliente.ListaClientes.sortBy(Cliente => Cliente.nombre)(Ordering[String].reverse)
    var i = 0
    val modelo = new DefaultTableModel()
    modelo.addColumn("CEDULA/RUC")
    modelo.addColumn("NOMBRE")
    modelo.addColumn("DIRECCION")
    modelo.addColumn("TELEFONO")
    modelo.addColumn("CORREO")
    view.tablaClientes.setModel(modelo)
    for (i <- 0 until sort.length) {
      modelo.insertRow(modelo.getRowCount, new Array[AnyRef](sort.length))
      modelo.setValueAt(sort(i).cedula, modelo.getRowCount - 1, 0)
      modelo.setValueAt(sort(i).nombre, modelo.getRowCount - 1, 1)
      modelo.setValueAt(sort(i).direccion, modelo.getRowCount - 1, 2)
      modelo.setValueAt(sort(i).telefono, modelo.getRowCount - 1, 3)
      modelo.setValueAt(sort(i).correo, modelo.getRowCount - 1, 4)
    }
  }

  def agregarProveedor(): Unit = {
    var k: Boolean = false
    if (!view.txtCedulaProveedor.getText().equals("") && !view.txtNombreProveedor.getText().equals("") && !view.txtDireccionProveedor.getText().equals("") && !view.txtTelefonoProveedor.getText().equals("") && !view.txtCorreoProveedor.getText().equals("")) {
      val telf = verificarEntero(view.txtTelefonoProveedor.getText())
      if (telf != -1) {
        if (view.txtCedulaProveedor.getText().length > 10) {
          k = validarRUC(view.txtCedulaProveedor.getText())
        }
        else {
          k = validarCedula(view.txtCedulaProveedor.getText())
        }
        if (k != false) {
          if (ContenedorProveedor.buscarProveedor(view.txtCorreoProveedor.getText(), modeloProveedor.ListaProveedores) == -1) {
            modeloProveedor.agregarProveedor(view.txtCedulaProveedor.getText(),
              view.txtNombreProveedor.getText(),
              view.txtDireccionProveedor.getText(),
              telf.toString,
              view.txtCorreoProveedor.getText())
            modeloProveedor.guardarProveedores()
            limpiarProveedor()
          }
          else {
            JOptionPane.showMessageDialog(null, "PROVEEDOR YA INGRESADO", "ERROR", JOptionPane.ERROR_MESSAGE)
          }
        }
        else {
          JOptionPane.showMessageDialog(null, "CEDULA/RUC INVALIDA", "ERROR", JOptionPane.ERROR_MESSAGE)
        }
      }
      else {
        JOptionPane.showMessageDialog(null, "Telefono debe ser un valor numerico", "ERROR", JOptionPane.ERROR_MESSAGE)
      }
    }
    else {
      JOptionPane.showMessageDialog(null, "INGRESE TODOS LOS DATOS", "ERROR", JOptionPane.ERROR_MESSAGE)
    }
  }

  def buscarProveedor(): Unit = {
    val k = ContenedorProveedor.buscarProveedor(view.txtCedulaProveedor.getText, modeloProveedor.ListaProveedores)
    if (k != -1) {
      view.txtNombreProveedor.setText(modeloProveedor.ListaProveedores(k).nombre)
      view.txtDireccionProveedor.setText(modeloProveedor.ListaProveedores(k).direccion)
      view.txtTelefonoProveedor.setText(modeloProveedor.ListaProveedores(k).telefono)
      view.txtCorreoProveedor.setText(modeloProveedor.ListaProveedores(k).correo)
    } else {
      JOptionPane.showMessageDialog(null, "CEDULA/RUC NO ENCONTRADA", "ERROR", JOptionPane.ERROR_MESSAGE)
    }
  }

  def modificarProveedor(): Unit = {
    var k: Boolean = false
    if (!view.txtCedulaProveedor.getText().equals("") && !view.txtNombreProveedor.getText().equals("") && !view.txtDireccionProveedor.getText().equals("") && !view.txtTelefonoProveedor.getText().equals("") && !view.txtCorreoProveedor.getText().equals("")) {
      val telf = verificarEntero(view.txtTelefonoProveedor.getText())
      if (telf != -1) {
        if (view.txtCedulaProveedor.getText().length > 10) {
          k = validarRUC(view.txtCedulaProveedor.getText())
        }
        else {
          k = validarCedula(view.txtCedulaProveedor.getText())
        }
        if (k != false) {
          val x = ContenedorProveedor.buscarProveedor(view.txtCedulaProveedor.getText(), modeloProveedor.ListaProveedores)
          if (x != -1) {
            modeloProveedor.modificarProveedor(view.txtCedulaProveedor.getText(),
              view.txtNombreProveedor.getText(),
              view.txtDireccionProveedor.getText(),
              telf.toString,
              view.txtCorreoProveedor.getText(), x)
            modeloProveedor.guardarProveedores()
            limpiarProveedor()
          }
          else {
            JOptionPane.showMessageDialog(null, "PROVEEDOR NO EXISTE", "ERROR", JOptionPane.ERROR_MESSAGE)
          }
        }
        else {
          JOptionPane.showMessageDialog(null, "CEDULA/RUC INVALIDA", "ERROR", JOptionPane.ERROR_MESSAGE)
        }
      }
      else {
        JOptionPane.showMessageDialog(null, "Telefono debe ser un valor numerico", "ERROR", JOptionPane.ERROR_MESSAGE)
      }
    }
    else {
      JOptionPane.showMessageDialog(null, "INGRESE TODOS LOS DATOS", "ERROR", JOptionPane.ERROR_MESSAGE)
    }
  }

  def eliminarProveedor(): Unit = {
    var k: Boolean = false
    if (!view.txtCedulaProveedor.getText().equals("")) {
      val x = ContenedorProveedor.buscarProveedor(view.txtCedulaProveedor.getText(), modeloProveedor.ListaProveedores)
      if (x != -1) {
        modeloProveedor.eliminarProveedor(x)
        limpiarProveedor()
      }
      else {
        JOptionPane.showMessageDialog(null, "PROVEEDOR NO EXISTE", "ERROR", JOptionPane.ERROR_MESSAGE)
      }
    }
    else {
      JOptionPane.showMessageDialog(null, "INGRESE CEDULA", "ERROR", JOptionPane.ERROR_MESSAGE)
    }
  }

  def mostrarProveedor(): Unit = {
    var i = 0
    val modelo = new DefaultTableModel()
    modelo.addColumn("CEDULA/RUC")
    modelo.addColumn("NOMBRE")
    modelo.addColumn("DIRECCION")
    modelo.addColumn("TELEFONO")
    modelo.addColumn("CORREO")
    view.tablaProveedores.setModel(modelo)
    for (i <- 0 until modeloProveedor.ListaProveedores.length) {
      modelo.insertRow(modelo.getRowCount, new Array[AnyRef](modeloProveedor.ListaProveedores.length))
      modelo.setValueAt(modeloProveedor.ListaProveedores(i).cedula, modelo.getRowCount - 1, 0)
      modelo.setValueAt(modeloProveedor.ListaProveedores(i).nombre, modelo.getRowCount - 1, 1)
      modelo.setValueAt(modeloProveedor.ListaProveedores(i).direccion, modelo.getRowCount - 1, 2)
      modelo.setValueAt(modeloProveedor.ListaProveedores(i).telefono, modelo.getRowCount - 1, 3)
      modelo.setValueAt(modeloProveedor.ListaProveedores(i).correo, modelo.getRowCount - 1, 4)
    }
  }

  def mostrarLibro(Libros:ArrayBuffer[Libro]):Unit = {
    var i = 0
    val modelo = new DefaultTableModel()
    modelo.addColumn("ISBN")
    modelo.addColumn("TITULO")
    modelo.addColumn("PRECIO COMPRA")
    modelo.addColumn("PRECIO VENTA")
    modelo.addColumn("CANTIDAD")
    modelo.addColumn("IMAGEN")
    view.tablaLibros.setModel(modelo)
    view.tablaLibros.getColumnModel.getColumn(5).setCellRenderer(new ImageRenderer())
    for (i <- 0 until Libros.length) {
      modelo.insertRow(modelo.getRowCount, new Array[AnyRef](Libros.length))
      view.tablaLibros.setRowHeight(i, 200)
      view.tablaLibros.getColumnModel().getColumn(5).setPreferredWidth(200)
      modelo.setValueAt(Libros(i).ISBN, modelo.getRowCount - 1, 0)
      modelo.setValueAt(Libros(i).titulo, modelo.getRowCount - 1, 1)
      modelo.setValueAt(Libros(i).precioCompra, modelo.getRowCount - 1, 2)
      modelo.setValueAt(Libros(i).precioVenta, modelo.getRowCount - 1, 3)
      modelo.setValueAt(Libros(i).cantidad, modelo.getRowCount - 1, 4)
      modelo.setValueAt(new ImageIcon("./src/vista/images/"+Libros(i).rutaImagen), modelo.getRowCount - 1, 5)
    }
  }

  def ordenarProveedorAsc(): Unit = {
    val sort = modeloProveedor.ListaProveedores.sortBy(Proveedor => Proveedor.nombre)
    var i = 0
    val modelo = new DefaultTableModel()
    modelo.addColumn("CEDULA/RUC")
    modelo.addColumn("NOMBRE")
    modelo.addColumn("DIRECCION")
    modelo.addColumn("TELEFONO")
    modelo.addColumn("CORREO")
    view.tablaProveedores.setModel(modelo)
    for (i <- 0 until sort.length) {
      modelo.insertRow(modelo.getRowCount, new Array[AnyRef](sort.length))
      modelo.setValueAt(sort(i).cedula, modelo.getRowCount - 1, 0)
      modelo.setValueAt(sort(i).nombre, modelo.getRowCount - 1, 1)
      modelo.setValueAt(sort(i).direccion, modelo.getRowCount - 1, 2)
      modelo.setValueAt(sort(i).telefono, modelo.getRowCount - 1, 3)
      modelo.setValueAt(sort(i).correo, modelo.getRowCount - 1, 4)
    }
  }

  def ordenarProveedorDesc(): Unit = {
    val sort = modeloProveedor.ListaProveedores.sortBy(Proveedor => Proveedor.nombre)(Ordering[String].reverse)
    var i = 0
    val modelo = new DefaultTableModel()
    modelo.addColumn("CEDULA/RUC")
    modelo.addColumn("NOMBRE")
    modelo.addColumn("DIRECCION")
    modelo.addColumn("TELEFONO")
    modelo.addColumn("CORREO")
    view.tablaProveedores.setModel(modelo)
    for (i <- 0 until sort.length) {
      modelo.insertRow(modelo.getRowCount, new Array[AnyRef](sort.length))
      modelo.setValueAt(sort(i).cedula, modelo.getRowCount - 1, 0)
      modelo.setValueAt(sort(i).nombre, modelo.getRowCount - 1, 1)
      modelo.setValueAt(sort(i).direccion, modelo.getRowCount - 1, 2)
      modelo.setValueAt(sort(i).telefono, modelo.getRowCount - 1, 3)
      modelo.setValueAt(sort(i).correo, modelo.getRowCount - 1, 4)
    }
  }

  def cargarImagen(): Unit ={
    val file:JFileChooser = new JFileChooser()
    file.showOpenDialog(view)
    val archivo:File = file.getSelectedFile
    if(archivo != null){
      val origen = archivo.getPath
      val org : Path = Paths.get(origen)
      val image :Image= ImageIO.read(archivo)
      val ImagenEscalada:Image = image.getScaledInstance(view.lblImagenRef.getWidth, view.lblImagenRef.getHeight, Image.SCALE_SMOOTH)
      val icon: ImageIcon = new ImageIcon(ImagenEscalada)
      view.lblImagenRef.setIcon(icon)
      dirImagen = archivo
    }else{
      JOptionPane.showMessageDialog(null, "Seleccione una Imagen")
    }
  }

  def guardarImagen(archivo:File):Unit={
    try {
      val dest: String = "./src/vista/images/" + archivo.getName
      val destino: Path = Paths.get(dest)
      val origen = archivo.getPath
      val org: Path = Paths.get(origen)
      Files.copy(org, destino, StandardCopyOption.REPLACE_EXISTING)
      rutaDestino = archivo.getName
      //Files.copy(org, destino)
    } catch {
      case ex: IOException => println("No se guardo la imagen" + ex.getMessage)
    }
  }

  def limpiarLibro():Unit={
    view.lblImagenRef.setIcon(null)
    view.txtISBN.setText("")
    view.txtTituloLibro.setText("")
    view.txtCantidad.setText("")
    view.txtPrecioVenta.setText("")
    view.txtPrecioCompra.setText("")
  }

  def buscarLibro():Unit={
    if(!view.txtISBN.getText.equals("")){
      val k = ContenedorLibro.buscarLibro(view.txtISBN.getText, modeloLibro.Libros)
      if(k != -1){
        view.txtISBN.setText(modeloLibro.Libros(k).ISBN)
        view.txtTituloLibro.setText(modeloLibro.Libros(k).titulo)
        view.txtPrecioVenta.setText(modeloLibro.Libros(k).precioVenta.toString)
        view.txtPrecioCompra.setText(modeloLibro.Libros(k).precioCompra.toString)
        view.txtCantidad.setText(modeloLibro.Libros(k).cantidad.toString)
        val file = new File("./src/vista/images/"+modeloLibro.Libros(k).rutaImagen)
        dirImagen = file
        val image = ImageIO.read(file)
        val scaledImage = image.getScaledInstance(view.lblImagenRef.getWidth, view.lblImagenRef.getHeight, Image.SCALE_SMOOTH)
        view.lblImagenRef.setIcon(new ImageIcon(scaledImage))
      }else{
        JOptionPane.showMessageDialog(null, "NO EXISTE LIBRO", "ERROR", JOptionPane.ERROR_MESSAGE)
      }
    }else{
      JOptionPane.showMessageDialog(null, "INGRESE ISBN A BUSCAR", "ERROR", JOptionPane.ERROR_MESSAGE)
    }
  }

  def agregarLibro():Unit={
    if(view.lblImagenRef.getIcon != null){
      if(!view.txtISBN.getText.equals("") && !view.txtTituloLibro.getText.equals("") && !view.txtPrecioVenta.getText.equals("") && !view.txtPrecioCompra.getText.equals("") && !view.txtCantidad.getText.equals("")){
        if(ContenedorLibro.buscarLibro(view.txtISBN.getText, modeloLibro.Libros)== -1){
          val precioVenta = verificarFloat(view.txtPrecioVenta.getText)
          val precioCompra = verificarFloat(view.txtPrecioCompra.getText)
          val cantidad = verificarEntero(view.txtCantidad.getText)
          if (precioVenta != -1 && precioCompra != -1 && cantidad != -1) {
            guardarImagen(dirImagen)
            modeloLibro.agregarLibro(view.txtISBN.getText, view.txtTituloLibro.getText, precioVenta, precioCompra, cantidad, rutaDestino)
            limpiarLibro()
            modeloLibro.guardarLibros()
            cargarCbLibros()
          } else {
            JOptionPane.showMessageDialog(null, "INGRESE VALORES NUMERICOS", "ERROR", JOptionPane.ERROR_MESSAGE)
          }
        }else{
          JOptionPane.showMessageDialog(null, "LIBRO YA INGRESADO", "ERROR", JOptionPane.ERROR_MESSAGE)
        }
      }else{
        JOptionPane.showMessageDialog(null, "INGRESE TODOS LOS DATOS", "ERROR", JOptionPane.ERROR_MESSAGE)
      }
    }else{
      JOptionPane.showMessageDialog(null, "SELECCIONE IMAGEN PARA EL LIBRO", "ERROR", JOptionPane.ERROR_MESSAGE)
    }
  }

  def modificarLibro(): Unit = {
    if (view.lblImagenRef.getIcon != null) {
      if (!view.txtISBN.getText.equals("") && !view.txtTituloLibro.getText.equals("") && !view.txtPrecioVenta.getText.equals("") && !view.txtPrecioCompra.getText.equals("") && !view.txtCantidad.getText.equals("")) {
        val k = ContenedorLibro.buscarLibro(view.txtISBN.getText, modeloLibro.Libros)
        if (k != -1) {
          val precioVenta = verificarFloat(view.txtPrecioVenta.getText)
          val precioCompra = verificarFloat(view.txtPrecioCompra.getText)
          val cantidad = verificarEntero(view.txtCantidad.getText)
          if (precioVenta != -1 && precioCompra != -1 && cantidad != -1) {
            guardarImagen(dirImagen)
            modeloLibro.modificarLibro(view.txtISBN.getText, view.txtTituloLibro.getText, precioVenta, precioCompra, cantidad, rutaDestino, k)
            limpiarLibro()
            modeloLibro.guardarLibros()
            cargarCbLibros()
          } else {
            JOptionPane.showMessageDialog(null, "INGRESE VALORES NUMERICOS", "ERROR", JOptionPane.ERROR_MESSAGE)
          }
        } else {
          JOptionPane.showMessageDialog(null, "NO EXISTE LIBRO", "ERROR", JOptionPane.ERROR_MESSAGE)
        }
      } else {
        JOptionPane.showMessageDialog(null, "INGRESE TODOS LOS DATOS", "ERROR", JOptionPane.ERROR_MESSAGE)
      }
    } else {
      JOptionPane.showMessageDialog(null, "SELECCIONE IMAGEN PARA EL LIBRO", "ERROR", JOptionPane.ERROR_MESSAGE)
    }
  }

  def eliminarLibro(): Unit = {
    if(!view.txtISBN.getText.equals("")){
      val k = ContenedorLibro.buscarLibro(view.txtISBN.getText, modeloLibro.Libros)
      if(k != -1){
        modeloLibro.eliminarLibro(k)
        modeloLibro.guardarLibros()
        limpiarLibro()
        cargarCbLibros()
      }else{
        JOptionPane.showMessageDialog(null, "NO EXISTE LIBRO", "ERROR", JOptionPane.ERROR_MESSAGE)
      }
    }else{
      JOptionPane.showMessageDialog(null, "INGRESE ISBN A ELIMINAR", "ERROR", JOptionPane.ERROR_MESSAGE)
    }
  }

  def ordenarLibroAsc(): Unit = {
    val sort = modeloLibro.Libros.sortBy(Libro => Libro.precioVenta)
    mostrarLibro(sort)
  }

  def ordenarLibroDesc(): Unit = {
    val sort = modeloLibro.Libros.sortBy(Libro => Libro.precioVenta)(Ordering[Float].reverse)
    mostrarLibro(sort)
  }

  def cargarCbLibros():Unit={
    view.cboAgregarLibro.removeAllItems()
    for(i <- 0 until modeloLibro.Libros.length){
      view.cboAgregarLibro.addItem(modeloLibro.Libros(i).titulo)
    }
  }

  def buscarClienteFactura():Unit={
    var cedula:String = ""
    var k = 0
    if(!view.txtCedulaFactura.getText.equals("")){
      if(view.cboTransaccion.getSelectedItem.toString.equalsIgnoreCase("compra")){
        k = ContenedorProveedor.buscarProveedor(view.txtCedulaFactura.getText, modeloProveedor.ListaProveedores)
        if(k!= -1){
          cedula = modeloProveedor.ListaProveedores(k).cedula
          view.lblNombreFactura.setText(modeloProveedor.ListaProveedores(k).nombre)
          view.lblDireccionFactura.setText(modeloProveedor.ListaProveedores(k).direccion)
          view.lblTelefonoFactura.setText(modeloProveedor.ListaProveedores(k).telefono)
          view.lblCorreoFactura.setText(modeloProveedor.ListaProveedores(k).correo)
          view.cboTransaccion.setEnabled(false)
        }else{
          JOptionPane.showMessageDialog(null, "NO EXISTE PROVEEDOR", "ERROR", JOptionPane.ERROR_MESSAGE)
        }
      }
      else{
        if(view.cboTransaccion.getSelectedItem.toString.equalsIgnoreCase("venta")){
          k = ContenedorCliente.buscarCliente(view.txtCedulaFactura.getText, modeloCliente.ListaClientes)
          if(k!= -1){
            cedula = modeloCliente.ListaClientes(k).cedula
            view.lblNombreFactura.setText(modeloCliente.ListaClientes(k).nombre)
            view.lblDireccionFactura.setText(modeloCliente.ListaClientes(k).direccion)
            view.lblTelefonoFactura.setText(modeloCliente.ListaClientes(k).telefono)
            view.lblCorreoFactura.setText(modeloCliente.ListaClientes(k).correo)
            view.cboTransaccion.setEnabled(false)
          }else{
            JOptionPane.showMessageDialog(null, "NO EXISTE CLIENTE", "ERROR", JOptionPane.ERROR_MESSAGE)
          }
        }
      }
      facturaTemp = new Factura(verificarEntero(view.txtNumFactura.getText),
        view.cboTransaccion.getSelectedItem.toString,
        cedula,
        view.obtenerFecha.getDate,
        view.cboTransaccion.getSelectedItem.toString)
    }else{
      JOptionPane.showMessageDialog(null, "INGRESE CEDULA/RUC", "ERROR", JOptionPane.ERROR_MESSAGE)
    }
  }

  def cargarnumFactura():Unit = {
    view.txtNumFactura.setText((modeloFactura.listaFactura.length+1).toString)
  }

  def cargarTablaItems():Unit = {
    var i = 0
    val modelo = new DefaultTableModel()
    modelo.addColumn("ITEM")
    modelo.addColumn("ISBN")
    modelo.addColumn("TITULO")
    modelo.addColumn("CANTIDAD")
    modelo.addColumn("PRECIO")
    modelo.addColumn("TOTAL")
    view.tablaAgregarItem.setModel(modelo)
    for (i <- 0 until facturaTemp.listaItemFactura.length) {
      val k = ContenedorLibro.buscarLibro(facturaTemp.listaItemFactura(i).ISBN, modeloLibro.Libros)
      modelo.insertRow(modelo.getRowCount, new Array[AnyRef](facturaTemp.listaItemFactura.length))
      modelo.setValueAt(facturaTemp.listaItemFactura.length, modelo.getRowCount - 1, 0)
      modelo.setValueAt(facturaTemp.listaItemFactura(i).ISBN, modelo.getRowCount - 1, 1)
      modelo.setValueAt(modeloLibro.Libros(k).titulo, modelo.getRowCount - 1, 2)
      modelo.setValueAt(facturaTemp.listaItemFactura(i).cantLibro, modelo.getRowCount - 1, 3)
      modelo.setValueAt(modeloLibro.Libros(k).precioVenta, modelo.getRowCount - 1, 4)
      modelo.setValueAt((modeloLibro.Libros(k).precioVenta*facturaTemp.listaItemFactura(i).cantLibro), modelo.getRowCount - 1, 5)
    }
  }

  def agregarItemFactura():Unit = {
    if(!view.lblNombreFactura.getText.equals("")){
      val k = ContenedorLibro.buscarLibroporTitulo(view.cboAgregarLibro.getSelectedItem.toString, modeloLibro.Libros)
      val cantidad = verificarEntero(view.spinCantidadLibro.getValue.toString)
      if (modeloLibro.Libros(k).cantidad > cantidad) {
        facturaTemp.agregarItemFactura(cantidad, modeloLibro.Libros(k).ISBN, 0.12)
        cargarTablaItems()
      } else {
        JOptionPane.showMessageDialog(null, "CANTIDAD DE LIBRO NO DISPONIBLE", "ERROR", JOptionPane.ERROR_MESSAGE)
      }
    }else{
      JOptionPane.showMessageDialog(null, "INGRESE DATOS DE PERSONA", "ERROR", JOptionPane.ERROR_MESSAGE)
    }
  }

  def eliminarItemFactura():Unit = {
    val item = verificarEntero(view.tablaAgregarItem.getValueAt(view.tablaAgregarItem.getSelectedRow, 0).toString)
    if(item!=null){
      facturaTemp.eliminarItemFactura(item - 1)
      cargarTablaItems()
    }

  }

  def limpiarFactura():Unit = {
    facturaTemp=null
    view.txtCedulaFactura.setText("")
    view.lblNombreFactura.setText("")
    view.lblTelefonoFactura.setText("")
    view.lblDireccionFactura.setText("")
    view.lblCorreoFactura.setText("")
    val modelo = view.tablaAgregarItem.getModel.asInstanceOf[DefaultTableModel]
    for(i <- 0 until view.tablaAgregarItem.getRowCount)
      modelo.removeRow(0)
  }

  def agregarFactura():Unit = {
      if(ContenedorFactura.buscarFactura(verificarEntero(view.txtNumFactura.getText), modeloFactura.listaFactura)== -1){
        if(!view.lblNombreFactura.getText.equals("")){
          if(!facturaTemp.listaItemFactura.isEmpty){
            modeloFactura.agregarFactura(facturaTemp)
            modeloFactura.guardarFacturas()
            cargarnumFactura()
            obtenerCaja()
            actualizarValorLibro()
            limpiarFactura()
            view.cboTransaccion.setEnabled(true)
          }else{
            JOptionPane.showMessageDialog(null, "INGRESE ITEMS A LA FACTURA", "ERROR", JOptionPane.ERROR_MESSAGE)
          }
        }else{
          JOptionPane.showMessageDialog(null, "INGRESE DATOS DE PERSONA", "ERROR", JOptionPane.ERROR_MESSAGE)
        }
      }else{
        JOptionPane.showMessageDialog(null, "FACTURA YA INGRESADA", "ERROR", JOptionPane.ERROR_MESSAGE)
      }
  }

  def eliminarFactura():Unit = {
    if(!view.txtNumFactura.getText.equals("")){
      val k = ContenedorFactura.buscarFactura(verificarEntero(view.txtNumFactura.getText), modeloFactura.listaFactura)
      if(k != -1){
        actualizacionFacturaEliminada(modeloFactura.listaFactura(k))
        modeloFactura.eliminarFactura(k)
        limpiarFactura()
        obtenerCaja()
      }else{
        JOptionPane.showMessageDialog(null, "NO EXISTE FACTURA", "ERROR", JOptionPane.ERROR_MESSAGE)
      }
    }else{
      JOptionPane.showMessageDialog(null, "INGRESE NUMERO DE FACTURA", "ERROR", JOptionPane.ERROR_MESSAGE)
    }
  }

  def buscarFactura():Unit = {
    facturaTemp = null
    if(!view.txtNumFactura.getText.equals("")){
      val k = ContenedorFactura.buscarFactura(verificarEntero(view.txtNumFactura.getText), modeloFactura.listaFactura)
      if(k!= -1){
        if(modeloFactura.listaFactura(k).tipoFactura.equalsIgnoreCase("compra")){
          val x = ContenedorProveedor.buscarProveedor(modeloFactura.listaFactura(k).cedula, modeloProveedor.ListaProveedores)
          view.txtCedulaFactura.setText(modeloProveedor.ListaProveedores(x).cedula)
          view.lblNombreFactura.setText(modeloProveedor.ListaProveedores(x).nombre)
          view.lblDireccionFactura.setText(modeloProveedor.ListaProveedores(x).direccion)
          view.lblTelefonoFactura.setText(modeloProveedor.ListaProveedores(x).telefono)
          view.lblCorreoFactura.setText(modeloProveedor.ListaProveedores(x).correo)
        }
        if(modeloFactura.listaFactura(k).tipoFactura.equalsIgnoreCase("venta")){
          val x = ContenedorCliente.buscarCliente(modeloFactura.listaFactura(k).cedula, modeloCliente.ListaClientes)
          view.txtCedulaFactura.setText(modeloCliente.ListaClientes(x).cedula)
          view.lblNombreFactura.setText(modeloCliente.ListaClientes(x).nombre)
          view.lblDireccionFactura.setText(modeloCliente.ListaClientes(x).direccion)
          view.lblTelefonoFactura.setText(modeloCliente.ListaClientes(x).telefono)
          view.lblCorreoFactura.setText(modeloCliente.ListaClientes(x).correo)
        }
        facturaTemp = modeloFactura.listaFactura(k)
        view.obtenerFecha.setDate(facturaTemp.fecha)
        view.cboPago.setSelectedItem(facturaTemp.tipoPago)
        view.cboTransaccion.setSelectedItem(facturaTemp.tipoFactura)
        cargarTablaItems()
      }else{
        JOptionPane.showMessageDialog(null, "NO EXISTE FACTURA", "ERROR", JOptionPane.ERROR_MESSAGE)
      }
    }else{
      JOptionPane.showMessageDialog(null, "INGRESE NUMERO DE FACTURA", "ERROR", JOptionPane.ERROR_MESSAGE)
    }
  }

  def obtenerCaja():Unit = {
    var k = 1000000.00
    for (i <- 0 until modeloFactura.listaFactura.length){
      for (j <- 0 until modeloFactura.listaFactura(i).listaItemFactura.length){
        val x = ContenedorLibro.buscarLibro(modeloFactura.listaFactura(i).listaItemFactura(j).ISBN, modeloLibro.Libros)
        if(modeloFactura.listaFactura(i).tipoFactura.equalsIgnoreCase("compra")){
          //println("furgr" + x)
          k = k - (modeloFactura.listaFactura(i).listaItemFactura(j).cantLibro * modeloLibro.Libros(x).precioVenta)
        }
        if (modeloFactura.listaFactura(i).tipoFactura.equalsIgnoreCase("venta")) {
          k = k + (modeloFactura.listaFactura(i).listaItemFactura(j).cantLibro * modeloLibro.Libros(x).precioVenta)
        }
      }
    }
    view.lblCaja.setText("CAJA: "+k.toString)
  }

  def actualizarValorLibro():Unit = {
    for (i <- 0 until facturaTemp.listaItemFactura.length){
      val k = ContenedorLibro.buscarLibro(facturaTemp.listaItemFactura(i).ISBN, modeloLibro.Libros)
      val libroTemp = modeloLibro.Libros(k)
      if(facturaTemp.tipoPago.equalsIgnoreCase("compra")){
        modeloLibro.modificarLibro(libroTemp.ISBN, libroTemp.titulo, libroTemp.precioVenta, libroTemp.precioCompra, libroTemp.cantidad+facturaTemp.listaItemFactura(i).cantLibro, libroTemp.rutaImagen, k)
      }
      if(facturaTemp.tipoPago.equalsIgnoreCase("venta")){
        modeloLibro.modificarLibro(libroTemp.ISBN, libroTemp.titulo, libroTemp.precioVenta, libroTemp.precioCompra, libroTemp.cantidad-facturaTemp.listaItemFactura(i).cantLibro, libroTemp.rutaImagen, k)
      }
    }
    modeloLibro.guardarLibros()
  }

  def actualizacionFacturaEliminada(facturaTemp:Factura):Unit = {
    for (i <- 0 until facturaTemp.listaItemFactura.length) {
      val k = ContenedorLibro.buscarLibro(facturaTemp.listaItemFactura(i).ISBN, modeloLibro.Libros)
      val libroTemp = modeloLibro.Libros(k)
      if (facturaTemp.tipoPago.equalsIgnoreCase("compra")) {
        modeloLibro.modificarLibro(libroTemp.ISBN, libroTemp.titulo, libroTemp.precioVenta, libroTemp.precioCompra, libroTemp.cantidad - facturaTemp.listaItemFactura(i).cantLibro, libroTemp.rutaImagen, k)
      }
      if (facturaTemp.tipoPago.equalsIgnoreCase("venta")) {
        modeloLibro.modificarLibro(libroTemp.ISBN, libroTemp.titulo, libroTemp.precioVenta, libroTemp.precioCompra, libroTemp.cantidad + facturaTemp.listaItemFactura(i).cantLibro, libroTemp.rutaImagen, k)
      }
    }
    modeloLibro.guardarLibros()
  }

  def obtenerTotal(factura:Factura):Double ={
    var k = 0.00
    for(i <- 0 until factura.listaItemFactura.length){
      val x = ContenedorLibro.buscarLibro(factura.listaItemFactura(i).ISBN, modeloLibro.Libros)
      k = k + (factura.listaItemFactura(i).cantLibro * modeloLibro.Libros(x).precioVenta)
    }
    return k
  }

  def mostrarFactura(Facturas: ArrayBuffer[Factura]): Unit = {
    var i = 0
    val modelo = new DefaultTableModel()
    modelo.addColumn("N# FACTURA")
    modelo.addColumn("TIPO")
    modelo.addColumn("CEDULA/RUC")
    modelo.addColumn("FECHA")
    modelo.addColumn("PAGO")
    modelo.addColumn("TOTAL")
    view.tablaProveedores1.setModel(modelo)
    for (i <- 0 until Facturas.length) {
      modelo.insertRow(modelo.getRowCount, new Array[AnyRef](Facturas.length))
      modelo.setValueAt(Facturas(i).numFactura, modelo.getRowCount - 1, 0)
      modelo.setValueAt(Facturas(i).tipoFactura, modelo.getRowCount - 1, 1)
      modelo.setValueAt(Facturas(i).cedula, modelo.getRowCount - 1, 2)
      modelo.setValueAt(Facturas(i).fecha, modelo.getRowCount - 1, 3)
      modelo.setValueAt(Facturas(i).tipoPago, modelo.getRowCount - 1, 4)
      modelo.setValueAt(obtenerTotal(Facturas(i)), modelo.getRowCount - 1, 5)
    }
  }

  def ordenarFacturaAsc(): Unit = {
    val sort = modeloFactura.listaFactura.sortBy(factura => factura.fecha)
    mostrarFactura(sort)
  }

  def ordenarFacturaDesc(): Unit = {
    val sort = modeloFactura.listaFactura.sortBy(factura => factura.fecha)(Ordering[Date].reverse)
    mostrarFactura(sort)
  }

  def reiniciarFactura():Unit = {
    limpiarFactura()
    view.cboTransaccion.setEnabled(true)
  }

  class SelectionChanged extends ListSelectionListener {
    override def valueChanged(e: ListSelectionEvent): Unit = {
      if (view.tablaAgregarItem.getSelectedRow != -1) view.btnEliminarItem.setEnabled(true)
    }
  }

  def actionPerformed(e: ActionEvent): Unit = {
    if (e.getSource eq view.btnAgregarCliente) {agregarCliente()}
    if(e.getSource eq view.btnBuscarCliente){buscarCliente()}
    if(e.getSource eq view.btnModificarCliente){modificarCliente()}
    if(e.getSource eq view.btnEliminarCliente){eliminarCliente()}
    if(e.getSource eq view.btnMostrarClientes){mostrarCliente()}
    if(e.getSource eq view.btnOrdenarAscClientes){ordenarClienteAsc()}
    if(e.getSource eq view.btnOrdenarDescClientes){ordenarClienteDesc()}
    if(e.getSource eq view.btnAgregarProveedor){agregarProveedor()}
    if (e.getSource eq view.btnBuscarProveedor) {buscarProveedor()}
    if (e.getSource eq view.btnModificarProveedor) {modificarProveedor()}
    if (e.getSource eq view.btnEliminarProveedor) {eliminarProveedor()}
    if (e.getSource eq view.btnMostrarProveedores) {mostrarProveedor()}
    if (e.getSource eq view.btnOrdenarAscProveedores) {ordenarProveedorAsc()}
    if (e.getSource eq view.btnOrdenarDescProveedores) {ordenarProveedorDesc()}
    if(e.getSource eq view.btnSeleccionarImagen){cargarImagen()}
    if(e.getSource eq view.btnAgregarLibro){agregarLibro()}
    if(e.getSource eq view.btnBuscarLibro){buscarLibro()}
    if(e.getSource eq view.btnMostrarLibros){mostrarLibro(modeloLibro.Libros)}
    if(e.getSource eq view.btnModificarLibro){modificarLibro()}
    if(e.getSource eq view.btnEliminarLibros){eliminarLibro()}
    if(e.getSource eq view.btnOrdenarAscLibros){ordenarLibroAsc()}
    if(e.getSource eq view.btnOrdenarDescLibros){ordenarLibroDesc()}
    if(e.getSource eq view.btnBuscarCedulaFactura){buscarClienteFactura()}
    if(e.getSource eq view.btnAgregarItem){agregarItemFactura()}
    if(e.getSource eq view.btnEliminarItem){eliminarItemFactura()}
    if(e.getSource eq view.btnAgregarFactura){agregarFactura()}
    if(e.getSource eq view.btnEliminarFactura){eliminarFactura()}
    if(e.getSource eq view.btnBuscarFactura){buscarFactura()}
    if(e.getSource eq view.btnMostrarFacturas){mostrarFactura(modeloFactura.listaFactura)}
    if(e.getSource eq view.btnOrdenarAscFacturas){ordenarFacturaAsc()}
    if(e.getSource eq view.btnOrdenarDescFacturas){ordenarFacturaDesc()}
    if(e.getSource eq view.btnReiniciarFactura){reiniciarFactura()}
  }

}

