package modelo

import java.io.{File, FileInputStream, FileOutputStream, IOException, ObjectInputStream, ObjectOutputStream}
import scala.collection.mutable.ArrayBuffer

class ContenedorCliente{
  var ListaClientes = new ArrayBuffer[Cliente]

  def agregarCliente(cedula: String, nombre: String, direccion: String, telefono: String, correo: String): Unit =
    ListaClientes.append(new Cliente(cedula, nombre, direccion, telefono, correo))

  def modificarCliente(cedula: String, nombre: String, direccion: String, telefono: String, correo: String, posi: Int): Unit = {
    ListaClientes(posi) = new Cliente(cedula, nombre, direccion, telefono, correo)
  }

  def eliminarCliente(posi: Int): Unit = {
    ListaClientes.remove(posi)
  }

  def guardarClientes(): Unit = {
    try {
      val file = new File("./Clientes.dat")
      val oos = new ObjectOutputStream(new FileOutputStream(file))
      oos.writeObject(ListaClientes)
      oos.close()
    } catch {
      case ex: IOException => //println("Error al crear el archivo: " + ex.getMessage)
    }
  }

  def cargarClientes(): Unit = {
    try {
      val file = new File("./Clientes.dat")
      val ois = new ObjectInputStream(new FileInputStream(file))
      ListaClientes = ois.readObject().asInstanceOf[ArrayBuffer[Cliente]]
      ois.close()
    } catch {
      case ex: IOException => //println("Error al crear el archivo: " + ex.getMessage)
    }
  }

}

  object ContenedorCliente {
    def buscarCliente(cedula: String, ListaClientes: ArrayBuffer[Cliente]): Int = {
      for (x <- 0 until ListaClientes.length) {
        if (ListaClientes(x).cedula.equals(cedula)) {
          return x
        }
      }
      return -1
    }
  }
