package modelo

class Persona(
             ccedula: String,
             cnombre: String,
             cdireccion: String,
             ctelefono: String,
             ccorreo: String) extends Serializable{
  var cedula: String =ccedula
  var nombre: String =cnombre
  var direccion: String =cdireccion
  var telefono: String =ctelefono
  var correo: String =ccorreo
}






