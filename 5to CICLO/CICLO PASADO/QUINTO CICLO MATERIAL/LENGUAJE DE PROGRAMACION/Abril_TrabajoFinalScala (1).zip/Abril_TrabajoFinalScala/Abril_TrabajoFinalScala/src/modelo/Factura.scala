package modelo

import java.util.Date
import scala.collection.mutable.ArrayBuffer

class Factura (val numFactura: Int, val tipoFactura:String, val cedula:String, val fecha:Date, val tipoPago:String) extends Serializable {
  var listaItemFactura = new ArrayBuffer[ItemFactura]

  def agregarItemFactura(cantLibro:Int, ISBN:String, iva:Double): Unit = {
    listaItemFactura.append(new ItemFactura(cantLibro, ISBN, iva))
  }

  def eliminarItemFactura(posi:Int):Unit = {
    listaItemFactura.remove(posi)
  }
}

object Factura{
  def buscarItemFactura (ISBN:String, ListaItemFactura: ArrayBuffer[ItemFactura]): Unit = {
    for(x <- 0 until ListaItemFactura.length){
      if (ListaItemFactura(x).ISBN.equals(ISBN)) {
        return x
      }
    }
    return - 1
  }
}
