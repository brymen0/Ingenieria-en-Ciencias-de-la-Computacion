package modelo

import java.io.{File, FileInputStream, FileOutputStream, IOException, ObjectInputStream, ObjectOutputStream}
import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

class ContenedorProveedor{
  var ListaProveedores = new ArrayBuffer[Proveedor]

  def agregarProveedor(cedula:String, nombre:String, direccion:String, telefono:String, correo:String): Unit=
    ListaProveedores.append(new Proveedor(cedula, nombre, direccion, telefono, correo))

  def modificarProveedor(cedula:String,nombre:String, direccion:String, telefono:String, correo:String, posi:Int): Unit= {
    ListaProveedores(posi) = new Proveedor(cedula, nombre, direccion, telefono, correo)
  }

  def eliminarProveedor(posi:Int): Unit={
    ListaProveedores.remove(posi)
  }

  def guardarProveedores(): Unit = {
    try {
      val file = new File("./Proveedores.dat")
      val oos = new ObjectOutputStream(new FileOutputStream(file))
      oos.writeObject(ListaProveedores)
      oos.close()
    } catch {
      case ex: IOException => //println("Error al crear el archivo: " + ex.getMessage)
    }
  }

  def cargarProveedores(): Unit = {
    try {
      val file = new File("./Proveedores.dat")
      val ois = new ObjectInputStream(new FileInputStream(file))
      ListaProveedores = ois.readObject().asInstanceOf[ArrayBuffer[Proveedor]]
      ois.close()
    } catch {
      case ex: IOException => //println("Error al crear el archivo: " + ex.getMessage)
    }
  }

}

object ContenedorProveedor {
  def buscarProveedor(cedula: String, ListaProveedores:ArrayBuffer[Proveedor]): Int =
  {
    for (x <- 0 until ListaProveedores.length) {
      if (ListaProveedores(x).cedula.equals(cedula)) {
        return x
      }
    }
    return -1
  }
}