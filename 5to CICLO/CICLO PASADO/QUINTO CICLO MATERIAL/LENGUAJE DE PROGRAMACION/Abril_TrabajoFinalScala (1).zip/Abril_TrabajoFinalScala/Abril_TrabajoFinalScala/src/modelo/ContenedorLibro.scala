package modelo

import java.io.{File, FileInputStream, FileOutputStream, IOException, ObjectInputStream, ObjectOutputStream}
import scala.collection.mutable.ArrayBuffer

class ContenedorLibro{
    var Libros = new ArrayBuffer[Libro]

    def agregarLibro(ISBN: String, titulo: String, precioVenta:Float, precioCompra:Float, cantidad:Int, rutaImagen:String): Unit={
      Libros.append(new Libro(ISBN, titulo, precioVenta, precioCompra, cantidad, rutaImagen))
    }

    def modificarLibro(ISBN: String, titulo: String, precioVenta:Float, precioCompra:Float, cantidad:Int, rutaImagen:String, posi:Int): Unit={
      Libros(posi) = new Libro(ISBN, titulo, precioVenta,precioCompra, cantidad, rutaImagen)
    }

    def eliminarLibro(posi:Int):Unit={
      Libros.remove(posi)
    }

  def guardarLibros(): Unit = {
    try {
      val file = new File("./Libros.dat")
      val oos = new ObjectOutputStream(new FileOutputStream(file))
      oos.writeObject(Libros)
      oos.close()
    } catch {
      case ex: IOException => //println("Error al crear el archivo: " + ex.getMessage)
    }
  }

  def cargarLibros(): Unit = {
    try {
      val file = new File("./Libros.dat")
      val ois = new ObjectInputStream(new FileInputStream(file))
      Libros = ois.readObject().asInstanceOf[ArrayBuffer[Libro]]
      ois.close()
    } catch {
      case ex: IOException => //println("Error al crear el archivo: " + ex.getMessage)
    }
  }

  def mostrarMasCostoso(): Libro = {
    val float = Libros.map(_.precioVenta).max
    return Libros(ContenedorLibro.buscarLibroPrecio(float, Libros))
  }

  def mostrarMenosCostoso(): Libro = {
    val float = Libros.map(_.precioVenta).min
    return Libros(ContenedorLibro.buscarLibroPrecio(float, Libros))
  }

}

object ContenedorLibro {
  def buscarLibro(ISBN: String, Libros: ArrayBuffer[Libro]): Int = {
    for (x <- 0 until Libros.length) {
      if (Libros(x).ISBN.equalsIgnoreCase(ISBN)) {
        return x
      }
    }
    return -1
  }

  def buscarLibroporTitulo(ISBN: String, Libros: ArrayBuffer[Libro]): Int = {
    for (x <- 0 until Libros.length) {
      if (Libros(x).titulo.equalsIgnoreCase(ISBN)) {
        return x
      }
    }
    return -1
  }

  def buscarLibroPrecio(precio: Float, Libros: ArrayBuffer[Libro]): Int = {
    for (x <- 0 until Libros.length) {
      if (Libros(x).precioVenta == precio) {
        return x
      }
    }
    return -1
  }
}


