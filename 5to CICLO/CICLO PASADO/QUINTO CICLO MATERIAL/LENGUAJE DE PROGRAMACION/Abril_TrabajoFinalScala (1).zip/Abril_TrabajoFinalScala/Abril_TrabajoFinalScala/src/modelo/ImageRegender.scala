package modelo
import javax.swing._
import javax.swing.table._
import java.awt._

class ImageRenderer extends TableCellRenderer {
  val lbl = new JLabel
  lbl.setOpaque(true) // para evitar problemas con la selección de celda

  override def getTableCellRendererComponent(table: JTable, value: Any, isSelected: Boolean, hasFocus: Boolean, row: Int, column: Int): Component = {
    value match {
      case icon: ImageIcon =>
        val width = table.getColumnModel().getColumn(column).getWidth() - table.getIntercellSpacing().width
        val height = table.getRowHeight(row) - table.getIntercellSpacing().height
        val scaledIcon = new ImageIcon(icon.getImage.getScaledInstance(width, height, java.awt.Image.SCALE_SMOOTH))
        lbl.setIcon(scaledIcon)
        lbl.setSize(new Dimension(width, height))
      case _ =>
    }
    lbl
  }
}