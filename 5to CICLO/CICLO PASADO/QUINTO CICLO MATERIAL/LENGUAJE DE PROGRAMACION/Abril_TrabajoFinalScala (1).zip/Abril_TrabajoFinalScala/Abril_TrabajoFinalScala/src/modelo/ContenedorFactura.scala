package modelo

import java.io.{File, FileInputStream, FileOutputStream, IOException, ObjectInputStream, ObjectOutputStream}
import java.util.Date
import scala.collection.mutable.ArrayBuffer

class ContenedorFactura{
  var listaFactura = new ArrayBuffer[Factura]

  def agregarFactura(factura: Factura):Unit = {
    listaFactura.append(factura)
  }

  def agregarItem(cantLibro:Int, ISBN:String, iva:Float, posi:Int):Unit = {
    listaFactura(posi).agregarItemFactura(cantLibro, ISBN, iva)
  }

  def eliminarItem(posiFactura: Int, posiItem:Int): Unit = {
    listaFactura(posiFactura).eliminarItemFactura(posiItem)
  }

  def eliminarFactura(posi:Int):Unit = {
    listaFactura.remove(posi)
  }

  def modificarFactura(numFactura:Int, tipoFactura:String, cedula:String, fecha:Date, tipoPago:String,posi:Int):Unit = {
    listaFactura(posi) = new Factura(numFactura, tipoFactura, cedula, fecha, tipoPago)
  }

  def guardarFacturas(): Unit = {
    try {
      val file = new File("./Facturas.dat")
      val oos = new ObjectOutputStream(new FileOutputStream(file))
      oos.writeObject(listaFactura)
      oos.close()
    } catch {
      case ex: IOException => //println("Error al crear el archivo: " + ex.getMessage)
    }
  }

  def cargarFacturas(): Unit = {
    try {
      val file = new File("./Facturas.dat")
      val ois = new ObjectInputStream(new FileInputStream(file))
      listaFactura = ois.readObject().asInstanceOf[ArrayBuffer[Factura]]
      ois.close()
    } catch {
      case ex: IOException => //println("Error al crear el archivo: " + ex.getMessage)
    }
  }

}
object ContenedorFactura{
  def buscarFactura(numFactura: Int, Facturas: ArrayBuffer[Factura]): Int = {
    for (x <- 0 until Facturas.length) {
      if (Facturas(x).numFactura == numFactura) {
        return x
      }
    }
    return -1
  }
}