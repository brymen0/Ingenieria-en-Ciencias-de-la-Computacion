from modelo.Persona import Persona
import pickle
class Cliente(Persona):
    pass

class ContenedorCliente():
    def __init__(self):
        self.listaClientes = []

    def agregarCliente(self, cedula, nombre, direccion, telefono, correo):
        self.listaClientes.append(Cliente(cedula, nombre, direccion, telefono,correo))

    def modificarCliente(self, cedula, nombre, direccion, telefono, correo, k):
        self.listaClientes[k] = Cliente(cedula, nombre, direccion, telefono, correo)

    def eliminarCliente(self, k):
        self.listaClientes.pop(k)

    def guardarCliente(self):
        try:
            with open ("Clientes.dat", "wb") as f:
                pickle.dump(self.listaClientes,f)
                f.close()
        except:
            print("No se ha podido guardar Clientes")

    def cargarCliente(self):
        try:
            with open ("Clientes.dat", "rb") as f:
                self.listaClientes = pickle.load(f)
                f.close()
        except:
            print("No existen datos para cargar")
    def buscarCliente(self, cedula):
        for k in range(len(self.listaClientes)):
            if self.listaClientes[k].cedula == cedula:
                return k
        return -1
    def mostrarCliente(self):
        print("\t\tLista de Clientes")
        for k in range(len(self.listaClientes)):
            print("Cedula: ", self.listaClientes[k].cedula,
                  " Nombre: ", self.listaClientes[k].nombre,
                  " Direccion: ", self.listaClientes[k].direccion,
                  " Telefono: ", self.listaClientes[k].telefono,
                  " Correo: ", self.listaClientes[k].correo)
