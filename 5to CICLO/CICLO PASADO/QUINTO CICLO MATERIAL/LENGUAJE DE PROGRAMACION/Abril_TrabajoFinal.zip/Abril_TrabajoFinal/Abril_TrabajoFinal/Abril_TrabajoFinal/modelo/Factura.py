import pickle
class ItemFactura(object):
    def __init__(self, cantLibro, ISBN, IVA):
        self.cantLibro = cantLibro
        self.ISBN = ISBN
        self.IVA = IVA

class Factura(object):
    def __init__(self, numeroFactura, tipoFactura, cedula, fecha, tipoPago):
        self.numeroFactura = numeroFactura
        self.tipoFactura = tipoFactura
        self.cedula = cedula
        self.fecha = fecha
        self.tipoPago = tipoPago
        self.listaItemFactura = []

    def agregarItemFactura(self, cantLibro, ISBN, IVA):
        self.listaItemFactura.append([cantLibro, ISBN, IVA])

    def modificarItemFactura(self, cantLibro, ISBN, IVA, posi):
        self.listaItemFactura[posi] = [cantLibro, ISBN, IVA]

    def eliminarItemFactura(self, posi):
        self.listaItemFactura.pop(posi)

    def buscarItemFactura(self, ISBN):
        for k in range(len(self.listaItemFactura)):
            if self.listaItemFactura[k][1] == ISBN:
                return k
        return -1

    def mostrarFactura(self):
        print("DETALLE DE LA FACTURA")
        for k in range(len(self.listaItemFactura)):
            print("ISBN: ", self.listaItemFactura[k][1], " Cant: ", self.listaItemFactura[k][0])

    def calcularTotal(self):
        return sum(self.listaItemFactura[k][1] + (self.listaItemFactura[k][1] * self.listaItemFactura[k][1])  for k in range(len(self.listaItemFactura)))


class ContenedorFactura():
    def __init__(self):
            self.listaFactura = []

    def agregarFactura(self, factura):
            self.listaFactura.append(factura)

    def agregarItem(self, cantLibro, ISBN, IVA, posi):
            self.listaFactura[posi].agregarItemFactura(cantLibro, ISBN, IVA)

    def mostrarFactura(self):
            print("***************************************************")
            print(" \t\t Lista de Facturas Almacenadas")
            print("***************************************************")
            for k in range(len(self.listaFactura)):
                print("Num. ", self.listaFactura[k].numeroFactura)
                print("***************************************************")
                self.listaFactura[k].mostrarFactura()
                print("***************************************************")
    def modificarFactura(self, numFactura, posi):
            self.listaFactura[self.listaFactura.index(numFactura)].modificarItemFactura(posi)

    def eliminarFactura(self, posi):
            self.listaFactura.pop(posi)
    def guardarFactura(self):
        try:
            with open ("Facturas.dat", "wb") as f:
                pickle.dump(self.listaFactura,f)
                f.close()
        except:
            print("No existen datos para guardar")


    def cargarFactura(self):
        try:
            with open ("Facturas.dat", "rb") as f:
                self.listaFactura = pickle.load(f)
                f.close()
        except:
            print("No existen datos para cargar")

    def buscarFactura(self, numFactura):
        for k in range(len(self.listaFactura)):
            if self.listaFactura[k].numeroFactura == numFactura:
                return k
        return -1

    def masTransacciones(self, ISBN):
        for k in range(len(self.listaFactura)):

            print()

    def masVendido(self, ISBN):
            print()