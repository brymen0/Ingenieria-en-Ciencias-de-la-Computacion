import pickle

class ContenedorLibro(object):
    def __init__(self):
        self.libros = dict()

    def agregarLibro(self, libro):
        self.libros.setdefault(libro.isbn, [libro.titulo, libro.precioVenta, libro.precioCompra, libro.cant, libro.rutaImagen])

    def eliminarLibro(self, isbn):
            self.libros.pop(isbn)
    def modificarLibro(self, libro):
            self.libros[libro.isbn] = [libro.titulo, libro.precioVenta, libro.precioCompra, libro.cant, libro.rutaImagen]
    def buscarLibroporISBN(self, isbn):
        for k in self.libros.keys():
            if k == isbn:
                return k
        return -1

    def buscarLibroporTitulo(self, titulo):
        for k in self.libros.keys():
            if self.libros[k][0] == titulo:
                return k
        return -1
    def masCostoso(self):
        listPrecios = []
        for k in self.libros.keys():
            listPrecios.append(self.libros[k][1])
        for k in self.libros.keys():
            if self.libros[k][1] == max(listPrecios):
                return k
    def menosCostoso(self):
        listPrecios = []
        for k in self.libros.keys():
            listPrecios.append(self.libros[k][1])
        for k in self.libros.keys():
            if self.libros[k][1] == min(listPrecios):
                return k
    def mostrarLibros(self):
        print("\t\tAlmacen de Libros")
        for k in self.libros.keys():
            print("ISBN: ", k, " Titulo: ", self.libros[k][0], " Precio Venta: ", self.libros[k][1], " Precio Compra: ", self.libros[k][2], " Cantidad: ", self.libros[k][3])
    def guardarLibro(self):
        with open ("Libros.dat", "wb") as f:
            pickle.dump(self.libros,f)
            f.close()

    def cargarLibro(self):
        try:
            with open ("Libros.dat", "rb") as f:
                self.libros = pickle.load(f)
                f.close()
        except:
            print("No existen datos para cargar")


