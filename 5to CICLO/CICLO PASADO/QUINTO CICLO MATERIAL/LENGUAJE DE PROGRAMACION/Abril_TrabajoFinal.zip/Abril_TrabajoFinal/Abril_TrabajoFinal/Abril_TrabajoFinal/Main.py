import sys
from PyQt6 import QtCore, QtWidgets
from controlador.ControladorPrincipal import *

app = QtWidgets.QApplication(sys.argv)
myApp = Principal()
myApp.show()
app.exec()

