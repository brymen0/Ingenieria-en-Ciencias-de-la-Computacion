import os
from os.path import basename, join
from shutil import copyfile
import datetime
from PyQt6.QtGui import QIcon, QPixmap
from PyQt6.QtCore import QEasingCurve,QPropertyAnimation
from PyQt6.QtWidgets import *
import sys
from vista.VentanaPrincipal import Ui_MainWindow
from vista.resources import *
from modelo.Libro import *
from modelo.Cliente import *
from modelo.ContenedorLibro import *
from modelo.Proveedor import *
from modelo.Factura import *
class Principal(QMainWindow):

    def __init__(self):
        self.rutaImagen = ""
        super().__init__()
        self.ui=Ui_MainWindow()
        self.ui.setupUi(self)
        self.modeloLibro = ContenedorLibro()
        self.modeloCliente = ContenedorCliente()
        self.modeloProveedor = ContenedorProveedor()
        self.modeloFactura = ContenedorFactura()
        self.ui.btnLibros.clicked.connect(lambda: self.ui.stackedWidget.setCurrentWidget(self.ui.pageLibros))
        self.ui.btnClientes.clicked.connect(lambda: self.ui.stackedWidget.setCurrentWidget(self.ui.pageClientes))
        self.ui.btnProveedores.clicked.connect(lambda: self.ui.stackedWidget.setCurrentWidget(self.ui.pageProveedores))
        self.ui.btnTrans.clicked.connect(lambda: self.ui.stackedWidget.setCurrentWidget(self.ui.pageTrans))
        self.ui.btnVolver.clicked.connect(lambda: self.ui.stackedWidget.setCurrentWidget(self.ui.pagePrincipal))
        self.ui.btnVolver_2.clicked.connect(lambda: self.ui.stackedWidget.setCurrentWidget(self.ui.pagePrincipal))
        self.ui.btnVolver_3.clicked.connect(lambda: self.ui.stackedWidget.setCurrentWidget(self.ui.pagePrincipal))
        self.ui.btnVolver_4.clicked.connect(lambda: self.ui.stackedWidget.setCurrentWidget(self.ui.pagePrincipal))
        self.ui.btnSeleccionarImagen.clicked.connect(self.buscarImagen)
        self.ui.btnMenu.clicked.connect(self.expandir)
        self.ui.btnAgregarLib.clicked.connect(self.agregarLibro)
        self.ui.btnEliminarLib.clicked.connect(self.eliminarLibro)
        self.ui.btnBuscarLibro.clicked.connect(self.buscarLibro)
        self.ui.btnModificarLib.clicked.connect(self.modificarLibro)
        self.ui.btnMasCost.clicked.connect(self.masCostoso)
        self.ui.btnMenosCost.clicked.connect(self.menosCostoso)
        self.ui.btnMasVendido.clicked.connect(self.masVendido)
        self.ui.btnMasTrans.clicked.connect(self.masTransaccionado)
        self.ui.btnAgregarCliente.clicked.connect(self.agregarCliente)
        self.ui.btnBuscarCliente.clicked.connect(self.buscarCliente)
        self.ui.btnEliminarCliente.clicked.connect(self.eliminarCliente)
        self.ui.btnModificarCliente.clicked.connect(self.modificarCliente)
        self.ui.btnAgregarProveedor.clicked.connect(self.agregarProveedor)
        self.ui.btnBuscarProveedor.clicked.connect(self.buscarProveedor)
        self.ui.btnEliminarProveedor.clicked.connect(self.eliminarProveedor)
        self.ui.btnModificarProveedor.clicked.connect(self.modificarProveedor)
        self.ui.btnMostrarLibros.clicked.connect(self.cargarTablaLibros)
        self.ui.btnBuscarPersona.clicked.connect(self.buscarPersona)
        self.ui.dateFactura.setDate(datetime.datetime.now().date())
        self.modeloCliente.cargarCliente()
        self.modeloProveedor.cargarProveedor()
        self.modeloLibro.cargarLibro()
        self.modeloFactura.cargarFactura()
        self.ui.txtNumFactura.setText(str(len(self.modeloFactura.listaFactura)+1))
        self.ui.btnComprarLibro.clicked.connect(self.agregarItem)
        self.factura = Factura
        self.ui.btnAgregarFactura.clicked.connect(self.agregarFactura)
        self.ui.btnBuscarFactura.clicked.connect(self.buscarFactura)
        self.ui.btnEliminarFactura.clicked.connect(self.eliminarFactura)
        self.ui.btnEliminarItem.clicked.connect(self.eliminarItem)
        self.ui.btnMostrarClientes.clicked.connect(self.cargarTablaClientes)
        self.ui.btnMostraProveedores.clicked.connect(self.cargarTablaProveedores)
        self.ui.btnMostrarFactura.clicked.connect(self.cargarTablaFacturas)
        self.ui.btnOrdenarAscLibros.clicked.connect(self.cargarTablaLibrosOrdAsc)
        self.ui.btnOrdenarDescLibros.clicked.connect(self.cargarTablaLibrosOrdDesc)
        self.ui.btnOrdenarAscClientes.clicked.connect(self.cargarTablaClientesOrdAsc)
        self.ui.btnOrdenarDescClientes.clicked.connect(self.cargarTablaClientesOrdDesc)
        self.ui.btnOrdenarAscProveedores.clicked.connect(self.cargarTablaProveedoresOrdAsc)
        self.ui.btnOrdenarDescProveedores.clicked.connect(self.cargarTablaProveedoresOrdDesc)
        self.ui.btnOrdenarAscFacturas.clicked.connect(self.cargarTablaFacturasOrdAsc)
        self.ui.btnOrdenarDescFacturas.clicked.connect(self.cargarTablaFacturasOrdDesc)
        self.cargarComboLibros()
        self.leerTransacciones(self)

    @staticmethod
    def inputFloat(mensaje):
        try:
            float(mensaje)
            if float(mensaje)>0:
                return float(mensaje)
            else:
                return -1
        except:
            return -1

    @staticmethod
    def inputEntero(mensaje):
        if mensaje.isnumeric() and int(mensaje)>0:
            return int(mensaje)
        else:
            return -1
    @staticmethod
    def limpiarCamposLibro(self):
        self.ui.txtISBN.clear()
        self.ui.txtTitulo.clear()
        self.ui.txtPrecioVent.clear()
        self.ui.txtPrecioComp.clear()
        self.ui.txtCant.clear()
        self.ui.lblImagenLibro.clear()

    @staticmethod
    def limpiarCamposCliente(self):
        self.ui.txtCedulaCliente.clear()
        self.ui.txtNombreCliente.clear()
        self.ui.txtDireccionCliente.clear()
        self.ui.txtTelfCliente.clear()
        self.ui.txtCorreoCliente.clear()

    @staticmethod
    def limpiarCamposProveedor(self):
        self.ui.txtCedulaProveedor.clear()
        self.ui.txtNombreProveedor.clear()
        self.ui.txtDireccionProveedor.clear()
        self.ui.txtTelfProveedor.clear()
        self.ui.txtCorreoProveedor.clear()

    def agregarLibro(self):
        if not self.ui.lblImagenLibro.pixmap().isNull():
            if self.ui.txtISBN.text() and self.ui.txtTitulo.text() and self.ui.txtPrecioComp.text() and self.ui.txtPrecioVent.text() and self.ui.txtCant.text():
                precioVenta = Principal.inputFloat(self.ui.txtPrecioVent.text())
                precioCompra = Principal.inputFloat(self.ui.txtPrecioComp.text())
                cantidad = Principal.inputEntero(self.ui.txtCant.text())
                if precioVenta!=-1 and precioCompra !=-1 and cantidad!=-1:
                    self.modeloLibro.agregarLibro(Libro(self.ui.txtISBN.text(),
                                                        self.ui.txtTitulo.text(),
                                                        precioVenta,
                                                        precioCompra,
                                                        cantidad,
                                                        self.rutaImagen))
                    self.modeloLibro.guardarLibro()
                    Principal.limpiarCamposLibro(self)
                    self.cargarComboLibros()
                else:
                    QMessageBox.critical(None, "ERROR", "Precio y Cantidad debe ser un valor numérico")
            else:
                QMessageBox.critical(None, "ERROR", "Ingrese TODOS los datos del Libro")
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese una Imagen para Libro")

    @staticmethod
    def validarCedula(self, cedula):
        valID= lambda id: sum([int(id[i]) if i%2 != 0 else int(id[i])*2 if int(id[i])*2<9 else int(id[i])*2-9 for i in range(len(id))])%10 ==0 and len(id) == 10
        if valID(cedula) == False:
            return False
        return True

    @staticmethod
    def verificar(self, nro):
        l = len(nro)
        if l == 10 or l == 13: # verificar la longitud correcta
            cp = int(nro[0:2])
            if cp >= 1 and cp <= 22: # verificar codigo de provincia
                tercer_dig = int(nro[2])
                if tercer_dig >= 0 and tercer_dig < 6 : # numeros enter 0 y 6
                    if l == 10:
                        return Principal.__validar_ruc(self, nro,0)
                    elif l == 13:
                        return Principal.__validar_ruc(self, nro,0) and nro[10:13] != '000' # se verifica q los ultimos numeros no sean 000
                elif tercer_dig == 6:
                    return Principal.__validar_ruc(self, nro,1) # sociedades publicas
                elif tercer_dig == 9: # si es ruc
                    return Principal.__validar_ruc(self, nro,2) # sociedades privadas
                else:
                    raise Exception(u'Tercer digito invalido')
            else:
                raise Exception(u'Codigo de provincia incorrecto')
        else:
            raise Exception(u'Longitud incorrecta del numero ingresado')

    @staticmethod
    def __validar_ruc(self, nro, tipo):
        total = 0
        if tipo == 0: # cedula y r.u.c persona natural
            base = 10
            d_ver = int(nro[9])# digito verificador
            multip = (2, 1, 2, 1, 2, 1, 2, 1, 2)
        elif tipo == 1: # r.u.c. publicos
            base = 11
            d_ver = int(nro[8])
            multip = (3, 2, 7, 6, 5, 4, 3, 2 )
        elif tipo == 2: # r.u.c. juridicos y extranjeros sin cedula
            base = 11
            d_ver = int(nro[9])
            multip = (4, 3, 2, 7, 6, 5, 4, 3, 2)
        for i in range(0,len(multip)):
            p = int(nro[i]) * multip[i]
            if tipo == 0:
                total+=p if p < 10 else int(str(p)[0])+int(str(p)[1])
            else:
                total+=p
        mod = total % base
        val = base - mod if mod != 0 else 0
        return val == d_ver

    def eliminarLibro(self):
        if self.ui.txtISBN.text():
            k = self.modeloLibro.buscarLibroporISBN(self.ui.txtISBN.text())
            if k!=-1:
                m = QMessageBox.question(None, "Sistema Gestión librería", "¿Está seguro de Eliminar?")
                if m == QMessageBox.StandardButton.Yes:
                    self.modeloLibro.eliminarLibro(self.ui.txtISBN.text())
                    self.modeloLibro.guardarLibro()
                    Principal.limpiarCamposLibro(self)
                    self.cargarComboLibros()
            else:
                QMessageBox.critical(None, "ERROR", "El libro NO EXISTE")
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese codigo ISBN")
    def masCostoso(self):
        if self.modeloLibro.libros:
            k = self.modeloLibro.masCostoso()
            self.ui.txtISBN.setText(str(k))
            self.ui.txtTitulo.setText(str(self.modeloLibro.libros[k][0]))
            self.ui.txtPrecioVent.setText(str(self.modeloLibro.libros[k][1]))
            self.ui.txtPrecioComp.setText(str(self.modeloLibro.libros[k][2]))
            self.ui.txtCant.setText(str(self.modeloLibro.libros[k][3]))
            self.ui.lblImagenLibro.setPixmap(QPixmap(self.modeloLibro.libros[k][4]))
            self.ui.lblImagenLibro.setScaledContents(True)
        else:
            QMessageBox.critical(None, "ERROR", "No hay Libros Agregados")

    def menosCostoso(self):
        if self.modeloLibro.libros:
            k = self.modeloLibro.menosCostoso()
            self.ui.txtISBN.setText(str(k))
            self.ui.txtTitulo.setText(str(self.modeloLibro.libros[k][0]))
            self.ui.txtPrecioVent.setText(str(self.modeloLibro.libros[k][1]))
            self.ui.txtPrecioComp.setText(str(self.modeloLibro.libros[k][2]))
            self.ui.txtCant.setText(str(self.modeloLibro.libros[k][3]))
            self.ui.lblImagenLibro.setPixmap(QPixmap(self.modeloLibro.libros[k][4]))
            self.ui.lblImagenLibro.setScaledContents(True)
        else:
            QMessageBox.critical(None, "ERROR", "No hay Libros Agregados")
    def masVendido(self):
        listaVendidos = []
        if self.modeloFactura.listaFactura:
            for k in range(len(self.modeloFactura.listaFactura)):
                if(self.modeloFactura.listaFactura[k].tipoFactura=="Venta"):
                    for x in range(len(self.modeloFactura.listaFactura[k].listaItemFactura)):
                        listaVendidos.append(self.modeloFactura.listaFactura[k].listaItemFactura[x][1])
            k = max(listaVendidos, key=listaVendidos.count)
            k = self.modeloLibro.menosCostoso()
            self.ui.txtISBN.setText(str(k))
            self.ui.txtTitulo.setText(str(self.modeloLibro.libros[k][0]))
            self.ui.txtPrecioVent.setText(str(self.modeloLibro.libros[k][1]))
            self.ui.txtPrecioComp.setText(str(self.modeloLibro.libros[k][2]))
            self.ui.txtCant.setText(str(self.modeloLibro.libros[k][3]))
            self.ui.lblImagenLibro.setPixmap(QPixmap(self.modeloLibro.libros[k][4]))
            self.ui.lblImagenLibro.setScaledContents(True)
        else:
            QMessageBox.critical(None, "ERROR", "No hay Libros Agregados")

    def masTransaccionado(self):
        listaVendidos = []
        if self.modeloFactura.listaFactura:
            for k in range(len(self.modeloFactura.listaFactura)):
                for x in range(len(self.modeloFactura.listaFactura[k].listaItemFactura)):
                    listaVendidos.append(self.modeloFactura.listaFactura[k].listaItemFactura[x][1])
            k = max(listaVendidos, key=listaVendidos.count)
            k = self.modeloLibro.menosCostoso()
            self.ui.txtISBN.setText(str(k))
            self.ui.txtTitulo.setText(str(self.modeloLibro.libros[k][0]))
            self.ui.txtPrecioVent.setText(str(self.modeloLibro.libros[k][1]))
            self.ui.txtPrecioComp.setText(str(self.modeloLibro.libros[k][2]))
            self.ui.txtCant.setText(str(self.modeloLibro.libros[k][3]))
            self.ui.lblImagenLibro.setPixmap(QPixmap(self.modeloLibro.libros[k][4]))
            self.ui.lblImagenLibro.setScaledContents(True)
        else:
            QMessageBox.critical(None, "ERROR", "No hay Libros Agregados")

    def buscarLibro(self):
        if self.ui.txtISBN.text():
            k = self.modeloLibro.buscarLibroporISBN(self.ui.txtISBN.text())
            if k!=-1:
                self.ui.txtISBN.setText(str(k))
                self.ui.txtTitulo.setText(str(self.modeloLibro.libros[k][0]))
                self.ui.txtPrecioVent.setText(str(self.modeloLibro.libros[k][1]))
                self.ui.txtPrecioComp.setText(str(self.modeloLibro.libros[k][2]))
                self.ui.txtCant.setText(str(self.modeloLibro.libros[k][3]))
                self.ui.lblImagenLibro.setPixmap(QPixmap(self.modeloLibro.libros[k][4]))
                self.ui.lblImagenLibro.setScaledContents(True)
            else:
                QMessageBox.critical(None, "ERROR", "El libro NO EXISTE")
        elif self.ui.txtTitulo.text():
            k = self.modeloLibro.buscarLibroporTitulo(self.ui.txtTitulo.text())
            if k!=-1:
                self.ui.txtISBN.setText(str(k))
                self.ui.txtTitulo.setText(str(self.modeloLibro.libros[k][0]))
                self.ui.txtPrecioVent.setText(str(self.modeloLibro.libros[k][1]))
                self.ui.txtPrecioComp.setText(str(self.modeloLibro.libros[k][2]))
                self.ui.txtCant.setText(str(self.modeloLibro.libros[k][3]))
                self.ui.lblImagenLibro.setPixmap(QPixmap(self.modeloLibro.libros[k][4]))
                self.ui.lblImagenLibro.setScaledContents(True)
            else:
                QMessageBox.critical(None, "ERROR", "El libro NO EXISTE")
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese Datos Primero")
        return -1

    def cargarTablaLibros(self):
        self.ui.tabVerLibros.clearContents()
        self.ui.tabVerLibros.setRowCount(0)
        if self.modeloLibro.libros:
            fila=0
            for i in self.modeloLibro.libros.keys():
                label = QLabel()
                self.ui.tabVerLibros.insertRow(fila)
                self.ui.tabVerLibros.setItem(fila, 0, QTableWidgetItem(str(i)))
                self.ui.tabVerLibros.setItem(fila, 1, QTableWidgetItem(str(self.modeloLibro.libros[i][0])))
                self.ui.tabVerLibros.setItem(fila, 2, QTableWidgetItem(str(self.modeloLibro.libros[i][1])))
                self.ui.tabVerLibros.setItem(fila, 3, QTableWidgetItem(str(self.modeloLibro.libros[i][2])))
                self.ui.tabVerLibros.setItem(fila, 4, QTableWidgetItem(str(self.modeloLibro.libros[i][3])))
                label.setPixmap(QPixmap(self.modeloLibro.libros[i][4]).scaled(100,100))
                self.ui.tabVerLibros.setCellWidget(fila, 5, label)
                fila = fila+1
            self.ui.tabVerLibros.resizeRowsToContents()
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese Libros")

    def cargarTablaLibrosOrdAsc(self):
        self.ui.tabVerLibros.clearContents()
        self.ui.tabVerLibros.setRowCount(0)
        sorted_Libros = dict(sorted(self.modeloLibro.libros.items(), key=lambda item:item[1][0]))
        if self.modeloLibro.libros:
            fila=0
            for i in sorted_Libros.keys():
                label = QLabel()
                self.ui.tabVerLibros.insertRow(fila)
                self.ui.tabVerLibros.setItem(fila, 0, QTableWidgetItem(i))
                self.ui.tabVerLibros.setItem(fila, 1, QTableWidgetItem(str(sorted_Libros[i][0])))
                self.ui.tabVerLibros.setItem(fila, 2, QTableWidgetItem(str(sorted_Libros[i][1])))
                self.ui.tabVerLibros.setItem(fila, 3, QTableWidgetItem(str(sorted_Libros[i][2])))
                self.ui.tabVerLibros.setItem(fila, 4, QTableWidgetItem(str(sorted_Libros[i][3])))
                label.setPixmap(QPixmap(sorted_Libros[i][4]).scaled(100,100))
                self.ui.tabVerLibros.setCellWidget(fila, 5, label)
                fila = fila+1
            self.ui.tabVerLibros.resizeRowsToContents()
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese Libros")

    def cargarTablaLibrosOrdDesc(self):
        self.ui.tabVerLibros.clearContents()
        self.ui.tabVerLibros.setRowCount(0)
        sorted_Libros = dict(sorted(self.modeloLibro.libros.items(), key=lambda item:item[1][0], reverse=True))
        if self.modeloLibro.libros:
            fila=0
            for i in sorted_Libros.keys():
                label = QLabel()
                self.ui.tabVerLibros.insertRow(fila)
                self.ui.tabVerLibros.setItem(fila, 0, QTableWidgetItem(i))
                self.ui.tabVerLibros.setItem(fila, 1, QTableWidgetItem(str(sorted_Libros[i][0])))
                self.ui.tabVerLibros.setItem(fila, 2, QTableWidgetItem(str(sorted_Libros[i][1])))
                self.ui.tabVerLibros.setItem(fila, 3, QTableWidgetItem(str(sorted_Libros[i][2])))
                self.ui.tabVerLibros.setItem(fila, 4, QTableWidgetItem(str(sorted_Libros[i][3])))
                label.setPixmap(QPixmap(sorted_Libros[i][4]).scaled(100,100))
                self.ui.tabVerLibros.setCellWidget(fila, 5, label)
                fila = fila+1
            self.ui.tabVerLibros.resizeRowsToContents()
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese Libros")

    def modificarLibro(self):
        if not self.ui.lblImagenLibro.pixmap().isNull():
            if self.ui.txtISBN.text() and self.ui.txtTitulo.text() and self.ui.txtPrecioComp.text() and self.ui.txtPrecioVent.text() and self.ui.txtCant.text():
                precioVenta = Principal.inputFloat(self.ui.txtPrecioVent.text())
                precioCompra = Principal.inputFloat(self.ui.txtPrecioComp.text())
                cantidad = Principal.inputEntero(self.ui.txtCant.text())
                if precioVenta!=-1 and precioCompra !=-1 and cantidad!=-1:
                    if self.modeloLibro.buscarLibroporISBN(self.ui.txtISBN.text())!=-1:
                        self.modeloLibro.modificarLibro(Libro(self.ui.txtISBN.text(),
                                                              self.ui.txtTitulo.text(),
                                                              precioVenta,
                                                              precioCompra,
                                                              cantidad,
                                                              self.rutaImagen))
                        self.modeloLibro.guardarLibro()
                        Principal.limpiarCamposLibro(self)
                    else:
                        QMessageBox.critical(None, "ERROR", "El Libro NO EXISTE")
                else:
                    QMessageBox.critical(None, "ERROR", "Precio y Cantidad debe ser un valor numérico")
            else:
                QMessageBox.critical(None, "ERROR", "Ingrese TODOS los datos del Libro")
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese una Imagen para Libro")

    def buscarImagen(self):
        origen = QFileDialog.getOpenFileName(
                self,
                caption="Selecciona una Imagen del Libro",
                directory=os.getcwd(),
                filter="Image Files (*.png *.jpg *.bmp *.jpeg)")[0]
        destino = join("./images", basename(origen))
        try:
            copyfile(origen, destino)
        except FileNotFoundError:
            QMessageBox.critical(None, "ERROR", "No se encuentra el archivo")
            return
        self.ui.lblImagenLibro.setPixmap(QPixmap(destino))
        self.ui.lblImagenLibro.setScaledContents(True)
        self.rutaImagen = destino

    def agregarCliente(self):
        if self.ui.txtCedulaCliente.text() and self.ui.txtNombreCliente.text() and self.ui.txtDireccionCliente.text() and self.ui.txtTelfCliente.text() and self.ui.txtCorreoCliente.text():
            telf = Principal.inputEntero(self.ui.txtTelfCliente.text())
            if telf!=-1:
                if len(self.ui.txtCedulaCliente.text())>10:
                    k = Principal.verificar(self, self.ui.txtCedulaCliente.text())
                else:
                    k = Principal.validarCedula(self, self.ui.txtCedulaCliente.text())
                if k != False:
                    if self.modeloCliente.buscarCliente(self.ui.txtCedulaCliente.text()) ==-1:
                        self.modeloCliente.agregarCliente(self.ui.txtCedulaCliente.text(),
                                                          self.ui.txtNombreCliente.text(),
                                                          self.ui.txtDireccionCliente.text(),
                                                          telf,
                                                          self.ui.txtCorreoCliente.text())
                        self.modeloCliente.guardarCliente()
                        Principal.limpiarCamposCliente(self)
                    else:
                        QMessageBox.critical(None, "ERROR", "CLIENTE YA INGRESADO")
                else:
                    QMessageBox.critical(None, "ERROR", "CEDULA/RUC INVALIDA")
            else:
                QMessageBox.critical(None, "ERROR", "Telefono debe ser un valor numérico")
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese TODOS los datos del Cliente")

    def buscarCliente(self):
        if self.ui.txtCedulaCliente.text():
            k = self.modeloCliente.buscarCliente(self.ui.txtCedulaCliente.text())
            if k!=-1:
                self.ui.txtCedulaCliente.setText(str(self.modeloCliente.listaClientes[k].cedula))
                self.ui.txtNombreCliente.setText(str(self.modeloCliente.listaClientes[k].nombre))
                self.ui.txtDireccionCliente.setText(str(self.modeloCliente.listaClientes[k].direccion))
                self.ui.txtTelfCliente.setText(str(self.modeloCliente.listaClientes[k].telefono))
                self.ui.txtCorreoCliente.setText(str(self.modeloCliente.listaClientes[k].correo))
            else:
                QMessageBox.critical(None, "ERROR", "El Cliente NO EXISTE")
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese Datos Primero")

    def modificarCliente(self):
        if self.ui.txtCedulaCliente.text() and self.ui.txtNombreCliente.text() and self.ui.txtDireccionCliente.text() and self.ui.txtTelfCliente.text() and self.ui.txtCorreoCliente.text():
            telf = Principal.inputEntero(self.ui.txtTelfCliente.text())
            if telf!=-1:
                if Principal.validarCedula(self, self.ui.txtCedulaCliente.text()) != -1:
                    k = self.modeloCliente.buscarCliente(self.ui.txtCedulaCliente.text())
                    if  k !=-1:
                        self.modeloCliente.modificarCliente(self.ui.txtCedulaCliente.text(),
                                                            self.ui.txtNombreCliente.text(),
                                                            self.ui.txtDireccionCliente.text(),
                                                            telf,
                                                            self.ui.txtCorreoCliente.text(), k)
                        self.modeloCliente.guardarCliente()
                        Principal.limpiarCamposCliente(self)
                    else:
                        QMessageBox.critical(None, "ERROR", "El Cliente NO EXISTE")
                else:
                    QMessageBox.critical(None, "ERROR", "CEDULA INVALIDA")
            else:
                QMessageBox.critical(None, "ERROR", "Telefono debe ser un valor numérico")
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese TODOS los datos del Cliente")

    def cargarTablaClientes(self):
        self.ui.tabVerClientes.clearContents()
        self.ui.tabVerClientes.setRowCount(0)
        if self.modeloCliente.listaClientes:
            fila=0
            for i in range(len(self.modeloCliente.listaClientes)):
                self.ui.tabVerClientes.insertRow(fila)
                self.ui.tabVerClientes.setItem(fila, 0, QTableWidgetItem(str(self.modeloCliente.listaClientes[i].cedula)))
                self.ui.tabVerClientes.setItem(fila, 1, QTableWidgetItem(str(self.modeloCliente.listaClientes[i].nombre)))
                self.ui.tabVerClientes.setItem(fila, 2, QTableWidgetItem(str(self.modeloCliente.listaClientes[i].direccion)))
                self.ui.tabVerClientes.setItem(fila, 3, QTableWidgetItem(str(self.modeloCliente.listaClientes[i].telefono)))
                self.ui.tabVerClientes.setItem(fila, 4, QTableWidgetItem(str(self.modeloCliente.listaClientes[i].correo)))
                fila = fila+1
                self.ui.tabVerClientes.resizeRowsToContents()
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese Clientes")

    def cargarTablaClientesOrdAsc(self):
        self.ui.tabVerClientes.clearContents()
        self.ui.tabVerClientes.setRowCount(0)
        Ordenada = sorted(self.modeloCliente.listaClientes, key= lambda object: object.nombre)
        if self.modeloCliente.listaClientes:
            fila=0
            for i in range(len(Ordenada)):
                self.ui.tabVerClientes.insertRow(fila)
                self.ui.tabVerClientes.setItem(fila, 0, QTableWidgetItem(str(Ordenada[i].cedula)))
                self.ui.tabVerClientes.setItem(fila, 1, QTableWidgetItem(str(Ordenada[i].nombre)))
                self.ui.tabVerClientes.setItem(fila, 2, QTableWidgetItem(str(Ordenada[i].direccion)))
                self.ui.tabVerClientes.setItem(fila, 3, QTableWidgetItem(str(Ordenada[i].telefono)))
                self.ui.tabVerClientes.setItem(fila, 4, QTableWidgetItem(str(Ordenada[i].correo)))
                fila = fila+1
                self.ui.tabVerClientes.resizeRowsToContents()
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese Clientes")


    def cargarTablaClientesOrdDesc(self):
        self.ui.tabVerClientes.clearContents()
        self.ui.tabVerClientes.setRowCount(0)
        Ordenada = sorted(self.modeloCliente.listaClientes, key= lambda object: object.nombre, reverse=True)
        if self.modeloCliente.listaClientes:
            fila=0
            for i in range(len(Ordenada)):
                self.ui.tabVerClientes.insertRow(fila)
                self.ui.tabVerClientes.setItem(fila, 0, QTableWidgetItem(str(Ordenada[i].cedula)))
                self.ui.tabVerClientes.setItem(fila, 1, QTableWidgetItem(str(Ordenada[i].nombre)))
                self.ui.tabVerClientes.setItem(fila, 2, QTableWidgetItem(str(Ordenada[i].direccion)))
                self.ui.tabVerClientes.setItem(fila, 3, QTableWidgetItem(str(Ordenada[i].telefono)))
                self.ui.tabVerClientes.setItem(fila, 4, QTableWidgetItem(str(Ordenada[i].correo)))
                fila = fila+1
                self.ui.tabVerClientes.resizeRowsToContents()
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese Clientes")

    def cargarTablaProveedores(self):
        self.ui.tbProveedores.clearContents()
        self.ui.tbProveedores.setRowCount(0)
        if self.modeloProveedor.listaProveedor:
            fila=0
            for i in range(len(self.modeloProveedor.listaProveedor)):
                self.ui.tbProveedores.insertRow(fila)
                self.ui.tbProveedores.setItem(fila, 0, QTableWidgetItem(str(self.modeloProveedor.listaProveedor[i].cedula)))
                self.ui.tbProveedores.setItem(fila, 1, QTableWidgetItem(str(self.modeloProveedor.listaProveedor[i].nombre)))
                self.ui.tbProveedores.setItem(fila, 2, QTableWidgetItem(str(self.modeloProveedor.listaProveedor[i].direccion)))
                self.ui.tbProveedores.setItem(fila, 3, QTableWidgetItem(str(self.modeloProveedor.listaProveedor[i].telefono)))
                self.ui.tbProveedores.setItem(fila, 4, QTableWidgetItem(str(self.modeloProveedor.listaProveedor[i].correo)))
                fila = fila+1
                self.ui.tbProveedores.resizeRowsToContents()
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese Proveedores")

    def cargarTablaProveedoresOrdAsc(self):
        self.ui.tbProveedores.clearContents()
        self.ui.tbProveedores.setRowCount(0)
        Ordenada = sorted(self.modeloProveedor.listaProveedor, key= lambda object: object.nombre)
        if self.modeloProveedor.listaProveedor:
            fila=0
            for i in range(len(Ordenada)):
                self.ui.tbProveedores.insertRow(fila)
                self.ui.tbProveedores.setItem(fila, 0, QTableWidgetItem(str(Ordenada[i].cedula)))
                self.ui.tbProveedores.setItem(fila, 1, QTableWidgetItem(str(Ordenada[i].nombre)))
                self.ui.tbProveedores.setItem(fila, 2, QTableWidgetItem(str(Ordenada[i].direccion)))
                self.ui.tbProveedores.setItem(fila, 3, QTableWidgetItem(str(Ordenada[i].telefono)))
                self.ui.tbProveedores.setItem(fila, 4, QTableWidgetItem(str(Ordenada[i].correo)))
                fila = fila+1
                self.ui.tbProveedores.resizeRowsToContents()
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese Proveedores")

    def cargarTablaProveedoresOrdDesc(self):
        self.ui.tbProveedores.clearContents()
        self.ui.tbProveedores.setRowCount(0)
        Ordenada = sorted(self.modeloProveedor.listaProveedor, key= lambda object: object.nombre, reverse=True)
        if self.modeloProveedor.listaProveedor:
            fila=0
            for i in range(len(Ordenada)):
                self.ui.tbProveedores.insertRow(fila)
                self.ui.tbProveedores.setItem(fila, 0, QTableWidgetItem(str(Ordenada[i].cedula)))
                self.ui.tbProveedores.setItem(fila, 1, QTableWidgetItem(str(Ordenada[i].nombre)))
                self.ui.tbProveedores.setItem(fila, 2, QTableWidgetItem(str(Ordenada[i].direccion)))
                self.ui.tbProveedores.setItem(fila, 3, QTableWidgetItem(str(Ordenada[i].telefono)))
                self.ui.tbProveedores.setItem(fila, 4, QTableWidgetItem(str(Ordenada[i].correo)))
                fila = fila+1
                self.ui.tbProveedores.resizeRowsToContents()
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese Proveedores")

    def cargarTablaFacturas(self):
        self.ui.tabFacturas.clearContents()
        self.ui.tabFacturas.setRowCount(0)
        if self.modeloFactura.listaFactura:
            fila=0
            for i in range(len(self.modeloFactura.listaFactura)):
                self.ui.tabFacturas.insertRow(fila)
                self.ui.tabFacturas.setItem(fila, 0, QTableWidgetItem(str(self.modeloFactura.listaFactura[i].numeroFactura)))
                self.ui.tabFacturas.setItem(fila, 1, QTableWidgetItem(str(self.modeloFactura.listaFactura[i].tipoFactura)))
                self.ui.tabFacturas.setItem(fila, 2, QTableWidgetItem(str(self.modeloFactura.listaFactura[i].cedula)))
                self.ui.tabFacturas.setItem(fila, 3, QTableWidgetItem(str(self.modeloFactura.listaFactura[i].fecha.toString("dd/MM/yyyy"))))
                self.ui.tabFacturas.setItem(fila, 4, QTableWidgetItem(str(self.modeloFactura.listaFactura[i].tipoPago)))
                self.ui.tabFacturas.setItem(fila, 5, QTableWidgetItem(str(sum(self.modeloLibro.libros[self.modeloFactura.listaFactura[i].listaItemFactura[x][1]][1] * self.modeloFactura.listaFactura[i].listaItemFactura[x][0] for x in range(len(self.modeloFactura.listaFactura[i].listaItemFactura))))))
                fila = fila+1
                self.ui.tabFacturas.resizeRowsToContents()
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese Facturas")


    def cargarTablaFacturasOrdAsc(self):
        self.ui.tabFacturas.clearContents()
        self.ui.tabFacturas.setRowCount(0)
        Ordenada = list(sorted(self.modeloFactura.listaFactura, key=lambda object:object.fecha))
        if self.modeloFactura.listaFactura:
            fila=0
            for i in range(len(Ordenada)):
                self.ui.tabFacturas.insertRow(fila)
                self.ui.tabFacturas.setItem(fila, 0, QTableWidgetItem(str(Ordenada[i].numeroFactura)))
                self.ui.tabFacturas.setItem(fila, 1, QTableWidgetItem(str(Ordenada[i].tipoFactura)))
                self.ui.tabFacturas.setItem(fila, 2, QTableWidgetItem(str(Ordenada[i].cedula)))
                self.ui.tabFacturas.setItem(fila, 3, QTableWidgetItem(str(Ordenada[i].fecha.toString("dd/MM/yyyy"))))
                self.ui.tabFacturas.setItem(fila, 4, QTableWidgetItem(str(Ordenada[i].tipoPago)))
                self.ui.tabFacturas.setItem(fila, 5, QTableWidgetItem(str(sum(self.modeloLibro.libros[Ordenada[i].listaItemFactura[x][1]][1] * Ordenada[i].listaItemFactura[x][0] for x in range(len(Ordenada[i].listaItemFactura))))))
                fila = fila+1
                self.ui.tabFacturas.resizeRowsToContents()
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese Facturas")

    def cargarTablaFacturasOrdDesc(self):
        self.ui.tabFacturas.clearContents()
        self.ui.tabFacturas.setRowCount(0)
        Ordenada = list(sorted(self.modeloFactura.listaFactura, key=lambda object:object.fecha, reverse=True))
        if self.modeloFactura.listaFactura:
            fila=0
            for i in range(len(Ordenada)):
                self.ui.tabFacturas.insertRow(fila)
                self.ui.tabFacturas.setItem(fila, 0, QTableWidgetItem(str(Ordenada[i].numeroFactura)))
                self.ui.tabFacturas.setItem(fila, 1, QTableWidgetItem(str(Ordenada[i].tipoFactura)))
                self.ui.tabFacturas.setItem(fila, 2, QTableWidgetItem(str(Ordenada[i].cedula)))
                self.ui.tabFacturas.setItem(fila, 3, QTableWidgetItem(str(Ordenada[i].fecha.toString("dd/MM/yyyy"))))
                self.ui.tabFacturas.setItem(fila, 4, QTableWidgetItem(str(Ordenada[i].tipoPago)))
                self.ui.tabFacturas.setItem(fila, 5, QTableWidgetItem(str(sum(self.modeloLibro.libros[Ordenada[i].listaItemFactura[x][1]][1] * Ordenada[i].listaItemFactura[x][0] for x in range(len(Ordenada[i].listaItemFactura))))))
                fila = fila+1
                self.ui.tabFacturas.resizeRowsToContents()
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese Facturas")

    def eliminarCliente(self):
        if self.ui.txtCedulaCliente.text():
            k = self.modeloCliente.buscarCliente(self.ui.txtCedulaCliente.text())
            if k!=-1:
                m = QMessageBox.question(None, "Sistema Gestión librería", "¿Está seguro de Eliminar?")
                if m == QMessageBox.StandardButton.Yes:
                    self.modeloCliente.eliminarCliente(k)
                    self.modeloCliente.guardarCliente()
                    Principal.limpiarCamposCliente(self)
            else:
                QMessageBox.critical(None, "ERROR", "El CLIENTE NO EXISTE")
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese CEDULA")

    def agregarProveedor(self):
        if self.ui.txtCedulaProveedor.text() and self.ui.txtNombreProveedor.text() and self.ui.txtDireccionProveedor.text() and self.ui.txtTelfProveedor.text() and self.ui.txtCorreoProveedor.text():
            telf = Principal.inputEntero(self.ui.txtTelfProveedor.text())
            if telf!=-1:
                if len(self.ui.txtCedulaProveedor.text())>10:
                    k = Principal.verificar(self, self.ui.txtCedulaProveedor.text())
                else:
                    k = Principal.validarCedula(self, self.ui.txtCedulaProveedor.text())
                if k != False:
                    if self.modeloProveedor.buscarProveedor(self.ui.txtCedulaProveedor.text()) ==-1:
                        self.modeloProveedor.agregarProveedor(self.ui.txtCedulaProveedor.text(),
                                                          self.ui.txtNombreProveedor.text(),
                                                          self.ui.txtDireccionProveedor.text(),
                                                          telf,
                                                          self.ui.txtCorreoProveedor.text())
                        self.modeloProveedor.guardarProveedor()
                        Principal.limpiarCamposProveedor(self)
                    else:
                        QMessageBox.critical(None, "ERROR", "PROVEEDOR YA INGRESADO")
                else:
                    QMessageBox.critical(None, "ERROR", "CEDULA INVALIDA")
            else:
                QMessageBox.critical(None, "ERROR", "Telefono debe ser un valor numérico")
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese TODOS los datos del Proveedor")

    def buscarProveedor(self):
        if self.ui.txtCedulaProveedor.text():
            k = self.modeloProveedor.buscarProveedor(self.ui.txtCedulaProveedor.text())
            if k!=-1:
                self.ui.txtCedulaProveedor.setText(str(self.modeloProveedor.listaProveedor[k].cedula))
                self.ui.txtNombreProveedor.setText(str(self.modeloProveedor.listaProveedor[k].nombre))
                self.ui.txtDireccionProveedor.setText(str(self.modeloProveedor.listaProveedor[k].direccion))
                self.ui.txtTelfProveedor.setText(str(self.modeloProveedor.listaProveedor[k].telefono))
                self.ui.txtCorreoProveedor.setText(str(self.modeloProveedor.listaProveedor[k].correo))
            else:
                QMessageBox.critical(None, "ERROR", "El PROVEEDOR NO EXISTE")
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese Datos Primero")

    @staticmethod
    def limpiarCamposFactura(self):
        self.ui.txtNumFactura.clear()
        self.ui.txtCedulaFactura.clear()
        self.ui.lblNombreFactura.clear()
        self.ui.lblDireccionFactura.clear()
        self.ui.lblTelefonoFactura.clear()
        self.ui.tbItemFactura.clearContents()
        self.ui.tbItemFactura.setRowCount(0)
        self.ui.cbTransaccion.setCurrentText("Venta")
        self.ui.cbTransaccion_2.setCurrentText("Efectivo")
        self.ui.spinBoxCantidad.setValue(1)
        self.ui.dateFactura.setDate(datetime.datetime.now().date())
        self.ui.cbTransaccion.setEnabled(True)

    def agregarFactura(self):
        facturaTemp = Factura(Principal.inputEntero(self.ui.txtNumFactura.text()),
                               self.ui.cbTransaccion.currentText(),
                               self.ui.txtCedulaFactura.text(),
                               self.ui.dateFactura.date(),
                               self.ui.cbTransaccion_2.currentText())
        facturaTemp.listaItemFactura = self.factura.listaItemFactura
        k=self.modeloFactura.buscarFactura(Principal.inputEntero(self.ui.txtNumFactura.text()))
        if(k==-1):
            if self.ui.tbItemFactura.rowCount()>0:
                self.modeloFactura.agregarFactura(facturaTemp)
                Principal.limpiarCamposFactura(self)
                self.ui.txtNumFactura.setText(str(len(self.modeloFactura.listaFactura)+1))
                Principal.leerTransacciones(self)
                self.modeloFactura.guardarFactura()
                self.factura = Factura
            else:
                QMessageBox.critical(None, "ERROR", "AGREGUE ITEMS")
        else:
            QMessageBox.critical(None, "ERROR", "FACTURA YA AGREGADA")

    def modificarProveedor(self):
        if self.ui.txtCedulaProveedor.text() and self.ui.txtNombreProveedor.text() and self.ui.txtDireccionProveedor.text() and self.ui.txtTelfProveedor.text() and self.ui.txtCorreoProveedor.text():
            telf = Principal.inputEntero(self.ui.txtTelfProveedor.text())
            if telf!=-1:
                if Principal.validarCedula(self, self.ui.txtCedulaProveedor.text()) != -1:
                    k = self.modeloProveedor.buscarProveedor(self.ui.txtCedulaProveedor.text())
                    if  k !=-1:
                        self.modeloProveedor.modificarProveedor(self.ui.txtCedulaProveedor.text(),
                                                            self.ui.txtNombreProveedor.text(),
                                                            self.ui.txtDireccionProveedor.text(),
                                                            telf,
                                                            self.ui.txtCorreoProveedor.text(), k)
                        self.modeloProveedor.guardarProveedor()
                        Principal.limpiarCamposProveedor(self)
                    else:
                        QMessageBox.critical(None, "ERROR", "El PROVEEDOR NO EXISTE")
                else:
                    QMessageBox.critical(None, "ERROR", "CEDULA INVALIDA")
            else:
                QMessageBox.critical(None, "ERROR", "Telefono debe ser un valor numérico")
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese TODOS los datos del Proveedor")

    def eliminarProveedor(self):
        if self.ui.txtCedulaProveedor.text():
            k = self.modeloProveedor.buscarProveedor(self.ui.txtCedulaProveedor.text())
            if k!=-1:
                m = QMessageBox.question(None, "Sistema Gestión librería", "¿Está seguro de Eliminar?")
                if m == QMessageBox.StandardButton.Yes:
                    self.modeloProveedor.eliminarProveedor(k)
                    self.modeloProveedor.guardarProveedor()
                    Principal.limpiarCamposProveedor(self)
            else:
                QMessageBox.critical(None, "ERROR", "El PROVEEDOR NO EXISTE")
        else:
            QMessageBox.critical(None, "ERROR", "Ingrese CEDULA")

    def expandir(self):
        ancho=self.ui.ContenedorMenu.width()
        if ancho==80:
            expansion=280
        elif ancho==280:
            expansion=80
        try:
            self.animacion=QPropertyAnimation(self.ui.ContenedorMenu, b"minimumWidth")
            self.animacion.setStartValue(ancho)
            self.animacion.setEndValue(expansion)
            self.animacion.setDuration(350)
            self.animacion.setEasingCurve(QEasingCurve.Type.InCirc)
            self.animacion.start()
        except:
            self.animacion.setStartValue(80)
            self.animacion.setEndValue(280)
            self.animacion.setDuration(350)
            self.animacion.setEasingCurve(QEasingCurve.Type.InCirc)
            self.animacion.start()


    def buscarFactura(self):
        self.ui.tbItemFactura.clearContents()
        self.ui.tbItemFactura.setRowCount(0)
        numFactura = Principal.inputEntero(self.ui.txtNumFactura.text())
        if numFactura!=-1:
            k = self.modeloFactura.buscarFactura(numFactura)
            if k!=-1:
                self.ui.txtNumFactura.setText(str(self.modeloFactura.listaFactura[k].numeroFactura))
                self.ui.txtCedulaFactura.setText(str(self.modeloFactura.listaFactura[k].cedula))
                if(self.modeloFactura.listaFactura[k].tipoFactura=="Venta"):
                    j = self.modeloCliente.buscarCliente(str(self.modeloFactura.listaFactura[k].cedula))
                    self.ui.lblNombreFactura.setText(str(self.modeloCliente.listaClientes[j].nombre))
                    self.ui.lblDireccionFactura.setText(str(self.modeloCliente.listaClientes[j].direccion))
                    self.ui.lblTelefonoFactura.setText(str(self.modeloCliente.listaClientes[j].telefono))
                else:
                    j = self.modeloProveedor.buscarProveedor(str(self.modeloFactura.listaFactura[k].cedula))
                    self.ui.lblNombreFactura.setText(str(self.modeloProveedor.listaProveedor[j].nombre))
                    self.ui.lblDireccionFactura.setText(str(self.modeloProveedor.listaProveedor[j].direccion))
                    self.ui.lblTelefonoFactura.setText(str(self.modeloProveedor.listaProveedor[j].telefono))
                fila=0
                for x in range(len(self.modeloFactura.listaFactura[k].listaItemFactura)):
                    self.ui.tbItemFactura.insertRow(fila)
                    self.ui.tbItemFactura.setItem(fila, 0, QTableWidgetItem(str(fila+1)))
                    self.ui.tbItemFactura.setItem(fila, 1, QTableWidgetItem(str(self.modeloFactura.listaFactura[k].listaItemFactura[x][1])))
                    i = self.modeloFactura.listaFactura[k].listaItemFactura[x][1]
                    self.ui.tbItemFactura.setItem(fila, 2, QTableWidgetItem(str(self.modeloLibro.libros[i][0])))
                    self.ui.tbItemFactura.setItem(fila, 3, QTableWidgetItem(str(self.modeloFactura.listaFactura[k].listaItemFactura[x][0])))
                    self.ui.tbItemFactura.setItem(fila, 4, QTableWidgetItem(str(self.modeloLibro.libros[i][1])))
                    self.ui.tbItemFactura.setItem(fila, 5, QTableWidgetItem(str(self.modeloFactura.listaFactura[k].listaItemFactura[x][0]*self.modeloLibro.libros[i][1])))
                    fila=fila+1
                self.ui.cbTransaccion.setCurrentText(str(self.modeloFactura.listaFactura[k].tipoFactura))
                self.ui.cbTransaccion_2.setCurrentText(str(self.modeloFactura.listaFactura[k].tipoPago))
                self.ui.dateFactura.setDate(self.modeloFactura.listaFactura[k].fecha)
                self.ui.btnEliminarItem.setEnabled(False)
                self.ui.btnComprarLibro.setEnabled(False)
            else:
                QMessageBox.critical(None, "ERROR", "FACTURA NO ENCONTRADA")
                self.ui.btnComprarLibro.setEnabled(True)
                self.ui.btnEliminarItem.setEnabled(True)
        else:
            QMessageBox.critical(None, "ERROR", "INGRESE VALOR NUMÉRICO")

    def cargarComboLibros(self):
        self.ui.cbLibros.clear()
        for k in self.modeloLibro.libros.keys():
            self.ui.cbLibros.addItem(self.modeloLibro.libros[k][0])

    @staticmethod
    def actualizarLibro(self, libro):
        self.modeloLibro.modificarLibro(libro)
        self.modeloLibro.guardarLibro()

    @staticmethod
    def leerTransacciones(self):
        total = 1000000
        if(self.modeloFactura.listaFactura):
            for i in range(len(self.modeloFactura.listaFactura)):
                if(self.modeloFactura.listaFactura[i].tipoFactura == "Venta"):
                    total = total + (sum(self.modeloLibro.libros[self.modeloFactura.listaFactura[i].listaItemFactura[x][1]][1] * self.modeloFactura.listaFactura[i].listaItemFactura[x][0] for x in range(len(self.modeloFactura.listaFactura[i].listaItemFactura))))
                else:
                    total = total - (sum(self.modeloLibro.libros[self.modeloFactura.listaFactura[i].listaItemFactura[x][1]][2] * self.modeloFactura.listaFactura[i].listaItemFactura[x][0] for x in range(len(self.modeloFactura.listaFactura[i].listaItemFactura))))
            self.ui.lblCaja.setText("Caja: "+ str(total))
        else:
            self.ui.lblCaja.setText("Caja: "+ str(total))

    def agregarItem(self):
        k = self.modeloLibro.buscarLibroporTitulo(self.ui.cbLibros.currentText())
        if self.ui.lblNombreFactura.text() != "":
            cantidad = Principal.inputEntero(self.ui.spinBoxCantidad.text())
            if (cantidad<=self.modeloLibro.libros[k][3] and self.factura.tipoFactura=="Venta"):
                self.factura.agregarItemFactura(cantidad, k, 0.12)
                x = self.factura.buscarItemFactura(self.modeloLibro.libros[k])
                fila = len(self.factura.listaItemFactura)-1
                self.ui.tbItemFactura.insertRow(fila)
                self.ui.tbItemFactura.setItem(fila, 0, QTableWidgetItem(str(fila+1)))
                self.ui.tbItemFactura.setItem(fila, 1, QTableWidgetItem(str(k)))
                self.ui.tbItemFactura.setItem(fila, 2, QTableWidgetItem(str(self.modeloLibro.libros[k][0])))
                self.ui.tbItemFactura.setItem(fila, 3, QTableWidgetItem(str(self.factura.listaItemFactura[x][0])))
                self.ui.tbItemFactura.setItem(fila, 4, QTableWidgetItem(str(self.modeloLibro.libros[k][1])))
                self.ui.tbItemFactura.setItem(fila, 5, QTableWidgetItem(str(self.factura.listaItemFactura[x][0]*self.modeloLibro.libros[k][1])))
                self.ui.tbItemFactura.resizeRowsToContents()
                Principal.actualizarLibro(self, Libro(k,
                                                    self.modeloLibro.libros[k][0],
                                                    self.modeloLibro.libros[k][1],
                                                    self.modeloLibro.libros[k][2],
                                                    self.modeloLibro.libros[k][3]-cantidad,
                                                    self.modeloLibro.libros[k][4]))
            elif(self.factura.tipoFactura=="Compra"):
                self.factura.agregarItemFactura(cantidad, k, 0.12)
                x = self.factura.buscarItemFactura(self.modeloLibro.libros[k])
                fila = len(self.factura.listaItemFactura)-1
                self.ui.tbItemFactura.insertRow(fila)
                self.ui.tbItemFactura.setItem(fila, 0, QTableWidgetItem(str(fila+1)))
                self.ui.tbItemFactura.setItem(fila, 1, QTableWidgetItem(str(k)))
                self.ui.tbItemFactura.setItem(fila, 2, QTableWidgetItem(str(self.modeloLibro.libros[k][0])))
                self.ui.tbItemFactura.setItem(fila, 3, QTableWidgetItem(str(self.factura.listaItemFactura[x][0])))
                self.ui.tbItemFactura.setItem(fila, 4, QTableWidgetItem(str(self.modeloLibro.libros[k][2])))
                self.ui.tbItemFactura.setItem(fila, 5, QTableWidgetItem(str(self.factura.listaItemFactura[x][0]*self.modeloLibro.libros[k][2])))
                self.ui.tbItemFactura.resizeRowsToContents()
                Principal.actualizarLibro(self, Libro(k,
                                                      self.modeloLibro.libros[k][0],
                                                      self.modeloLibro.libros[k][1],
                                                      self.modeloLibro.libros[k][2],
                                                      self.modeloLibro.libros[k][3]+cantidad,
                                                      self.modeloLibro.libros[k][4]))
            else:
                QMessageBox.critical(None, "ERROR", "EXCEDIÓ LA CANTIDAD DE LIBROS DISPONIBLES")
        else:
            QMessageBox.critical(None, "ERROR", "INGRESE DATOS DE PERSONA PRIMERO")

    def eliminarItem(self):
            k = self.ui.tbItemFactura.item(self.ui.tbItemFactura.currentRow(), 1).text()
            j = Principal.inputEntero(self.ui.tbItemFactura.item(self.ui.tbItemFactura.currentRow(), 3).text())
            if(self.factura.tipoFactura=="Venta"):
                Principal.actualizarLibro(self, Libro(k,
                                                      self.modeloLibro.libros[k][0],
                                                      self.modeloLibro.libros[k][1],
                                                      self.modeloLibro.libros[k][2],
                                                      self.modeloLibro.libros[k][3]+j,
                                                      self.modeloLibro.libros[k][4]))
                self.factura.eliminarItemFactura(self.ui.tbItemFactura.currentRow())
            else:
                Principal.actualizarLibro(self, Libro(k,
                                                      self.modeloLibro.libros[k][0],
                                                      self.modeloLibro.libros[k][1],
                                                      self.modeloLibro.libros[k][2],
                                                      self.modeloLibro.libros[k][3]-j,
                                                      self.modeloLibro.libros[k][4]))
                self.factura.eliminarItemFactura(self.ui.tbItemFactura.currentRow())
            lambda:self.ui.tbItemFactura.removeRow(self.ui.tbItemFactura.currentRow())
            fila=0
            self.ui.tbItemFactura.clearContents()
            self.ui.tbItemFactura.setRowCount(0)
            for x in range(len(self.factura.listaItemFactura)):
                self.ui.tbItemFactura.insertRow(fila)
                self.ui.tbItemFactura.setItem(fila, 0, QTableWidgetItem(str(fila+1)))
                self.ui.tbItemFactura.setItem(fila, 1, QTableWidgetItem(str(self.factura.listaItemFactura[x][1])))
                i = self.factura.listaItemFactura[x][1]
                self.ui.tbItemFactura.setItem(fila, 2, QTableWidgetItem(str(self.modeloLibro.libros[i][0])))
                self.ui.tbItemFactura.setItem(fila, 3, QTableWidgetItem(str(self.factura.listaItemFactura[x][0])))
                self.ui.tbItemFactura.setItem(fila, 4, QTableWidgetItem(str(self.modeloLibro.libros[i][1])))
                self.ui.tbItemFactura.setItem(fila, 5, QTableWidgetItem(str(self.factura.listaItemFactura[x][0]*self.modeloLibro.libros[i][1])))
                fila=fila+1

    def eliminarFactura(self):
        numFactura = Principal.inputEntero(self.ui.txtNumFactura.text())
        if numFactura!=-1:
            k = self.modeloFactura.buscarFactura(numFactura)
            if k!=-1:
                m = QMessageBox.question(None, "Sistema Gestión librería", "¿Está seguro de Eliminar?")
                if m == QMessageBox.StandardButton.Yes:
                    self.modeloFactura.eliminarFactura(k)
                    Principal.limpiarCamposFactura(self)
                    self.modeloFactura.guardarFactura()
            else:
                QMessageBox.critical(None, "ERROR", "FACTURA NO ENCONTRADA")
        else:
            QMessageBox.critical(None, "ERROR", "INGRESE VALOR NUMÉRICO")

    def buscarPersona(self):
        self.ui.tbItemFactura.clearContents()
        self.ui.tbItemFactura.setRowCount(0)
        if(self.ui.cbTransaccion.currentText() == "Venta"):
            k = self.modeloCliente.buscarCliente(self.ui.txtCedulaFactura.text())
            if (k!=-1):
                self.ui.lblNombreFactura.setText(str(self.modeloCliente.listaClientes[k].nombre))
                self.ui.lblDireccionFactura.setText(str(self.modeloCliente.listaClientes[k].direccion))
                self.ui.lblTelefonoFactura.setText(str(self.modeloCliente.listaClientes[k].telefono))
                QMessageBox.information(None, "SUCCESS", "CLIENTE CARGADO")
                self.ui.cbTransaccion.setEnabled(False)
                self.factura = Factura(Principal.inputEntero(self.ui.txtNumFactura.text()),
                                  self.ui.cbTransaccion.currentText(),
                                  self.ui.txtCedulaFactura.text(),
                                  self.ui.dateFactura.date(),
                                  self.ui.cbTransaccion_2.currentText())
                self.ui.btnComprarLibro.setEnabled(True)
                self.ui.btnEliminarItem.setEnabled(True)

            else:
                QMessageBox.critical(None, "ERROR", "El CLIENTE NO EXISTE")
        if(self.ui.cbTransaccion.currentText() == "Compra"):
            k = self.modeloProveedor.buscarProveedor(self.ui.txtCedulaFactura.text())
            if (k!=-1):
                self.ui.lblNombreFactura.setText(str(self.modeloProveedor.listaProveedor[k].nombre))
                self.ui.lblDireccionFactura.setText(str(self.modeloProveedor.listaProveedor[k].direccion))
                self.ui.lblTelefonoFactura.setText(str(self.modeloProveedor.listaProveedor[k].telefono))
                QMessageBox.information(None, "SUCCESS", "PROVEEDOR CARGADO")
                self.ui.cbTransaccion.setEnabled(False)
                self.factura = Factura(Principal.inputEntero(self.ui.txtNumFactura.text()),
                                       self.ui.cbTransaccion.currentText(),
                                       self.ui.txtCedulaFactura.text(),
                                       self.ui.dateFactura.date(),
                                       self.ui.cbTransaccion_2.currentText())
                self.ui.btnComprarLibro.setEnabled(True)
                self.ui.btnEliminarItem.setEnabled(True)
            else:
                QMessageBox.critical(None, "ERROR", "El PROVEEDOR NO EXISTE")
    
if __name__=="__main__":
    app=QApplication(sys.argv)
    window=Principal()
    window.show()
    sys.exit(app.exec())