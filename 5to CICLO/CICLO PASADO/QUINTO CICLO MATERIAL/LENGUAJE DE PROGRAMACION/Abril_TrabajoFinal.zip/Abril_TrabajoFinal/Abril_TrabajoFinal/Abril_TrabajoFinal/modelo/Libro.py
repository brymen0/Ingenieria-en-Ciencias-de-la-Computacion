class Libro(object):
    def __init__(self, isbn, titulo, precioVenta, precioCompra, cant, rutaImagen):
        self.isbn = isbn
        self.titulo = titulo
        self.precioVenta = precioVenta
        self.precioCompra = precioCompra
        self.cant = cant
        self.rutaImagen = rutaImagen

    def __eq__(self, otroLibro):
        return otroLibro.isbn == self.isbn
