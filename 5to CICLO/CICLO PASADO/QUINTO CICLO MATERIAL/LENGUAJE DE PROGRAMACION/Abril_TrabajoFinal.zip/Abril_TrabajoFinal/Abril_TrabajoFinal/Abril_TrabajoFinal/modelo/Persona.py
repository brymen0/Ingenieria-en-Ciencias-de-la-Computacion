class Persona(object):
    def __init__(self, cedula, nombre, direccion, telefono, correo):
        self.cedula = cedula
        self.nombre = nombre
        self.direccion = direccion
        self.telefono = telefono
        self.correo = correo

    def __eq__(self, otraPersona):
        return self.cedula == otraPersona.cedula

    def validarCedula(self):
        valID= lambda id: sum([int(id[i]) if i%2 != 0 else int(id[i])*2 if int(id[i])*2<9 else int(id[i])*2-9 for i in range(len(id))])%10 ==0 and len(id) == 10

    def validarRUC(self):
        print()
