from modelo.Persona import Persona
import pickle
class Proveedor(Persona):
    pass

class ContenedorProveedor():
    def __init__(self):
        self.listaProveedor = []

    def agregarProveedor(self, cedula, nombre, direccion, telefono, correo):
        self.listaProveedor.append(Proveedor(cedula, nombre, direccion, telefono,correo))

    def modificarProveedor(self, cedula, nombre, direccion, telefono, correo, k):
        self.listaProveedor[k] = Proveedor(cedula, nombre, direccion, telefono, correo)

    def eliminarProveedor(self, cedula):
        self.listaProveedor.pop(cedula)

    def guardarProveedor(self):
        try:
            with open ("Proveedores.dat", "wb") as f:
                pickle.dump(self.listaProveedor,f)
                f.close()
        except:
            print("No se ha podido guardar Proveedores")

    def cargarProveedor(self):
        try:
            with open ("Proveedores.dat", "rb") as f:
                self.listaProveedor = pickle.load(f)
                f.close()
        except:
            print("No existen datos para cargar")

    def buscarProveedor(self, cedula):
        for k in range(len(self.listaProveedor)):
            if self.listaProveedor[k].cedula == cedula:
                return k
        return -1

    def mostrarProveedor(self):
        print("\t\tLista de Proveedores")
        for k in range(len(self.listaProveedor)):
            print("Cedula: ", self.listaProveedor[k].cedula,
                  " Nombre: ", self.listaProveedor[k].nombre,
                  " Direccion: ", self.listaProveedor[k].direccion,
                  " Telefono: ", self.listaProveedor[k].telefono,
                  " Correo: ", self.listaProveedor[k].correo)
