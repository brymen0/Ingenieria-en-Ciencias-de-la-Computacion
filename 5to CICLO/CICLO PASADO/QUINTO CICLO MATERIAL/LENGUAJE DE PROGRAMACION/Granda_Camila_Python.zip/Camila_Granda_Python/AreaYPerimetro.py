import math


def perimetro(lado1, lado2, lado3):
    return lado1+lado2+lado3

def area(lado1, lado2, lado3):
    s=(lado1+lado2+lado3)/2
    return math.sqrt(s*(s-lado1)*(s-lado2)*(s-lado3))


while True:

    try:
        lado1 = float(input("Ingrese lado 1: "))
        lado2 = float(input("Ingrese lado 2: "))
        lado3 = float(input("Ingrese lado 3: "))
        print("El perímetro es : ", perimetro(lado1, lado2, lado3))
        print("El area es : ", area(lado1, lado2, lado3))
        break
    except ValueError:
        print("Ingreso mal de valores, debe ingresar solo números")
        continue
