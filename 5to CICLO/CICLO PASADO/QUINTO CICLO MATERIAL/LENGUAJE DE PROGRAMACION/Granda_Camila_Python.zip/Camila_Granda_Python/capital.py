
def capital(euros, interes, anio):

    return euros*(1+interes/100)**anio


while True:
    try:

        euros = float(input("Ingrese una cantidad de euros: "))
        interes = float(input("Ingrese una tasa de interés: "))
        anio = int(input("Ingrese el número de años: "))

        print("Su capital es: ", capital(euros, interes, anio))
        break

    except ValueError:
        print("Ingreso mal de valores, debe ingresar solo números")
        continue
