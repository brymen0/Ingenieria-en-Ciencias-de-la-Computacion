import math


def area(lado1, lado2, angulo):

    anguloTransformado = angulo*math.pi/180
    return 1/2*lado1*lado2*math.sin(anguloTransformado)


while True:

    try:
        lado1 = float(input("Ingrese lado 1 en metros: "))
        lado2 = float(input("Ingrese lado 2 en metros: "))
        angulo = float(input("Ingrese angulo θ en grados: "))
        print("El área es: ",area(lado1, lado2, angulo))
        break

    except ValueError:
        print("Ingreso mal de valores, debe ingresar solo números")
        continue
