import re

def toISBN13( isbn ):

    result = ""

    if isValidISBN10( isbn ):

        isbn = isbn[:len(isbn) - 1] # remove check digit

        result = "978-" + isbn
        result += str( calcCheckDigitForISBN13(result) ) # append check digit

    return result

def isValidISBN10( code ):

    result = False
    
    # isbn10 string have 10 chars.
    # First 9 chars should be numbers and the 10th char can be a number or an 'X'    
    if re.match('^\d{9}[\d,X]{1}$', code):
        sum = 0

        # result = (isbn[0] * 1 + isbn[1] * 2 + ... + isbn[9] * 10) mod 11 == 0
        for i in range(0,9):
            sum += int(code[i]) * (i + 1)
        
        sum += 10 if isbn[9] == 'X' else int(code[9]) * 10

        result = sum % 11 == 0

    return result

def calcCheckDigitForISBN13( code ):
    
    result = -1
    
    code = code.replace("-", "")

    sum = 0

    for i in range(len(code)):
        digit = int(code[i])
        sum += digit * ( 3 if isOdd(i) else 1)
    
    result = ( 10 - sum % 10 ) % 10

    return result

def isOdd( n ): 
    return n % 2 != 0

isbns = [
    "0811821846",
    "1616550414",
    "0553418025",
]

for isbn in isbns:
    print ( "ISBN10({0}) = ISBN13({1})".format(isbn, toISBN13(isbn)) )