import scala.collection.mutable.ListBuffer
import scala.io.StdIn.{readChar, readInt, readLine}
import java.util.ArrayList
import java.io.{FileInputStream, FileNotFoundException, FileOutputStream, IOException, ObjectInputStream, ObjectOutputStream, Serializable}
import java.util
import scala.collection._

class Libro (var titulo:String, var autor:String, var anio:String) extends Serializable{


}
class Socio(var dni:String, var nombre:String, var tlf:String) extends Serializable{
  @SerialVersionUID(100L)
    var libros = new ArrayList[Libro]()


    var dias =0
    var banned = false
  def solicitar(libro:Libro){
    libros.add(libro)
  }

  def getNombre(): String ={
    nombre
  }


  def devolver(libro:Libro): Unit = {
      libros.remove(libro)
  }

}

class ManejoLibros() extends Serializable{
  @SerialVersionUID(100L)
  var listaLibros= new ArrayList[Libro]()

  def addLibro(titulo:String,autor:String,anio:String): Unit ={
    //Serializar antes para sobreescribir la lista anterior
    listaLibros.add(new Libro(titulo,autor, anio))
    //Guardar lista completa
  }
  def setLibros(newList:ArrayList[Libro]): Unit ={
    listaLibros.clear()
    listaLibros.addAll(newList)
  }

}

class Files(var manejoSocios: ManejoSocios, var manejoLibros: ManejoLibros) extends Serializable{

  def guardarSocios(): Unit ={
    var output = new ObjectOutputStream(new FileOutputStream("socios.dat"))
    output.writeObject(manejoSocios)
    output.close
  }
  def recuperarSocios(): Unit ={
    try {
      var input = new ObjectInputStream(new FileInputStream("socios.dat"))
      var obtenido = input.readObject.asInstanceOf[ManejoSocios]
      input.close

      manejoSocios.setSocios(obtenido.getSocios)

      println("Datos recuperados con exito")

    }catch{
      case a: FileNotFoundException => println("No se pudo recuperar el archivo")
    }
  }
  def guardarLibros(): Unit ={
    var output = new ObjectOutputStream(new FileOutputStream("libros.dat"))
    output.writeObject(manejoLibros)
    output.close
  }
  def recuperarLibros(): Unit ={
    try {
      var input = new ObjectInputStream(new FileInputStream("libros.dat"))
      var obtenido = input.readObject.asInstanceOf[ManejoLibros]
      input.close

      manejoLibros.setLibros(obtenido.listaLibros)

      println("Datos recuperados con exito")

    }catch{
      case a: FileNotFoundException => println("No se pudo recuperar el archivo")
    }
  }

}

class ManejoSocios() extends Serializable{
  @SerialVersionUID(100L)
  var listaSocios = new util.ArrayList[Socio]

  def addSocio(dni:String,nombre:String,tlf:String): Unit ={
    listaSocios.add(new Socio(dni, nombre, tlf))
    //Leer archivo anterior

    //Remplazar lista con los datos nuevos
  }


  def getSocios: util.ArrayList[Socio] = try {

    listaSocios
  }
  def setSocios(newList: ArrayList[Socio]): Unit ={
    listaSocios.clear()
    listaSocios.addAll(newList)
  }
}

object Launcher{
  def main(args: Array[String]): Unit = {
    var sel = "0"
    var manSocios = new ManejoSocios
    var manLibros = new ManejoLibros
    var data = new Files(manSocios,manLibros)
    do{
      print(" Biblioteca\n 1)Añadir socio \n2)Añadir libro \n3)Realizar prestamo \n4)Devolver libro \n5) Salir \n")
      sel=readLine()
      sel match {
        case "1" =>
          println("Ingrese DNI del socio")
          var dni = readLine()
          println("Ingrese nombre del socio")
          var nombre = readLine()
          println("Ingrese tlf de socio")
          var tlf= readLine()
          manSocios.addSocio(dni,nombre,tlf)
          data.guardarSocios()
        case "2" =>
          println("Titulo del libro")
          var tit = readLine()
          println("Autor?")
          var aut = readLine()
          println("Año")
          var anio = readLine()
          manLibros.addLibro(tit,aut,anio)
          data.guardarLibros()
        case "3" =>
          println("Elija el socio que solicita el libro")
          data.recuperarSocios()
          var list = manSocios.getSocios
          data.recuperarLibros()
          var listalibros = manLibros.listaLibros
          for (i <- 0 until  list.size()) {
            println((i+1)+")"+list.get(i).getNombre())
          }
          println("Escoja la posicion numerica")
          var aux= readInt()
          if(list.get(aux-1).libros.size() <3){
            if(list.get(aux-1).banned==false ){
              println("Elija el libro solicitado: \n ")
              try{

                for(i <- 0 until( listalibros.size())){
                  println(i+1+" "+listalibros.get(i).titulo)
                }
              } catch {
                case e: Exception => println("No hay libros disponiobles")
              }
              println("Escoja el libro (Posicion): \\n")
              var aux2 = readInt()
              list.get(aux-1).solicitar(listalibros.get(aux2-1))
              listalibros.remove(aux2-1)
              println("Cuanto tiempo solicita el libro? \n")
              var time = readInt()
              list.get(aux-1).dias=time
              data.guardarLibros()
              data.guardarSocios()
            }else{
              println("El usuario esta penalizado")
              data.guardarLibros()
              data.guardarSocios()
            }
          }else{
            println("El usuario ya ha solicitado demasiados libros")
          }
        case "4" =>
          data.recuperarLibros()
          data.recuperarSocios()
          println("Elija el socio que devuelve el libro \n")
          var listSocios = manSocios.getSocios
          var listLibros = manLibros.listaLibros
          for(i <- 0 until listSocios.size()){
            println((i+1)+") "+listSocios.get(i).nombre)
          }
          println("Escoja el nombre (Posicion numerica)? \n")
          var aux = readInt()
          println("Elija el libro del socio solicitado: \n")
          for(i <- 0  until listSocios.get(aux-1).libros.size()){
            println((i+1)+" "+listSocios.get(aux-1).libros.get(i).titulo)

          }
          println("Escoja el libro (Posicion) \n")
          var aux2= readInt()
          println("Dias que se ha quedado con el libro?")
          var time = readInt()

          if(time > 10){
            println("El socio tiene una penalizacione de ",3*time," dias por demora")
            listSocios.get(aux-1).banned=true
          }
          listLibros.add(listSocios.get(aux-1).libros.get(aux2-1))
          listSocios.get(aux-1).libros.remove(aux2-1)
          data.guardarLibros()
          data.guardarSocios()
        case _ =>
          print("Exit")
      }
    }while(sel!="7")
  }


}

