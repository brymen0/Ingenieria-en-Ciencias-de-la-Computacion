package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;

public class VistaPremios extends JFrame {

	private JPanel contentPane;
	public JButton btnOk;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaPremios frame = new VistaPremios();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaPremios() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 964, 673);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPremios = new JLabel("Premios");
		lblPremios.setHorizontalAlignment(SwingConstants.CENTER);
		lblPremios.setFont(new Font("Tahoma", Font.BOLD, 29));
		lblPremios.setBounds(242, 10, 553, 46);
		contentPane.add(lblPremios);
		
		JLabel lblNewLabel = new JLabel("1er lugar:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(104, 167, 157, 29);
		contentPane.add(lblNewLabel);
		
		JLabel lbldoLugar = new JLabel("2do lugar:");
		lbldoLugar.setHorizontalAlignment(SwingConstants.CENTER);
		lbldoLugar.setFont(new Font("Tahoma", Font.BOLD, 24));
		lbldoLugar.setBounds(104, 307, 157, 29);
		contentPane.add(lbldoLugar);
		
		JLabel lblerLugar = new JLabel("3er lugar:");
		lblerLugar.setHorizontalAlignment(SwingConstants.CENTER);
		lblerLugar.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblerLugar.setBounds(104, 433, 157, 29);
		contentPane.add(lblerLugar);
		
		JLabel lblNewLabel_1 = new JLabel("$100");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_1.setBounds(436, 167, 157, 29);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("$50");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_1_1.setBounds(436, 307, 157, 29);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("$25");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_1_2.setBounds(436, 433, 157, 29);
		contentPane.add(lblNewLabel_1_2);
		
		btnOk = new JButton("Ok");
		btnOk.setFont(new Font("SansSerif", Font.PLAIN, 20));
		btnOk.setBounds(461, 564, 117, 29);
		contentPane.add(btnOk);
	}
}
