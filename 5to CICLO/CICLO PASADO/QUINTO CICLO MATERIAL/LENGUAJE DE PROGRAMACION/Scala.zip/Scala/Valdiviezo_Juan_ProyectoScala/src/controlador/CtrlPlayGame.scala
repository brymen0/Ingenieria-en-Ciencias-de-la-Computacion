package controlador

import modelo.{DataPartido, DataPrediccion, DataUsuario, ManejoPartido, ManejoPrediccion, ManejoUsuario, Partido, Prediccion, Usuario}
import vista.{VentPlayGame, VistaGame}

import java.awt.event.{ActionEvent, MouseEvent}
import java.util
import javax.swing.table.DefaultTableModel

class CtrlPlayGame extends AdapterListener{
  var viewGame = new VentPlayGame
  viewGame.setVisible(true)
  viewGame.tablePlayGame.addMouseListener(this)
  var manejoPartido = new ManejoPartido
  var data = new DataPartido(manejoPartido)
  data.loadPartidos()
  var listaPartidos = manejoPartido.listaPartidos
  var aux = new Array[Partido](listaPartidos.size())
  aux= listaPartidos.toArray(aux)
  var model: DefaultTableModel = viewGame.tablePlayGame.getModel.asInstanceOf[DefaultTableModel]
  for(item:Partido <- aux){
    model.addRow(Array[AnyRef](item.equipoA,item.equipoB,item.fecha,"Jugar!"))
  }
  viewGame.tablePlayGame.setModel(model)
  override def mouseClicked(e: MouseEvent): Unit = {
    if ( e.getSource== viewGame.tablePlayGame) {
      val sel = this.viewGame.tablePlayGame.getSelectedRow
      println(sel)
      //var newPred = new CtrladdPred(sel)
      var teamA = this.viewGame.tablePlayGame.getValueAt(sel, 0).asInstanceOf[String]
      var teamB = this.viewGame.tablePlayGame.getValueAt(sel,1).asInstanceOf[String]
      var date = this.viewGame.tablePlayGame.getValueAt(sel,2).asInstanceOf[String]
      var nPlay = new CtrlPlay(teamA,teamB,date,sel)
      viewGame.setVisible(false)
    }
  }

}

class CtrlPlay(var teamA:String,var teamB:String,var date:String,var row:Int) extends AdapterListener{
  var play = new VistaGame
  play.setVisible(true)
  play.btnPlay.addActionListener(this)
  play.lblTeamA.setText(teamA)
  play.lblEquipoB.setText(teamB)
  play.lblFecha.setText(date)
  override def actionPerformed(e: ActionEvent): Unit = {
    if(e.getSource==play.btnPlay){
      var scoreA= play.txtScoreAF.getText
      var scoreB=play.txtScoreBF.getText
      var manPreds= new ManejoPrediccion
      var manUsers = new ManejoUsuario
      var manPartidos = new ManejoPartido
      var dataGames = new DataPartido(manPartidos)
      var dataUs = new DataUsuario(manUsers)
      var data = new DataPrediccion(manPreds)
      dataUs.loadUsers()
      data.loadPreds()
      dataGames.loadPartidos()
      //Lista de predicciones
      var listPreds= manPreds.listPreds
      var lpredi = new Array[Prediccion](listPreds.size())
      lpredi= listPreds.toArray(lpredi)
      //Lista de usuarios
      var listUsuarios = manUsers.listaUsuarios
      var lUsers = new Array[Usuario](listUsuarios.size())
      lUsers=listUsuarios.toArray(lUsers)
      //Lista de partidos
      var listGames = manPartidos.listaPartidos
      var lPartidos = new Array[Partido](listGames.size())
      lPartidos= listGames.toArray(lPartidos)
      play.setVisible(false)
      //Marcador final en la prediccion
      for(listaP <- lpredi){
        println(listaP.partido.equipoA)
        println(lPartidos(row).equipoA)
        if(listaP.partido.equals(lPartidos(this.row))){
          //Asignamos el marcador final
          listaP.partido.scoreAFin=scoreA
          listaP.partido.scoreBFin=scoreB

          listaP.calScore()
          for(user <- lUsers){
            if(user.equals(listaP.user)){
              user.points+= listaP.predPoints
              user.pred+=1
            }
          }
          manPartidos.listaPartidos.remove(row)
          dataGames.savePartidos()

        }


      }
      //Cambios en LUsers
      //Cambios en Lpredi

      manUsers.replaceArray(lUsers)
      manPreds.replaceArray(lpredi)
      data.savePreds()
      dataUs.saveUsers()


    }
  }

}
