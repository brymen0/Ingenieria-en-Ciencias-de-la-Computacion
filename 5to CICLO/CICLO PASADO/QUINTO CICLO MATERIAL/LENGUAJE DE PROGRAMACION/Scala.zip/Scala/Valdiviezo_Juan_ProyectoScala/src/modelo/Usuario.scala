package modelo

import java.io.{FileInputStream, FileNotFoundException, FileOutputStream, ObjectInputStream, ObjectOutputStream}
import java.util

class Usuario(var id:String,var nombre:String,var tlf:String) extends Serializable{
  var points:Double = 0
  var pred:Int = 0

  def equals(obj:Usuario): Boolean ={
    if(this.id==obj.id&&this.nombre==obj.nombre){
      return true
    }else{
      return false
    }
  }

}
class ManejoUsuario()extends Serializable{
  var listaUsuarios = new util.ArrayList[Usuario]()
  var data = new DataUsuario(this)
  def addUsers(usuario:Usuario){
    data.loadUsers()
    listaUsuarios.add(usuario)
    data.saveUsers()
  }

  def replaceUsers(listanueva:util.ArrayList[Usuario]): Unit ={
    listaUsuarios.clear()
    listaUsuarios.addAll(listanueva)
  }
  def replaceArray(arr:Array[Usuario]): Unit ={
    listaUsuarios.clear()
    for(item <- arr){
      listaUsuarios.add(item)
    }
  }

}
class DataUsuario(var manejo:ManejoUsuario)extends Serializable{
    def saveUsers(): Unit ={
      var output = new ObjectOutputStream(new FileOutputStream("users.dat"))
      output.writeObject(manejo)
      output.close
    }

  def loadUsers(): Unit ={
    try {
      var input = new ObjectInputStream(new FileInputStream("users.dat"))
      var data = input.readObject.asInstanceOf[ManejoUsuario]
      input.close
      manejo.replaceUsers(data.listaUsuarios)

      println("Usuarios recuperados con exito")

    }catch{
      case a: FileNotFoundException => println("No se pudo recuperar el archivo")
    }
  }
}