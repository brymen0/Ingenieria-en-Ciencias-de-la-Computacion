package modelo

import java.io.{FileInputStream, FileNotFoundException, FileOutputStream, ObjectInputStream, ObjectOutputStream}
import java.util

class Partido(var equipoA:String, var equipoB:String,var fecha:String) extends Serializable{
  var scoreAFin=""
  var scoreBFin=""

   def equals(obje: Partido): Boolean = {
    if(equipoA==obje.equipoA&&equipoB==obje.equipoB&&fecha==obje.fecha){
      return true
    }else{
      return false
    }
  }
}

class ManejoPartido() extends Serializable{
  var listaPartidos = new util.ArrayList[Partido]()
  var data = new DataPartido(this)

  def addPartido(partido:Partido): Unit ={
    data.loadPartidos()
    listaPartidos.add(partido)
    data.savePartidos()

  }

  def replacePartidos(listanueva:util.ArrayList[Partido]): Unit ={
    listaPartidos.clear()
    listaPartidos.addAll(listanueva)
  }
}

class DataPartido(var manejoPartido: ManejoPartido) extends Serializable{
  def savePartidos(): Unit ={
    var output = new ObjectOutputStream(new FileOutputStream("games.dat"))
    output.writeObject(manejoPartido)
    output.close
  }

  def loadPartidos(): Unit ={
    try {
      var input = new ObjectInputStream(new FileInputStream("games.dat"))
      var data = input.readObject.asInstanceOf[ManejoPartido]
      input.close
      manejoPartido.replacePartidos(data.listaPartidos)

      println("Partidos recuperados con exito")

    }catch{
      case a: FileNotFoundException => println("No se pudo recuperar el archivo")
    }
  }
}

