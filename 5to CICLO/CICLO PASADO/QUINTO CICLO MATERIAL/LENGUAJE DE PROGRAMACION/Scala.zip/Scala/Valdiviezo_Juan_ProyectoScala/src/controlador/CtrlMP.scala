package controlador

import java.awt.event.ActionEvent
import java.awt.event.ActionListener
import javax.swing.Action
import vista.VistaMP

class CtrlMP() extends ActionListener {
  var vistaMenu: VistaMP = null
  vistaMenu = new VistaMP
  vistaMenu.setVisible(true)
  vistaMenu.btnUsuarios.addActionListener(this)
  vistaMenu.btnGanadores.addActionListener(this)
  vistaMenu.btnPartidos.addActionListener(this)
  vistaMenu.btnPredicciones.addActionListener(this)
  vistaMenu.btnPremios.addActionListener(this)
  vistaMenu.itemJugar.addActionListener(this)
  vistaMenu.itemaddUser.addActionListener(this)
  vistaMenu.itemaddPartido.addActionListener(this)


  override def actionPerformed(e: ActionEvent): Unit = {
      if(e.getSource()== vistaMenu.itemaddUser){
        var adduser = new CtrladdUser
      }
      if(e.getSource() == vistaMenu.btnUsuarios){
        var rankUser = new CtrlUserRank
      }
      if(e.getSource==vistaMenu.btnPartidos){
        var games = new CtrltabPartidos
      }
      if(e.getSource==vistaMenu.itemaddPartido){
        var addPartdo= new CtrladdGame
      }
      if(e.getSource== vistaMenu.btnPredicciones){
        var pred = new CtrlTabPred
      }
      if(e.getSource==vistaMenu.itemJugar){
        var play = new CtrlPlayGame
      }
      if(e.getSource==vistaMenu.btnGanadores){
        var win = new CtrlGanadores
      }
      if(e.getSource==vistaMenu.btnPremios){
        var price = new CtrlPremios
      }

  }
}
