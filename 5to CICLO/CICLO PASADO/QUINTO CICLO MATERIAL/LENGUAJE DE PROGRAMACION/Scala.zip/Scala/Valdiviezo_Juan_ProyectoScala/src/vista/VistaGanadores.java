package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;

public class VistaGanadores extends JFrame {

	private JPanel contentPane;
	public JButton btnOk;
	public JLabel lblFp1;
	public JLabel lblFp2;
	public JLabel lblFp3;
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaGanadores frame = new VistaGanadores();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaGanadores() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 947, 680);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPremios = new JLabel("Premios");
		lblPremios.setHorizontalAlignment(SwingConstants.CENTER);
		lblPremios.setFont(new Font("Tahoma", Font.BOLD, 29));
		lblPremios.setBounds(228, 22, 553, 46);
		contentPane.add(lblPremios);
		
		JLabel lblNewLabel = new JLabel("1er lugar:");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblNewLabel.setBounds(90, 179, 157, 29);
		contentPane.add(lblNewLabel);
		
		lblFp1 = new JLabel(".");
		lblFp1.setHorizontalAlignment(SwingConstants.CENTER);
		lblFp1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblFp1.setBounds(422, 179, 157, 29);
		contentPane.add(lblFp1);
		
		JLabel lbldoLugar = new JLabel("2do lugar:");
		lbldoLugar.setHorizontalAlignment(SwingConstants.CENTER);
		lbldoLugar.setFont(new Font("Tahoma", Font.BOLD, 24));
		lbldoLugar.setBounds(90, 319, 157, 29);
		contentPane.add(lbldoLugar);
		
		lblFp2 = new JLabel(".");
		lblFp2.setHorizontalAlignment(SwingConstants.CENTER);
		lblFp2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblFp2.setBounds(422, 319, 157, 29);
		contentPane.add(lblFp2);
		
		lblFp3 = new JLabel(".");
		lblFp3.setHorizontalAlignment(SwingConstants.CENTER);
		lblFp3.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblFp3.setBounds(422, 445, 157, 29);
		contentPane.add(lblFp3);
		
		JLabel lblerLugar = new JLabel("3er lugar:");
		lblerLugar.setHorizontalAlignment(SwingConstants.CENTER);
		lblerLugar.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblerLugar.setBounds(90, 445, 157, 29);
		contentPane.add(lblerLugar);
		
		btnOk = new JButton("Ok");
		btnOk.setFont(new Font("SansSerif", Font.PLAIN, 20));
		btnOk.setBounds(447, 576, 117, 29);
		contentPane.add(btnOk);
	}

}
