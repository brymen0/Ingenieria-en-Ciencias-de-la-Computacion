package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.util.EventObject;
import javax.swing.table.DefaultTableModel;

public class VistaPartidos extends JFrame {

	private JPanel contentPane;
	public JTable tablePartidos;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaPartidos frame = new VistaPartidos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaPartidos() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1005, 686);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPartidos = new JLabel("Partidos");
		lblPartidos.setHorizontalAlignment(SwingConstants.CENTER);
		lblPartidos.setFont(new Font("Tahoma", Font.BOLD, 29));
		lblPartidos.setBounds(225, 10, 553, 46);
		contentPane.add(lblPartidos);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(55, 110, 863, 429);
		contentPane.add(scrollPane);
		
		tablePartidos = new JTable() {
			public boolean editCellAt(int row, int column, EventObject e) {
				return false;
			}
		};
		tablePartidos.editingCanceled(null);	
		tablePartidos.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
			"EquipoA", "EquipoB","Fecha","Predicci\u00F3n"
			}
		));

		scrollPane.setViewportView(tablePartidos);
	}

}
