package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;

public class VistaGame extends JFrame {

	private JPanel contentPane;
	public JTextField txtScoreAF;
	public JTextField txtScoreBF;
	public JButton btnPlay;
	public JLabel lblTeamA;
	public JLabel lblEquipoB;
	public JLabel lblFecha;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaGame frame = new VistaGame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaGame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 911, 623);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblJugarPartido = new JLabel("Jugar partido");
		lblJugarPartido.setHorizontalAlignment(SwingConstants.CENTER);
		lblJugarPartido.setFont(new Font("Tahoma", Font.BOLD, 29));
		lblJugarPartido.setBounds(187, 10, 553, 46);
		contentPane.add(lblJugarPartido);
		
		lblTeamA = new JLabel("Equipo A");
		lblTeamA.setHorizontalAlignment(SwingConstants.CENTER);
		lblTeamA.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblTeamA.setBounds(129, 157, 168, 46);
		contentPane.add(lblTeamA);
		
		JLabel lblVs = new JLabel("VS");
		lblVs.setHorizontalAlignment(SwingConstants.CENTER);
		lblVs.setFont(new Font("Tahoma", Font.BOLD, 33));
		lblVs.setBounds(379, 157, 168, 46);
		contentPane.add(lblVs);
		
		lblEquipoB = new JLabel("Equipo B");
		lblEquipoB.setHorizontalAlignment(SwingConstants.CENTER);
		lblEquipoB.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblEquipoB.setBounds(617, 157, 168, 46);
		contentPane.add(lblEquipoB);
		
		lblFecha = new JLabel("Fecha");
		lblFecha.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblFecha.setBounds(444, 229, 59, 27);
		contentPane.add(lblFecha);
		
		JLabel lblMarcadorFinal = new JLabel("Marcador final");
		lblMarcadorFinal.setHorizontalAlignment(SwingConstants.CENTER);
		lblMarcadorFinal.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblMarcadorFinal.setBounds(352, 262, 238, 46);
		contentPane.add(lblMarcadorFinal);
		
		txtScoreAF = new JTextField();
		txtScoreAF.setFont(new Font("Serif", Font.PLAIN, 46));
		txtScoreAF.setColumns(10);
		txtScoreAF.setBounds(340, 318, 96, 74);
		contentPane.add(txtScoreAF);
		
		JLabel lblVs_1 = new JLabel(":");
		lblVs_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblVs_1.setFont(new Font("Tahoma", Font.BOLD, 33));
		lblVs_1.setBounds(441, 323, 46, 46);
		contentPane.add(lblVs_1);
		
		txtScoreBF = new JTextField();
		txtScoreBF.setFont(new Font("Serif", Font.PLAIN, 46));
		txtScoreBF.setColumns(10);
		txtScoreBF.setBounds(497, 318, 96, 74);
		contentPane.add(txtScoreBF);
		
		btnPlay = new JButton("Jugar");
		btnPlay.setFont(new Font("SansSerif", Font.BOLD, 20));
		btnPlay.setBounds(414, 451, 111, 35);
		contentPane.add(btnPlay);
	}

}
