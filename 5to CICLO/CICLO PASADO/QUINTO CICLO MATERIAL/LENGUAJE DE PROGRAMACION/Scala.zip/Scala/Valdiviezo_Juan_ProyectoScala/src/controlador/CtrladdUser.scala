package controlador

import modelo.{DataUsuario, ManejoUsuario, Usuario}
import vista.{VistaUserRank, Vista_addUser}

import javax.swing.table.DefaultTableModel
import java.awt.event.{ActionEvent, ActionListener}
import java.util
import javax.swing.JOptionPane
import scala.collection.convert.ImplicitConversions.`collection AsScalaIterable`



class CtrladdUser()  extends ActionListener {
  var vistaaddUser= new Vista_addUser
  vistaaddUser.setVisible(true)
  vistaaddUser.btnGuardarUser.addActionListener(this)
  vistaaddUser.setDefaultCloseOperation(2)

  override def actionPerformed(e: ActionEvent): Unit ={
    if(e.getSource()==vistaaddUser.btnGuardarUser){
      var id = vistaaddUser.txtId.getText
      var nombre = vistaaddUser.txtNombre.getText
      var tlf = vistaaddUser.txtTelefono.getText
      var manejoUsuario= new ManejoUsuario
      var data = new DataUsuario(manejoUsuario)
      data.loadUsers()
      var band = false
      if(id!="" && nombre != "" && tlf !=""){
        var user = new Usuario(id, nombre, tlf)
        for(item <- manejoUsuario.listaUsuarios){
          if(item.id.equals(user.id)){
            band=true
          }
        }
        if(!band){
          manejoUsuario.addUsers(user)
        }else{
          JOptionPane.showMessageDialog(null,"Error,usuario agregado previamente")
        }

      }else{
        JOptionPane.showMessageDialog(null,"Error,campos incompletos")
      }

      vistaaddUser.txtId.setText("")
      vistaaddUser.txtNombre.setText("")
      vistaaddUser.txtTelefono.setText("")

    }
  }
}

class CtrlUserRank() extends AdapterListener{
  var vistaUserRank = new VistaUserRank
  vistaUserRank.setVisible(true)
  vistaUserRank.setDefaultCloseOperation(2)
  var manejoUsuario = new ManejoUsuario
  var data = new DataUsuario(manejoUsuario)
  data.loadUsers()
  var listaUsuarios = manejoUsuario.listaUsuarios
  var aux = new Array[Usuario](listaUsuarios.size)
  aux= listaUsuarios.toArray(aux)
  var sorted = aux.sortWith(_.points>_.points)

  var model: DefaultTableModel = vistaUserRank.tableUsersR.getModel.asInstanceOf[DefaultTableModel]

  //Cargamos la tabla
    for(item:Usuario <- sorted){
      model.addRow(Array[AnyRef](item.id,item.nombre,item.tlf,item.pred.toString,item.points.toString))
    }
    vistaUserRank.tableUsersR.setModel(model)


}
