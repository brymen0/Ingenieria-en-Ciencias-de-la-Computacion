package controlador

import modelo.{DataUsuario, ManejoUsuario, Usuario}
import vista.{VistaGanadores, VistaPremios}

import java.awt.event.ActionEvent

class CtrlGanadores extends AdapterListener{
  var ventW= new VistaGanadores
  ventW.setVisible(true)
  ventW.btnOk.addActionListener(this)
  var manUsers = new ManejoUsuario
  var data = new DataUsuario(manUsers)
  data.loadUsers()
  var listUsers = manUsers.listaUsuarios
  var aux = new Array[Usuario](listUsers.size())
  aux = listUsers.toArray(aux)
  var sorted: Array[Usuario] = aux.sortWith(_.points>_.points) //Ordena un objeto segun un parametro
  try{
    ventW.lblFp1.setText(sorted(0).nombre)
    ventW.lblFp2.setText(sorted(1).nombre)
    ventW.lblFp3.setText(sorted(2).nombre)
  }catch{
    case e: Exception => println(":D")
  }

  override def actionPerformed( e :ActionEvent): Unit = {
    if(e.getSource==ventW.btnOk){
      ventW.setVisible(false)
    }
  }
}

class CtrlPremios()extends AdapterListener{
  var price = new VistaPremios
  price.setVisible(true)
  price.btnOk.addActionListener(this)

  override def actionPerformed(e :ActionEvent): Unit = {
    if(e.getSource== price.btnOk){
      price.setVisible(false)
    }
  }

}
