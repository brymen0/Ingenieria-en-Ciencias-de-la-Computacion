package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class VentTPreds extends JFrame {

	private JPanel contentPane;
	public JTable tablePredicciones;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentTPreds frame = new VentTPreds();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentTPreds() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 983, 678);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPrediccionesRealizadas = new JLabel("Predicciones realizadas");
		lblPrediccionesRealizadas.setHorizontalAlignment(SwingConstants.CENTER);
		lblPrediccionesRealizadas.setFont(new Font("Tahoma", Font.BOLD, 29));
		lblPrediccionesRealizadas.setBounds(227, 10, 553, 46);
		contentPane.add(lblPrediccionesRealizadas);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(48, 99, 888, 424);
		contentPane.add(scrollPane);
		
		tablePredicciones = new JTable();
		tablePredicciones.setFont(new Font("Tahoma", Font.PLAIN, 19));
		tablePredicciones.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Usuario", "Equipo A", "Equipo B", "Fecha", "Predicci\u00F3n ","Marcador final", "Puntaje"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tablePredicciones.getColumnModel().getColumn(6).setResizable(false);
		
		scrollPane.setViewportView(tablePredicciones);
		
		JLabel lblNewLabel = new JLabel("Nota: De un click en la celda de puntaje para ver un resumen.");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(65, 554, 780, 25);
		contentPane.add(lblNewLabel);
	}
}
