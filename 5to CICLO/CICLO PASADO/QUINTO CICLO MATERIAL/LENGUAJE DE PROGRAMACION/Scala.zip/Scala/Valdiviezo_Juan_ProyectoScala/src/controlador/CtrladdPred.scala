package controlador

import modelo.{DataPartido, DataPrediccion, DataUsuario, ManejoPartido, ManejoPrediccion, ManejoUsuario, Prediccion, Usuario}
import vista.{VentTPreds, VistaAddPrediccion}

import java.awt.event.{ActionEvent, MouseEvent}
import java.util
import javax.swing.JOptionPane
import javax.swing.table.DefaultTableModel


class CtrladdPred(var row: Int) extends AdapterListener {
  var vistaAddPred = new VistaAddPrediccion
  var manPred = new ManejoPrediccion
  var dataPred = new DataPrediccion(manPred)
  var manGames = new ManejoPartido
  var dataP = new DataPartido(manGames)
  dataP.loadPartidos()
  dataPred.loadPreds()
  var listGames = manGames.listaPartidos

  vistaAddPred.setVisible(true)
  vistaAddPred.setDefaultCloseOperation(2)
  vistaAddPred.btnSalir.addActionListener(this)
  vistaAddPred.btnGuardar.addActionListener(this)
  vistaAddPred.lblTeamA.setText(listGames.get(row).equipoA)
  vistaAddPred.lblEquipoB.setText(listGames.get(row).equipoB)
  var manUsers = new ManejoUsuario
  var data = new DataUsuario(manUsers)
  var listaUser: util.ArrayList[Usuario] = manUsers.listaUsuarios
  data.loadUsers()
  var aux = new Array[Usuario](listaUser.size())
  var arr:Array[String] = new Array[String](listaUser.size())
  aux= listaUser.toArray(aux)

  var preds = new Array[Prediccion](manPred.listPreds.size())
  preds = manPred.listPreds.toArray(preds)

  for(aux:Usuario <- aux ){
    vistaAddPred.cbxUser.addItem(aux.nombre)
  }
  override def actionPerformed(e: ActionEvent): Unit = {
    if(e.getSource==vistaAddPred.btnGuardar){

      var indexUser = vistaAddPred.cbxUser.getSelectedIndex
      var scoreA = vistaAddPred.txtScoreA.getText
      var scoreB = vistaAddPred.txtScoreB.getText
      var band = false
      println(aux(indexUser).nombre,indexUser)
      var pred = new Prediccion(listGames.get(row),aux(indexUser),indexUser,scoreA,scoreB)
      if(scoreA!=""&&scoreB!=""){
        for(item <- preds){
          if(item.equal(pred)){
            item.scoreA=scoreA
            item.scoreB=scoreB
            band = true
            manPred.replaceArray(preds)
          }
        }
        if(!band){
          manPred.addPrediccion(pred)
        }
        dataPred.savePreds()
      }

      JOptionPane.showMessageDialog(null,"Prediccion agregada con exito")
      vistaAddPred.txtScoreA.setText("")
      vistaAddPred.txtScoreB.setText("")
    }
    if(e.getSource==vistaAddPred.btnSalir){
        vistaAddPred.setVisible(false)
        var dos= new CtrltabPartidos
    }

  }
}

class CtrlTabPred extends AdapterListener{
  var viewTabPreds= new VentTPreds
  viewTabPreds.setVisible(true)
  viewTabPreds.tablePredicciones.addMouseListener(this)
  var manPreds= new ManejoPrediccion
  var data = new DataPrediccion(manPreds)
  data.loadPreds()
  var listPreds= manPreds.listPreds
  var aux = new Array[Prediccion](listPreds.size())
  aux= listPreds.toArray(aux)
  var model: DefaultTableModel = viewTabPreds.tablePredicciones.getModel.asInstanceOf[DefaultTableModel]

  for(item:Prediccion <- aux){
    model.addRow(Array[AnyRef](item.user.nombre,item.partido.equipoA,item.partido.equipoB,item.partido.fecha,item.scoreA +" : "+ item.scoreB,item.partido.scoreAFin+" : "+item.partido.scoreBFin,item.predPoints.toString))
  }
  viewTabPreds.tablePredicciones.setModel(model)
  override def mouseClicked(e: MouseEvent): Unit = {
    if(e.getSource==viewTabPreds.tablePredicciones){
      val sel = this.viewTabPreds.tablePredicciones.getSelectedRow
      val col = this.viewTabPreds.tablePredicciones.getSelectedColumn
      val res = new CtrlResumen(sel)
    }
  }
}

