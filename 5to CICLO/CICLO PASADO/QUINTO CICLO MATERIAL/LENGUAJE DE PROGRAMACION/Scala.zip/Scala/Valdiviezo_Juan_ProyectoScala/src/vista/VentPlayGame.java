package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class VentPlayGame extends JFrame {

	private JPanel contentPane;
	public JTable tablePlayGame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentPlayGame frame = new VentPlayGame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentPlayGame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1007, 683);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPrediccionesRealizadas = new JLabel("Predicciones realizadas");
		lblPrediccionesRealizadas.setHorizontalAlignment(SwingConstants.CENTER);
		lblPrediccionesRealizadas.setFont(new Font("Tahoma", Font.BOLD, 29));
		lblPrediccionesRealizadas.setBounds(244, 30, 553, 46);
		contentPane.add(lblPrediccionesRealizadas);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(65, 119, 888, 424);
		contentPane.add(scrollPane);
		
		tablePlayGame = new JTable();
		tablePlayGame.setFont(new Font("Tahoma", Font.PLAIN, 21));
		tablePlayGame.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Equipo A", "Equipo B", "Fecha", "Jugar"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tablePlayGame.getColumnModel().getColumn(0).setResizable(false);
		tablePlayGame.getColumnModel().getColumn(1).setResizable(false);
		tablePlayGame.getColumnModel().getColumn(2).setResizable(false);
		tablePlayGame.getColumnModel().getColumn(3).setResizable(false);
		scrollPane.setViewportView(tablePlayGame);
		
		JLabel lblNotaDeUn = new JLabel("Nota: De un click en la celda de \"Jugar\" para ejecutar un partido.");
		lblNotaDeUn.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNotaDeUn.setBounds(82, 574, 581, 25);
		contentPane.add(lblNotaDeUn);
	}

}
