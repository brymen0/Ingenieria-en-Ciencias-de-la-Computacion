import controlador.CtrlMP

object Launcher {
  def main(args: Array[String]): Unit = {
      var xd = new CtrlMP
  }
}
