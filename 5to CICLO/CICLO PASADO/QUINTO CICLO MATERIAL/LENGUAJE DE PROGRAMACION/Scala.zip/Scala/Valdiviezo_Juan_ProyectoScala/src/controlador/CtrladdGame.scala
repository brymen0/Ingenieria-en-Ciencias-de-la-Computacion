package controlador

import com.sun.org.apache.xpath.internal.operations.Or
import modelo.{DataPartido, ManejoPartido, Partido}
import org.omg.CORBA.ORB
import vista.{VistaPartidos, VistaaddPartido}

import java.awt.event.{ActionEvent, MouseEvent}
import java.util
import javax.swing.JOptionPane
import javax.swing.table.DefaultTableModel
import scala.collection.mutable.ListBuffer

class CtrladdGame extends AdapterListener{
  var vistaAddGame: VistaaddPartido = new VistaaddPartido
  vistaAddGame.setVisible(true)
  vistaAddGame.setDefaultCloseOperation(2)
  vistaAddGame.btnAgregar.addActionListener(this)
  vistaAddGame.btnSalir.addActionListener(this)
  var mangame = new ManejoPartido

  override def actionPerformed(e: ActionEvent): Unit = {
    if(e.getSource==vistaAddGame.btnAgregar){
      var teamA = vistaAddGame.cbxTeamA.getSelectedItem.toString
      var teamB = vistaAddGame.cbxTeamB.getSelectedItem.toString
      var manAux = new ManejoPartido
      var data = new DataPartido(manAux)
      data.loadPartidos()
      var band = false
      var arrAux = new Array[Partido](manAux.listaPartidos.size())
      arrAux = manAux.listaPartidos.toArray(arrAux)
      if(!teamA.equals("Vacío")&&(!teamB.equals("Vacío"))){
        if(!teamA.equals(teamB)){
          var game = new Partido(teamA,teamB,vistaAddGame.txtDate.getText)
          for(item <- arrAux){
            if(item.equals(game)){
              band=true
            }
          }
          if(!band){
            mangame.addPartido(game)
          }else{
            JOptionPane.showMessageDialog(null,"Error, partido previamente agregado")
          }


          vistaAddGame.cbxTeamA.setSelectedIndex(0)
          vistaAddGame.cbxTeamB.setSelectedIndex(0)
        }else{
          JOptionPane.showMessageDialog(null,"Error, datos invalidos")
        }
      }
    }
    if(e.getSource==vistaAddGame.btnSalir){
      vistaAddGame.setVisible(false)
    }
  }

}

class CtrltabPartidos() extends AdapterListener{
  var vistaTabGames: VistaPartidos = new VistaPartidos
  vistaTabGames.setVisible(true)
  vistaTabGames.setDefaultCloseOperation(2)
  var manejoPartido = new ManejoPartido
  var data = new DataPartido(manejoPartido)
  data.loadPartidos()
  var listaPartidos = manejoPartido.listaPartidos
  var aux = new Array[Partido](listaPartidos.size())
  aux= listaPartidos.toArray(aux)
  vistaTabGames.tablePartidos.addMouseListener(this)
  var model: DefaultTableModel = vistaTabGames.tablePartidos.getModel.asInstanceOf[DefaultTableModel]

  for(item:Partido <- aux){
    model.addRow(Array[AnyRef](item.equipoA,item.equipoB,item.fecha,"Realizar predicción"))
  }
  vistaTabGames.tablePartidos.setModel(model)

  override def mouseClicked(e: MouseEvent): Unit = {
    if ( e.getSource== vistaTabGames.tablePartidos) {
      val sel = this.vistaTabGames.tablePartidos.getSelectedRow
      println(sel)
     // var teamA = this.vistaTabGames.tablePartidos.getValueAt(sel, 0).asInstanceOf[String]
      var newPred = new CtrladdPred(sel)
      vistaTabGames.setVisible(false)
    }
  }
}

