package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;

public class VistaaddPartido extends JFrame {

	private JPanel contentPane;
	public JComboBox cbxTeamB;
	public JButton btnSalir;
	public JButton btnAgregar;
	public JComboBox cbxTeamA;
	private JLabel lblNewLabel_1;
	public JTextField txtDate;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaaddPartido frame = new VistaaddPartido();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaaddPartido() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 863, 659);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("A\u00F1adir participante");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 29));
		lblNewLabel.setBounds(177, 24, 553, 46);
		contentPane.add(lblNewLabel);
		
		cbxTeamA = new JComboBox();
		cbxTeamA.setFont(new Font("SansSerif", Font.BOLD, 21));
		cbxTeamA.setModel(new DefaultComboBoxModel(new String[] {"Vac\u00EDo", "Ecuador", "Colombia", "Per\u00FA", "Brazil", "Argentina", "USA", "Alemania", "Espa\u00F1a", "M\u00E9xco", "Portugal", "Jap\u00F3n", "Canada", "Chile"}));
		cbxTeamA.setBounds(151, 197, 170, 74);
		contentPane.add(cbxTeamA);
		
		JLabel lblVs = new JLabel("VS");
		lblVs.setHorizontalAlignment(SwingConstants.CENTER);
		lblVs.setFont(new Font("Tahoma", Font.BOLD, 32));
		lblVs.setBounds(398, 209, 88, 46);
		contentPane.add(lblVs);
		
		btnAgregar = new JButton("Agregar");
		btnAgregar.setFont(new Font("SansSerif", Font.PLAIN, 21));
		btnAgregar.setBounds(192, 443, 129, 36);
		contentPane.add(btnAgregar);
		
		btnSalir = new JButton("Salir");
		btnSalir.setFont(new Font("SansSerif", Font.PLAIN, 21));
		btnSalir.setBounds(559, 443, 129, 36);
		contentPane.add(btnSalir);
		
		cbxTeamB = new JComboBox();
		cbxTeamB.setModel(new DefaultComboBoxModel(new String[] {"Vac\u00EDo", "Ecuador", "Colombia", "Per\u00FA", "Brazil", "Argentina", "USA", "Alemania", "Espa\u00F1a", "M\u00E9xco", "Portugal", "Jap\u00F3n", "Canada", "Chile"}));
		cbxTeamB.setFont(new Font("SansSerif", Font.BOLD, 21));
		cbxTeamB.setBounds(559, 197, 170, 74);
		contentPane.add(cbxTeamB);
		
		lblNewLabel_1 = new JLabel("Fecha");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblNewLabel_1.setBounds(414, 306, 88, 46);
		contentPane.add(lblNewLabel_1);
		
		txtDate = new JTextField();
		txtDate.setText("3/2/2022");
		txtDate.setHorizontalAlignment(SwingConstants.CENTER);
		txtDate.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtDate.setBounds(398, 362, 104, 23);
		contentPane.add(txtDate);
		txtDate.setColumns(10);
	}
}
