package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JToolBar;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JLabel;

public class VistaMP extends JFrame {

	private JPanel contentPane;
	public JMenuItem itemaddUser;
	public JMenuItem itemaddPartido;
	public JMenuItem itemJugar;
	public JButton btnUsuarios;
	public JButton btnPartidos;
	public JButton btnPredicciones;
	public JButton btnPremios;
	public JButton btnGanadores;
	public Image imagen;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaMP frame = new VistaMP();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaMP() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 908, 646);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnAdmin = new JMenu("Administrar");
		menuBar.add(mnAdmin);
		
		itemaddUser = new JMenuItem("Agregar Usuario");
		mnAdmin.add(itemaddUser);
		
		itemaddPartido = new JMenuItem("Agregar Partido");
		mnAdmin.add(itemaddPartido);
		
		itemJugar = new JMenuItem("Jugar Partido");
		mnAdmin.add(itemJugar);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		btnUsuarios = new JButton("Usuarios");
		btnUsuarios.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnUsuarios.setBounds(558, 92, 282, 54);
		contentPane.add(btnUsuarios);
		
		btnPartidos = new JButton("Partidos");
		btnPartidos.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnPartidos.setBounds(558, 202, 282, 54);
		contentPane.add(btnPartidos);
		
		btnPredicciones = new JButton("Predicciones");
		btnPredicciones.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnPredicciones.setBounds(558, 303, 282, 54);
		contentPane.add(btnPredicciones);
		
		btnPremios = new JButton("Premios");
		btnPremios.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnPremios.setBounds(558, 396, 282, 54);
		contentPane.add(btnPremios);
		
		btnGanadores = new JButton("Ganadores");
		btnGanadores.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnGanadores.setBounds(558, 497, 282, 54);
		contentPane.add(btnGanadores);
		
		JLabel lblNewLabel_1 = new JLabel("");
		//imagen = new ImageIcon(this.getClass().getResource("../logo.png")).getImage();
		
		//lblNewLabel_1.setIcon(new ImageIcon(imagen.getScaledInstance(300, 300, Image.SCALE_DEFAULT)));
		lblNewLabel_1.setBounds(88, 172, 322, 315);
		contentPane.add(lblNewLabel_1);
	}
}
