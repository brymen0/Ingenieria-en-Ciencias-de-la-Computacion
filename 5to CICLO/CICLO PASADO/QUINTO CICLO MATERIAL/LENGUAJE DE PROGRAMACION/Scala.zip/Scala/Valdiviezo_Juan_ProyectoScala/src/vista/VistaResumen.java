package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Label;
import java.awt.Color;
import javax.swing.JButton;

public class VistaResumen extends JFrame {

	private JPanel contentPane;
	public JLabel lblAResult;
	public JLabel lblAMarcador;
	public JLabel lblAMarcRes;
	public JLabel lblAM3;
	public JLabel lblAMR3;
	public JLabel lblAGolesT;
	public JLabel lblAlmost;
	public JLabel lblATotal;
	public JButton btnOk;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaResumen frame = new VistaResumen();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaResumen() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 577, 678);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblResumen = new JLabel("Resumen");
		lblResumen.setHorizontalAlignment(SwingConstants.CENTER);
		lblResumen.setFont(new Font("Tahoma", Font.BOLD, 29));
		lblResumen.setBounds(10, 10, 553, 46);
		contentPane.add(lblResumen);
		
		JLabel lblNewLabel = new JLabel("------------------------------------------------------------------------------------------------------------------------------------------------------------");
		lblNewLabel.setBounds(0, 66, 573, 13);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Acierto al resultado:");
		lblNewLabel_1.setFont(new Font("SansSerif", Font.BOLD, 20));
		lblNewLabel_1.setBounds(31, 110, 205, 26);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Acierto al marcador:");
		lblNewLabel_1_1.setFont(new Font("SansSerif", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(31, 170, 205, 26);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Acierto marcador y resultado:");
		lblNewLabel_1_2.setFont(new Font("SansSerif", Font.BOLD, 20));
		lblNewLabel_1_2.setBounds(31, 227, 296, 26);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Acierto marcador >3 goles:");
		lblNewLabel_1_3.setFont(new Font("SansSerif", Font.BOLD, 20));
		lblNewLabel_1_3.setBounds(31, 280, 256, 26);
		contentPane.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Acierto marcador y resultado >3:");
		lblNewLabel_1_4.setFont(new Font("SansSerif", Font.BOLD, 20));
		lblNewLabel_1_4.setBounds(31, 338, 310, 26);
		contentPane.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Bono goles de un equipo:");
		lblNewLabel_1_5.setFont(new Font("SansSerif", Font.BOLD, 20));
		lblNewLabel_1_5.setBounds(31, 396, 242, 26);
		contentPane.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Bono \"se acerc\u00F3\":");
		lblNewLabel_1_6.setFont(new Font("SansSerif", Font.BOLD, 20));
		lblNewLabel_1_6.setBounds(31, 453, 205, 26);
		contentPane.add(lblNewLabel_1_6);
		
		lblAResult = new JLabel("*");
		lblAResult.setHorizontalAlignment(SwingConstants.CENTER);
		lblAResult.setFont(new Font("SansSerif", Font.BOLD, 20));
		lblAResult.setBounds(443, 110, 65, 26);
		contentPane.add(lblAResult);
		
		lblAMarcador = new JLabel("*");
		lblAMarcador.setHorizontalAlignment(SwingConstants.CENTER);
		lblAMarcador.setFont(new Font("SansSerif", Font.BOLD, 20));
		lblAMarcador.setBounds(443, 170, 65, 26);
		contentPane.add(lblAMarcador);
		
		lblAMarcRes = new JLabel("*");
		lblAMarcRes.setHorizontalAlignment(SwingConstants.CENTER);
		lblAMarcRes.setFont(new Font("SansSerif", Font.BOLD, 20));
		lblAMarcRes.setBounds(443, 227, 65, 26);
		contentPane.add(lblAMarcRes);
		
		lblAM3 = new JLabel("*");
		lblAM3.setHorizontalAlignment(SwingConstants.CENTER);
		lblAM3.setFont(new Font("SansSerif", Font.BOLD, 20));
		lblAM3.setBounds(443, 280, 65, 26);
		contentPane.add(lblAM3);
		
		lblAMR3 = new JLabel("*");
		lblAMR3.setHorizontalAlignment(SwingConstants.CENTER);
		lblAMR3.setFont(new Font("SansSerif", Font.BOLD, 20));
		lblAMR3.setBounds(443, 338, 65, 26);
		contentPane.add(lblAMR3);
		
		lblAGolesT = new JLabel("*");
		lblAGolesT.setHorizontalAlignment(SwingConstants.CENTER);
		lblAGolesT.setFont(new Font("SansSerif", Font.BOLD, 20));
		lblAGolesT.setBounds(443, 396, 65, 26);
		contentPane.add(lblAGolesT);
		
		lblAlmost = new JLabel("*");
		lblAlmost.setHorizontalAlignment(SwingConstants.CENTER);
		lblAlmost.setFont(new Font("SansSerif", Font.BOLD, 20));
		lblAlmost.setBounds(443, 453, 65, 26);
		contentPane.add(lblAlmost);
		
		JLabel lblNewLabel_1_6_1 = new JLabel("Total:");
		lblNewLabel_1_6_1.setForeground(new Color(255, 0, 0));
		lblNewLabel_1_6_1.setFont(new Font("SansSerif", Font.BOLD, 22));
		lblNewLabel_1_6_1.setBounds(263, 500, 78, 26);
		contentPane.add(lblNewLabel_1_6_1);
		
		lblATotal = new JLabel("*");
		lblATotal.setHorizontalAlignment(SwingConstants.CENTER);
		lblATotal.setFont(new Font("SansSerif", Font.BOLD, 22));
		lblATotal.setBounds(263, 536, 65, 26);
		contentPane.add(lblATotal);
		
		JLabel lblNewLabel_2 = new JLabel("------------------------------------------------------------------------------------------------------------------------------------------------------------");
		lblNewLabel_2.setBounds(0, 561, 573, 13);
		contentPane.add(lblNewLabel_2);
		
		btnOk = new JButton("Ok");
		btnOk.setFont(new Font("SansSerif", Font.PLAIN, 20));
		btnOk.setBounds(247, 584, 105, 39);
		contentPane.add(btnOk);
	}
}
