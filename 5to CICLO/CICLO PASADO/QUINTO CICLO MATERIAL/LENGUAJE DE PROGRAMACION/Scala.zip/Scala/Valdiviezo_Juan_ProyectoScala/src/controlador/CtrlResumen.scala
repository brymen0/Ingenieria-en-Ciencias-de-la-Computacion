package controlador

import modelo.{DataPrediccion, ManejoPrediccion, Prediccion}
import vista.VistaResumen

import java.awt.event.ActionEvent

class CtrlResumen(var row:Int) extends AdapterListener{
  var vi = new VistaResumen
  vi.setVisible(true)
  vi.btnOk.addActionListener(this)
  var manPreds = new ManejoPrediccion
  var data = new DataPrediccion(manPreds)
  data.loadPreds()
  var listPreds: Prediccion = manPreds.listPreds.get(row)
  vi.lblAResult.setText(listPreds.ar)
  vi.lblAMarcador.setText(listPreds.am)
  vi.lblAMarcRes.setText(listPreds.arm)
  vi.lblAM3.setText(listPreds.am3)
  vi.lblAMR3.setText(listPreds.arm3)
  vi.lblAGolesT.setText(listPreds.aGE)
  vi.lblAlmost.setText(listPreds.almost)
  vi.lblATotal.setText(listPreds.predPoints.toString)
  override def actionPerformed(e: ActionEvent): Unit = {
    if(e.getSource==vi.btnOk){
      vi.setVisible(false)
    }
  }


}
