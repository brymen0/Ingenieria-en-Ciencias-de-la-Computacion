package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;

public class Vista_addUser extends JFrame {

	public JPanel contentPane;
	public JTextField txtId;
	public JTextField txtNombre;
	public JTextField txtTelefono;
	public JButton btnGuardarUser;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Vista_addUser frame = new Vista_addUser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Vista_addUser() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 675);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("A\u00F1adir participante");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 29));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(173, 30, 553, 46);
		contentPane.add(lblNewLabel);
		
		JLabel lblId = new JLabel("ID:");
		lblId.setHorizontalAlignment(SwingConstants.CENTER);
		lblId.setFont(new Font("Tahoma", Font.BOLD, 29));
		lblId.setBounds(73, 165, 110, 46);
		contentPane.add(lblId);
		
		txtId = new JTextField();
		txtId.setBounds(225, 176, 504, 30);
		contentPane.add(txtId);
		txtId.setColumns(10);
		
		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setHorizontalAlignment(SwingConstants.CENTER);
		lblNombre.setFont(new Font("Tahoma", Font.BOLD, 29));
		lblNombre.setBounds(25, 269, 158, 46);
		contentPane.add(lblNombre);
		
		txtNombre = new JTextField();
		txtNombre.setColumns(10);
		txtNombre.setBounds(225, 280, 504, 30);
		contentPane.add(txtNombre);
		
		JLabel lblTelfono = new JLabel("Tel\u00E9fono:");
		lblTelfono.setHorizontalAlignment(SwingConstants.CENTER);
		lblTelfono.setFont(new Font("Tahoma", Font.BOLD, 29));
		lblTelfono.setBounds(25, 383, 158, 46);
		contentPane.add(lblTelfono);
		
		txtTelefono = new JTextField();
		txtTelefono.setColumns(10);
		txtTelefono.setBounds(225, 394, 504, 30);
		contentPane.add(txtTelefono);
		
		btnGuardarUser = new JButton("Guardar");
		btnGuardarUser.setFont(new Font("SansSerif", Font.PLAIN, 21));
		btnGuardarUser.setBounds(380, 533, 129, 36);
		contentPane.add(btnGuardarUser);
	}
}
