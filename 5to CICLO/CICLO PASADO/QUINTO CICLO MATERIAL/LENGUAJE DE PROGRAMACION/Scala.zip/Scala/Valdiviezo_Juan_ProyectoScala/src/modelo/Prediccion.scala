package modelo

import java.io.{FileInputStream, FileNotFoundException, FileOutputStream, ObjectInputStream, ObjectOutputStream}
import java.util

class Prediccion(var partido: Partido,var user:Usuario,var idexUser:Int,var scoreA:String,var scoreB:String)extends Serializable {
  var ar="0"
  var am="0"
  var arm="0"
  var am3="0"
  var arm3="0"
  var aGE="0"
  var almost ="0"
  var predPoints:Double=0

  def equal(obj:Prediccion): Boolean ={
    //Fix this mess
    if(partido.equipoA==obj.partido.equipoA&&partido.equipoB==obj.partido.equipoB&&partido.fecha==obj.partido.fecha&&user.id==obj.user.id){
      return true
    }else{
      return false
    }
  }

  def calScore(): Unit ={
    var scoreAFin = Integer.parseInt(partido.scoreAFin)
    var scoreBFin = Integer.parseInt(partido.scoreBFin)
    var scoreA = Integer.parseInt(this.scoreA)
    var scoreB = Integer.parseInt(this.scoreB)
    var scoreTotal:Double = 0

    //Caso acierta resultado
    if((scoreA<scoreB && scoreAFin<scoreBFin) || (scoreB<scoreA && scoreBFin<scoreAFin)){
      scoreTotal += 2
      this.ar ="2"
    }
    //Caso acierto marcador
    if((scoreA==scoreAFin && scoreB==scoreBFin) || (scoreA==scoreBFin && scoreB==scoreAFin)){
      scoreTotal += 1
      this.am="1"
      //Caso Marcador >3 goles
      if ((scoreAFin + scoreBFin)>3){
        this.am3="1"
        scoreTotal +=1
      }
    }
    //Caso acierto y marcador
    if(scoreA == scoreAFin && scoreB == scoreBFin){
      scoreTotal += 3
      this.arm="3"
      //Caso marcador y resultados >3
      if((scoreAFin + scoreBFin)>3){
        scoreTotal += 1
        this.arm3="1"
      }
      //Bono casi se acerca
    }else if(((scoreA == (scoreAFin+1) || scoreA == (scoreAFin-1)) &&(scoreB == scoreBFin)) || ((scoreA == scoreAFin) && (scoreB == (scoreBFin+1) || scoreB == (scoreBFin-1)))){
      scoreTotal += 0.5
      this.almost="0.5"
      //Bonos de goles de un equipo
    }else if(scoreA == scoreAFin || scoreB == scoreBFin){
      scoreTotal +=0.5
      this.aGE="0.5"
    }
    this.predPoints=scoreTotal

  }

}

class ManejoPrediccion() extends Serializable{
  var listPreds = new util.ArrayList[Prediccion]()
  var data = new DataPrediccion(this)

  def addPrediccion(pred:Prediccion): Unit ={
    data.loadPreds()
    listPreds.add(pred)
    data.savePreds()
  }

  def replacePreds(newList:util.ArrayList[Prediccion]): Unit ={
    listPreds.clear()
    listPreds.addAll(newList)
  }

  def replaceArray(arr: Array[Prediccion]): Unit ={
    listPreds.clear()
    for(item <- arr){
      listPreds.add(item)
    }
  }
}

class DataPrediccion(var manejoPred: ManejoPrediccion) extends Serializable{
  def savePreds(): Unit ={
    var output = new ObjectOutputStream(new FileOutputStream("preds.dat"))
    output.writeObject(manejoPred)
    output.close
  }

  def loadPreds(): Unit ={
    try {
      var input = new ObjectInputStream(new FileInputStream("preds.dat"))
      var data = input.readObject.asInstanceOf[ManejoPrediccion]
      input.close
      manejoPred.replacePreds(data.listPreds)

      println("Predicciones recuperadas con exito")

    }catch{
      case a: FileNotFoundException => println("No se pudo recuperar el archivo")
    }
  }
}

