package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;

public class VistaAddPrediccion extends JFrame {

	private JPanel contentPane;
	public JTextField txtScoreA;
	public JTextField txtScoreB;
	public JLabel lblTeamA;
	public JLabel lblEquipoB;
	public JLabel lblFecha;
	public JComboBox <String> cbxUser;
	public JButton btnGuardar;
	public JButton btnSalir;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaAddPrediccion frame = new VistaAddPrediccion();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaAddPrediccion() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 936, 663);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRealizarPrediccin = new JLabel("Realizar predicci\u00F3n");
		lblRealizarPrediccin.setHorizontalAlignment(SwingConstants.CENTER);
		lblRealizarPrediccin.setFont(new Font("Tahoma", Font.BOLD, 29));
		lblRealizarPrediccin.setBounds(192, 20, 553, 46);
		contentPane.add(lblRealizarPrediccin);
		
		lblTeamA = new JLabel("Equipo A");
		lblTeamA.setHorizontalAlignment(SwingConstants.CENTER);
		lblTeamA.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblTeamA.setBounds(134, 167, 168, 46);
		contentPane.add(lblTeamA);
		
		lblEquipoB = new JLabel("Equipo B");
		lblEquipoB.setHorizontalAlignment(SwingConstants.CENTER);
		lblEquipoB.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblEquipoB.setBounds(622, 167, 168, 46);
		contentPane.add(lblEquipoB);
		
		JLabel lblVs = new JLabel("VS");
		lblVs.setHorizontalAlignment(SwingConstants.CENTER);
		lblVs.setFont(new Font("Tahoma", Font.BOLD, 33));
		lblVs.setBounds(384, 167, 168, 46);
		contentPane.add(lblVs);
		
		JLabel lblMarcador = new JLabel("Marcador");
		lblMarcador.setHorizontalAlignment(SwingConstants.CENTER);
		lblMarcador.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblMarcador.setBounds(384, 277, 168, 46);
		contentPane.add(lblMarcador);
		
		lblFecha = new JLabel("Fecha");
		lblFecha.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblFecha.setBounds(433, 249, 59, 27);
		contentPane.add(lblFecha);
		
		txtScoreA = new JTextField();
		txtScoreA.setFont(new Font("Serif", Font.PLAIN, 46));
		txtScoreA.setBounds(345, 328, 96, 74);
		contentPane.add(txtScoreA);
		txtScoreA.setColumns(10);
		
		txtScoreB = new JTextField();
		txtScoreB.setFont(new Font("Serif", Font.PLAIN, 46));
		txtScoreB.setColumns(10);
		txtScoreB.setBounds(502, 328, 96, 74);
		contentPane.add(txtScoreB);
		
		JLabel lblVs_1 = new JLabel(":");
		lblVs_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblVs_1.setFont(new Font("Tahoma", Font.BOLD, 33));
		lblVs_1.setBounds(446, 333, 46, 46);
		contentPane.add(lblVs_1);
		
		JLabel lblParticipante = new JLabel("Participante:");
		lblParticipante.setHorizontalAlignment(SwingConstants.CENTER);
		lblParticipante.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblParticipante.setBounds(145, 437, 168, 46);
		contentPane.add(lblParticipante);
		
		cbxUser = new JComboBox<>();
		
		
		cbxUser.setFont(new Font("Tahoma", Font.PLAIN, 23));
		cbxUser.setBounds(345, 456, 263, 27);
		contentPane.add(cbxUser);
		
		btnGuardar = new JButton("Guardar");
		btnGuardar.setFont(new Font("SansSerif", Font.BOLD, 20));
		btnGuardar.setBounds(217, 553, 111, 35);
		contentPane.add(btnGuardar);
		
		btnSalir = new JButton("Salir");
		btnSalir.setFont(new Font("SansSerif", Font.BOLD, 20));
		btnSalir.setBounds(572, 553, 111, 35);
		contentPane.add(btnSalir);
	}

}
