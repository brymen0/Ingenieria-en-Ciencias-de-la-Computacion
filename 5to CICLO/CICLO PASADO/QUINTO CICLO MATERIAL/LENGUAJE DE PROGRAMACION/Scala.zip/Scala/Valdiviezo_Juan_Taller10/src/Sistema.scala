import java.io.{FileInputStream, FileNotFoundException, FileOutputStream, ObjectInputStream, ObjectOutputStream}
import java.util
import scala.io.StdIn.{readChar, readFloat, readInt, readLine}

object Sistema {
  def main(args: Array[String]): Unit = {
    var sel = "0"
    var manTar = new ManejoTareas
    var manPro = new ManejoProyectos
    var data = new Data(manTar,manPro)
    do{
      println("Menu proyectos\n " +
        "1)Agregar tareas \n" +
        "2) Agregar proyectos \n " +
        "3)Listar proyectos (tareas)\n" +
        "4)Salir \n" +
        "Seleccione una opcion \n")
      sel = readLine()
      sel match {
        case "1" =>
          data.recuperarTareas()
          var listaTareas = manTar.listaTareas
          var tasks =0
          var band = false
          println("Ingresar tarea nueva")
          println("Nombre de la tarea?")
          var nombre = readLine()
          println("Fecha en la que se realizara la tarea? dd/mm/aaaa")
          var fecha= readLine()
          println("Lugar donde se realizará la tarea? [Oficina,ciudad, zona rural]")
          var lugar = readLine()
          if(listaTareas.size()>0){
            print("Tareas que tienen que hacerse antes? \n")
            var cont =1
            for(i <- 0 until listaTareas.size()){
              println(cont,") ",listaTareas.get(i).nombre)
              cont+=1
            }
            print("Digite el indice? \n")
             tasks= readInt()
            band=true
          }else{
            println("No hay tareas anteriores, asi que no puede depender de otra tarea...")

          }
          print("Tipo de tarea? [Produccion,Recaudacion,Reuniones]\n")
          var tipo = readLine()
          print("Costo de la tarea? \n")
          var costo = readFloat()

          //Tarea previa
          var tarea = new Tarea(nombre,fecha,lugar,tipo,costo)
          if(band==true){
            tarea.tasks.add(listaTareas.get(tasks-1))
          }
          manTar.addTasks(tarea)
          data.guardarTareas()

        case "2" =>
          data.recuperarTareas()
          var listaTareas = manTar.listaTareas
          var listaAxu= new util.ArrayList[Tarea]()
          print("Ingresar proyecto nuevo... \n \n")
          print("Nombre de el proyecto \n")
          var nombre = readLine()
          if(listaTareas.size()>0){
            var cho="0"
            do{
              print("1)Ingresar tarea \n")
              print("2)Salir \n")
              cho=readLine()
              println("Seleccione: \n")
              if(cho =="1"){
                print("Tareas que quiera agregar? \n")
                for(i<-0 until listaTareas.size()){
                  println((i+1),") ",listaTareas.get(i).nombre)
                }
                println("Ingrese el indice")
                var index= readInt()
                listaAxu.add(listaTareas.get(index-1))
              }
            }while(cho!="2")
            println("Ingrese presupuesto")
            var cost = readFloat()
            manPro.addProyecto(new Proyecto(nombre,cost,listaAxu))

          }else{
            println("No hay tareas anteriores, necesita agregar tareas")
          }
          data.guardarProyectos()
          data.guardarTareas()
        case "3" =>
          data.recuperarTareas()
          data.recuperarProyectos()
          var listPro = manPro.listaProyectos
          if(listPro.size()>0){
            println("Lista de proyectos")
            for(i<- 0 until listPro.size()){
              println((i+1),") ",listPro.get(i).nombre)
            }
            println("Seleccione un proyecto para detallar")
            var index= readInt()
            var proy= listPro.get(index-1)
            println("Nombre del proyecto \n" + proy.nombre)
            println("Presupuesto Inicial \n"+ proy.presInicial)
            if(proy.listaTareas.size() >0){
              println("Tareas disponibles")
              for(i<- 0 until(proy.listaTareas.size())){
                println("Nombre tarea",i+1)
                println(proy.listaTareas.get(i).nombre)
                println("Fecha ", proy.listaTareas.get(i).fecha)
                println("Lugar: ", proy.listaTareas.get(i).lugar)
                //println("Tareas anteriores  ", proy.listaTareas.get(i))
                println("Tipo ", proy.listaTareas.get(i).tipo)
                println("Costo ", proy.listaTareas.get(i).costo)

              }

            }

          }
        case _ =>
          println("Exit")

      }
    }while(sel !="4")
  }
}
class Tarea(var nombre:String,var fecha:String,var lugar:String,var tipo:String, var costo: Float) extends Serializable{
  var tasks = new util.ArrayList[Tarea]()
}

class Proyecto(var nombre:String,var presInicial:Float,var listaTareas:util.ArrayList[Tarea]) extends Serializable{
  var saldo = 0.0
}

class ManejoTareas()extends Serializable{
  var listaTareas = new util.ArrayList[Tarea]()

  def addTasks(task:Tarea): Unit ={
    listaTareas.add(task)
  }
  def setTareas(nlist:util.ArrayList[Tarea]): Unit ={
    listaTareas.clear()
    listaTareas.addAll(nlist)
  }

}

class ManejoProyectos() extends Serializable{
  var listaProyectos = new util.ArrayList[Proyecto]()

  def addProyecto(proyec:Proyecto): Unit ={
    listaProyectos.add(proyec)
  }
  def setProyectos(nuevaLista:util.ArrayList[Proyecto]): Unit ={
    listaProyectos.clear()
    listaProyectos.addAll(nuevaLista)
  }



}

class Data(var manejoTareas: ManejoTareas, var manejoProyectos: ManejoProyectos) extends Serializable{
  def guardarProyectos(): Unit ={
    var output = new ObjectOutputStream(new FileOutputStream("proyectos.dat"))
    output.writeObject(manejoProyectos)
    output.close
  }
  def recuperarProyectos(): Unit ={
    try {
      var input = new ObjectInputStream(new FileInputStream("proyectos.dat"))
      var data = input.readObject.asInstanceOf[ManejoProyectos]
      input.close
      manejoProyectos.setProyectos(data.listaProyectos)

      println("Proyectos recuperados con exito")

    }catch{
      case a: FileNotFoundException => println("No se pudo recuperar el archivo")
    }
  }
  def guardarTareas(): Unit ={
    var output = new ObjectOutputStream(new FileOutputStream("tareas.dat"))
    output.writeObject(manejoTareas)
    output.close
  }
  def recuperarTareas(): Unit ={
    try {
      var input = new ObjectInputStream(new FileInputStream("tareas.dat"))
      var data = input.readObject.asInstanceOf[ManejoTareas]
      input.close
      manejoTareas.setTareas(data.listaTareas)

      println("Tareas recuperados con exito")

    }catch{
      case a: FileNotFoundException => println("No se pudo recuperar el archivo")
    }
  }

}

