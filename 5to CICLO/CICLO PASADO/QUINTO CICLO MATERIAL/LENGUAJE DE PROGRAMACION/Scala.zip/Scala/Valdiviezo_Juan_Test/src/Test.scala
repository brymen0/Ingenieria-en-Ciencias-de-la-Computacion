trait Equal{
  def isEqual(x:Any): Boolean

}




object Test {

}
