import scala.io.StdIn.{readDouble, readInt}

object Calificaciones {
  def main(args: Array[String]): Unit = {
    var estudiantes = 0
    var tareas = 0
    println("Ingrese el numero de estudiantes")
    estudiantes=readInt()
    println("Ingrese numero de tareas")
    tareas=readInt()

    val calificaciones =Array[Array[Double]](estudiantes,tareas)
    for(i <- 0 until (estudiantes);j <- 0 until tareas ){
      println("Ingrese calificacion "+ (j+1)+"del estudiante #"+(i+1))
      var c= readDouble()
      if(c<=0){
        calificaciones(i)(j)=0.0
      }else{
        calificaciones(i)(j)=c
      }
    }
    var op = 0
    do{
      print(:)
    }while(true)

  }
  ef ejerciciosxalumno(num):
    cont =0
  num =num-1
  for i in range(m):
  if not int(matriz[num][i]) <0:
    cont +=1
  return print("Ejercicios entregados",cont)

  def mediaEjerciciosxAlumno(num):
  suma =float(0)
  num =num-1
  for i in range(m):
  if not int(matriz[num][i]) <0:
    suma=suma+float(matriz[num][i])
  return print("Media en notas",suma/len(matriz[num]))

  def mediaTodosEjerciciosxAlumno(num):
  suma =float(0)
  num =num-1
  for i in range(m):
  if not int(matriz[num][i]) <0:
    suma=suma+float(matriz[num][i])
  else:
  return 0
  return suma/len(matriz[num])

  def numAlumnosentrega():
  alum=[]
  for i in range(n):
  if mediaTodosEjerciciosxAlumno(i+1)>3.5:
    alum.append(i+1)
  return alum

  def mediaenEjercicio(ejer):
  suma =float(0)
  ejer =ejer-1
  for i in range(n):
  if not int(matriz[i][ejer]) <0:
    suma=suma+float(matriz[i][ejer])
  return print("Media en notas en el ejercicio",suma/n)


  def notaMasAlta(num):
  num=num-1
  alta=max(matriz[num])
  return print("La nota mas alta del estudiante {}".format(num+1), alta)

  def notaMasBaja(num):
  num=num-1
  baja=min(matriz[num])
  return print("La nota mas baja del estudiante {}".format(num+1), baja)


  #Columnas que no contengan -1

  def ejercicioPresente(ejer):
  lista=[]
  for i in range(n):
  if not '-1' ==matriz[i][ejer]:
  lista.append(i+1)
  return print("Estudiantes que presentaron el ejercicio {} ".format(ejer),lista)
}
