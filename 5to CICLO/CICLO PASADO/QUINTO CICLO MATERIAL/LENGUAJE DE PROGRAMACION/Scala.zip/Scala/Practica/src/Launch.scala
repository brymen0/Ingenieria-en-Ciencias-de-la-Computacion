import java.io.{FileInputStream, FileNotFoundException, FileOutputStream, ObjectInputStream, ObjectOutputStream}
import java.util
import scala.io.StdIn.{readDouble, readInt, readLine}

object Launch {
  def main(args: Array[String]): Unit = {
    var sel = "3"
    var manejo = new Manejo
    var data = new Data(manejo)
    do{
      println("1\t Crear vehiculo")
      println("2\t Listar vehiculos")
      println("3.	Los vehículos con velocidad máxima mayor a un parámetro.")
      println("4.\tLos vehículos que cada 100 km consuman menos que un parámetro.")
      println("5.\tEl vehículo con mayor coeficiente de eficiencia,")
      println("6.\tLa cantidad total de pasajeros que pueden transportar los vehículos de la empresa a más de cierta velocidad")

      println("7\t Salir")
      sel = readLine("Ingrese una opcion")
      sel match {
        case "1" =>
          println("1) Bicicleta")
          println("2) Motocicleta")
          println("3) Auto")
          var cho = readLine("Elija una opcion")
          cho match {
            case "1" =>
              println("Ingrese la velocidad maxima")
              var velMax = readInt()
              println("Gasto por 100Km")
              var gasto = readDouble()
              var bici = new Bicicleta(velMax,gasto)
              manejo.addBici(bici)
              data.guardarDatos()
            case "2" =>
              println("Cilindrada de la moto")
              var cill= readInt()
              var moto = new Moto(cill)
              manejo.addMotos(moto)
              data.guardarDatos()
            case "3" =>
              println("Velocidad maxima del vehiculo?")
              var velMax= readDouble()
              println("Cantidad de pasajeros")
              var pass= readInt()
              var car = new Auto(velMax,pass)
              manejo.addAuto(car)
              data.guardarDatos()

          }
        case "2" =>
          data.recuperarDatos()
          var listaAutos = manejo.listaAuto
          var listaBici = manejo.listaBicis
          var listaMoto = manejo.listaMotos
          var auxA = new Array[Auto](listaAutos.size())
          auxA= listaAutos.toArray(auxA)
          var auxB = new Array[Bicicleta](listaBici.size())
          auxB= listaBici.toArray(auxB)
          var auxC = new Array[Moto](listaMoto.size())
          auxC= listaMoto.toArray(auxC)
          for(item <- auxA){
              println(item.toString)
          }
          for(item <- auxB){
            println(item.toString)
          }
          for(item <- auxC){
            println(item.toString)
          }
        case "3" =>
          println("Vehiculos con mayor velocidad")
          data.recuperarDatos()
          var listaAutos = manejo.listaAuto
          var listaBici = manejo.listaBicis
          var listaMoto = manejo.listaMotos
          println("Ingrese la velocidad")
          var vel = readDouble()
          var auxA = new Array[Auto](listaAutos.size())
          auxA= listaAutos.toArray(auxA)
          var auxB = new Array[Bicicleta](listaBici.size())
          auxB= listaBici.toArray(auxB)
          var auxC = new Array[Moto](listaMoto.size())
          auxC= listaMoto.toArray(auxC)
          for(item <- auxA){
            if(item.velMax> vel){
              println(item.toString)
            }

          }
          for(item <- auxB){
            if(item.velMax> vel){
              println(item.toString)
            }
          }
          for(item <- auxC){
            if(item.velMax> vel){
              println(item.toString)
            }
          }
        case "4" =>
          println("Vehiculos que cada 100 km consuman menos que un parámetro")
          data.recuperarDatos()
          var listaAutos = manejo.listaAuto
          var listaBici = manejo.listaBicis
          var listaMoto = manejo.listaMotos
          println("Ingrese el consumo")
          var consumo = readDouble()
          var auxA = new Array[Auto](listaAutos.size())
          auxA= listaAutos.toArray(auxA)
          var auxB = new Array[Bicicleta](listaBici.size())
          auxB= listaBici.toArray(auxB)
          var auxC = new Array[Moto](listaMoto.size())
          auxC= listaMoto.toArray(auxC)
          for(item <- auxA){
            if(item.costoP100<consumo ){
              println(item.toString)
            }

          }
          for(item <- auxB){
            if(item.costoP100<consumo ){
              println(item.toString)
            }
          }
          for(item <- auxC){
            if(item.costoP100<consumo ){
              println(item.toString)
            }
          }

        case "5" =>
          data.recuperarDatos()
          var listaAutos = manejo.listaAuto
          var listaBici = manejo.listaBicis
          var listaMoto = manejo.listaMotos
          var listaxd = new util.ArrayList[Vehiculo]()
          listaxd.addAll(listaAutos)
          listaxd.addAll(listaMoto)
          listaxd.addAll(listaBici)
          println("Ingrese el consumo")
          var consumo = readDouble()
          var auxA = new Array[Vehiculo](listaxd.size())
          auxA= listaxd.toArray(auxA)

          var auto = auxA(0)
          for(item <- auxA){
            if((item.cantPasajeros*item.velMax/item.costoP100)>=(auto.cantPasajeros*auto.velMax/auto.costoP100) ){
              auto=item
            }
          }
          println("El vehiculo que cumple es :")
          println(auto+ "Coeficiente:" + auto.cantPasajeros*auto.velMax/auto.costoP100 )
        case "6" =>
          data.recuperarDatos()
          var listaAutos = manejo.listaAuto
          var listaBici = manejo.listaBicis
          var listaMoto = manejo.listaMotos
          var listaxd = new util.ArrayList[Vehiculo]()
          listaxd.addAll(listaAutos)
          listaxd.addAll(listaMoto)
          listaxd.addAll(listaBici)
          println("Ingrese la velocidad como parametro")
          var vel = readDouble()
          var auxA = new Array[Vehiculo](listaxd.size())
          auxA= listaxd.toArray(auxA)
          for(item <- auxA){
            if(item.velMax>vel){
              println(item)
              println("Este vehiculo puede llevar estos pasajeros "+ item.cantPasajeros)
            }
          }
        case "7" =>
          println("Salir")
      }

    }while(sel!="7")

  }
}

class Manejo() extends Serializable{
  var listaMotos = new util.ArrayList[Moto]()
  var listaBicis= new util.ArrayList[Bicicleta]()
  var listaAuto = new util.ArrayList[Auto]()
  def addMotos(moto:Moto): Unit ={
    listaMotos.add(moto)
  }
  def setMotos(newList:util.ArrayList[Moto]): Unit ={
    listaMotos.clear()
    listaMotos.addAll(newList)
  }
  def addBici(bici:Bicicleta): Unit ={
    listaBicis.add(bici)
  }
  def setBicis(newList:util.ArrayList[Bicicleta]): Unit ={
    listaBicis.clear()
    listaBicis.addAll(newList)
  }
  def addAuto(auto:Auto): Unit ={
    listaAuto.add(auto)
  }
  def setAuto(newList:util.ArrayList[Auto]): Unit ={
    listaAuto.clear()
    listaAuto.addAll(newList)
  }

}

class Data(var manejo:Manejo){
  def guardarDatos(): Unit ={
    var output = new ObjectOutputStream(new FileOutputStream("Fsociety.dat"))
    output.writeObject(manejo)
    output.close
  }
  def recuperarDatos(): Unit ={
    try {
      var input = new ObjectInputStream(new FileInputStream("Fsociety.dat"))
      var data = input.readObject.asInstanceOf[Manejo]
      input.close
      manejo.setAuto(data.listaAuto)
      manejo.setMotos(data.listaMotos)
      manejo.setBicis(data.listaBicis)

      println("Datos recuperados con exito")

    }catch{
      case a: FileNotFoundException => println("No se pudo recuperar el archivo")
    }
  }
}
