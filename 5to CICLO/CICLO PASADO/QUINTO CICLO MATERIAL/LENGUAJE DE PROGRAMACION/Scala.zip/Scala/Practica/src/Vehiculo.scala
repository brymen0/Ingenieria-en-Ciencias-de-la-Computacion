trait Vehiculo {
  var velMax:Double
  var cantPasajeros:Int
  var costoP100:Double
}
