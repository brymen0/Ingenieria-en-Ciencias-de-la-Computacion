class Bicicleta(VelMax:Double,gastoP100:Double)extends Vehiculo with Serializable  {
  var rodado:Double = 1.2
  override var velMax: Double = VelMax*rodado
  override var cantPasajeros: Int = 1
  override var costoP100: Double = gastoP100

  override def toString: String = s"Bicicleta( Velocidad: $velMax,catidad de pasajeros: $cantPasajeros, costo x100km: $costoP100"
}
