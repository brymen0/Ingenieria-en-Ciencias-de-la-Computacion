import java.util

class Moto(Cilindrada:Int)extends Vehiculo  with Serializable{
  override var velMax: Double = cilindrada/5
  override var cantPasajeros: Int=0
  override var costoP100: Double = 5+cilindrada/200
  var cilindrada: Int=0
  if(cilindrada<=150){
    cantPasajeros=1
  }else{
    cantPasajeros=2
  }

  override def toString: String = s"Moto( Velocidad: $velMax,catidad de pasajeros: $cantPasajeros, costo x100km: $costoP100, Cilindrada: $cilindrada"

}


