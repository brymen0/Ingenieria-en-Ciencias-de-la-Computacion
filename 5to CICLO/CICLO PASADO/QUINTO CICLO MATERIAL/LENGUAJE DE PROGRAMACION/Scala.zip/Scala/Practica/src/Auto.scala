class Auto(VelMax:Double,CantPass:Int) extends Vehiculo with Serializable{
  override var velMax: Double = VelMax
  override var cantPasajeros: Int = CantPass
  override var costoP100: Double = 20+(cantPasajeros*10)

  override def toString: String = s"Auto( Velocidad: $velMax,catidad de pasajeros: $cantPasajeros, costo x100km: $costoP100"
}
