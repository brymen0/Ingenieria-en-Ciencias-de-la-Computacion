import Array._
import scala.:+
import scala.collection.mutable.ListBuffer
import scala.io.StdIn.{readChar, readDouble, readInt, readLine}

object Ciclistas {
  def ganador_vuelta(cicl:Array[String],mat:  Array[Array[Double]]): String ={
    var numcicl = cicl.length
    var numVueltas = mat(0).length
    var suma= new ListBuffer[Double]() //Como una lista mutable
    var aux =0.toDouble
    var menor = 0.0
    for(i <- 0 until numcicl){
      for(j <- 0 until numVueltas){
        aux+=mat(i)(j)
        suma += aux
        aux=0
      }
    }
    menor=suma.head
    for(x <- suma.indices){
      if (suma(x) < menor){
        menor=suma(x)
      }
    }
    suma.toList

  return cicl(suma.indexOf(menor))

  }
  def ganador_etapa(cicl:Array[String],mat:Array[Array[Double]],numEtapa:Int): String ={
    var numCicl=cicl.length
    var numVueltas= mat(0).length
    var suma= new ListBuffer[Double]
    var aux=0.0
    var menor = 0.0

    for(i <- 0 until numCicl) {
      aux += mat(i)(numEtapa - 1)
      suma += aux
      menor = suma.head
    }
    for(x <- suma.indices){
      if(suma(x)<menor){
        menor=suma(x)
      }
    }
    suma.toList
    return  cicl(suma.indexOf(menor))

  }

  def ganador_cadaEtapa(cicl:Array[String],mat:Array[Array[Double]]): Unit ={
    var numVueltas= mat(0).length
    var p =0
    for(i <-0 until numVueltas){

      println("Ganador Etapa: "+ (i+1))
      println(ganador_etapa(cicl,mat,i+1))
    }
  }


  def main(args: Array[String]): Unit = {
    println("Cuantos ciclistas ingresaron?");
    var numcicl = readInt() //Num de filas Mat
    var ciclistas = new Array[String](numcicl) //Array de ciclistas
    for(i <- 0 until(numcicl)){ //Llenamos vector de
      ciclistas(i)=scala.io.StdIn.readLine("Nombre del ciclista #"+(i+1)+"   ")

    }

    println("Cuantas vueltas se dieron?");
    var numVueltas= readInt()
    var vueltas = ofDim[Double](numcicl,numVueltas) //Matriz creada
    for (i <- 0 until(numcicl)){
      println("Vueltas ciclista   "+ ciclistas(i))
      for(j <- 0 until numVueltas){

        print("Vuelta#"+(j+1)+"   ")
        vueltas(i)(j)=readDouble()
      }
    }
    //Imprimimos Ciclistas
    println("Ciclistas :")
    for( i <- 0 until numcicl){
      print(" "+ciclistas(i))
    }
    println("")
    //Imprimimos matriz
    for(i<- 0 until numcicl){
      for(j<- 0 until numVueltas){
        print("["+vueltas(i)(j)+"]")
      }
      println("")
    }

    println("El ganador por vuelta es:")
    //println(ganador_vuelta(ciclistas,vueltas))
    println("El ganador por etapa es:")
    println("Etapa?")
    var etapa = readInt()
    println("Ganador  " +ganador_etapa(ciclistas,vueltas,etapa))

    println("Ganador de cada etapa")
    ganador_cadaEtapa(ciclistas,vueltas)
  }
}
