import scala.io.StdIn.{readChar, readInt}
import scala.util.control.Breaks.break
import scala.sys.process._
import scala.math


object Vectores {

  def crossProd(x: List[Int],y: List[Int]): List[Int] ={
    //var aux =x.flatMap(a => y.map(b => (a, b))) //Emula producto cruz
    return List(x(1)*y(2)-x(2)*y(1),x(2)*y(0)-x(0)*y(2),x(0)*y(1)-x(1)*y(0))
  }
  def angulo(x: List[Int],y: List[Int]): Double={
     ((180/math.Pi)*math.acos((x(0)*y(0)+x(1)*y(1)+x(2)*y(2))/(math.sqrt(math.pow(x(0),2)+math.pow(x(1),2)+math.pow(x(2),2))*math.sqrt(math.pow(y(0),2)+math.pow(y(1),2)+math.pow(y(2),2)))))
  }
  def magVect(x:List[Int]): Double={
    return math.sqrt((x.map(square)).sum)//lol  (x.map(_^2)).sum
  }
  def square(a: Int): Int ={
    return a*a
  }

  def main(args: Array[String]): Unit = {
    var sel=0
    var vecA= List[Int]()
    var vecB= List[Int]()

    do {

      println("Menu")

    println("1) Introducir el primer vector\n2) Introducir el segundo vector\n3) Calcular la suma\n4) Calcular la diferencia\n5) Calcular el producto escalar\n6) Calcular el producto vectorial\n7) Calcular el ´angulo (en grados) entre ellos\n8) Calcular la longitud\n9) Finalizar")
      println("Escoja una opcion")
      sel=readChar()
      //Declaramos listas

      sel match {
        case '1'  =>
          var x =0
          var y =0
          var z =0
          println("Ingrese primer vector")
          println("Ingrese valor x del primer vector")
          x=readInt()
          println("Ingrese valor y del primer vector")
          y=readInt()
          println("Ingrese valor z del primer vector")
          z=readInt()

          vecA = List(x,y,z)

        case '2'  =>
          var x =0
          var y =0
          var z =0
          println("Ingrese segundo vector")
          println("Ingrese valor x del segundo vector")
          x=readInt()
          println("Ingrese valor y del segundo vector")
          y=readInt()
          println("Ingrese valor z del segundo vector")
          z=readInt()
          vecB = List(x,y,z)

        case '3'  =>
          var vecSuma= (vecA,vecB).zipped.map(_ + _) //Sumamos las listas
          println("Suma de los dos vectores es: "+vecSuma)

        case '4' =>
          //Calcular la diferencia
          println("a) Restar primer vector menos segundo vector")
          println("b) Restar segundo vector menos primer vector")
          var aux= readChar()
          aux match {
            case 'a' =>
              var vecDiff=(vecA,vecB).zipped.map(_ - _)
              println("Resta de los dos vectores A-B es: "+vecDiff)
            case 'b' =>
              var vecDiff=(vecB,vecA).zipped.map(_ - _)
              println("Resta de los dos vectores B-A es: "+vecDiff)
            case _ =>
              println("Opcion invalida")
          }

        case '5' =>
          //Producto escalar
          val dot = vecA.zip(vecB)
          val product = (dot.map { case (vecA, vecB) => vecA * vecB }).sum //Emula un producto punto
          println("Producto escalar "+ product)

        case '6' =>
          //Producto cruz
          println("a)VectorA X VectorB")
          println("b)VectorB X VectorA")
          var aux= readChar()
          aux match {
            case 'a' =>
              println(crossProd(vecA,vecB))
            case 'b' =>
              println(crossProd(vecB,vecA))
            case _ =>
              println("Entrada invalida")
          }
        case '7' =>
          //Angulo entre vectores
          println("El ángulo entre los vectores es: "+ angulo(vecA,vecB))
        case '8' =>
          //Magnitud
          println("a)VectorA")
          println("b)VectorB")
          var aux= readChar()
          aux match {
            case 'a' =>
              println("La magnitud de el vector A es: "+ magVect(vecA))
            case 'b' =>
              println("La magnitud de el vector B es: "+ magVect(vecB))
            case _ =>
              println("Entrada invalida")
          }

        case whoa  => println("Salir")
      }

    }while(sel!='9')
  }





}
