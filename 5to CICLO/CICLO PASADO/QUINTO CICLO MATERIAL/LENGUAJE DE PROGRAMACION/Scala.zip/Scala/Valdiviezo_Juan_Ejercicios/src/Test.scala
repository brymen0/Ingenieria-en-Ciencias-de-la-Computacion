object Test {
  def main(args: Array[String]): Unit = {
    //Lista de enteros
    var listA = List[Int]()
    //Cargamos la lista con algunos valores
    listA = List(3, 4, 5)
    //Operación head
    // print(listA.head)
    //Operación tail
    //print(listA.tail)
    // Lista vacía
    var listNull = List[Int]()
    listNull = Nil
    // print(listNull.isEmpty)

    //Conjunto de caracteres
    var setA = Set('A', 'B', 'C', 'D', 'E')
    setA += 'F'
    //print(setA)

    //Map
    var mapA = Map('R' -> "Rojo", 'A' -> "Azul", 'V' -> "Verde")


    //Operación keys
    //print(mapA.keys)

    //Obtener el valor mediante la clave
    //print(mapA('R'))
    //Map sin asignación
    var A:Map[Char,Int] = Map()
    // Mapa vacío
    //print(A.isEmpty)
    //Agregamos un elemento al Map
    mapA += ('N'-> "Negro")
    //println(mapA)

    //Creamos unas tuplas
    val t = (1, 3.14, "Fred")
    //Forma Alterna
    val tupleA = new Tuple3(1, 3.14, "Fred")

    val (edad, peso, nombre) = tupleA
   // println(nombre) // Fred
    //println(edad) // 1
    //Option
    //val a:Option[Int] = Some(5)
    //val b:Option[Int] = None
    //Aplicacion Options
    val capitals = Map("Pichincha" -> "Quito", "Azuay" -> "Cuenca")

    //println("show(capitals.get( \"Pichincha\")) : " + show(capitals.get( "Pichincha")) )
    //println("show(capitals.get( \"Guayas\")) : " + show(capitals.get( "Guayas")) )
  }
  def show(x: Option[String]) = x match {
    case Some(s) => s
    case None => "?"

  }
  //Ejemplo getOrElse()
  val a:Option[Int] = Some(5)
  val b:Option[Int] = None

  //println("a.getOrElse(0): " + a.getOrElse(0) )
  //println("b.getOrElse(10): " + b.getOrElse(10) )
  //Ejemplo de las operaciones de Iterator
  val it = Iterator("Cuenca", "Yunguilla", "Paute", "Gualaceo")
  //while (it.hasNext){
   // println(it.next())
  //}
  //Ejemplo size y lenght
   val ita = Iterator(20,40,2,50,69)
  val itb = Iterator(20,40,2,50,69, 90)

  println("ita size: " + ita.size )
  println("itb length " + itb.length )

}
