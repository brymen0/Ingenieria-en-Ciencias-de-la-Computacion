import java.io.{FileInputStream, FileNotFoundException, FileOutputStream, ObjectInputStream, ObjectOutputStream}
import java.util
import scala.collection.mutable.ListBuffer
import scala.io.StdIn.{readDouble, readInt, readLine}

object Main {
  def main(args: Array[String]): Unit = {
    var cc = "7"
    var aux = new Listas
    var datos = new Datos(aux)
    do{
      println("Menu")
      println("1) Agrega equipo")
      println("2) Agrega jugador (listar los equipos que existen)")
      println("3) Cantidad de jugadores (solicitar de qué equipo)")
      println("4) Devolver la suma de los puntos anotados por los jugadores (solicitar de qué equipo)")
      println("5) Listar equipos (orden alfabético descendente)")
      println("6) Listar jugadores (orden alfabético ascendente)")
      println("7) Salir")
      cc=readLine("Seleccione una opcion")
      cc match {
        case "1" =>
          datos.recuperar()
          var nombre = readLine("Nombre del equipo?")
          var team = new Equipo(nombre)
          println("Equipo agregado")
          aux.addEquipos(team)
          datos.guardar()
        case "2" =>
          datos.recuperar()
          println("Numero de camiseta ")
          var numCam = readInt()
          var nombre = readLine("Nombre del jugador")
          println("Puntos anotados")
          var puntos = readDouble()
          var jugador = new Jugador(numCam,nombre,puntos)
          println("Escoja un equipo disponible")
          var co = 1
          for(i <- aux.listaEquipos){
            println(co+") "+i.nombreEquipo)
          }
          var dos = readInt()
          dos= dos -1
          println("Jugador agregado al equipo "+ aux.listaEquipos(dos).nombreEquipo)
          jugador.team=true
          aux.listaEquipos(dos).listJugadores+=jugador
          aux.listaJugadores+=jugador

          datos.guardar()
        case "3" =>
          datos.recuperar()
          println("Escoja un equipo disponible")
          var co = 1
          for(i <- aux.listaEquipos){
            println(co+") "+i.nombreEquipo)
          }
          var dos = readInt()
          dos=dos-1
          println("Cantidad de jugadores del equipo "+aux.listaEquipos(dos).nombreEquipo+" es "+aux.listaEquipos(dos).numJugadores() )
        case "4" =>
          datos.recuperar()
          println("Escoja un equipo disponible ")
          var co = 1
          for(i <- aux.listaEquipos){
            println(co+") "+i.nombreEquipo)
          }
          var dos = readInt()
          dos = dos -1
          println("Suma de todos los puntos de los jugadores "+aux.listaEquipos(dos).nombreEquipo+" es "+aux.listaEquipos(dos).sumPuntos())
        case "5" =>
          datos.recuperar()
          var some = aux.listaEquipos.sortBy(_.nombreEquipo).reverse
          println("Equipos ordenados")
          for(i<- some){
            println(i.nombreEquipo)
          }
        case "6" =>
          datos.recuperar()
          var some = aux.listaJugadores.sortBy(_.nombre)
          println("Jugadores ordenados")
          for(i<- some){
            println("Nombre " + i.nombre +"  Numero de camiseta " + i.numeroUnif + "  Puntos anotados"+ i.puntosAnotados)
          }

        case "7" =>
          println("salir")
      }
    }while(cc!="7")
  }

}


class Equipo(var nombreEquipo:String) extends Serializable{
  var listJugadores = new ListBuffer[Jugador]
  //Devolver la cantidad de jugadores registrados en un equipo
  def numJugadores(): Int ={
    return listJugadores.size
  }
  //Devolver la suma de los puntos anotados por los jugadores
  def sumPuntos(): Double={
    var sum:Double = 0
  for(aux <-  listJugadores){
    sum+=aux.puntosAnotados
  }
    return sum
  }

}

class Jugador(var numeroUnif:Int,var nombre:String, var  puntosAnotados:Double) extends Serializable{
  var team = false
}

class Listas() extends Serializable{
  var listaJugadores = new ListBuffer[Jugador]
  var listaEquipos= new ListBuffer[Equipo]

  def addJugador(jugador:Jugador): Unit ={
    listaJugadores+=jugador
  }
  def setJugador(List:ListBuffer[Jugador]): Unit ={
    listaJugadores.clear()
    listaJugadores.addAll(List)
  }
  def addEquipos(team:Equipo): Unit ={
    listaEquipos+=team
  }
  def setEquipos(newList:ListBuffer[Equipo]): Unit ={
    listaEquipos.clear()
    listaEquipos.addAll(newList)
  }
}


class Datos(meta:Listas) extends Serializable{
  def guardar(): Unit ={
    var output = new ObjectOutputStream(new FileOutputStream("data.dat"))
    output.writeObject(meta)
    output.close
  }
  def recuperar(): Unit ={
    try {
      var input = new ObjectInputStream(new FileInputStream("data.dat"))
      var data = input.readObject.asInstanceOf[Listas]
      input.close
      meta.setJugador(data.listaJugadores)
      meta.setEquipos(data.listaEquipos)

      println("Datos recuperados con exito")

    }catch{
      case a: FileNotFoundException => println("No se pudo recuperar el archivo")
    }
  }
}

