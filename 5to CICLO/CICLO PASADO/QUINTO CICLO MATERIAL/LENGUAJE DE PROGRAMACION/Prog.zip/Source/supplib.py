import numpy as np
from scipy import signal
from scipy.io import loadmat
import sys
import os
import soundfile as sf
import shutil


def shift(xs, n):
    e = np.empty_like(xs)
    if n >= 0:
        e[:n] = 0.0
        e[n:] = xs[:-n]
    else:
        e[n:] = 0.0
        e[:n] = xs[-n:]
    return e


def copy_folder(in_folder, out_folder):
    if not (os.path.isdir(out_folder)):
        shutil.copytree(in_folder, out_folder, ignore=ig_f)


def ig_f(dir, files):
    return [f for f in files if os.path.isfile(os.path.join(dir, f))]


def load_IR(IR_file):

    if ".mat" in IR_file:
        IR = loadmat(IR_file, squeeze_me=True, struct_as_record=False) #load matlab file
        IR = IR[list(IR.keys())[3]] #get the IR
    else:
        IR = sf.read(IR_file)[0] #load wav file
        #Sampling IR to 16 kHz
        IR = signal.resample(IR, int(len(IR)*16000/48000))
        #convert to mono if stereo
        if len(IR.shape) > 1:
            IR = np.mean(IR, axis=1)
    return IR


def ReadList(list_file):
    with open(list_file, "r") as f:
        lines = f.readlines()
    list_sig = []
    list_ir = []
    for x in lines:
        list_sig.append(x.split(" ")[0])
        list_ir.append(x.split(" ")[1].rstrip())
    return [list_sig, list_ir]
