
import numpy as np
from scipy import signal
import sys
import os
import soundfile as sf
import matplotlib.pyplot as plt

# Load support lib
from supplib import ReadList
from supplib import copy_folder
from supplib import load_IR
from supplib import shift

# Reading input arguments
in_folder = "clean_examples/"
out_folder = "rev_examples/" # output folder
list_file = "list.txt"  # list file ("wav_file IR_file")

# Read List file
list_sig, list_ir = ReadList(list_file)


# Replicate input folder structure to output folder
copy_folder(in_folder, out_folder)

# Speech Data Reverberation Loop
for i in range(len(list_sig)):
    # Open clean wav file
    # Read the signal
    [signal_clean, fs] = sf.read(list_sig[i])
    #convert to mono if stereo
    if len(signal_clean.shape) > 1:
        signal_clean = np.mean(signal_clean, axis=1)   
    #sampling input signal to 16 kHz
    fs = 16000
    signal_clean = signal.resample(signal_clean, int(len(signal_clean)*fs/48000))
    #input signal
    signal_clean = signal_clean.astype(np.float64)
    #display signal
    plt.plot(signal_clean)
    plt.show()

    # Signal normalization
    signal_clean = signal_clean / np.max(np.abs(signal_clean))

    # Open Impulse Response (IR) h[n]
    IR = load_IR(list_ir[i])

    # IR normalization
    IR = IR / np.abs(np.max(IR))
    p_max = np.argmax(np.abs(IR))
    
    # Reverberation
    signal_rev = signal.fftconvolve(signal_clean, IR, mode="full")

    # Normalization
    signal_rev = signal_rev / np.max(np.abs(signal_rev))

    # IR delay compensation
    signal_rev = shift(signal_rev, -p_max)

    # Cut reverberated signal (same length as clean sig)
    signal_rev = signal_rev[0 : signal_clean.shape[0]]
    #plot reverberated signal in red color
    plt.plot(signal_rev, 'r')
    plt.show()
    # Save Reverberated Speech
    file_out = list_sig[i].replace(in_folder, out_folder)
    # wavfile.write(file_out,fs,signal_rev)
    sf.write(file_out, signal_rev, fs)

    print("Done %s" % (file_out))
