from .Usuario import *
import pickle
class CtrlUsuario(object):

    listaUsers = []


    #Agregar usuario    
    def saveUsers(self,user:Usuario):
        #Verificamos si hay datos anteriores 
        try:
            file = open("users.dat", "rb")
            self.listaUsers.clear()
            self.listaUsers = pickle.load(file)  # Cargamos la lista de usuarios
            print("Encontro el archivo")
            
        except FileNotFoundError:
            print("No encontro el archivo")
        
        #Serializamos los datos
        self.listaUsers.append(user)
        file = open("users.dat", "wb")
        pickle.dump(self.listaUsers, file)
        file.close()


    def getUsers() -> list:  
        try:
            file = open("users.dat", "rb")
            listaUsers = pickle.load(file)  # Cargamos la lista de usuarios
            return listaUsers
        except FileNotFoundError:
            print("Error de lectura, no se ha podido encontrar el archivo")
            return []

    def replaceUsers(self,lista:list):
        self.listaUsers.clear()
        self.listaUsers=lista
        file = open("users.dat", "wb")
        pickle.dump(self.listaUsers, file)
        file.close()   






            

    

        
