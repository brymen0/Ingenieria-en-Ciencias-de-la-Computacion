#Clase usuario

class Usuario(object):
    def __init__(self,id,nombre,tlf):
        self.id = id
        self.nombre = nombre
        self.tlf = tlf
        self.points=int("0")
        self.pred=int("0")
    #Equivalente al equals
    def __eq__(self,other):

        if self.id != other.id: return False
        return True