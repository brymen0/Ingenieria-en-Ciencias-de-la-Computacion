from .Partido import *
from .Usuario import *

class Prediccion(object):
    def __init__(self,partido:Partido,user:Usuario,indexUser, scoreA,scoreB):
        self.partido = partido
        self.user = user
        self.indexUser = indexUser
        #Prediccion
        self.scoreA = scoreA
        self.scoreB = scoreB
        #Puntaje 
        self.ar="0"
        self.am="0"
        self.arm="0"
        self.am3="0"
        self.arm3="0"
        self.aGE="0"
        self.almost="0"

        self.predPoints="0"

    def calScore(self):
        scoreAFin=int(self.partido.scoreAFin)
        scoreBFin =int( self.partido.scoreBFin)
        scoreA=int(self.scoreA)
        scoreB=int(self.scoreB)
        scoreTotal=0
        #Caso acierta resultado 
        if (scoreA<scoreB and scoreAFin<scoreBFin) or (scoreB<scoreA and scoreBFin<scoreAFin):  #Gana el aquipo A o equipo B
            scoreTotal += 2
            self.ar="2"
            
        #Caso acierto marcador
        if(scoreA==scoreAFin and scoreB==scoreBFin) or (scoreA==scoreBFin and scoreB==scoreAFin):
            scoreTotal += 1
            self.am="1"
            #Caso Marcador >3 goles
            if (scoreAFin + scoreBFin)>3:
                self.am3="1"
                scoreTotal +=1

        #Caso acierto resultado y marcador
        if scoreA == scoreAFin and scoreB == scoreBFin: #Acierto completo
            scoreTotal += 3
            self.arm="3"
            #Caso marcador y resultados >3
            if (scoreAFin + scoreBFin)>3 :
                scoreTotal += 1
                self.arm3="1"
        #Bono casi se acerca
        elif ((scoreA == (scoreAFin+1) or scoreA == (scoreAFin-1)) and(scoreB == scoreBFin)) or ((scoreA == scoreAFin)and (scoreB == (scoreBFin+1) or scoreB == (scoreBFin-1))):
            scoreTotal += 0.5
            self.almost="0.5"
        #Bonos de goles de un equipo 
        elif scoreA == scoreAFin or scoreB == scoreBFin: #Acierto parcial
            scoreTotal +=0.5
            self.aGE="0.5"

        self.predPoints=str(scoreTotal)

    
