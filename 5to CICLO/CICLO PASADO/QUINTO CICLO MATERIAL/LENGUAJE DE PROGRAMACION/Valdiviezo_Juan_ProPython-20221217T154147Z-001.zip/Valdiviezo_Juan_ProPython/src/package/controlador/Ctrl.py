import pickle
import sys
from PyQt6 import QtCore, QtWidgets

app= QtWidgets.QApplication(sys.argv)



from ..vista.MainWindow import *
from ..vista.AddParticipante import *
from ..vista.AddPartido import *
from ..vista.VentRankUsuarios import *
from ..vista.VentPartidos import *
from ..vista.ventPrediccion import *
from ..vista.VentPredRealizadas import *
from ..vista.VentResumen import *
from ..vista.VentGame import *
from ..vista.VentPlayGame import *
from ..vista.DialogoAC import *
from ..vista.VentGanadores import *
from ..vista.VentPremios import *

from ..modelo.Usuario import *
from ..modelo.Partido import *
from ..modelo.Prediccion import *
from ..modelo.CtrlPrediccion import *
from ..modelo.CtrlUsuario import *
from ..modelo.CtrlPartido import *

#Dialog Window
class DialogWindow(QtWidgets.QDialog, Ui_DialogoAC):
    def __init__(self, parent=None):
        super(DialogWindow, self).__init__(parent)
        self.setupUi(self)


class VentanaPrincipal(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super(VentanaPrincipal, self).__init__(parent)
        self.setupUi(self)
        self.actionaddUser.triggered.connect(self.ingreso_Datos)
        self.actionaddPartido.triggered.connect(self.nuevoPartido)
        self.actionJugar.triggered.connect(self.playGame)
        self.BtoUsuarios.clicked.connect(self.mostrarUsuarios)
        self.BtnSalir.clicked.connect(self.salir)
        self.BtoPartidos.clicked.connect(self.mostrarPartidos)
        self.BtnPredicciones.clicked.connect(self.mostrarPredicciones)
        self.BtnGanadores.clicked.connect(self.mostrarGanadores)
        self.BtoPremios.clicked.connect(self.mostrarPremios)

    def ingreso_Datos(self):
        self.aux = VentAddUser()
        self.aux.show()
        self.aux.activateWindow()

    def nuevoPartido(self):
        self.aux = VentAddPartido()
        self.aux.show()
        self.aux.activateWindow()

    def playGame(self):
        self.aux = VentTableGame()
        self.aux.show()
        self.aux.activateWindow()

    def mostrarUsuarios(self):
        self.aux = VentUsuarios()
        self.aux.show()
        self.aux.activateWindow()

    def mostrarPartidos(self):
        self.aux = VentPartidos()
        self.aux.show()
        self.aux.activateWindow()

    def mostrarPredicciones(self):
        self.aux =VentPredicciones()
        self.aux.show()
        self.aux.activateWindow()
    
    def mostrarGanadores(self):
        self.aux =VentGanadores()
        self.aux.show()
        self.aux.activateWindow()
    
    def mostrarPremios(self):
        self.aux =VentPremios()
        self.aux.show()
        self.aux.activateWindow()

    def salir(self):
        sys.exit(0)

# Ventana agregar Usuarios


class VentAddUser(QtWidgets.QWidget, Ui_VentanaAddPersona):

    def __init__(self, parent=None):
        super(VentAddUser, self).__init__(parent)
        self.setupUi(self)
        self.BtnGuardar.clicked.connect(self.guardarUser)
        self.winDialog = DialogWindow()

    def guardarUser(self):
        #Validacion Cedula
        valID= lambda id: sum([int(id[i]) if i%2 != 0 else int(id[i])*2 if int(id[i])*2<9 else int(id[i])*2-9 for i in range(len(id))])%10 ==0 and len(id) == 10
        ced = self.txtID.text()
        nombre = self.txtNombre.text()
        tlf = self.txtTlf.text()
        dos = CtrlUsuario()
        if(not nombre.isnumeric()) and tlf.isnumeric() and ced.isnumeric():
            if valID(str(ced)) :
                # Serializamos (Mandar al modelo)
                user = Usuario(ced, nombre, tlf)
                listusers=CtrlUsuario.getUsers()
                if user in listusers: #Verificamos que no se registre otra vez
                    self.winDialog.dialog('Error',"Error, ese usuario ya se encuentra registrado",2,2)
                    self.winDialog.show()
                else:
                    if ced != "" and nombre != "":
                        CtrlUsuario.saveUsers(dos, user)  # Pasamos al archivo
                        self.winDialog.dialog('Ok',"Usuario almacenado de forma exitosa",1,1)
                        self.winDialog.show()
                    else:
                        self.winDialog.dialog('Error',"Error, entrada inválida",2,2)
                        self.winDialog.show()
            else:
                self.winDialog.dialog('Error',"Error, cédula inválida",2,2)
                self.winDialog.show()
        else:
            self.winDialog.dialog('Error',"Error, entrada inválida",2,2)
            self.winDialog.show()        
        ced = self.txtID.setText("")
        nombre = self.txtNombre.setText("")
        tlf = self.txtTlf.setText("")

    
# Ventana agregar partidos


class VentAddPartido(QtWidgets.QWidget, Ui_addPartido):
    def __init__(self, parent=None):
        super(VentAddPartido, self).__init__(parent)
        self.setupUi(self)
        self.btnAgregarPartido.clicked.connect(self.addPartido)
        self.btnSalirVPartido.clicked.connect(self.salir)
        self.winDialog = DialogWindow()
       
    def addPartido(self):
        equiA = self.cbxEquipoA.currentText()
        equiB = self.cbxEquipoB.currentText()
        dos=CtrlPartido()
        date = self.dateEditPartido.date()
        game = Partido(equiA, equiB, date)
        listPart=CtrlPartido.getPartidos()
        if game in listPart: #Verificamos que no se haya registrado antes
           self.winDialog.dialog('Error',"Error, ese partido ya se encuentra registrado",2,2)
           self.winDialog.show()
        else:
            if ((equiA!=equiB) and((equiA !="Vacío") and (equiB != "Vacío")) ):
                CtrlPartido.savePartido(dos,game)
                self.winDialog.dialog('Ok',"Partido almacenado de forma exitosa",1,1)
                self.winDialog.show()
            else:
                self.winDialog.dialog('Error',"Error, elección inválida de equipos",2,2)
                self.winDialog.show()

    def salir(self):
        #Accion de salir
        self.hide()

#Listar usuarios
class VentUsuarios(QtWidgets.QWidget, Ui_VentRank):

    def __init__(self, parent=None):
        super(VentUsuarios, self).__init__(parent)
        self.setupUi(self)
        # Posible boton cerrar ventana
        

        # Cargar datos
        #Ordenamos por puntos
        listUsers = sorted(CtrlUsuario.getUsers(), key=lambda x: x.points, reverse=True)
       
        for i in range(0, len(listUsers)):
            self.tableRank.setItem(
                i, 0, QtWidgets.QTableWidgetItem(listUsers[i].id))
            self.tableRank.setItem(
                i, 1, QtWidgets.QTableWidgetItem(listUsers[i].nombre))
            self.tableRank.setItem(
                i, 2, QtWidgets.QTableWidgetItem(listUsers[i].tlf))
            self.tableRank.setItem(
                i, 3, QtWidgets.QTableWidgetItem(str(listUsers[i].pred)))
            self.tableRank.setItem(
                i, 4, QtWidgets.QTableWidgetItem(str(listUsers[i].points)))
        #self.tableRank.sortItems(4,QtCore.Qt.SortOrder(0)) #Ordenar de forma descendente
        #self.tableRank.sortByColumn(4,QtCore.Qt.SortOrder(1))
        # Agregamos a tabla
    
    def getRank(self)-> list:
        try:
            return [self.tableRank.item(i,1).text()  for i in range(3) ]
        except AttributeError:
            print("No existen ganadores aun")
            


#Listar los partidos
class VentPartidos(QtWidgets.QWidget, Ui_VentPartidos):
    def __init__(self, parent=None):
        super(VentPartidos, self).__init__(parent)
        self.setupUi(self)
        listPartidos=CtrlPartido.getPartidos()
        for i in range(0, len(listPartidos)):
            self.tablePartidosAv.setItem(
                i, 0, QtWidgets.QTableWidgetItem(listPartidos[i].equipoA))
            self.tablePartidosAv.setItem( 
                i, 1, QtWidgets.QTableWidgetItem(listPartidos[i].equipoB))
            self.tablePartidosAv.setItem(
                i, 2, QtWidgets.QTableWidgetItem(
                str(listPartidos[i].fecha.toPyDate())))
            self.tablePartidosAv.setItem(
                i,3,QtWidgets.QTableWidgetItem("Realizar predicción"))
        self.tablePartidosAv.sortItems(2, QtCore.Qt.SortOrder(0)) #Ordenar de forma ascendente
        self.tablePartidosAv.doubleClicked.connect(self.on_click)

    #@QtCore.pyqtSlot(QtCore.QModelIndex)
    def on_click(self, index):
        #Cuando se da click en la celda indicada
        row = index.row()
        column = index.column()
        #Mostramos la ventana de prediccion
        if(row<len(CtrlPartido.getPartidos()) and column ==3):
            self.aux = ventPrediccion(row, column)
            self.aux.show()
            self.aux.activateWindow()


#Crear predicciones
class ventPrediccion(QtWidgets.QWidget, Ui_ventPrediccion):
    def __init__(self,row,column, parent=None):
        super(ventPrediccion, self).__init__(parent)

        self.setupUi(self)
        self.row = row
        self.column = column
        self.Partido=CtrlPartido.getPartidos()
        self.Usuarios=CtrlUsuario.getUsers()
        #Ingresamos los datos a la ventana
        self.lblEqA.setText(self.Partido[row].equipoA)
        self.lblEqB.setText(self.Partido[row].equipoB)
        self.lblFechaPart.setText(str(self.Partido[row].fecha.toPyDate()))
        #llenamos el CbX
        index=0
        for i in self.Usuarios:
            self.cbxPredUsuario.addItem(i.nombre)
        self.BtnGuardarPred.clicked.connect(self.guardarPred)
        self.BtnSalirPred.clicked.connect(self.hide)
        

    def guardarPred(self):
         #Identificador de usuarios
        self.indexUser=self.cbxPredUsuario.currentIndex() 
        #Marcador
        self.scoreA=self.txtScoreA.text()
        self.scoreB=self.txtScoreB.text()
        ####
        print(self.Usuarios[self.indexUser].nombre,self.indexUser)
        pred=Prediccion(self.Partido[self.row],self.Usuarios[self.indexUser],self.indexUser,self.scoreA,self.scoreB)
        dos=CtrlPrediccion()
        #Guardamos las predicciones 
        CtrlPrediccion.savePred(dos,pred)
        #Volvemos a blanco
        self.txtScoreA.setText("")
        self.txtScoreB.setText("")         

#Ventana tabla de predicciones   
class VentPredicciones(QtWidgets.QWidget,Ui_ventPredRealizadas):
    def __init__(self, parent=None):
        super(VentPredicciones, self).__init__(parent)
        self.setupUi(self)
        listPreds=CtrlPrediccion.getPreds()
        #Tabla de predicciones
        for i in range(len(listPreds)):
           
            self.tablePreds.setItem(
                i,0,QtWidgets.QTableWidgetItem(listPreds[i].user.nombre))
            self.tablePreds.setItem(
                i,1,QtWidgets.QTableWidgetItem(listPreds[i].partido.equipoA))
            self.tablePreds.setItem(
                i,2,QtWidgets.QTableWidgetItem(listPreds[i].partido.equipoB))
            self.tablePreds.setItem(
                i,3, QtWidgets.QTableWidgetItem(str(listPreds[i].partido.fecha.toPyDate())))
            item=QtWidgets.QTableWidgetItem(listPreds[i].scoreA +" : " +listPreds[i].scoreB)
            item.setTextAlignment(4)
            self.tablePreds.setItem(
                i,4, item)
            item=QtWidgets.QTableWidgetItem(listPreds[i].partido.scoreAFin+" : "+listPreds[i].partido.scoreBFin)
            item.setTextAlignment(4)
            self.tablePreds.setItem(
                i,5, item) #.
            item=QtWidgets.QTableWidgetItem(listPreds[i].predPoints)
            item.setTextAlignment(4)
            self.tablePreds.setItem(
                i,6, item)
               #Centrar tabla xd

            self.tablePreds.doubleClicked.connect(self.on_click)

    #@QtCore.pyqtSlot(QtCore.QModelIndex)
    def on_click(self, index):
        #Cuando se da click en la celda indicada
        row = index.row()
        column = index.column()
        #Mostramos la ventana de prediccion
        if(row<len(CtrlPrediccion.getPreds()) and column ==6):
            self.aux = VentResumen(row, column)
            self.aux.show()
            self.aux.activateWindow()

class VentResumen(QtWidgets.QWidget,Ui_ventResumen):
    def __init__(self,row,column, parent=None):
        super(VentResumen, self).__init__(parent)
        self.setupUi(self) 

        self.row = row
        self.column = column
        listPreds=CtrlPrediccion.getPreds()
        self.lblAResult.setText(listPreds[row].ar)   
        self.lblAMarcador.setText(listPreds[row].am)
        self.lblAMarcRes.setText(listPreds[row].arm)
        self.lblAM3.setText(listPreds[row].am3)
        self.lblAMR3.setText(listPreds[row].arm3)
        self.lblAGolesT.setText(listPreds[row].aGE)
        self.lblAlmost.setText(listPreds[row].almost)
        #Total
        self.lblATotal.setText(listPreds[row].predPoints)

        self.btnCerrar.clicked.connect(self.hide)
        

class VentTableGame(QtWidgets.QWidget,Ui_VentTabGame):
    def __init__(self, parent=None):
        super(VentTableGame, self).__init__(parent)
        self.setupUi(self)
        listPartidos=CtrlPartido.getPartidos()
        for i in range(0, len(listPartidos)):
            self.tablePartidosPlay.setItem(
                i, 0, QtWidgets.QTableWidgetItem(listPartidos[i].equipoA))
            self.tablePartidosPlay.setItem( 
                i, 1, QtWidgets.QTableWidgetItem(listPartidos[i].equipoB))
            self.tablePartidosPlay.setItem(
                i, 2, QtWidgets.QTableWidgetItem(
                str(listPartidos[i].fecha.toPyDate())))
            item=QtWidgets.QTableWidgetItem("Jugar!")
            item.setTextAlignment(4)
            self.tablePartidosPlay.setItem(
                i,3,item)

        self.tablePartidosPlay.doubleClicked.connect(self.on_click)

    #@QtCore.pyqtSlot(QtCore.QModelIndex)
    def on_click(self, index):
        #Cuando se da click en la celda indicada
        row = index.row()
        column = index.column()
        #Mostramos la ventana de juego
        if(row<len(CtrlPartido.getPartidos()) and column ==3):
            self.aux = VentGame(row, column)
            self.hide()
            dos= CtrlPartido()
            CtrlPartido.delPartido(dos,row)
            self.aux.show()

class VentGame(QtWidgets.QWidget, Ui_VentPlayGame):
    def __init__(self,row,column, parent=None):
        super(VentGame, self).__init__(parent)
        self.setupUi(self)

        self.row = row
        self.column = column
        self.partidos=CtrlPartido.getPartidos()
        self.usuarios=CtrlUsuario.getUsers()
        #Ingresamos los datos a la ventana
        self.lblEqA.setText(self.partidos[row].equipoA) 
        self.lblEqB.setText(self.partidos[row].equipoB)
        self.lblFechaPart.setText(str(self.partidos[row].fecha.toPyDate()))


        self.BtnJugar.clicked.connect(self.playGame)
    
    def playGame(self):
        sa=self.txtScoreA.text()
        sb=self.txtScoreB.text()
        obj=CtrlPrediccion()
        us=CtrlUsuario()
        listPred=CtrlPrediccion.getPreds()
        
        self.hide()
        #Marcador final en la prediccion 
        for lista in listPred:
            if lista.partido==self.partidos[self.row]:
                #Asignamos el marcador final
                lista.partido.scoreAFin=sa
                lista.partido.scoreBFin=sb
                lista.calScore()
                for user in self.usuarios:
                    if user == lista.user: #Comparamos usuarios
                        user.points+=float(lista.predPoints) #le damos los puntos por su prediccion
                        user.pred+=1

        #Volver a mandar la lista
        CtrlPrediccion.replacePreds(obj,listPred)
        CtrlUsuario.replaceUsers(us,self.usuarios)

   
       

class VentGanadores(QtWidgets.QWidget, Ui_ventGanadores):
    def __init__(self, parent=None):
        super(VentGanadores, self).__init__(parent)
        self.setupUi(self)
        self.winDialog = DialogWindow()
        obj=VentUsuarios() #Obtenemos los ganadores de la ventana  de usuarios
        try:
            self.lblG1.setText(obj.getRank()[0])
            self.lblG2.setText(obj.getRank()[1])
            self.lblG3.setText(obj.getRank()[2])
        except:
            self.hide()
            self.winDialog.dialog('Error',"Error, No exiten ganadores",2,2)
            self.winDialog.show()
            self.winDialog.activateWindow()
        self.btnSalirVGanadores.clicked.connect(self.hide)    
    

#ventana Mostrar premios
class VentPremios(QtWidgets.QWidget,Ui_ventPremios):
    def __init__(self, parent=None):
        super(VentPremios, self).__init__(parent)
        self.setupUi(self)
        self.btnSalirVPremios.clicked.connect(self.hide)
        



def start():
    app = QtWidgets.QApplication(sys.argv)
    myApp = VentanaPrincipal() 
    myApp.show()
    app.exec()
