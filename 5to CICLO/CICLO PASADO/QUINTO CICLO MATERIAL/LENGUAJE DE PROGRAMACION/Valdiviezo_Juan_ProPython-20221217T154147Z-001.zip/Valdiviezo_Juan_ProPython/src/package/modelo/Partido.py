#Clase Partidos

class Partido(object):
    def __init__(self,equipoA,equipoB,fecha):
        self.equipoA = equipoA
        self.equipoB = equipoB
        self.fecha = fecha
        #Marcador final
        #Marcador final
        self.scoreAFin=""
        self.scoreBFin=""
    #Equivalente al equals
    def __eq__(self,other):

        if self.equipoA != other.equipoA: return False
        if self.equipoB != other.equipoB: return False
        if self.fecha.toPyDate() != other.fecha.toPyDate(): return False
            
        return True
