from .Partido import *
import pickle 

class CtrlPartido(object):
    listGames = []

    def savePartido(self, game:Partido):
        try:
            file = open("games.dat", "rb")
            self.listGames.clear()
            self.listGames = pickle.load(file)  # Cargamos la lista de usuarios
            print("Encontro el archivo")
            
        except FileNotFoundError:
            print("No encontro el archivo")
        
        
        #Serializamos los datos
        self.listGames.append(game)
        file = open("games.dat", "wb")
        pickle.dump(self.listGames, file)
        file.close()

    def getPartidos() -> list:
        try:
            file = open("games.dat", "rb")
            return pickle.load(file)  # Cargamos la lista de partidos
        except FileNotFoundError:
            print("Error de lectura, no se ha podido encontrar el archivo")
            return []

    def delPartido(self,index):
        self.listGames.clear()
        try:
            file = open("games.dat", "rb")
            self.listGames.clear()
            self.listGames = pickle.load(file)  # Cargamos la lista de usuarios
            print("Encontro el archivo")

        except FileNotFoundError:
            print("No encontro el archivo")

        del self.listGames[index]
        file = open("games.dat", "wb")
        pickle.dump(self.listGames, file)
        file.close()

