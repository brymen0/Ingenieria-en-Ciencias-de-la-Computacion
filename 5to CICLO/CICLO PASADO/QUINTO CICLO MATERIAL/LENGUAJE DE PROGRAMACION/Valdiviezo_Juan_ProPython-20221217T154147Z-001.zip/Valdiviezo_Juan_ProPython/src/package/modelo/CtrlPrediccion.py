from .Prediccion import *
import pickle

class CtrlPrediccion(object):
    listPreds = []

    def savePred(self,pred:Prediccion):
        try:
            file=open("preds.dat", "rb")
            self.listPreds.clear()
            self.listPreds=pickle.load(file)
            print("Encontro file preds")
        except FileNotFoundError:
            print("No encontro el archivo")   
        #Validamos que un usuario sobreescriba su prediccion 
        #Comparar usuario con partido
        #Serializamos los datos
        band= True
        for aux in self.listPreds:
            if (aux.user == pred.user) and (aux.partido==pred.partido):
                aux.scoreA=pred.scoreA
                aux.scoreB=pred.scoreB
                band= False
        if band:
            self.listPreds.append(pred)
        
        file = open("preds.dat", "wb")
        pickle.dump(self.listPreds, file)
        file.close()  

    def getPreds()-> list:
        try:
            file= open("preds.dat","rb")
            return pickle.load(file)
        except FileNotFoundError:
            print("Error de lectura, no se ha podido encontrar el archivo")
            return []  

    def replacePreds(self,lista:list):
        self.listPreds.clear()
        self.listPreds=lista
        file = open("preds.dat", "wb")
        pickle.dump(self.listPreds, file)
        file.close()   
