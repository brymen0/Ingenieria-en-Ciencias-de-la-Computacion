
import package.controlador.Ctrl  as ctrl

if __name__=="__main__":
    ctrl.start()
    
