import pickle
def inputFloat(mensaje):
    entrada=0.0
    while True:
        try:
            entrada = float(input(mensaje))
        except:
            print("La entrada debe ser un valor numérico")
            continue
        return entrada

def inputEntero(mensaje):
    entrada = "palabra"
    while entrada.isalpha():
        try:
            entrada = int(input(mensaje))
        except:
            print("La entrada debe ser un valor entero")
            continue
        return entrada

class Persona(object):
    def __init__(self, nombre, edad, sexo):
        self.nombre = nombre
        self.edad = edad
        self.sexo = sexo

class ContenedorPersona(object):
    def __init__(self):
        self.Personas = dict()

    def agregarPersona(self, nombre, edad, sexo):
        self.Personas[nombre] = Persona(nombre, edad, sexo)

    def guardarPersona(self):
        try:
                with open ("Personas.dat", "wb") as f:
                    pickle.dump(self.Personas,f)
                    f.close()
        except:
            print("Error al guardar Personas")
    def cargarPersona(self):
        try:
            with open ("Personas.dat", "rb") as f:
                self.Personas = pickle.load(f)
                f.close()
        except:
            print("Error al cargar Personas")
    def buscarPersona(self, nombre):
        for k in self.Personas.keys():
            if self.Personas[k].nombre == nombre:
                return k
        return -1
    def mostrarPersona(self):
        print("\t\tLista de Personas")
        for k in self.Personas.keys():
            print("Nombre: ", self.Personas[k].nombre,
                  " Edad: ", self.Personas[k].edad,
                  " Sexo: ", self.Personas[k].sexo)
    def calcularPromedio(self, sexo):
        self.listaPersonas = [self.Personas[k] for k in self.Personas.keys()]
        filtrado=list(filter(lambda x: x.sexo == sexo, self.listaPersonas))
        promedio = sum([filtrado[k].edad for k in range(len(filtrado))])/len(filtrado)
        print("El promedio de edad de sexo: ", sexo, " es: ", promedio)
#Menu de Opciones
opc, submenu = 0,0
Personas = ContenedorPersona()
Personas.cargarPersona()
while opc !=4:
    print("\tRegistro Civil\n"
          +"1. Agregar Persona\n"
          +"2. Listar Persona\n"
          +"3. Calcular Promedio de acuerdo al Sexo\n"
          +"4. Salir")
    opc = inputEntero("Ingrese su opcion: ")
    if opc==1:
        Personas.agregarPersona(input("Ingrese nombre: "), inputEntero("Ingrese edad: "), input("Ingrese sexo: "))
        Personas.guardarPersona()
    elif opc==2:
        Personas.mostrarPersona()
    elif opc==3:
        print("\tPromedio de acuerdo al Sexo\n"
              +"1. Masculino\n"
              +"2. Femenino")
        submenu = inputEntero("Ingrese su opcion: ")
        if submenu==1:
            Personas.calcularPromedio("M")
        elif submenu==2:
            Personas.calcularPromedio("F")
        elif submenu>2 or submenu<0:
            print("Valor Ingresado Incorrecto")
    elif opc==4:
        print("Ha terminado el Programa");
        break
    elif opc>4 or opc<0:
        print("Valor Ingresado Incorrecto");