import math

def inputFloat(mensaje):
    entrada=0.0
    while True:
        try:
            entrada = float(input(mensaje))
        except:
            print("La entrada debe ser un valor numérico")
            continue
        return entrada

def inputEntero(mensaje):
    entrada = "palabra"
    while entrada.isalpha():
        try:
            entrada = int(input(mensaje))
        except:
            print("La entrada debe ser un valor entero")
            continue
        return entrada


def calcularTipoNumero(tipo):

    def calcularNumeroNarcicista(numero):
        digitos = [int(numero[i])**len(numero) for i in range(len(numero))]
        if sum(digitos)==numero: print("El numero ingresado es NARCISISTA")
        else: print("El numero ingresado no es NARCISISTA")

    def calcularNumeroPerfecto(numA):
        if sum(filter(lambda i:numA%i==0,[i for i in range(1,numA)])) == numA: print("El numero ingresado ES PERFECTO")
        else: print("El numero NO ES PERFECTO")

    def calcularNumerosAmigos(numeroA, numeroB):
        numeroAmigo = sum(filter(lambda i:numeroA%i==0,[i for i in range(1,numeroA)]))==numeroB and sum(filter(lambda i:numeroB%i==0,[i for i in range(1,numeroB)]))==numeroA
        if numeroAmigo==True: print("Los numeros ingresados SI SON AMIGOS")
        else: print("Los numeros ingresados NO SON AMIGOS")
    figu_func = {"Narcisista": calcularNumeroNarcicista,
                "Perfecto": calcularNumeroPerfecto,
                "Amigos": calcularNumerosAmigos}

    return figu_func[tipo]

#Menu de Opciones
opc = 0
while opc !=4:
    print("\tCalcular Tipos de Numeros\n"
          +"1. Calcular Numero Narcisista\n"
          +"2. Calcular Numero Perfecto\n"
          +"3. Calcular Numeros Amigos\n"
          +"4. Salir")
    opc = inputEntero("Ingresa tu opcion: ")
    if opc==1:
        calcularTipoNumero("Narcisista")(input("Ingrese un Numero: "))
    elif opc==2:
        calcularTipoNumero("Perfecto")(inputEntero("Ingrese un Numero: "))
    elif opc==3:
        calcularTipoNumero("Amigos")(inputEntero("Ingrese Numero1: "), inputEntero("Ingrese Numero2: "))
    elif opc==4:
        print("Ha terminado el Programa");
        break
    elif opc>4 or opc<0:
        print("Valor Ingresado Incorrecto");