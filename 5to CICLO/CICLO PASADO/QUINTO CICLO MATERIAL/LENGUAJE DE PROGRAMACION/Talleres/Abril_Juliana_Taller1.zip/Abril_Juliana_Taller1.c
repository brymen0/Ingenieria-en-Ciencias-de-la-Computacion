#include<stdio.h>
#include<stdlib.h>
#include <locale.h>
#define TAM 100
void validar_numeros (char *p);

void mostrarMatriz(int nfilas, int ncolumnas, int matriz[nfilas][ncolumnas])
{
	int i,j;
	printf("\n");
	
	for (i=0; i<nfilas; i++){
		for (j=0; j<ncolumnas; j++){
			printf ("%d \t ",matriz[i][j]);
		}
		printf("\n");
	}
}

void llenarMatriz(int nfilas, int ncolumnas, int matriz[nfilas][ncolumnas])
{
	int i,j;
	printf("\n");
	
	for (i=0; i<nfilas; i++){
		for (j=0; j<ncolumnas; j++){
			printf ("Alumno %d Nota %d: ",i+1, j+1);
			scanf("%d", &matriz[i][j]);
		}
		printf("\n");
	}
}

int  contarEjercicios(int filas, int colum, int numAlum, int matriz[filas][colum]){
	int i, j, cont=0;
	for (j=0; j<colum; j++){
		if(matriz[numAlum-1][j] != -1){
			cont++;
		}
	}
	return cont;
}

double  devolverMedia(int filas, int colum, int numAlum, int matriz[filas][colum]){
	int i, j, cont=0, aux=colum;
	for (j=0; j<colum; j++){
		if(matriz[numAlum-1][j] != -1){
			cont=cont+matriz[numAlum-1][j];
		}else{
			aux--;
		}
	}
	double media = cont/(aux);
	return media;
}

double  devolverMediaTotal(int filas, int colum, int numAlum, int matriz[filas][colum]){
	int i, j, cont=0, aux=colum;
	for (j=0; j<colum; j++){
		if(matriz[numAlum-1][j] != -1){
			cont=cont+matriz[numAlum-1][j];
		}else{
			return 0;
		}
	}
	double media = cont/(aux);
	return media;
}

double  devolverNotaMedia(int filas, int colum, int nota, int matriz[filas][colum]){
	int i, j, cont=0, aux=filas;
	for (j=0; j<filas; j++){
		if(matriz[j][nota-1] != -1){
			cont=cont+matriz[j][nota-1];
		}else{
			aux--;
		}
	}
	double media = cont/(aux);
	return media;
}

int  devolverNotaPresentada(int filas, int colum, int nota, int matriz[filas][colum]){
	int i, j, cont=0, aux=filas;
	for (j=0; j<filas; j++){
		if(matriz[j][nota-1] != -1){
			cont=cont+matriz[j][nota-1];
		}else{
			aux--;
		}
	}
	return aux;
}

int  devolverNotaMayor(int filas, int colum, int nota, int matriz[filas][colum]){
	int mayor = matriz[0][nota-1], posMayor=0, i;
	
    for(i = 1; i < filas; i++)
    {
        if(matriz[i][nota-1] > mayor)
        {
            mayor = matriz[i][nota-1];
            posMayor = i;
        }
    }
	return mayor;
}

int  devolverNotaMenor(int filas, int colum, int nota, int matriz[filas][colum]){
	int menor = matriz[0][nota-1], posMayor=0, i;
	
    for(i = 1; i < filas; i++)
    {
        if(matriz[i][nota-1] < menor && matriz[i][nota-1] != -1)
        {
            menor = matriz[i][nota-1];
            posMayor = i;
        }
    }
	return menor;
}

int  contarMediaTotal(int filas, int colum, int matriz[filas][colum]){
	int i, j, cont=0, aux=0;
	double media;
	for (i=0; i<filas; i++){
		cont=0;
		for (j=0; j<colum; j++){
			if(matriz[i][j] != -1){
				cont=cont+matriz[i][j];
			}else{
				break;
			}
		}
		media = cont/(colum);
		if(media>3.5){
			aux++;
		}	
	}
	return aux;
}


int main(){
	setlocale(LC_CTYPE, "Spanish");
	char buffer[TAM];
	int filas, columnas, n=0, i, tcla, num;
	double numDouble;
	printf ("\n*************Ingreso de Datos************\n");
	printf ("Ingrese el n�mero de estudiantes: \n");
	scanf("%d", &filas);
	printf ("Ingrese el n�mero de notas: \n");
	scanf("%d", &columnas);
	int matriz[filas][columnas];
	llenarMatriz(filas, columnas, matriz);
	//mostrarMatriz(filas, columnas, matriz);
	do{
		printf ("\n*************Men� de Opciones************\n");
		printf ("1. Ejercicio 1\n");
		printf ("2. Ejercicio 2\n");
		printf ("3. Ejercicio 3\n");
		printf ("4. Ejercicio 4\n");
		printf ("5. Ejercicio 5\n");
		printf ("6. Ejercicio 6\n");
		printf ("7. Ejercicio 7\n");
		printf ("8. Ejercicio 8\n");
		printf ("9. Ejercicio 9\n");
		printf ("10. Salir del Programa\n");
		printf ("*******************************************\n");
		validar_numeros (buffer);
		tcla = atoi(buffer);
		printf ("\n");
		switch (tcla){
			case 1:
				printf("Usted ha elegido: 1.Dado el n�mero de un alumno, devolver el n�mero de ejercicios entregados\n");
				printf("Ingrese un n�mero n: ");
				scanf("%d", &n);
				num = contarEjercicios(filas, columnas, n, matriz);
				printf("El n�mero de trabajos entregados por el Alumno %d es: %d\n", n, num);
			break;
			case 2:
				printf("Usted ha elegido: 2.Dado el n�mero de un alumno, devolver la media sobre los ejercicios entregados.\n");
				printf("Ingrese un n�mero n: ");
				scanf("%d", &n);
				numDouble = devolverMedia(filas, columnas, n, matriz);
				printf("El n�mero de media de trabajos entregados por el Alumno %d es: %f\n", n, numDouble);
				break;
			case 3:
				printf("Usted ha elegido: 3.Dado el n�mero de un alumno, devolver la media sobre los ejercicios entregados.\n");
				printf("Ingrese un n�mero n: ");
				scanf("%d", &n);
				numDouble = devolverMediaTotal(filas, columnas, n, matriz);
				printf("El n�mero de media de trabajos entregados por el Alumno %d es: %f\n", n, numDouble);
				break;
			case 4:
				printf("Usted ha elegido: 4.Devolver el n�mero de todos los alumnos que han entregado todos los ejercicios\n");
				num = contarMediaTotal(filas, columnas, matriz);
				printf("El n�mero de estudiantes con todos los trabajos entregados es: %d\n",num);
				break;
			case 5:
				printf("Usted ha elegido: 5.Dado el n�mero de una nota, devolver la media sobre los ejercicios entregados.\n");
				printf("Ingrese un n�mero n: ");
				scanf("%d", &n);
				numDouble = devolverNotaMedia(filas, columnas, n, matriz);
				printf("La nota media de trabajos entregados por la Nota %d es: %f\n", n, numDouble);
				break;
			case 6:
				printf("Usted ha elegido: 6.Dado el n�mero de una nota, devolver la nota m�s alta.\n");
				printf("Ingrese un n�mero n: ");
				scanf("%d", &n);
				num = devolverNotaMayor(filas, columnas, n, matriz);
				printf("La nota mayor de trabajos entregados por la Nota %d es: %d\n", n, num);
				break;
			case 7:
				printf("Usted ha elegido: 7.Dado el n�mero de una nota, devolver la nota m�s baja.\n");
				printf("Ingrese un n�mero n: ");
				scanf("%d", &n);
				num = devolverNotaMenor(filas, columnas, n, matriz);
				printf("La nota menor de trabajos entregados por la Nota %d es: %d\n", n, num);
				break;
			case 8:
				printf("Usted ha elegido: 8.Dado el n�mero de una nota, devolver el n�mero de estudiantes que lo presentaron.\n");
				printf("Ingrese un n�mero n: ");
				scanf("%d", &n);
				num = devolverNotaPresentada(filas, columnas, n, matriz);
				printf("El n�mero de estudiantes que presentaron la Nota %d es: %d\n", n, num);
				break;
			case 9:
				printf   ("Usted ha elegido: 2.Dado el n�mero de un alumno, devolver la media sobre los ejercicios entregados.\n");
				break;
			case 10:
				printf  ("**************Fin del Programa*************");
				break;
			default:
				printf ("Opci�n Inv�lida, Int�ntelo de Nuevo D: \n\n");	
		}
	}while(tcla!=10);
}


void validar_numeros (char *p)
{
    int i;
    char tecla;
 
    /*importante inicializar los valores
    ya que la implementacion que hice lo amerita*/
    i = 0;
    p[0] = '\0';
 
    do
    {
        tecla = getch ();//atrapa un caracter sin dejar un eco
 
        /*8 es la tecla para eliminar un caracter
        y el i obligaotiamente tiene que ser mayor que cero
        ya que si entra al if y tiene valor cero, el valor de i
        decrementar� y p tendr�a un subindice -1, "p[-1]"�?*/
        if ( i > 0 && tecla == 8 )
        {
            printf ( "\b \b" );
            p[--i] = '\0';
        }
        else
        {
            //rango de numeros y 32 es el espacio/
            if ( (tecla >= 48 && tecla <= 57)  || 
                tecla == 44 || tecla==46 )
            {
                printf ( "%c", tecla );
                p[i++] = tecla;
            }
        }
    } while ((tecla != 13 || p[0] == '\0') && i < TAM);
    /* 13 inidica el Enter, i tiene que ser menor 
    que TAM pues de lo contrario, estar�a accediendo
    a memoria no reservada*/
 
    p[i] = '\0';  //colocamos el fin de cadena/
 
    return ;
}
