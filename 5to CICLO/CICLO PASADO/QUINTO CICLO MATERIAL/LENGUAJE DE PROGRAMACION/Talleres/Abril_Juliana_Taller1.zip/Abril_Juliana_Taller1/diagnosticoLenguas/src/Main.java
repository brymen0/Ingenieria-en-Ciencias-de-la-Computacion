import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int filas, columnas, tcla, n, num;
        double numDouble;
        System.out.println("\n*************Ingreso de Datos************");
        System.out.println("Ingrese el número de estudiantes: ");
        filas = leer.nextInt();
        System.out.println("Ingrese el número de notas: ");
        columnas = leer.nextInt();
        int matriz[][] = new int[filas][columnas];
        llenarMatriz(filas, columnas, matriz);
        mostrarMatriz(filas, columnas, matriz);
        do{
            System.out.println ("*************Menú de Opciones************");
            System.out.println ("1. Ejercicio 1");
            System.out.println ("2. Ejercicio 2");
            System.out.println ("3. Ejercicio 3");
            System.out.println ("4. Ejercicio 4");
            System.out.println ("5. Ejercicio 5");
            System.out.println ("6. Ejercicio 6");
            System.out.println ("7. Ejercicio 7");
            System.out.println ("8. Ejercicio 8");
            System.out.println ("9. Ejercicio 9");
            System.out.println ("10. Salir del Programa");
            System.out.println ("*******************************************");
            tcla = leer.nextInt();
            switch (tcla){
                case 1:
                    System.out.println("Usted ha elegido: 1.Dado el número de un alumno, devolver el número de ejercicios entregados");
                    System.out.println("Ingrese un número n: ");
                    n = leer.nextInt();
                    num = contarEjercicios(filas, columnas, n, matriz);
                    System.out.println("El número de trabajos entregados por el Alumno" + n + "es: "+num);
                    break;
                case 2:
                    System.out.println("Usted ha elegido: 2.Dado el número de un alumno, devolver la media sobre los ejercicios entregados.");
                    System.out.println("Ingrese un número n: ");
                    n = leer.nextInt();
                    numDouble = devolverMedia(filas, columnas, n, matriz);
                    System.out.println("El número de media de trabajos entregados por el Alumno es: " +numDouble);
                    break;
                case 3:
                    System.out.println("Usted ha elegido: 3.Dado el número de un alumno, devolver la media sobre los ejercicios entregados.");
                    System.out.println("Ingrese un número n: ");
                    n = leer.nextInt();
                    numDouble = devolverMediaTotal(filas, columnas, n, matriz);
                    System.out.println("El número de media de trabajos entregados por el Alumno es: " + numDouble);
                    break;
                case 4:
                    System.out.println("Usted ha elegido: 4.Devolver el número de todos los alumnos que han entregado todos los ejercicios");
                    num = contarMediaTotal(filas, columnas, matriz);
                    System.out.println("El número de estudiantes con todos los trabajos entregados es: "+num);
                    break;
                case 5:
                    System.out.println("Usted ha elegido: 5.Dado el número de una nota, devolver la media sobre los ejercicios entregados.");
                    System.out.println("Ingrese un número n: ");
                    n = leer.nextInt();
                    numDouble = devolverNotaMedia(filas, columnas, n, matriz);
                    System.out.println("La nota media de trabajos entregados por la Nota es: "+numDouble);
                    break;
                case 6:
                    System.out.println("Usted ha elegido: 6.Dado el número de una nota, devolver la nota más alta.");
                    System.out.println("Ingrese un número n: ");
                    n = leer.nextInt();
                    num = devolverNotaMayor(filas, columnas, n, matriz);
                    System.out.println("La nota mayor de trabajos entregados por la Nota es: "+num);
                    break;
                case 7:
                    System.out.println("Usted ha elegido: 7.Dado el número de una nota, devolver la nota más baja.");
                    System.out.println("Ingrese un número n: ");
                    n = leer.nextInt();
                    num = devolverNotaMenor(filas, columnas, n, matriz);
                    System.out.println("La nota menor de trabajos entregados por la Nota es: "+num);
                    break;
                case 8:
                    System.out.println("Usted ha elegido: 8.Dado el número de una nota, devolver el número de estudiantes que lo presentaron.");
                    System.out.println("Ingrese un número n: ");
                    n = leer.nextInt();
                    num = devolverNotaPresentada(filas, columnas, n, matriz);
                    System.out.println("El número de estudiantes que presentaron la Nota es: "+num);
                    break;
                case 9:
                    System.out.println   ("Usted ha elegido: 2.Dado el número de un alumno, devolver la media sobre los ejercicios entregados.");
                    break;
                case 10:
                    System.out.println  ("**************Fin del Programa*************");
                    break;
                default:
                    System.out.println ("Opción Inválida, Inténtelo de Nuevo D: \n");
            }
        }while(tcla!=10);
    }
    public static void llenarMatriz(int filas, int columnas, int matriz[][]){
        Scanner leer = new Scanner(System.in);
        for (int x=0; x < matriz.length; x++) {
            for (int y=0; y < matriz[x].length; y++) {
                System.out.println ("Alumno "+(x+1)+" Nota "+(y+1));
                matriz[x][y] = leer.nextInt();
            }
        }
    }

    public static void mostrarMatriz(int filas, int columnas, int matriz[][]){
        for (int x=0; x < matriz.length; x++) {
            for (int y=0; y < matriz[x].length; y++) {
                System.out.println (matriz[x][y]);
            }
        }
    }

    public static int  contarEjercicios(int filas, int colum, int numAlum, int matriz[][]){
        int i, j, cont=0;
        for (j=0; j<colum; j++){
            if(matriz[numAlum-1][j] != -1){
                cont++;
            }
        }
        return cont;
    }

     public static double  devolverMedia(int filas, int colum, int numAlum, int matriz[][]){
        int i, j, cont=0, aux=colum;
        for (j=0; j<colum; j++){
            if(matriz[numAlum-1][j] != -1){
                cont=cont+matriz[numAlum-1][j];
            }else{
                aux--;
            }
        }
        double media = cont/(aux);
        return media;
    }

    public static double  devolverMediaTotal(int filas, int colum, int numAlum, int matriz[][]){
        int i, j, cont=0, aux=colum;
        for (j=0; j<colum; j++){
            if(matriz[numAlum-1][j] != -1){
                cont=cont+matriz[numAlum-1][j];
            }else{
                return 0;
            }
        }
        double media = cont/(aux);
        return media;
    }

    public static double  devolverNotaMedia(int filas, int colum, int nota, int matriz[][]){
        int i, j, cont=0, aux=filas;
        for (j=0; j<filas; j++){
            if(matriz[j][nota-1] != -1){
                cont=cont+matriz[j][nota-1];
            }else{
                aux--;
            }
        }
        double media = cont/(aux);
        return media;
    }

    public static int  devolverNotaPresentada(int filas, int colum, int nota, int matriz[][]){
        int i, j, cont=0, aux=filas;
        for (j=0; j<filas; j++){
            if(matriz[j][nota-1] != -1){
                cont=cont+matriz[j][nota-1];
            }else{
                aux--;
            }
        }
        return aux;
    }

    public static int  devolverNotaMayor(int filas, int colum, int nota, int matriz[][]){
        int mayor = matriz[0][nota-1], posMayor=0, i;

        for(i = 1; i < filas; i++)
        {
            if(matriz[i][nota-1] > mayor)
            {
                mayor = matriz[i][nota-1];
                posMayor = i;
            }
        }
        return mayor;
    }

    public static int  devolverNotaMenor(int filas, int colum, int nota, int matriz[][]){
        int menor = matriz[0][nota-1], posMayor=0, i;

        for(i = 1; i < filas; i++)
        {
            if(matriz[i][nota-1] < menor && matriz[i][nota-1] != -1)
            {
                menor = matriz[i][nota-1];
                posMayor = i;
            }
        }
        return menor;
    }

    public static int  contarMediaTotal(int filas, int colum, int matriz[][]){
        int i, j, cont=0, aux=0;
        double media;
        for (i=0; i<filas; i++){
            cont=0;
            for (j=0; j<colum; j++){
                if(matriz[i][j] != -1){
                    cont=cont+matriz[i][j];
                }else{
                    break;
                }
            }
            media = cont/(colum);
            if(media>3.5){
                aux++;
            }
        }
        return aux;
    }
}