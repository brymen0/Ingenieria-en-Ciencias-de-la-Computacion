padre(teraj,abraham).
padre(teraj,sarai).
padre(teraj,najor).
padre(teraj,haran).
padre(abraham,isaac).
padre(abraham,ismael).
padre(haran,lot).
padre(haran,melca).
padre(haran,jesca).
padre(najor,batuel).
padre(najor,laban).
padre(isaac,esau).
padre(isaac,jacob).
madre(agar,ismael).
madre(sarai,isaac).
madre(melca,batuel).
madre(batuel,rebeca).
madre(batuel,laban).
madre(rebeca,esau).
madre(rebeca,jacob).
hombre(isaac).
hombre(lot).
hombre(najor).
hombre(laban).
hombre(abraham).
hombre(haran).
hombre(teraj).
hombre(esau).
hombre(jacob).
hombre(ismael).
mujer(melca).
mujer(jesca).
mujer(sarai).
mujer(agar).
mujer(batuel).
mujer(rebeca).
casado(abraham,sarai).
casado(najor,melca).
casado(isaac,rebeca).

ascendiente_directo(X, Y) :- (padre(X, Y); madre(X, Y)).
ascendiente(X, Z) :- ascendiente_directo(X, Z).
ascendiente(X, Z) :- ascendiente_directo(X, Y), ascendiente(Y, Z).
hijo(X,Y) :- hombre(X), ascendiente_directo(Y,X).
hija(X,Y) :- mujer(X), ascendiente_directo(Y,X).
abuelo(X,Y) :- padre(Z,Y),padre(X,Z).
abuela(X,Y) :- madre(Z,Y),madre(X,Z).
hermanos(X,Y):-(padre(Z,X);madre(Z,X)),(madre(Z,Y);padre(Z,Y)),X\=Y.
hermano(X,Y) :- hombre(X), hermanos(X,Y).
hermana(X,Y) :- mujer(X), hermanos(X,Y).
tio(W,X) :- hombre(W),(padre(Y,X),(hermano(Y,W);hermana(Y,W)));(madre(V,Z),(hermano(V,W);hermana(V,W))),X\=Z.
tia(W,X) :- mujer(W),(padre(Y,X),(hermano(Y,W);hermana(Y,W)));(madre(V,Z),(hermano(V,W);hermana(V,W))), X\=Z.
sobrino(X,Y) :- hombre(X),(padre(Z,X),(hermano(Z,Y);hermana(Z,Y)));(madre(Z,X),(hermano(Z,V);hermana(Z,V))),Y\=V.
sobrina(X,Y) :- mujer(X),(padre(Z,X),(hermano(Z,Y);hermana(Z,Y)));(madre(Z,X),(hermano(Z,V);hermana(Z,V))),Y\=V.
primo(Z,M) :- hombre(Z),(padre(X,Z);madre(X,Z)),(padre(Y,M);madre(Y,M)),X\=Y,Z\=M,(hermano(X,Y);hermana(X,Y)).
prima(Z,M) :- mujer(Z),(padre(X,Z);madre(X,Z)),(padre(Y,M);madre(Y,M)),X\=Y,Z\=M,(hermano(X,Y);hermana(X,Y)).
incestuosos(X,Y) :- (casado(X,Y);casado(Y,X)),(hermano(X,Y);hermana(X,Y)).

