funciona(japoneses,220).
funciona(hindues,110).
funciona(camerun,380).
funciona(camerun,110).
funciona(alemanes,220).
funciona(japoneses,380).
marca(hitachi,japoneses).
marca(honda,japoneses).
marca(pradesh,hindues).
marca(mokuta,camerun).
marca(grundig,alemana).

pais(argentina,220).
pais(ecuador,110).
pais(turquia,380).
pais(iran,380).

voltfunc(X,Z):-marca(X,Y),funciona(Y,Z).
expo(X,M):-marca(X,Y),funciona(Y,Z), pais(M,Z).
