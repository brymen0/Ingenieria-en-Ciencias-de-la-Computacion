package vista

import controlador.{BusquedaXTitulo, Libros, clientes, compraLibros, eliminarLibros, historialFacturas, proovedores, ventaLibros, ventanaPrincipal}
import modelo.{Cliente, Factura, Libro, Proovedor, archivos, archivosCaja, archivosCliente, archivosCompra, archivosFactura, archivosProovedor, archivosTransacciones, archivosTransaccionesCli, archivosTransaccionesProv, caja, ctrlCliente, ctrlFactura, ctrlLibros, ctrlProovedor, ctrlTransacciones, ctrlTransaccionesCli, ctrlTransaccionesProv, transacciones}

import java.awt.event.{ActionEvent, ActionListener, MouseAdapter, MouseEvent}
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO
import javax.swing.event.{ListSelectionEvent, ListSelectionListener}
import javax.swing.{ImageIcon, JFileChooser, JOptionPane}
import javax.swing.table.DefaultTableModel
import scala.collection.mutable
import scala.util.Random

class appLibros extends ActionListener {
  var vistaMenu = new ventanaPrincipal
  vistaMenu.setLocationRelativeTo(vistaMenu)
  vistaMenu.setVisible(true)
  vistaMenu.accionLibros.addActionListener(this)
  vistaMenu.accionRegistroClientes.addActionListener(this)
  vistaMenu.accionRegistroProovedores.addActionListener(this)
  vistaMenu.accionComprarLibros.addActionListener(this)
  vistaMenu.accionVenderLibros.addActionListener(this)
  vistaMenu.accionFacturacion.addActionListener(this)
  vistaMenu.accionSalir.addActionListener(this)
  vistaMenu.accionAyuda.addActionListener(this)
  override def actionPerformed(e: ActionEvent): Unit = {
    if (e.getSource == vistaMenu.accionLibros){
      var abastecimiento = new abastecimiento
    }
    if(e.getSource == vistaMenu.accionRegistroClientes){
      var registroClientes = new registroClientes
    }
    if(e.getSource == vistaMenu.accionRegistroProovedores){
      var registroProovedores = new registroProovedores
    }
    if(e.getSource == vistaMenu.accionComprarLibros){
      var compraLibros = new compra
    }
    if(e.getSource == vistaMenu.accionVenderLibros){
      var ventaLibros = new venta
    }
    if(e.getSource == vistaMenu.accionFacturacion){
      var facturacion = new facturacion
    }
    if(e.getSource== vistaMenu.accionSalir){
      System.exit(0)
    }
    if(e.getSource == vistaMenu.accionAyuda){
      JOptionPane.showMessageDialog(null, "Tienda de Libros, Camila Granda")
    }
  }
}

class abastecimiento extends ActionListener{
  var ctrl = new ctrlLibros
  val data = new archivos(ctrl)
  val listaLib: mutable.Seq[Libro] = ctrl.listaLibros
  var ventanaLibros = new Libros
  ventanaLibros.btnAbastecer.addActionListener(this)
  ventanaLibros.btnSubirImagen.addActionListener(this)
  ventanaLibros.btnEliminar.addActionListener(this)
  ventanaLibros.btnLimpiar.addActionListener(this)
  ventanaLibros.listaLibros.addListSelectionListener(new ListSelectionListener {
    override def valueChanged(e: ListSelectionEvent): Unit = {
      val itemSeleccionado = ventanaLibros.listaLibros.getSelectedIndex
      if(itemSeleccionado == 0){
        val input = JOptionPane.showInputDialog(null, "Ingrese ISBN a buscar: ", "Búsqueda del ISBN", JOptionPane.QUESTION_MESSAGE)
        if(input!="" | input!=null){
          data.recuperarArchivos("libros.dat")
          for (item: Libro <- listaLib){
            if (input==item.ISBN){
              JOptionPane.showMessageDialog(null, s"ISBN: ${item.ISBN}\nTitulo: ${item.titulo}\nPrecioCompra: ${item.precioCompra}\nPrecioVenta: ${item.precioVenta}\nCantidad: ${item.cantidadActual}")
            }
          }
        }else{
          JOptionPane.showMessageDialog(null, "No se permite campos vacíos")
        }
      }
      if(itemSeleccionado==1){
        var ventBusqueda = new ventanaBusqueda
      }
      if(itemSeleccionado==2){
        try{
          JOptionPane.showMessageDialog(null, "El libro más costoso es: " + ctrl.costoso())
        }catch {
          case _: Throwable => JOptionPane.showMessageDialog(null, "No hay libros registrados")
        }

      }
      if(itemSeleccionado==3){
        try{
          JOptionPane.showMessageDialog(null, "El libro más barato es: " + ctrl.barato())
        }catch {
          case _: Throwable => JOptionPane.showMessageDialog(null, "No hay libros registrados")
        }
      }
    }
  })
  ventanaLibros.setDefaultCloseOperation(1)
  ventanaLibros.setLocationRelativeTo(ventanaLibros)
  ventanaLibros.setResizable(false)
  ventanaLibros.setVisible(true)

  override def actionPerformed(e: ActionEvent): Unit = {

    if (e.getSource == ventanaLibros.btnSubirImagen) {
      val fileChooser = new JFileChooser()
      val returnVal = fileChooser.showOpenDialog(null)
      if (returnVal == JFileChooser.APPROVE_OPTION) {
        val selectedFile = fileChooser.getSelectedFile.getCanonicalFile
        val currentDir = new File(".").getCanonicalPath
        val relativePath = selectedFile.getCanonicalPath.substring(currentDir.length() + 1)
        val image = ImageIO.read(selectedFile)
        val width = 150
        val height = 150
        val resizedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB)
        val g = resizedImage.createGraphics()
        g.drawImage(image, 0, 0, width, height, null)
        g.dispose()
        ventanaLibros.subirImagen.setIcon(new ImageIcon(resizedImage))
        ventanaLibros.txtDirImagen.setText(relativePath)
      } else {
        JOptionPane.showMessageDialog(null, "No ha seleccionado ningún archivo")
      }

    }

    if (e.getSource == ventanaLibros.btnAbastecer) {
      if (ventanaLibros.txtISBN.getText != "" & ventanaLibros.txtTitulo.getText != "" & ventanaLibros.txtPrecioCompra.getText != ""
        & ventanaLibros.txtPrecioVenta.getText != "" & ventanaLibros.txtCantidad.getText != "" & ventanaLibros.txtDirImagen.getText != "") {
        try {
          val ISBN = ventanaLibros.txtISBN.getText
          val data = new archivos(ctrl)
          data.recuperarArchivos("libros.dat")
          var bandera = false
          if (ctrl.isbn13(ISBN)) {
            val titulo = ventanaLibros.txtTitulo.getText
            if (titulo.matches("[a-zA-z]+([ '-][a-zA-Z]+)*")) {
              val precioCompra = ventanaLibros.txtPrecioCompra.getText
              val precioC: Float = precioCompra.toFloat
              val precioVenta = ventanaLibros.txtPrecioVenta.getText
              val precioV: Float = precioVenta.toFloat
              val cantidad = ventanaLibros.txtCantidad.getText
              val cant: Int = cantidad.toInt
              val dirImagen = ventanaLibros.txtDirImagen.getText
              var libros = new Libro(ISBN, titulo, precioC, precioV, cant, dirImagen)
              for (item <- ctrl.listaLibros) {
                if (item.ISBN.equals(libros.ISBN)) {
                  bandera = true
                }
              }
              if (!bandera) {
                ctrl.ingresarLibros(libros)
                JOptionPane.showMessageDialog(null, "Registro exitoso")
                ventanaLibros.txtISBN.setText("")
                ventanaLibros.txtTitulo.setText("")
                ventanaLibros.txtPrecioCompra.setText("")
                ventanaLibros.txtPrecioVenta.setText("")
                ventanaLibros.txtCantidad.setText("")
                ventanaLibros.txtDirImagen.setText("")
                ventanaLibros.subirImagen.setText("")
              } else {
                JOptionPane.showMessageDialog(null, "Error,libro ya fue agregado previamente")
              }
            } else {
              JOptionPane.showMessageDialog(null, "Evite poner nombres de libros con la letra ñ")
            }
          }
        } catch {
          case exception: Exception =>
            JOptionPane.showMessageDialog(null, "Mal ingreso de datos")
        }
      }
      else {
        JOptionPane.showMessageDialog(null, "No se permite campos vacíos")
      }
    }

    if (e.getSource == ventanaLibros.btnEliminar) {
      var eliminacion = new eliminacionLibros
    }

    if(e.getSource == ventanaLibros.btnLimpiar){
      ventanaLibros.txtISBN.setText("")
      ventanaLibros.txtTitulo.setText("")
      ventanaLibros.txtPrecioCompra.setText("")
      ventanaLibros.txtPrecioVenta.setText("")
      ventanaLibros.txtCantidad.setText("")
      ventanaLibros.txtDirImagen.setText("")
      ventanaLibros.subirImagen.setText("")

    }
  }
}

class eliminacionLibros extends ActionListener{

  val ventanaEliminarLib= new eliminarLibros
  val model: DefaultTableModel = ventanaEliminarLib.tablaLibros.getModel.asInstanceOf[DefaultTableModel]
  val ctrl = new ctrlLibros
  val data = new archivos(ctrl)
  ventanaEliminarLib.tablaLibros.setEnabled(false)
  data.recuperarArchivos("libros.dat")
  val listaLib: mutable.Seq[Libro] = ctrl.listaLibros
  var cont = 0
  //Cargamos la tabla
  for (item: Libro <- listaLib) {
    model.setValueAt(item.ISBN, cont, 0)
    model.setValueAt(item.titulo, cont, 1)
    model.setValueAt(item.precioCompra, cont, 2)
    model.setValueAt(item.precioVenta, cont, 3)
    model.setValueAt(item.cantidadActual, cont, 4)
    model.setValueAt(item.imagen, cont, 5)
    cont = 1 + cont
  }
  ventanaEliminarLib.tablaLibros.setModel(model)
  ventanaEliminarLib.btnEliminar.addActionListener(this)
  ventanaEliminarLib.setDefaultCloseOperation(1)
  ventanaEliminarLib.setLocationRelativeTo(ventanaEliminarLib)
  ventanaEliminarLib.setResizable(false)
  ventanaEliminarLib.setVisible(true)

  override def actionPerformed(e: ActionEvent): Unit = {

    if(e.getSource == ventanaEliminarLib.btnEliminar){
      var aux=0
      var libroEliminar = ventanaEliminarLib.txtISBNeliminar.getText
      if (libroEliminar != "") {
        for (item: Libro <- listaLib) {
          if(libroEliminar == item.ISBN){
            if (ctrl.eliminar(aux)) {
              data.recuperarArchivos("libros.dat")
              val model: DefaultTableModel = ventanaEliminarLib.tablaLibros.getModel.asInstanceOf[DefaultTableModel]
              for {
                i <- 0 until model.getRowCount
                j <- 0 until model.getColumnCount
              } {
                model.setValueAt("", i, j)
              }
              val listaLib: mutable.Seq[Libro] = ctrl.listaLibros
              var cont = 0
              //Cargamos la tabla
              for (item: Libro <- listaLib) {
                model.setValueAt(item.ISBN, cont, 0)
                model.setValueAt(item.titulo, cont, 1)
                model.setValueAt(item.precioCompra, cont, 2)
                model.setValueAt(item.precioVenta, cont, 3)
                model.setValueAt(item.cantidadActual, cont, 4)
                model.setValueAt(item.imagen, cont, 5)
                cont = 1 + cont
              }
              ventanaEliminarLib.tablaLibros.setModel(model)
              JOptionPane.showMessageDialog(null, "Eliminación hecha")
            } else {
              JOptionPane.showMessageDialog(null, "No se puede borrar")
            }
          }
          aux = 1+aux
        }

      } else {
        JOptionPane.showMessageDialog(null, "No se permite campos vacíos")
      }
    }
  }
}

class ventanaBusqueda{
  val ventanaBuscar = new BusquedaXTitulo
  val ctrl = new ctrlLibros
  val model: DefaultTableModel = ventanaBuscar.tablaLibrosXTitulo.getModel.asInstanceOf[DefaultTableModel]
  val data = new archivos(ctrl)
  ventanaBuscar.tablaLibrosXTitulo.setEnabled(false)
  data.recuperarArchivos("libros.dat")
  val listaLib: mutable.Seq[Libro] = ctrl.listaLibros
  var bandera = false
  var cont = 0
  val input: String = JOptionPane.showInputDialog(null, "Ingrese título del libro a buscar: ", "Búsqueda mediante el Título", JOptionPane.QUESTION_MESSAGE)
  if (input != "" | input != null) {
    for (item: Libro <- listaLib) {
      if (input == item.titulo) {
        model.setValueAt(item.ISBN, cont, 0)
        model.setValueAt(item.titulo, cont, 1)
        model.setValueAt(item.precioCompra, cont, 2)
        model.setValueAt(item.precioVenta, cont, 3)
        model.setValueAt(item.cantidadActual, cont, 4)
        model.setValueAt(item.imagen, cont, 5)
        bandera = true
        cont = 1 + cont
      }
    }

    ventanaBuscar.tablaLibrosXTitulo.setModel(model)
    ventanaBuscar.setDefaultCloseOperation(1)
    ventanaBuscar.setLocationRelativeTo(ventanaBuscar)
    ventanaBuscar.setResizable(false)
    ventanaBuscar.setVisible(true)
    if(!bandera){
      ventanaBuscar.dispose()
      JOptionPane.showMessageDialog(null, "No se encontró el libro")
    }

  } else {
    JOptionPane.showMessageDialog(null, "No se permite campos vacíos")
  }
}

class registroClientes extends ActionListener{

  val ventanaRegistroClientes = new clientes
  val ctrl = new ctrlCliente
  val data = new archivosCliente(ctrl)
  val model: DefaultTableModel = ventanaRegistroClientes.tablaClientes.getModel.asInstanceOf[DefaultTableModel]
  ventanaRegistroClientes.btnRegistrarCliente.addActionListener(this)
  ventanaRegistroClientes.listarCliente.addMouseListener(new MouseAdapter {
    override def mouseClicked(e: MouseEvent): Unit = {
      if (e.getSource == ventanaRegistroClientes.listarCliente) {
        data.recuperarArchivos("clientes.dat")
        val listaCli: mutable.Seq[Cliente] = ctrl.listaClientes
        var cont = 0
        //Cargamos la tabla
        for (item: Cliente <- listaCli) {
          model.setValueAt(item.cedula, cont, 0)
          model.setValueAt(item.nombre, cont, 1)
          model.setValueAt(item.apellido, cont, 2)
          model.setValueAt(item.direccion, cont, 3)
          model.setValueAt(item.telefono, cont, 4)
          cont = 1 + cont
        }
        ventanaRegistroClientes.tablaClientes.setModel(model)
      }
    }
  })
  ventanaRegistroClientes.modificarCliente.addMouseListener(new MouseAdapter {
    override def mouseClicked(e: MouseEvent): Unit = {
      if (e.getSource == ventanaRegistroClientes.modificarCliente) {
        var bandera = false
        val input: String = JOptionPane.showInputDialog(null, "Ingrese cédula del cliente a modificar: ", "Modificación del Cliente", JOptionPane.QUESTION_MESSAGE)
        if (input != "" | input != null) {
          data.recuperarArchivos("clientes.dat")
          val listaCLiente: mutable.Seq[Cliente] = ctrl.listaClientes
          if (listaCLiente.nonEmpty) {
            for (item <- ctrl.listaClientes) {
              if (item.cedula.equals(input)) {
                bandera = true
                try {
                  val nombre = JOptionPane.showInputDialog(null, "Ingrese el nuevo nombre del cliente: ", "Modificación del Cliente", JOptionPane.QUESTION_MESSAGE)
                  val apellido = JOptionPane.showInputDialog(null, "Ingrese el nuevo apellido del cliente: ", "Modificación del Cliente", JOptionPane.QUESTION_MESSAGE)
                  val direccion = JOptionPane.showInputDialog(null, "Ingrese la nueva dirección del cliente: ", "Modificación del Cliente", JOptionPane.QUESTION_MESSAGE)
                  val telefono = JOptionPane.showInputDialog(null, "Ingrese el nuevo teléfono del cliente: ", "Modificación del Cliente", JOptionPane.QUESTION_MESSAGE)
                  ctrl.modificarCliente(input, nombre, apellido, direccion, telefono)
                  JOptionPane.showMessageDialog(null, "Modificación hecha")
                } catch {
                  case e: Exception => JOptionPane.showMessageDialog(null, "No se permite campos vacíos")
                }
              }
            }
            if (!bandera) {
              JOptionPane.showMessageDialog(null, "No se encontró el cliente con esa cédula")
            }
          }
        }
      }
    }
  })
  ventanaRegistroClientes.eliminarCliente.addMouseListener(new MouseAdapter {
    override def mouseClicked(e: MouseEvent): Unit = {
      if (e.getSource == ventanaRegistroClientes.eliminarCliente) {
        var bandera = false
        val input: String = JOptionPane.showInputDialog(null, "Ingrese cédula del cliente a eliminar: ", "Eliminación del Cliente", JOptionPane.QUESTION_MESSAGE)
        if (input != "" | input != null) {
          data.recuperarArchivos("clientes.dat")
          val listaCLiente: mutable.Seq[Cliente] = ctrl.listaClientes
          if (listaCLiente.nonEmpty) {
            for (item <- ctrl.listaClientes) {
              if (item.cedula.equals(input)) {
                bandera = true
                ctrl.eliminarCliente(input)
                val model: DefaultTableModel = ventanaRegistroClientes.tablaClientes.getModel.asInstanceOf[DefaultTableModel]
                for {
                  i <- 0 until model.getRowCount
                  j <- 0 until model.getColumnCount
                } {
                  model.setValueAt("", i, j)
                }
                JOptionPane.showMessageDialog(null, "Eliminación hecha")
              }
            }
            if (!bandera) {
              JOptionPane.showMessageDialog(null, "No se encontró el cliente con esa cédula")
            }
          }
        }
      }
    }
  })
  ventanaRegistroClientes.buscarCliente.addMouseListener(new MouseAdapter {
    override def mouseClicked(e: MouseEvent): Unit = {
      if (e.getSource == ventanaRegistroClientes.buscarCliente) {
        var bandera = false
        val input: String = JOptionPane.showInputDialog(null, "Ingrese cédula del cliente a buscar: ", "Búsqueda del Cliente", JOptionPane.QUESTION_MESSAGE)
        if (input != "" | input != null) {
          data.recuperarArchivos("clientes.dat")
          val listaCLiente: mutable.Seq[Cliente] = ctrl.listaClientes
          if (listaCLiente.nonEmpty) {
            for (item <- ctrl.listaClientes) {
              if (item.cedula.equals(input)) {
                bandera = true
                JOptionPane.showMessageDialog(null, "Cédula: " + item.cedula + "\nNombre: " + item.nombre + "\nApellido: " + item.apellido + "\nDirección: " + item.direccion + "\nTeléfono: " + item.telefono)
              }
            }
            if (!bandera) {
              JOptionPane.showMessageDialog(null, "No se encontró el cliente con esa cédula")
            }
          }
        }
      }
    }
  })
  ventanaRegistroClientes.btnLimpiarCliente.addActionListener(this)
  ventanaRegistroClientes.tablaClientes.setEnabled(false)
  ventanaRegistroClientes.setDefaultCloseOperation(1)
  ventanaRegistroClientes.setLocationRelativeTo(ventanaRegistroClientes)
  ventanaRegistroClientes.setResizable(false)
  ventanaRegistroClientes.setVisible(true)

  override def actionPerformed(e: ActionEvent): Unit = {
    if (e.getSource == ventanaRegistroClientes.btnRegistrarCliente) {
      try {
        var cedula = ventanaRegistroClientes.txtCedula.getText
        if (ctrl.verifCedula(cedula)) {
          var nombre = ventanaRegistroClientes.txtNombre.getText
          var apellido = ventanaRegistroClientes.txtApellido.getText
          var direccion = ventanaRegistroClientes.txtDireccion.getText
          var telefono = ventanaRegistroClientes.txtTelefono.getText
          if (nombre != "" & apellido != "" & direccion != "" & telefono != "" & cedula != "") {
            if(ctrl.verifTelefono(telefono)){
              data.recuperarArchivos("clientes.dat")
              var bandera = false
              var cliente = new Cliente(cedula, nombre, apellido, direccion, telefono)
              for (item <- ctrl.listaClientes) {
                if (item.cedula.equals(cliente.cedula)) {
                  bandera = true
                }
              }
              if (!bandera) {
                ctrl.ingresarCliente(cliente)
                JOptionPane.showMessageDialog(null, "Registro exitoso")
              }
              else {
                JOptionPane.showMessageDialog(null, "El cliente ya existe")
              }
            }else {
              JOptionPane.showMessageDialog(null, "El teléfono debe ser numérico")
            }
          } else {
            JOptionPane.showMessageDialog(null, "No se permite campos vacíos")
          }
        } else {
          JOptionPane.showMessageDialog(null, "Cédula incorrecta")
        }
      } catch {
        case e: Exception => JOptionPane.showMessageDialog(null, "Error en el registro")
      }
    }

    if(e.getSource == ventanaRegistroClientes.btnLimpiarCliente){
      ventanaRegistroClientes.txtCedula.setText("")
      ventanaRegistroClientes.txtNombre.setText("")
      ventanaRegistroClientes.txtApellido.setText("")
      ventanaRegistroClientes.txtDireccion.setText("")
      ventanaRegistroClientes.txtTelefono.setText("")
    }
  }
}

class registroProovedores extends ActionListener{

  val ventanaRegistroProovedor = new proovedores
  val ctrl = new ctrlProovedor
  val data = new archivosProovedor(ctrl)
  val model: DefaultTableModel = ventanaRegistroProovedor.tablaProovedor.getModel.asInstanceOf[DefaultTableModel]
  ventanaRegistroProovedor.btnRegistrarProovedor.addActionListener(this)
  ventanaRegistroProovedor.listarProovedor.addMouseListener(new MouseAdapter {
    override def mouseClicked(e: MouseEvent): Unit = {
      if (e.getSource == ventanaRegistroProovedor.listarProovedor) {
        data.recuperarArchivos("proovedores.dat")
        val listaProovedor: mutable.Seq[Proovedor] = ctrl.listaProovedor
        var cont = 0
        //Cargamos la tabla
        for (item: Proovedor <- listaProovedor) {
          model.setValueAt(item.ruc, cont, 0)
          model.setValueAt(item.nombre, cont, 1)
          model.setValueAt(item.apellido, cont, 2)
          model.setValueAt(item.direccion, cont, 3)
          model.setValueAt(item.telefono, cont, 4)
          cont = 1 + cont
        }
        ventanaRegistroProovedor.tablaProovedor.setModel(model)
      }
    }
  })
  ventanaRegistroProovedor.modificarProovedor.addMouseListener(new MouseAdapter {
    override def mouseClicked(e: MouseEvent): Unit = {
      if (e.getSource == ventanaRegistroProovedor.modificarProovedor) {
        var bandera = false
        val input: String = JOptionPane.showInputDialog(null, "Ingrese RUC del proovedor a modificar: ", "Modificación del Proovedor", JOptionPane.QUESTION_MESSAGE)
        if (input != "" | input != null) {
          data.recuperarArchivos("proovedores.dat")
          val listaProovedor: mutable.Seq[Proovedor] = ctrl.listaProovedor
          if (listaProovedor.nonEmpty) {
            for (item <- ctrl.listaProovedor) {
              if (item.ruc.equals(input)) {
                bandera = true
                try {
                  val nombre = JOptionPane.showInputDialog(null, "Ingrese el nuevo nombre del proovedor: ", "Modificación del Proovedor", JOptionPane.QUESTION_MESSAGE)
                  val apellido = JOptionPane.showInputDialog(null, "Ingrese el nuevo apellido del proovedor: ", "Modificación del Proovedor", JOptionPane.QUESTION_MESSAGE)
                  val direccion = JOptionPane.showInputDialog(null, "Ingrese la nueva dirección del proovedor: ", "Modificación del Proovedor", JOptionPane.QUESTION_MESSAGE)
                  val telefono = JOptionPane.showInputDialog(null, "Ingrese el nuevo teléfono del proovedor: ", "Modificación del Proovedor", JOptionPane.QUESTION_MESSAGE)
                  ctrl.modificarProovedor(input, nombre, apellido, direccion, telefono)
                  JOptionPane.showMessageDialog(null, "Modificación hecha")
                } catch {
                  case e: Exception => JOptionPane.showMessageDialog(null, "No se permite campos vacíos")
                }
              }
            }
            if (!bandera) {
              JOptionPane.showMessageDialog(null, "No se encontró el proovedor con ese RUC")
            }
          }
        }
      }
    }
  })
  ventanaRegistroProovedor.eliminarProovedor.addMouseListener(new MouseAdapter {
    override def mouseClicked(e: MouseEvent): Unit = {
      if (e.getSource == ventanaRegistroProovedor.eliminarProovedor) {
        var bandera = false
        val input: String = JOptionPane.showInputDialog(null, "Ingrese RUC del proovedor a eliminar: ", "Eliminación del Proovedor", JOptionPane.QUESTION_MESSAGE)
        if (input != "" | input != null) {
          data.recuperarArchivos("proovedores.dat")
          val listaProovedor: mutable.Seq[Proovedor] = ctrl.listaProovedor
          if (listaProovedor.nonEmpty) {
            for (item <- ctrl.listaProovedor) {
              if (item.ruc.equals(input)) {
                bandera = true
                ctrl.eliminarProovedor(input)
                val model: DefaultTableModel = ventanaRegistroProovedor.tablaProovedor.getModel.asInstanceOf[DefaultTableModel]
                for {
                  i <- 0 until model.getRowCount
                  j <- 0 until model.getColumnCount
                } {
                  model.setValueAt("", i, j)
                }
                JOptionPane.showMessageDialog(null, "Eliminación hecha")
              }
            }
            if (!bandera) {
              JOptionPane.showMessageDialog(null, "No se encontró el proovedor con ese RUC")
            }
          }
        }
      }
    }
  })
  ventanaRegistroProovedor.buscarProovedor.addMouseListener(new MouseAdapter {
    override def mouseClicked(e: MouseEvent): Unit = {
      if (e.getSource == ventanaRegistroProovedor.buscarProovedor) {
        var bandera = false
        val input: String = JOptionPane.showInputDialog(null, "Ingrese RUC del proovedor a buscar: ", "Búsqueda del Proovedor", JOptionPane.QUESTION_MESSAGE)
        if (input != "" | input != null) {
          data.recuperarArchivos("proovedores.dat")
          val listaProovedor: mutable.Seq[Proovedor] = ctrl.listaProovedor
          if (listaProovedor.nonEmpty) {
            for (item <- ctrl.listaProovedor) {
              if (item.ruc.equals(input)) {
                bandera = true
                JOptionPane.showMessageDialog(null, "RUC: " + item.ruc + "\nNombre: " + item.nombre + "\nApellido: " + item.apellido + "\nDirección: " + item.direccion + "\nTeléfono: " + item.telefono)
              }
            }
            if (!bandera) {
              JOptionPane.showMessageDialog(null, "No se encontró el proovedor con ese RUC")
            }
          }
        }
      }
    }
  })
  ventanaRegistroProovedor.btnLimpiarProovedor.addActionListener(this)
  ventanaRegistroProovedor.tablaProovedor.setEnabled(false)
  ventanaRegistroProovedor.setDefaultCloseOperation(1)
  ventanaRegistroProovedor.setLocationRelativeTo(ventanaRegistroProovedor)
  ventanaRegistroProovedor.setResizable(false)
  ventanaRegistroProovedor.setVisible(true)

  override def actionPerformed(e: ActionEvent): Unit = {
    if (e.getSource == ventanaRegistroProovedor.btnRegistrarProovedor) {
      try {
        val ruc = ventanaRegistroProovedor.txtRUC.getText
        if (ctrl.verifnum(ruc)) {
          val nombre = ventanaRegistroProovedor.txtNombre.getText
          val apellido = ventanaRegistroProovedor.txtApellido.getText
          val direccion = ventanaRegistroProovedor.txtDireccion.getText
          val telefono = ventanaRegistroProovedor.txtTelefono.getText
          if (nombre != "" & apellido != "" & direccion != "" & telefono != "" & ruc != "") {
            if(ctrl.verifnum(telefono)){
              data.recuperarArchivos("proovedores.dat")
              var bandera = false
              var proovedor = new Proovedor(ruc, nombre, apellido, direccion, telefono)
              for (item <- ctrl.listaProovedor) {
                if (item.ruc.equals(proovedor.ruc)) {
                  bandera = true
                }
              }
              if (!bandera) {
                ctrl.ingresarProovedor(proovedor)
                JOptionPane.showMessageDialog(null, "Registro exitoso")
              }
              else {
                JOptionPane.showMessageDialog(null, "El proovedor ya existe")
              }
            }else {
              JOptionPane.showMessageDialog(null, "El teléfono debe ser numérico")
            }
          } else {
            JOptionPane.showMessageDialog(null, "No se permite campos vacíos")
          }
        } else {
          JOptionPane.showMessageDialog(null, "RUC incorrecta")
        }
      } catch {
        case e: Exception => JOptionPane.showMessageDialog(null, "Error en el registro")
      }
    }

    if(e.getSource == ventanaRegistroProovedor.btnLimpiarProovedor){
      ventanaRegistroProovedor.txtRUC.setText("")
      ventanaRegistroProovedor.txtNombre.setText("")
      ventanaRegistroProovedor.txtApellido.setText("")
      ventanaRegistroProovedor.txtDireccion.setText("")
      ventanaRegistroProovedor.txtTelefono.setText("")
    }
  }
}

class compra extends ActionListener{
  val ventanaRegistroCompra = new compraLibros
  val valCaja = new caja
  val dataCaja = new archivosCaja(valCaja)
  val ctrlPro = new ctrlProovedor
  val dataPro = new archivosProovedor(ctrlPro)
  val ctrl = new ctrlLibros
  val data = new archivos(ctrl)
  val ctrlTrans = new ctrlTransaccionesProv
  val ctrlCom = new modelo.compra
  val dataTrans = new archivosTransaccionesProv(ctrlTrans)
  ventanaRegistroCompra.btnComprar.setEnabled(false)
  ventanaRegistroCompra.btnBuscarCompra.addActionListener(this)
  ventanaRegistroCompra.btnComprar.addActionListener(this)
  ventanaRegistroCompra.btnLimpiar.addActionListener(this)
  ventanaRegistroCompra.setDefaultCloseOperation(1)
  ventanaRegistroCompra.setLocationRelativeTo(ventanaRegistroCompra)
  ventanaRegistroCompra.setResizable(false)
  ventanaRegistroCompra.setVisible(true)

  override def actionPerformed(e: ActionEvent): Unit = {
    if(e.getSource == ventanaRegistroCompra.btnBuscarCompra) {
      valCaja.valorCaja()
      dataCaja.recuperarArchivos()
      val valor = valCaja.recorrerLista()
      if (valor != "") {
        ventanaRegistroCompra.txtCaja.setText(valor)
        ventanaRegistroCompra.btnComprar.setEnabled(true)
      } else {
        JOptionPane.showMessageDialog(null, "No hay dinero en caja")
      }
      var bandera = false
      val RUC = ventanaRegistroCompra.txtcompraRUC.getText
      dataPro.recuperarArchivos("proovedores.dat")
      val listaProovedor: mutable.Seq[Proovedor] = ctrlPro.listaProovedor
      if (listaProovedor.nonEmpty) {
        for (item <- ctrlPro.listaProovedor) {
          if (item.ruc.equals(RUC)) {
            ventanaRegistroCompra.txtcompraRUC.setEnabled(false)
            bandera = true
            ventanaRegistroCompra.txtcompraNombre.setText(item.nombre)
            ventanaRegistroCompra.txtcompraApellidos.setText(item.apellido)
            ventanaRegistroCompra.txtcompraDireccion.setText(item.direccion)
            ventanaRegistroCompra.txtcompraTelefono.setText(item.telefono)
            val model: DefaultTableModel = ventanaRegistroCompra.tablaLibrosCompra.getModel.asInstanceOf[DefaultTableModel]
            ventanaRegistroCompra.tablaLibrosCompra.setEnabled(false)
            data.recuperarArchivos("libros.dat")
            val listaLib: mutable.Seq[Libro] = ctrl.listaLibros
            var cont = 0
            for (item: Libro <- listaLib) {
              model.setValueAt(item.ISBN, cont, 0)
              model.setValueAt(item.titulo, cont, 1)
              model.setValueAt(item.precioCompra, cont, 2)
              model.setValueAt(item.cantidadActual, cont, 3)
              cont = 1 + cont
            }
            ventanaRegistroCompra.tablaLibrosCompra.setModel(model)
            ventanaRegistroCompra.txtcompraISBN.setEnabled(true)
            ventanaRegistroCompra.txtcompraCantidad.setEnabled(true)
          }
        }
        if (!bandera) {
          JOptionPane.showMessageDialog(null, "No se encontró el proovedor con ese RUC")
        }
      }
    }

    if(e.getSource == ventanaRegistroCompra.btnComprar){
      val isbnPedir = ventanaRegistroCompra.txtcompraISBN.getText
      val cantidadPedir = ventanaRegistroCompra.txtcompraCantidad.getText
      val num = ctrlCom.compraLibro(isbnPedir,cantidadPedir.toInt,ventanaRegistroCompra.txtcompraRUC.getText)
      if(num != -1){
        dataTrans.recuperarArchivos()
        var aux =0
        val model: DefaultTableModel = ventanaRegistroCompra.tablaComprasRealizadas.getModel.asInstanceOf[DefaultTableModel]
        val listaTrans: mutable.Seq[transacciones] = ctrlTrans.listaTransaccionesProovedores
        //Cargamos la tabla
        for (item: transacciones <- listaTrans) {
          model.setValueAt(item.cedRuc, aux, 0)
          model.setValueAt(item.isbn, aux, 1)
          model.setValueAt(item.precioCV, aux, 2)
          model.setValueAt(item.ejemplares, aux, 3)
          model.setValueAt(item.fecha, aux, 4)
          aux = 1 + aux
        }
        ventanaRegistroCompra.tablaComprasRealizadas.setModel(model)
        valCaja.valorCaja()
        dataCaja.recuperarArchivos()
        val valor = valCaja.recorrerLista()
        ventanaRegistroCompra.txtCaja.setText(valor)

        data.recuperarArchivos("libros.dat")
        var cont = 0
        val modelo: DefaultTableModel = ventanaRegistroCompra.tablaLibrosCompra.getModel.asInstanceOf[DefaultTableModel]
        val listaLib: mutable.Seq[Libro] = ctrl.listaLibros
        //Cargamos la tabla
        for (item: Libro <- listaLib) {
          modelo.setValueAt(item.ISBN, cont, 0)
          modelo.setValueAt(item.titulo, cont, 1)
          modelo.setValueAt(item.precioCompra, cont, 2)
          modelo.setValueAt(item.cantidadActual, cont, 3)
          cont = 1 + cont
        }
        ventanaRegistroCompra.tablaLibrosCompra.setModel(modelo)
      }
    }

    if(e.getSource==ventanaRegistroCompra.btnLimpiar){
      ventanaRegistroCompra.txtcompraRUC.setText("")
      ventanaRegistroCompra.txtcompraRUC.setEnabled(true)
      ventanaRegistroCompra.txtcompraNombre.setText("")
      ventanaRegistroCompra.txtcompraApellidos.setText("")
      ventanaRegistroCompra.txtcompraDireccion.setText("")
      ventanaRegistroCompra.txtcompraTelefono.setText("")
      ventanaRegistroCompra.txtcompraISBN.setText("")
      ventanaRegistroCompra.txtcompraCantidad.setText("")
      ventanaRegistroCompra.txtCaja.setText("")
      ventanaRegistroCompra.txtcompraISBN.setEnabled(false)
      ventanaRegistroCompra.txtcompraCantidad.setEnabled(false)
      ventanaRegistroCompra.btnComprar.setEnabled(false)
      val model: DefaultTableModel = ventanaRegistroCompra.tablaLibrosCompra.getModel.asInstanceOf[DefaultTableModel]
      for {
        i <- 0 until model.getRowCount
        j <- 0 until model.getColumnCount
      } {
        model.setValueAt("", i, j)
      }
      val modelo: DefaultTableModel = ventanaRegistroCompra.tablaComprasRealizadas.getModel.asInstanceOf[DefaultTableModel]
      for {
        i <- 0 until modelo.getRowCount
        j <- 0 until modelo.getColumnCount
      } {
        modelo.setValueAt("", i, j)
      }
    }
  }
}

class venta extends ActionListener{
  ////////////////////
  val ventanaRegistroVenta = new ventaLibros
  val valCaja = new caja
  val dataCaja = new archivosCaja(valCaja)
  val ctrlCliente = new ctrlCliente
  val dataCli = new archivosCliente(ctrlCliente)
  val ctrl = new ctrlLibros
  val data = new archivos(ctrl)
  val ctrlTrans = new ctrlTransaccionesCli
  val ctrlCom = new modelo.venta
  val dataTrans = new archivosTransaccionesCli(ctrlTrans)
  ventanaRegistroVenta.btnVender.setEnabled(false)
  ventanaRegistroVenta.btnBuscarVenta.addActionListener(this)
  ventanaRegistroVenta.btnVender.addActionListener(this)
  ventanaRegistroVenta.btnLimpiar.addActionListener(this)
  ventanaRegistroVenta.btnMasVendido.addActionListener(this)
  ventanaRegistroVenta.setDefaultCloseOperation(1)
  ventanaRegistroVenta.setLocationRelativeTo(ventanaRegistroVenta)
  ventanaRegistroVenta.setResizable(false)
  ventanaRegistroVenta.setVisible(true)

  override def actionPerformed(e: ActionEvent): Unit = {
    if (e.getSource == ventanaRegistroVenta.btnBuscarVenta) {
      valCaja.valorCaja()
      dataCaja.recuperarArchivos()
      val valor = valCaja.recorrerLista()
      if (valor != "") {
        ventanaRegistroVenta.txtCaja.setText(valor)
        ventanaRegistroVenta.btnVender.setEnabled(true)
      } else {
        JOptionPane.showMessageDialog(null, "No hay dinero en caja")
      }
      var bandera = false
      val cedula = ventanaRegistroVenta.txtventaCedula.getText
      dataCli.recuperarArchivos("clientes.dat")
      val listaCli: mutable.Seq[Cliente] = ctrlCliente.listaClientes
      if (listaCli.nonEmpty) {
        for (item <- ctrlCliente.listaClientes) {
          if (item.cedula.equals(cedula)) {
            ventanaRegistroVenta.txtventaCedula.setEnabled(false)
            bandera = true
            ventanaRegistroVenta.txtventaNombre.setText(item.nombre)
            ventanaRegistroVenta.txtventaApellidos.setText(item.apellido)
            ventanaRegistroVenta.txtventaDireccion.setText(item.direccion)
            ventanaRegistroVenta.txtventaTelefono.setText(item.telefono)
            val model: DefaultTableModel = ventanaRegistroVenta.tablaLibrosVenta.getModel.asInstanceOf[DefaultTableModel]
            ventanaRegistroVenta.tablaLibrosVenta.setEnabled(false)
            data.recuperarArchivos("libros.dat")
            val listaLib: mutable.Seq[Libro] = ctrl.listaLibros
            var cont = 0
            for (item: Libro <- listaLib) {
              model.setValueAt(item.ISBN, cont, 0)
              model.setValueAt(item.titulo, cont, 1)
              model.setValueAt(item.precioVenta, cont, 2)
              model.setValueAt(item.cantidadActual, cont, 3)
              cont = 1 + cont
            }
            ventanaRegistroVenta.tablaLibrosVenta.setModel(model)
            ventanaRegistroVenta.txtventaISBN.setEnabled(true)
            ventanaRegistroVenta.txtventaCantidad.setEnabled(true)
          }
        }
        if (!bandera) {
          JOptionPane.showMessageDialog(null, "No se encontró el proovedor con ese RUC")
        }
      }
    }

    if (e.getSource == ventanaRegistroVenta.btnVender) {
      val isbnPedir = ventanaRegistroVenta.txtventaISBN.getText
      val cantidadPedir = ventanaRegistroVenta.txtventaCantidad.getText
      val num = ctrlCom.venderLibro(isbnPedir, cantidadPedir.toInt, ventanaRegistroVenta.txtventaCedula.getText)
      if (num != -1) {
        dataTrans.recuperarArchivos()
        var aux = 0
        val model: DefaultTableModel = ventanaRegistroVenta.tablaVentasRealizadas.getModel.asInstanceOf[DefaultTableModel]
        val lista: mutable.Seq[transacciones] = ctrlTrans.listaTransaccionesClientes
        //Cargamos la tabla
        for (i: transacciones <- lista) {
          model.setValueAt(i.cedRuc, aux, 0)
          model.setValueAt(i.isbn, aux, 1)
          model.setValueAt(i.precioCV, aux, 2)
          model.setValueAt(i.ejemplares, aux, 3)
          model.setValueAt(i.fecha, aux, 4)
          aux = 1 + aux
        }
        ventanaRegistroVenta.tablaVentasRealizadas.setModel(model)
        valCaja.valorCaja()
        dataCaja.recuperarArchivos()
        val valor = valCaja.recorrerLista()
        ventanaRegistroVenta.txtCaja.setText(valor)

        data.recuperarArchivos("libros.dat")
        var cont = 0
        val modelo: DefaultTableModel = ventanaRegistroVenta.tablaLibrosVenta.getModel.asInstanceOf[DefaultTableModel]
        val listaLib: mutable.Seq[Libro] = ctrl.listaLibros
        //Cargamos la tabla
        for (item: Libro <- listaLib) {
          modelo.setValueAt(item.ISBN, cont, 0)
          modelo.setValueAt(item.titulo, cont, 1)
          modelo.setValueAt(item.precioVenta, cont, 2)
          modelo.setValueAt(item.cantidadActual, cont, 3)
          cont = 1 + cont
        }
        ventanaRegistroVenta.tablaLibrosVenta.setModel(modelo)
      }else{
        JOptionPane.showMessageDialog(null, "No hay suficientes libros en stock")
      }
    }

    if (e.getSource == ventanaRegistroVenta.btnLimpiar) {
      ventanaRegistroVenta.txtventaCedula.setText("")
      ventanaRegistroVenta.txtventaCedula.setEnabled(true)
      ventanaRegistroVenta.txtventaNombre.setText("")
      ventanaRegistroVenta.txtventaApellidos.setText("")
      ventanaRegistroVenta.txtventaDireccion.setText("")
      ventanaRegistroVenta.txtventaTelefono.setText("")
      ventanaRegistroVenta.txtventaISBN.setText("")
      ventanaRegistroVenta.txtventaCantidad.setText("")
      ventanaRegistroVenta.txtCaja.setText("")
      ventanaRegistroVenta.txtventaISBN.setEnabled(false)
      ventanaRegistroVenta.txtventaCantidad.setEnabled(false)
      ventanaRegistroVenta.btnVender.setEnabled(false)
      val model: DefaultTableModel = ventanaRegistroVenta.tablaLibrosVenta.getModel.asInstanceOf[DefaultTableModel]
      for {
        i <- 0 until model.getRowCount
        j <- 0 until model.getColumnCount
      } {
        model.setValueAt("", i, j)
      }
      val modelo: DefaultTableModel = ventanaRegistroVenta.tablaVentasRealizadas.getModel.asInstanceOf[DefaultTableModel]
      for {
        i <- 0 until modelo.getRowCount
        j <- 0 until modelo.getColumnCount
      } {
        modelo.setValueAt("", i, j)
      }
    }

    if(e.getSource == ventanaRegistroVenta.btnMasVendido){
      try{
        JOptionPane.showMessageDialog(null, "El libro más vendido es: " + ctrlCom.libroMasVendido())
      }catch {
        case ex: Exception => JOptionPane.showMessageDialog(null, "No hay ventas registradas")
      }
    }
  }
}

class facturacion extends ActionListener{
  val ventanaFacturacion = new controlador.facturacion
  ventanaFacturacion.btnRegistrarFactura.setEnabled(false)
  ventanaFacturacion.btnBuscar.addActionListener(this)
  ventanaFacturacion.btnLimpiar.addActionListener(this)
  ventanaFacturacion.btnRegistrarFactura.addActionListener(this)
  var list: mutable.ListBuffer[Factura] = mutable.ListBuffer()
  var listTrans: mutable.ListBuffer[transacciones] = mutable.ListBuffer()
  ventanaFacturacion.menuHistorialTransacciones.addMouseListener(new MouseAdapter {
  override def mouseClicked(e: MouseEvent): Unit = {
    val ventanaHistorial = new controlador.historialTransacciones
    val ctrlHist = new ctrlTransacciones
    val dataHist = new archivosTransacciones(ctrlHist)
    dataHist.recuperarArchivos()
    ventanaHistorial.setDefaultCloseOperation(1)
    ventanaHistorial.setLocationRelativeTo(ventanaHistorial)
    ventanaHistorial.setResizable(false)
    ventanaHistorial.setVisible(true)

    //llenar la tabla de transacciones
    val modelo: DefaultTableModel = ventanaHistorial.tablaHistTransacciones.getModel.asInstanceOf[DefaultTableModel]
    val listaLib: mutable.Seq[transacciones] = ctrlHist.listaTransacciones
    //Cargamos la tabla
    var cont = 0
    for (item: transacciones <- listaLib) {
      modelo.setValueAt(item.cedRuc, cont, 0)
      modelo.setValueAt(item.isbn, cont, 1)
      modelo.setValueAt(item.precioCV, cont, 2)
      modelo.setValueAt(item.ejemplares, cont, 3)
      modelo.setValueAt(item.fecha, cont, 4)
      modelo.setValueAt(item.tipo, cont, 5)
      cont = 1 + cont
    }
    ventanaHistorial.tablaHistTransacciones.setModel(modelo)

  }
  })

  ventanaFacturacion.menuHistorialFacturas.addMouseListener(new MouseAdapter {
    override def mouseClicked(e: MouseEvent): Unit = {
      val ventanaHistorial = new historialFacturas
      val ctrl = new ctrlFactura
      val data = new archivosFactura(ctrl)
      data.recuperarArchivos()
      ventanaHistorial.setDefaultCloseOperation(1)
      ventanaHistorial.setLocationRelativeTo(ventanaHistorial)
      ventanaHistorial.setResizable(false)
      ventanaHistorial.setVisible(true)

      //llenar la tabla de facturas
      val modelo: DefaultTableModel = ventanaHistorial.tablaHistFactura.getModel.asInstanceOf[DefaultTableModel]
      val listaLib: mutable.Seq[Factura] = ctrl.listaFactura
      //Cargamos la tabla
      var cont = 0
      for (item: Factura <- listaLib) {
        modelo.setValueAt(item.nroFactura, cont, 0)
        modelo.setValueAt(item.cedRuc, cont, 1)
        modelo.setValueAt(item.fecha, cont, 2)
        modelo.setValueAt(item.ejemplares, cont, 3)
        modelo.setValueAt(item.isbn, cont, 4)
        modelo.setValueAt(item.titulo, cont, 5)
        modelo.setValueAt(item.precioCV, cont, 6)
        modelo.setValueAt(item.preciototal, cont, 7)
        modelo.setValueAt(item.tipo, cont, 8)
        cont = 1 + cont
      }
      ventanaHistorial.tablaHistFactura.setModel(modelo)

    }
  })
  ventanaFacturacion.setDefaultCloseOperation(1)
  ventanaFacturacion.setLocationRelativeTo(ventanaFacturacion)
  ventanaFacturacion.setResizable(false)
  ventanaFacturacion.setVisible(true)
  override def actionPerformed(e: ActionEvent): Unit = {

    if(e.getSource == ventanaFacturacion.btnBuscar){
      var bandera = false
      val cedulaRUC = ventanaFacturacion.txtCedulaRuc.getText
      val ctrlCli = new ctrlCliente
      val dataCli = new archivosCliente(ctrlCli)
      val ctrlProv = new ctrlProovedor
      val dataProv = new archivosProovedor(ctrlProv)
      val ctrlTransProv = new ctrlTransaccionesProv
      val dataTransProv = new archivosTransaccionesProv(ctrlTransProv)
      val ctrlTransCli = new ctrlTransaccionesCli
      val dataTransCli = new archivosTransaccionesCli(ctrlTransCli)
      dataCli.recuperarArchivos("clientes.dat")
      dataProv.recuperarArchivos("proovedores.dat")
      dataTransProv.recuperarArchivos()
      dataTransCli.recuperarArchivos()
      var tem = false
      for(item <- ctrlTransCli.listaTransaccionesClientes){
        if(item.cedRuc == cedulaRUC){
          tem = true
          for (item <- ctrlCli.listaClientes) {
            if (item.cedula == cedulaRUC) {
              bandera = true
              ventanaFacturacion.txtCedulaRuc.setEnabled(false)
              ventanaFacturacion.txtNombres.setText(item.nombre)
              ventanaFacturacion.txtApellidos.setText(item.apellido)
              ventanaFacturacion.txtDireccion.setText(item.direccion)
              ventanaFacturacion.txtTelefono.setText(item.telefono)
              ventanaFacturacion.txtTipo.setText("Venta")
              ventanaFacturacion.btnRegistrarFactura.setEnabled(true)
            }
          }
        }
      }
      for(i <- ctrlTransProv.listaTransaccionesProovedores){
        if(i.cedRuc == cedulaRUC){
          tem = true
          for (item <- ctrlProv.listaProovedor) {
            if (item.ruc == cedulaRUC) {
              bandera = true
              ventanaFacturacion.txtCedulaRuc.setEnabled(false)
              ventanaFacturacion.txtNombres.setText(item.nombre)
              ventanaFacturacion.txtApellidos.setText(item.apellido)
              ventanaFacturacion.txtDireccion.setText(item.direccion)
              ventanaFacturacion.txtTelefono.setText(item.telefono)
              ventanaFacturacion.txtTipo.setText("Compra")
              ventanaFacturacion.btnRegistrarFactura.setEnabled(true)
            }
          }
        }
      }
      if(!tem){
        JOptionPane.showMessageDialog(null, "No se encontró transacciones pendientes de la persona ingresada")
      }
      if(bandera) {
        val diaActual = java.time.LocalDate.now.toString
        var aux = false
        ventanaFacturacion.txtFecha.setText(diaActual)
        //generar numero aleatorio sin repetir
        var num = math.random()
        //generar numero aleatorio
        var numFactura = (Random.nextDouble() * 1000000).toInt
        val ctrlFact = new ctrlFactura
        val data = new archivosFactura(ctrlFact)
        data.recuperarArchivos()
        for (item <- ctrlFact.listaFactura) {
          if(item.nroFactura.equals(numFactura)){
            aux = true
          }
        }

        if(!aux){
            val cedRuc = ventanaFacturacion.txtCedulaRuc.getText
            val tipo = ventanaFacturacion.txtTipo.getText
            val fecha = ventanaFacturacion.txtFecha.getText
            ventanaFacturacion.txtNumFactura.setText(numFactura.toString)
            list.clear()
            list = ctrlFact.generarFactura(numFactura, cedRuc, tipo, fecha)
            if (list.nonEmpty) {
              val modelo: DefaultTableModel = ventanaFacturacion.tablaTransaccionesPendientes.getModel.asInstanceOf[DefaultTableModel]
              //Cargamos la tabla
              var cont = 0
              var listPrecio: collection.mutable.ListBuffer[Float] = collection.mutable.ListBuffer()
              for (item: Factura <- list) {
                modelo.setValueAt(item.ejemplares, cont, 0)
                modelo.setValueAt(item.isbn, cont, 1)
                modelo.setValueAt(item.titulo, cont, 2)
                modelo.setValueAt(item.precioCV, cont, 3)
                modelo.setValueAt(item.preciototal, cont, 4)
                cont = 1 + cont
                listPrecio += item.preciototal
              }
              ventanaFacturacion.tablaTransaccionesPendientes.setModel(modelo)
              //suma los valores de la lista
              ventanaFacturacion.txtTotal.setText(listPrecio.sum.toString)
              ventanaFacturacion.btnRegistrarFactura.setEnabled(true)
            } else {
              JOptionPane.showMessageDialog(null, "No hay transacciones pendientes")
            }
          }
        }
      }


    if(e.getSource == ventanaFacturacion.btnLimpiar){
      ventanaFacturacion.txtCedulaRuc.setText("")
      ventanaFacturacion.txtNombres.setText("")
      ventanaFacturacion.txtApellidos.setText("")
      ventanaFacturacion.txtDireccion.setText("")
      ventanaFacturacion.txtTelefono.setText("")
      ventanaFacturacion.txtTipo.setText("")
      ventanaFacturacion.txtFecha.setText("")
      ventanaFacturacion.txtNumFactura.setText("")
      ventanaFacturacion.txtTotal.setText("")
      ventanaFacturacion.txtCedulaRuc.setEnabled(true)
      ventanaFacturacion.btnRegistrarFactura.setEnabled(false)
      val modelo: DefaultTableModel = ventanaFacturacion.tablaTransaccionesPendientes.getModel.asInstanceOf[DefaultTableModel]
      for {
        i <- 0 until modelo.getRowCount
        j <- 0 until modelo.getColumnCount
      } {
        modelo.setValueAt("", i, j)
      }
    }

    if(e.getSource == ventanaFacturacion.btnRegistrarFactura) {
      try {
        val ctrlFact = new ctrlFactura
        val data = new archivosFactura(ctrlFact)
        data.recuperarArchivos()
        if (ctrlFact.listaFactura.nonEmpty) {
          for (item <- list) {
            ctrlFact.listaFactura += item
            data.guardarArchivo()
          }
        } else {
          ctrlFact.listaFactura = list
          data.guardarArchivo()
        }

        val ctrlTransProv = new ctrlTransaccionesProv
        val dataTransProv = new archivosTransaccionesProv(ctrlTransProv)
        val ctrlTransCli = new ctrlTransaccionesCli
        val dataTransCli = new archivosTransaccionesCli(ctrlTransCli)
        val ctrlCompra = new modelo.compra
        val ctrlVenta = new modelo.venta
        dataTransProv.recuperarArchivos()
        dataTransCli.recuperarArchivos()
        val tipo = ventanaFacturacion.txtTipo.getText
        for (item: Factura <- list) {
          if (tipo.equals("Compra")) {
            if (item.cedRuc == ventanaFacturacion.txtCedulaRuc.getText) {
              val indice =ctrlCompra.indiceTrans(item.isbn, item.cedRuc, item.fecha)
              ctrlTransProv.listaTransaccionesProovedores.remove(indice)
              dataTransProv.guardarArchivo()
            }
          } else {
            if (item.cedRuc == ventanaFacturacion.txtCedulaRuc.getText) {
              val indice =ctrlVenta.indiceCli( item.isbn,item.cedRuc, item.fecha)
              ctrlTransCli.listaTransaccionesClientes.remove(indice)
              dataTransCli.guardarArchivo()
            }
          }
        }
        list.clear()
        JOptionPane.showMessageDialog(null, "Factura registrada")
      } catch {
        case ex: Exception =>
          JOptionPane.showMessageDialog(null, "La factura ya se registro anteriormente")
      }
    }
  }
}