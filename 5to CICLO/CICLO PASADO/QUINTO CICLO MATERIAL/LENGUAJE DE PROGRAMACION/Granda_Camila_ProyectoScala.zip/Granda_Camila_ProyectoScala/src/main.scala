import vista.appLibros

object main {
  def main(args: Array[String]): Unit = {
    var ctrl = new appLibros
  }
}
