package modelo

import java.io.{FileInputStream, FileNotFoundException, FileOutputStream, ObjectInputStream, ObjectOutputStream}
import scala.collection.mutable

class transacciones(var cedRuc: String, var isbn: String, var precioCV: Float, var ejemplares: Int, var fecha: String, var tipo:String) extends Serializable {
}

class ctrlTransaccionesProv extends Serializable{
  var listaTransaccionesProovedores = new mutable.ListBuffer[transacciones]

  def reemplazar(listanueva: mutable.ListBuffer[transacciones]): Unit = {
    listaTransaccionesProovedores.clear()
    listaTransaccionesProovedores ++= listanueva
  }
}

class ctrlTransaccionesCli extends Serializable{
  var listaTransaccionesClientes = new mutable.ListBuffer[transacciones]

  def reemplazar(listanueva: mutable.ListBuffer[transacciones]): Unit = {
    listaTransaccionesClientes.clear()
    listaTransaccionesClientes ++= listanueva
  }
}

class ctrlTransacciones extends Serializable{
  var listaTransacciones = new mutable.ListBuffer[transacciones]

  def reemplazar(listanueva: mutable.ListBuffer[transacciones]): Unit = {
    listaTransacciones.clear()
    listaTransacciones ++= listanueva
  }
}

class caja extends Serializable {
  var listaCaja = new mutable.ListBuffer[String]
  var archi = new archivosCaja(this)
  var archiCompra = new archivosCompra(new compra)
  var archiVenta = new archivosVenta(new venta)
  var compra = new compra
  var venta = new venta


  def recorrerLista(): String = {
    var elemento = ""
    archi.recuperarArchivos()
    for (i <- listaCaja) {
        elemento = i
    }
    return elemento
  }

  def valorCaja(): Unit ={
    archi.recuperarArchivos()
    archiVenta.recuperarArchivos()
    archiCompra.recuperarArchivos()
    if(compra.listaCompra.isEmpty & venta.listaVenta.isEmpty & listaCaja.isEmpty){
      listaCaja+="1000000.0"
      archi.guardarArchivo()
    }
  }

  def reemplazarCaja(listanueva: mutable.ListBuffer[String]): Unit = {
    listaCaja.clear()
    listaCaja ++= listanueva
  }
}


class compra extends Serializable{
  var listaCompra = new mutable.ListBuffer[Libro]
  var archi = new archivosCompra(this)
  var libro = new Libro("","",0F,0F,0,"")
  var transaccion = new transacciones("","",0F,0,"","")
  var transaccionAux = new transacciones("","",0F,0,"","")

  def reemplazarCompra(listanueva: mutable.ListBuffer[Libro]): Unit = {
    listaCompra.clear()
    listaCompra ++= listanueva
  }

  def librosComprados(): Int ={
    archi.recuperarArchivos()
    var cont = 0
    for(i <- listaCompra){

      cont = cont +1
    }
    cont
  }

  def indice(isbn : String): Int ={
    val ctrl = new ctrlLibros
    val dataLibro = new archivos(ctrl)

    dataLibro.recuperarArchivos("libros.dat")
    var cont =0
    for(i <- ctrl.listaLibros){
      if(i.ISBN == isbn){
        return cont
      }
      cont = cont +1
    }
    cont
  }
  //metodo para obtener el indice de un listBuffer
  def indiceTrans(isbn : String, cedRuc: String, fecha:String): Int ={
    val transacciones = new ctrlTransaccionesProv
    val dataTrans = new archivosTransaccionesProv(transacciones)
    dataTrans.recuperarArchivos()
    var cont =0
    for(i <- transacciones.listaTransaccionesProovedores){
      if(i.isbn == isbn  & i.cedRuc == cedRuc & i.fecha == fecha){
        return cont
      }
      cont = cont +1
    }
    cont
  }
  def compraLibro(isbn: String, numero: Int, dameRUC: String): Int ={
    val ctrl = new ctrlLibros
    val dataLibro = new archivos(ctrl)
    dataLibro.recuperarArchivos("libros.dat")
    val transacciones = new ctrlTransaccionesProv
    val dataTrans = new archivosTransaccionesProv(transacciones)
    val historial = new ctrlTransacciones
    val dataTransHist = new archivosTransacciones(historial)
    val caja = new caja
    val dataCaja = new archivosCaja(caja)
    var ejemplarAdd = 0
    var num = 0
    var verif = false
    val diaActual = java.time.LocalDate.now.toString
    dataLibro.recuperarArchivos("libros.dat")
    for(item <- ctrl.listaLibros){
      if(item.ISBN.equals(isbn)) {
        verif = true
        archi.recuperarArchivos()
        dataTransHist.recuperarArchivos()
        dataTrans.recuperarArchivos()
        dataCaja.recuperarArchivos()
        libro = new Libro(item.ISBN, item.titulo, item.precioCompra, item.precioVenta, item.cantidadActual - (item.cantidadActual - numero), item.imagen)
        transaccion = new transacciones(dameRUC, item.ISBN, item.precioCompra, item.cantidadActual - (item.cantidadActual - numero), diaActual, "Compra")
        ejemplarAdd = item.cantidadActual + numero
        if (librosComprados() != 0) {
          archi.recuperarArchivos()
          if (listaCompra.nonEmpty) {
            caja.listaCaja(0) = (caja.recorrerLista().toFloat - item.precioVenta * numero).toString
            dataCaja.guardarArchivo()
            if (!listaCompra.exists(_.ISBN == isbn)) {
              listaCompra += libro
              archi.guardarArchivo()
            } else {
              for (i <- listaCompra) {
                if (i.ISBN == isbn) {
                  listaCompra(librosComprados() - 1) = new Libro(i.ISBN, i.titulo, i.precioCompra, i.precioVenta, i.cantidadActual + numero, i.imagen)
                  archi.guardarArchivo()
                }
              }
            }
            var aux = false
            for (ite <- transacciones.listaTransaccionesProovedores) {
              if (isbn == ite.isbn & diaActual == ite.fecha & dameRUC == ite.cedRuc) {
                aux = true
                transaccionAux = new transacciones(dameRUC, ite.isbn, ite.precioCV, ite.ejemplares + numero, ite.fecha, "Compra")
                transacciones.listaTransaccionesProovedores(indiceTrans(isbn, dameRUC, diaActual)) = transaccionAux
                dataTrans.guardarArchivo()
              }
            }

            var tempo = false
            for (it <- historial.listaTransacciones) {
              if (isbn == it.isbn & diaActual == it.fecha & dameRUC == it.cedRuc) {
                tempo = true
                transaccionAux = new transacciones(dameRUC, it.isbn, it.precioCV, it.ejemplares + numero, it.fecha, "Compra")
                historial.listaTransacciones(indiceTrans(isbn, dameRUC, diaActual)) = transaccionAux
                dataTransHist.guardarArchivo()
              }
            }

            if(!aux){
              transacciones.listaTransaccionesProovedores += transaccion
              dataTrans.guardarArchivo()
            }
            if (!tempo) {
              historial.listaTransacciones += transaccion
              dataTransHist.guardarArchivo()
            }
            val libroMod = new Libro(isbn, item.titulo, item.precioCompra, item.precioVenta, ejemplarAdd, item.imagen)
            ctrl.listaLibros(indice(isbn)) = libroMod
            dataLibro.guardarArchivo("libros.dat")
          }
          else {
            if ((caja.recorrerLista().toFloat - item.precioCompra) > -1) {
              caja.listaCaja(0) = (caja.recorrerLista().toFloat - item.precioCompra * numero).toString
              dataCaja.guardarArchivo()
              archi.recuperarArchivos()
              dataTrans.recuperarArchivos()
              dataTransHist.recuperarArchivos()
              libro = new Libro(item.ISBN, item.titulo, item.precioCompra, item.precioVenta, item.cantidadActual + numero, item.imagen)
              listaCompra(librosComprados()-1) = libro
              archi.guardarArchivo()
              var aux = false
              for (ite <- transacciones.listaTransaccionesProovedores) {
                if (isbn == ite.isbn & diaActual == ite.fecha & dameRUC == ite.cedRuc) {
                  aux = true
                  transaccionAux = new transacciones(dameRUC, ite.isbn, ite.precioCV, ite.ejemplares + numero, ite.fecha, "Compra")
                  transacciones.listaTransaccionesProovedores(indiceTrans(isbn,dameRUC,diaActual)) = transaccionAux
                  dataTrans.guardarArchivo()
                }
              }

              var tempo = false
              for (it <- historial.listaTransacciones) {
                if (isbn == it.isbn & diaActual == it.fecha & dameRUC == it.cedRuc) {
                  tempo = true
                  transaccionAux = new transacciones(dameRUC, it.isbn, it.precioCV, it.ejemplares + numero, it.fecha, "Compra")
                  historial.listaTransacciones(indiceTrans(isbn, dameRUC, diaActual)) = transaccionAux
                  dataTransHist.guardarArchivo()
                }
              }

              if (!aux) {
                transacciones.listaTransaccionesProovedores += transaccion
                dataTrans.guardarArchivo()
              }

              if (!tempo) {
                historial.listaTransacciones += transaccion
                archi.guardarArchivo()
                dataTransHist.guardarArchivo()
              }
              val libroMod = new Libro(isbn, item.titulo, item.precioCompra, item.precioVenta, ejemplarAdd, item.imagen)
              ctrl.listaLibros(indice(isbn)) = libroMod
              dataLibro.guardarArchivo("libros.dat")
            }
          }
        } else {
          caja.listaCaja(0) = (caja.recorrerLista().toFloat - item.precioCompra * numero).toString
          dataCaja.guardarArchivo()
          listaCompra += libro
          transacciones.listaTransaccionesProovedores += transaccion
          historial.listaTransacciones += transaccion
          archi.guardarArchivo()
          dataTrans.guardarArchivo()
          dataTransHist.guardarArchivo()
          val libroMod = new Libro(isbn, item.titulo, item.precioCompra, item.precioVenta, ejemplarAdd, item.imagen)
          ctrl.listaLibros(indice(isbn)) = libroMod
          dataLibro.guardarArchivo("libros.dat")
        }
        num = 1
      }
    }
    if(!verif){
      num = -1
    }
    num
  }
}

class venta extends Serializable{

  var listaCantidad = new mutable.ListBuffer[Int]
  var listaNombre = new mutable.ListBuffer[String]
  var listaVenta = new mutable.ListBuffer[Libro]
  var archi = new archivosVenta(this)
  var libro = new Libro("", "", 0F, 0F, 0, "")
  var transaccion = new transacciones("", "", 0F, 0, "", "")
  var transaccionAux = new transacciones("", "", 0F, 0, "", "")

  def reemplazarVenta(listanueva: mutable.ListBuffer[Libro]): Unit = {
    listaVenta.clear()
    listaVenta ++= listanueva
  }

  //contar cuantos libros existen en la lista de venta
  def librosVendidos(): Int = {
    archi.recuperarArchivos()
    var cont = 0
    for (i <- listaVenta) {
      cont = cont + 1
    }
    cont
  }

  //metodo para obtener el indice de un listBuffer
  def indiceCli(isbn: String, cedRuc: String, fecha: String): Int = {
    val transacciones = new ctrlTransaccionesCli
    val dataCli = new archivosTransaccionesCli(transacciones)
    dataCli.recuperarArchivos()
    var cont = 0
    for (i <- transacciones.listaTransaccionesClientes) {
      if (i.isbn == isbn & i.cedRuc == cedRuc & i.fecha == fecha) {
        return cont
      }
      cont = cont + 1
    }
    cont
  }

  //metodo para obtener el indice de un listBuffer
  def indiceTrans(isbn: String, cedRuc: String, fecha: String): Int = {
    val transacciones = new ctrlTransacciones
    val data = new archivosTransacciones(transacciones)
    data.recuperarArchivos()
    var cont = 0
    for (i <- transacciones.listaTransacciones) {
      if (i.isbn == isbn & i.cedRuc == cedRuc & i.fecha == fecha) {
        return cont
      }
      cont = cont + 1
    }
    cont
  }

  //metodo para buscar el libro mas vendido
  def libroMasVendido(): String = {
    archi.recuperarArchivos()
    listaCantidad.clear()
    listaNombre.clear()
    for (i: Libro <- listaVenta) {

      listaCantidad += (i.cantidadActual)
      listaNombre += (i.titulo)
    }
    val mayor = listaCantidad.max
    val indice = listaCantidad.indexOf(mayor)
    listaNombre(indice)
  }
  def venderLibro(isbn: String, numero: Int, dameRUC: String): Int = {
    val ctrl = new ctrlLibros
    val dataLibro = new archivos(ctrl)
    dataLibro.recuperarArchivos("libros.dat")
    var compra = new compra
    val transacciones = new ctrlTransaccionesCli
    val dataCli = new archivosTransaccionesCli(transacciones)
    val historial = new ctrlTransacciones
    val dataTransHist = new archivosTransacciones(historial)
    val caja = new caja
    val dataCaja = new archivosCaja(caja)
    var ejemplarEli = 0
    var num = 0
    var verif = false
    val diaActual = java.time.LocalDate.now.toString
    dataLibro.recuperarArchivos("libros.dat")
    for (item <- ctrl.listaLibros) {
      if ((item.cantidadActual-(item.cantidadActual-numero)) <= item.cantidadActual){
        if(numero!=0){
          if (item.ISBN.equals(isbn)) {
            verif = true
            archi.recuperarArchivos()
            dataTransHist.recuperarArchivos()
            dataCli.recuperarArchivos()
            dataCaja.recuperarArchivos()
            libro = new Libro(item.ISBN, item.titulo, item.precioCompra, item.precioVenta, item.cantidadActual - (item.cantidadActual - numero), item.imagen)
            transaccion = new transacciones(dameRUC, item.ISBN, item.precioVenta, item.cantidadActual - (item.cantidadActual - numero), diaActual, "Venta")
            ejemplarEli = item.cantidadActual - numero
            if (librosVendidos() != 0) {
              archi.recuperarArchivos()
              if (listaVenta.nonEmpty) {
                caja.listaCaja(0) = (caja.recorrerLista().toFloat + item.precioVenta * numero).toString
                dataCaja.guardarArchivo()
                if (!listaVenta.exists(_.ISBN == isbn)) {
                  listaVenta += libro
                  archi.guardarArchivo()
                } else {
                  for (i <- listaVenta) {
                    if (i.ISBN == isbn) {
                      listaVenta(librosVendidos() - 1) = new Libro(i.ISBN, i.titulo, i.precioCompra, i.precioVenta, i.cantidadActual + numero, i.imagen)
                      archi.guardarArchivo()
                    }
                  }
                }
                var aux = false
                for (ite <- transacciones.listaTransaccionesClientes) {
                  if (isbn == ite.isbn & diaActual == ite.fecha & dameRUC == ite.cedRuc) {
                    aux = true
                    transaccionAux = new transacciones(dameRUC, ite.isbn, ite.precioCV, ite.ejemplares + numero, ite.fecha, "Venta")
                    transacciones.listaTransaccionesClientes(indiceCli(isbn, dameRUC, diaActual)) = transaccionAux
                    dataCli.guardarArchivo()
                  }
                }
                var tempo = false
                for (it <- historial.listaTransacciones) {
                  if (isbn == it.isbn & diaActual == it.fecha & dameRUC == it.cedRuc) {
                    tempo = true
                    transaccionAux = new transacciones(dameRUC, it.isbn, it.precioCV, it.ejemplares + numero, it.fecha, "Venta")
                    historial.listaTransacciones(indiceTrans(isbn, dameRUC, diaActual)) = transaccionAux
                    dataTransHist.guardarArchivo()
                  }
                }
                if (!aux) {
                  transacciones.listaTransaccionesClientes += transaccion
                  dataCli.guardarArchivo()
                }

                if (!tempo) {
                  historial.listaTransacciones += transaccion
                  dataTransHist.guardarArchivo()
                }
                val libroMod = new Libro(isbn, item.titulo, item.precioCompra, item.precioVenta, ejemplarEli, item.imagen)
                ctrl.listaLibros(compra.indice(isbn)) = libroMod
                dataLibro.guardarArchivo("libros.dat")

              }
              else {
                caja.listaCaja(0) = (caja.recorrerLista().toFloat + item.precioVenta * numero).toString
                dataCaja.guardarArchivo()
                archi.recuperarArchivos()
                dataCli.recuperarArchivos()
                dataTransHist.recuperarArchivos()
                for (i <- listaVenta) {
                  if (i.ISBN == isbn) {
                    libro = new Libro(i.ISBN, i.titulo, i.precioCompra, i.precioVenta, i.cantidadActual + numero, i.imagen)
                    listaVenta(librosVendidos() - 1) = libro
                    archi.guardarArchivo()
                  }
                }

                var aux = false
                for (ite <- transacciones.listaTransaccionesClientes) {
                  if (isbn == ite.isbn & diaActual == ite.fecha & dameRUC == ite.cedRuc) {
                    aux = true
                    transaccionAux = new transacciones(dameRUC, ite.isbn, ite.precioCV, ite.ejemplares + numero, ite.fecha, "Venta")
                    transacciones.listaTransaccionesClientes(indiceCli(isbn, dameRUC, diaActual)) = transaccionAux
                    dataCli.guardarArchivo()
                  }
                }
                var tempo = false
                for (it <- historial.listaTransacciones) {
                  if (isbn == it.isbn & diaActual == it.fecha & dameRUC == it.cedRuc) {
                    tempo = true
                    transaccionAux = new transacciones(dameRUC, it.isbn, it.precioCV, it.ejemplares + numero, it.fecha, "Venta")
                    historial.listaTransacciones(indiceTrans(isbn, dameRUC, diaActual)) = transaccionAux
                    dataTransHist.guardarArchivo()
                  }
                }

                if (!aux) {
                  transacciones.listaTransaccionesClientes += transaccion
                  dataCli.guardarArchivo()
                }

                if (!tempo) {
                  historial.listaTransacciones += transaccion
                  archi.guardarArchivo()
                  dataTransHist.guardarArchivo()
                }
                val libroMod = new Libro(isbn, item.titulo, item.precioCompra, item.precioVenta, ejemplarEli, item.imagen)
                ctrl.listaLibros(compra.indice(isbn)) = libroMod
                dataLibro.guardarArchivo("libros.dat")
              }
            } else {
              caja.listaCaja(0) = (caja.recorrerLista().toFloat + item.precioVenta * numero).toString
              dataCaja.guardarArchivo()
              listaVenta += libro
              transacciones.listaTransaccionesClientes += transaccion
              historial.listaTransacciones += transaccion
              archi.guardarArchivo()
              dataCli.guardarArchivo()
              dataTransHist.guardarArchivo()
              val libroMod = new Libro(isbn, item.titulo, item.precioCompra, item.precioVenta, ejemplarEli, item.imagen)
              ctrl.listaLibros(compra.indice(isbn)) = libroMod
              dataLibro.guardarArchivo("libros.dat")
            }
            num = 1
          }
        }

      }else{
        num = -1
      }

    }
    if (!verif) {
      num = -1
    }
    num
  }
}

class archivosCaja(var manejo:caja)extends Serializable{
  def guardarArchivo(): Unit ={
    val output = new ObjectOutputStream(new FileOutputStream("caja.dat"))
    output.writeObject(manejo)
    output.close()
  }

  def recuperarArchivos(): Boolean ={
    try {
      val input = new ObjectInputStream(new FileInputStream("caja.dat"))
      val data = input.readObject.asInstanceOf[caja]
      input.close()
      manejo.reemplazarCaja(data.listaCaja)
      true
    }catch{
      case a: FileNotFoundException => false
    }
  }
}

class archivosCompra(var manejo:compra)extends Serializable{
  def guardarArchivo(): Unit ={
    val output = new ObjectOutputStream(new FileOutputStream("librosComprados.dat"))
    output.writeObject(manejo)
    output.close()
  }

  def recuperarArchivos(): Boolean ={
    try {
      val input = new ObjectInputStream(new FileInputStream("librosComprados.dat"))
      val data = input.readObject.asInstanceOf[compra]
      input.close()
      manejo.reemplazarCompra(data.listaCompra)
      true
    }catch{
      case a: FileNotFoundException => false
    }
  }
}

class archivosVenta(var manejo:venta)extends Serializable{
  def guardarArchivo(): Unit ={
    val output = new ObjectOutputStream(new FileOutputStream("librosVendidos.dat"))
    output.writeObject(manejo)
    output.close()
  }

  def recuperarArchivos(): Boolean ={
    try {
      val input = new ObjectInputStream(new FileInputStream("librosVendidos.dat"))
      val data = input.readObject.asInstanceOf[venta]
      input.close()
      manejo.reemplazarVenta(data.listaVenta)
      true
    }catch{
      case a: FileNotFoundException => false
    }
  }
}

class archivosTransaccionesProv(var manejo:ctrlTransaccionesProv)extends Serializable{
  def guardarArchivo(): Unit ={
    val output = new ObjectOutputStream(new FileOutputStream("transaccionesProovedores.dat"))
    output.writeObject(manejo)
    output.close()
  }

  def recuperarArchivos(): Boolean ={
    try {
      val input = new ObjectInputStream(new FileInputStream("transaccionesProovedores.dat"))
      val data = input.readObject.asInstanceOf[ctrlTransaccionesProv]
      input.close()
      manejo.reemplazar(data.listaTransaccionesProovedores)
      true
    }catch{
      case a: FileNotFoundException => false
    }
  }
}

class archivosTransaccionesCli(var manejo:ctrlTransaccionesCli)extends Serializable{
  def guardarArchivo(): Unit ={
    val output = new ObjectOutputStream(new FileOutputStream("transaccionesClientes.dat"))
    output.writeObject(manejo)
    output.close()
  }

  def recuperarArchivos(): Boolean ={
    try {
      val input = new ObjectInputStream(new FileInputStream("transaccionesClientes.dat"))
      val data = input.readObject.asInstanceOf[ctrlTransaccionesCli]
      input.close()
      manejo.reemplazar(data.listaTransaccionesClientes)
      true
    }catch{
      case a: FileNotFoundException => false
    }
  }
}

class archivosTransacciones(var manejo:ctrlTransacciones)extends Serializable{
  def guardarArchivo(): Unit ={
    val output = new ObjectOutputStream(new FileOutputStream("HistorialTransacciones.dat"))
    output.writeObject(manejo)
    output.close()
  }

  def recuperarArchivos(): Boolean ={
    try {
      val input = new ObjectInputStream(new FileInputStream("HistorialTransacciones.dat"))
      val data = input.readObject.asInstanceOf[ctrlTransacciones]
      input.close()
      manejo.reemplazar(data.listaTransacciones)
      true
    }catch{
      case a: FileNotFoundException => false
    }
  }
}