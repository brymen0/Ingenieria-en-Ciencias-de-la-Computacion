package modelo

import java.io.{FileInputStream, FileNotFoundException, FileOutputStream, ObjectInputStream, ObjectOutputStream}
import scala.collection.mutable

class Factura (var nroFactura: Int, var cedRuc: String, var fecha: String, var ejemplares: Int, var isbn: String,var titulo: String, var precioCV: Float, var preciototal: Float, var tipo:String) extends Serializable{
  def equals(obj: Factura): Boolean = {
    if (this.nroFactura == obj.nroFactura) {
      true
    } else {
      false
    }
  }
}

class ctrlFactura extends Serializable{
  var listaFactura =new mutable.ListBuffer[Factura]()
  var archi = new archivosFactura(this)

  def generarFactura(numFactura: Int, cedRuc: String, tipo: String, fecha: String): mutable.ListBuffer[Factura] ={
    val crtllibros = new ctrlLibros
    val dataLibro = new archivos(crtllibros)
    val ctrlTransProv = new ctrlTransaccionesProv
    val dataTransProv = new archivosTransaccionesProv(ctrlTransProv)
    val ctrlTransCli = new ctrlTransaccionesCli
    val dataTransCli = new archivosTransaccionesCli(ctrlTransCli)
    dataLibro.recuperarArchivos("libros.dat")
    dataTransProv.recuperarArchivos()
    dataTransCli.recuperarArchivos()
    listaFactura.clear()
    var titulo = ""
    var precioT =0F
    if (tipo == "Compra") {
      //proovedores
      for (item: transacciones <- ctrlTransProv.listaTransaccionesProovedores) {
        for (i: Libro <- crtllibros.listaLibros) {
          if (item.isbn == i.ISBN) {
            titulo = i.titulo
          }
        }
        precioT = item.precioCV * item.ejemplares
        val fact = new Factura(numFactura, cedRuc, fecha, item.ejemplares, item.isbn, titulo, item.precioCV, precioT, "Compra")
        listaFactura += fact
      }

      if (ctrlTransProv.listaTransaccionesProovedores.nonEmpty) {
        listaFactura
      }
      else {
        null
      }
    }
    else if(tipo == "Venta"){
      //clientes
      for (item: transacciones <- ctrlTransCli.listaTransaccionesClientes) {
        for (i: Libro <- crtllibros.listaLibros) {
          if (item.isbn == i.ISBN) {
            titulo = i.titulo
          }
        }
        precioT = item.precioCV * item.ejemplares
        val fact = new Factura(numFactura, cedRuc, fecha, item.ejemplares, item.isbn, titulo, item.precioCV, precioT, "Venta")
        listaFactura += fact
      }
      if (ctrlTransCli.listaTransaccionesClientes.nonEmpty) {
        listaFactura
      }
      else {
       null
      }
    }
    else{
      null
    }
  }

  def reemplazar(listanueva: mutable.ListBuffer[Factura]): Unit = {
    listaFactura.clear()
    listaFactura ++= listanueva
  }
}

class archivosFactura(var manejo:ctrlFactura)extends Serializable{
  def guardarArchivo(): Unit ={
    val output = new ObjectOutputStream(new FileOutputStream("facturas.dat"))
    output.writeObject(manejo)
    output.close()
  }

  def recuperarArchivos(): Boolean ={
    try {
      val input = new ObjectInputStream(new FileInputStream("facturas.dat"))
      val data = input.readObject.asInstanceOf[ctrlFactura]
      input.close()
      manejo.reemplazar(data.listaFactura)
      true
    }catch{
      case a: FileNotFoundException => false
    }
  }
}
