package modelo

import java.io.{FileInputStream, FileNotFoundException, FileOutputStream, ObjectInputStream, ObjectOutputStream}
import scala.collection.mutable
class Libro(var ISBN: String,var titulo: String,var precioCompra: Float,var precioVenta: Float,var cantidadActual: Int,var imagen: String) extends Serializable {

  def equals(obj: Libro): Boolean = {
    if (this.ISBN == obj.ISBN) {
      true
    } else {
      false
    }
  }
}

class ctrlLibros extends Serializable {

  var listaPrecio = new mutable.ListBuffer[Float]
  var listaNombre =new mutable.ListBuffer[String]
  var listaLibros =new mutable.ListBuffer[Libro]()
  var archi = new archivos(this)

  def ingresarLibros(lib: Libro): Unit={
    archi.recuperarArchivos("libros.dat")
    listaLibros+=(lib)
    archi.guardarArchivo("libros.dat")
  }

  def eliminar(indice: Int): Boolean ={
    try{
      listaLibros.remove(indice)
      archi.guardarArchivo("libros.dat")
      true
    }catch {
      case a: Exception => false
    }
  }

  def reemplazar(listanueva: mutable.ListBuffer[Libro]): Unit = {
    listaLibros.clear()
    listaLibros++=listanueva
  }
  //VALIDACION DEL ISBN
  def isbn13(isbn: String): Boolean ={
    import java.util.regex.Pattern
    val regex = "^(?:ISBN(?:-13)?:? )?(?=[0-9]{13}$|(?=(?:[0-9]+[- ]){4})[- 0-9]{17}$)97[89][- ]?[0-9]{1,5}[- ]?[0-9]+[- ]?[0-9]+[- ]?[0-9]$"
    val pattern = Pattern.compile(regex)
    val matcher = pattern.matcher(isbn)
    matcher.matches
  }

  def costoso(): String ={
    archi.recuperarArchivos("libros.dat")
    listaPrecio.clear()
    listaNombre.clear()
    for(i: Libro<-listaLibros){
      listaPrecio+=(i.precioVenta)
      listaNombre+=(i.titulo)
    }
    var mayor = listaPrecio.max
    var indice = listaPrecio.indexOf(mayor)
    listaNombre(indice)
  }

  def barato():String={
    archi.recuperarArchivos("libros.dat")
    listaPrecio.clear()
    listaNombre.clear()
    for(i: Libro<-listaLibros){
      listaPrecio+=(i.precioVenta)
      listaNombre+=(i.titulo)
    }
    var menor = listaPrecio.min
    var indice = listaPrecio.indexOf(menor)
    listaNombre(indice)
  }
}

class archivos(var manejo:ctrlLibros)extends Serializable{
  def guardarArchivo(nombre: String): Unit ={
    val output = new ObjectOutputStream(new FileOutputStream(nombre))
    output.writeObject(manejo)
    output.close()
  }

  def recuperarArchivos(nombre: String): Boolean ={
    try {
      val input = new ObjectInputStream(new FileInputStream(nombre))
      val data = input.readObject.asInstanceOf[ctrlLibros]
      input.close()
      manejo.reemplazar(data.listaLibros)
      true
    }catch{
      case a: FileNotFoundException => false
    }
  }
}
