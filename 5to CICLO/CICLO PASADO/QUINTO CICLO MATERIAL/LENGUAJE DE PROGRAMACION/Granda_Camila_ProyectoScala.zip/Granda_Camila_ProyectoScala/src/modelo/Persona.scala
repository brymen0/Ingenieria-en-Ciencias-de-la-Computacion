package modelo

import java.io.{FileInputStream, FileNotFoundException, FileOutputStream, ObjectInputStream, ObjectOutputStream}
import scala.collection.mutable

class Persona(var nombre: String, var apellido: String, var telefono: String, var direccion: String) extends Serializable {
}
//generar herencia de la clase Persona llamado Proovedor y serializable
class Proovedor(var ruc: String,nombre: String, apellido: String, telefono: String, direccion: String) extends Persona(nombre, apellido, telefono, direccion) with Serializable {
  def equals(obj: Proovedor): Boolean = {
    if (this.ruc == obj.ruc) {
      true
    } else {
      false
    }
  }
}
//generar herencia de la clase Persona llamado Cliente
class Cliente(var cedula: String,nombre: String, apellido: String, telefono: String, direccion: String) extends Persona(nombre, apellido, telefono, direccion) with Serializable {
  def equals(obj: Cliente): Boolean = {
    if (this.cedula == obj.cedula) {
      true
    } else {
      false
    }
  }
}

class ctrlProovedor extends Serializable{
  var listaProovedor =new mutable.ListBuffer[Proovedor]()
  var archi = new archivosProovedor(this)

  def ingresarProovedor(pro: Proovedor): Unit={
      archi.recuperarArchivos("proovedores.dat")
      listaProovedor+=(pro)
      archi.guardarArchivo("proovedores.dat")
  }

  def reemplazar(listanueva: mutable.ListBuffer[Proovedor]): Unit = {
    listaProovedor.clear()
    listaProovedor ++= listanueva
  }

  //metodo para modificar el proovedor
  def modificarProovedor(RUC: String, nombre: String, apellido: String, telefono: String, direccion: String): Unit = {
    for (i: Proovedor <- listaProovedor) {
      if (i.ruc == RUC) {
        i.nombre = nombre
        i.apellido = apellido
        i.telefono = telefono
        i.direccion = direccion
      }
    }
    archi.guardarArchivo("proovedores.dat")
  }

  //eliminacion del proovedor por medio del RUC
  def eliminarProovedor(RUC: String): Unit = {
    for (i: Proovedor <- listaProovedor) {
      if (i.ruc == RUC) {
        listaProovedor.remove(listaProovedor.indexOf(i))
      }
    }
    archi.guardarArchivo("proovedores.dat")
  }

  def verifnum(tel: String): Boolean = {
    val regex = "[0-9]+".r
    regex.findFirstIn(tel) match {
      case Some(_) => true
      case None => false
    }
  }
}

class ctrlCliente extends Serializable{
  var listaClientes =new mutable.ListBuffer[Cliente]()
  var archi = new archivosCliente(this)

  def ingresarCliente(pro: Cliente): Unit = {
    archi.recuperarArchivos("clientes.dat")
    listaClientes += (pro)
    archi.guardarArchivo("clientes.dat")
  }

  //metodo para modificar el cliente
  def modificarCliente(cedula: String, nombre: String, apellido: String, telefono: String, direccion: String): Unit = {
    for (i: Cliente <- listaClientes) {
      if (i.cedula == cedula) {
        i.nombre = nombre
        i.apellido = apellido
        i.telefono = telefono
        i.direccion = direccion
      }
    }
    archi.guardarArchivo("clientes.dat")
  }
  //eliminacion del cliente por medio de la cedula
  def eliminarCliente(cedula: String): Unit = {
    for (i: Cliente <- listaClientes) {
      if (i.cedula == cedula) {
        listaClientes.remove(listaClientes.indexOf(i))
      }
    }
    archi.guardarArchivo("clientes.dat")
  }

  def reemplazar(listanueva: mutable.ListBuffer[Cliente]): Unit = {
    listaClientes.clear()
    listaClientes ++= listanueva
  }

  def verifCedula(ced: String): Boolean = {
    var numero = 0
    var suma = 0
    var resultado = 0
    for (i <- 0 until ced.length) {
      numero = String.valueOf(ced.charAt(i)).toInt
      if (i % 2 == 0) {
        numero = numero * 2
        if (numero > 9) {
          numero = numero - 9
        }
      }
      suma = suma + numero
    }
    if (suma % 10 != 0) {
      resultado = 10 - (suma % 10)
      resultado == numero
    }
    else true
  }

  //telefono sea numerico con regex
  def verifTelefono(tel: String): Boolean = {
    val regex = "[0-9]+".r
    regex.findFirstIn(tel) match {
      case Some(_) => true
      case None => false
    }
  }
}

class archivosCliente(var manejo:ctrlCliente)extends Serializable {
  def guardarArchivo(nombre: String): Unit = {
    val output = new ObjectOutputStream(new FileOutputStream(nombre))
    output.writeObject(manejo)
    output.close()
  }

  def recuperarArchivos(nombre: String): Boolean = {
    try {
      val input = new ObjectInputStream(new FileInputStream(nombre))
      val data = input.readObject.asInstanceOf[ctrlCliente]
      input.close()
      manejo.reemplazar(data.listaClientes)
      true
    } catch {
      case a: FileNotFoundException => false
    }
  }
}

class archivosProovedor(var manejo:ctrlProovedor)extends Serializable {
  def guardarArchivo(nombre: String): Unit = {
    val output = new ObjectOutputStream(new FileOutputStream(nombre))
    output.writeObject(manejo)
    output.close()
  }

  def recuperarArchivos(nombre: String): Boolean = {
    try {
      val input = new ObjectInputStream(new FileInputStream(nombre))
      val data = input.readObject.asInstanceOf[ctrlProovedor]
      input.close()
      manejo.reemplazar(data.listaProovedor)
      true
    } catch {
      case a: FileNotFoundException => false
    }
  }
}