import java.io.{FileInputStream, FileNotFoundException, FileOutputStream, ObjectInputStream, ObjectOutputStream}
import java.util
import scala.io.StdIn.{readChar, readInt, readLine}
import java.util.Collections
import java.util.Comparator

object Launch {
  var sel = "0"
  var manFut=new ManejoFutbolista
  var manEntr = new ManejoEntrenador
  var manejoMasajista= new ManejoMasajista
  var data = new Data(manFut,manEntr,manejoMasajista)
  def main(args: Array[String]): Unit = {
    do {
      println("Menu")

      println("1)Agregar futbolista")
      println("2)Agregar Entrenador")
      println("3)Agregar Masajista")
      println("4)Listado de los integrantes que comienzan una concentración en orden ascendente")
      println("5) println(\"4)Listado de los integrantes que comienzan una concentración en orden ascendente\")")
      println("6)Salir")
      sel = readLine()
      sel match {
        case "1" =>
          println("ID?")
          var id=readInt()
          println("Nombre?")
          var nombre=readLine()
          var apellido = readLine("Ingrese el apellido:")

          var edad = 0
          println("Ingrese la edad :")
          edad = readInt()

          var dorsal = 0
          println("Ingrese el dorsal :")
          dorsal = readInt()

          var demarcacion = readLine("Ingrese la demarcacion:")

          var futbo= new Futbolista(id,nombre,apellido,edad,dorsal,demarcacion)
          var focus=readLine("Va a comenzar una concentracion? s/n")
          if(focus=="s"){
            futbo.concenctrarse()
          }

          var viaje=readLine("Se encuentra de viaje? s/n")
          if(viaje=="s") {
            futbo.viajar()
          }
          manFut.addFutbolista(futbo)
          data.guardarFutbolistas()
        case "2" =>
          var id = 0
          println("Ingrese el id del entrenador:")
          id = readInt()

          var nombre = readLine("Ingrese el nombre:")
          var apellido = readLine("Ingrese el apellido:")

          var edad = 0
          println("Ingrese la edad del entrenador:")
          edad = readInt()


          println("Ingrese el id de la federacion:")
          var idFederacion = readLine()

          var entre = new Entrenador(id,nombre,apellido,edad,idFederacion)
          var focus=readLine("Va a comenzar una concentracion? s/n")
          if(focus=="s"){
            entre.concenctrarse()
          }

          var viaje=readLine("Se encuentra de viaje? s/n")
          if(viaje=="s") {
            entre.viajar()
          }
          manEntr.addEntrenador(entre)
          data.guardarEntrenador()

        case "3" =>
          var id = 0
          println("Ingrese el id del masajista:")
          id = readInt()

          var nombre = readLine("Ingrese el nombre:")
          var apellido = readLine("Ingrese el apellido:")


          println("Ingrese la edad del masajista:")
          var edad = readInt()

          var titulacion = readLine("Ingrese la titulacion:")


          println("anios de experiencia:")
          var experiencia = readInt()

          var masajista = new Masajista(id, nombre,apellido,edad,titulacion,experiencia)
          manejoMasajista.addMa(masajista)

        case "4" =>
          data.recuperarFutbolistas()
          var listFut= manFut.listaFutbolistas
          var apellidos= new util.ArrayList[String]()

          for(i<-0 until(listFut.size())){
            if(listFut.get(i).focus) {
              apellidos.add(listFut.get(i).Apellidos)
            }
          }
          util.Collections.sort(apellidos)
          for(i<-0 until(apellidos.size())){
            println(apellidos.get(i))
          }
        case "5"=>
          data.recuperarEntrenador()
          var listCoach=manEntr.listaEntrenador
          var apellidos= new util.ArrayList[String]()

          for(i<-0 until(listCoach.size())){
            if(listCoach.get(i).focus) {
              apellidos.add(listCoach.get(i).Apellidos)
            }
          }

          val comparador = Collections.reverseOrder
          //util.Collections.sort(apellidos,comparador)

          for(i<-0 until(apellidos.size())){
            println(apellidos.get(i))
          }

      }

    }while(sel!="6")
  }
}


class Persona(var id:Int,var Nombre:String,var Apellidos:String,var Edad:Int) {
  var focus= false
  var trip = false
      def concenctrarse(): Unit ={
        focus=true
      }

      def viajar(): Unit ={
        trip=true
      }

}

class Futbolista(var id:Int,var Nombre:String,var Apellidos:String,var Edad:Int,var dorsal:Int, var demarcacion:String)extends Serializable{
  var focus= false
  var trip = false
  var game= false
  var train = false
  def concenctrarse(): Unit ={
    focus=true
  }

  def viajar(): Unit ={
    trip=true
  }
  def jugarPartido(): Unit ={
    game= true
  }

  def entrenar(): Unit ={
    train= true
  }

}

class Entrenador(var id:Int,var Nombre:String,var Apellidos:String,var Edad:Int,var idFederacion:String)extends Serializable{
  var focus= false
  var trip = false
  var Dgame= false
  var train = false
  def concenctrarse(): Unit ={
    focus=true
  }

  def viajar(): Unit ={
    trip=true
  }
  def dirigirPartido(): Unit ={
    Dgame= true
  }

  def dirigirentrenamiento(): Unit ={
    train= true
  }
}

class Masajista(var id:Int,var Nombre:String,var Apellidos:String,var Edad:Int,var titulacion:String,var aniosExperiencia:Int)extends Serializable{
  var focus= false
  var trip = false
  var dmasaje= false

  def concenctrarse(): Unit ={
    focus=true
  }

  def viajar(): Unit ={
    trip=true
  }
  def darMasaje(): Unit ={
    dmasaje= true
  }
}
class ManejoFutbolista()extends Serializable{
  var listaFutbolistas = new util.ArrayList[Futbolista]()

  def addFutbolista(futb:Futbolista): Unit ={
    listaFutbolistas.add(futb)
  }
  def setFutbolistas(nuevaLista:util.ArrayList[Futbolista]): Unit = {
    listaFutbolistas.clear()
    listaFutbolistas.addAll(nuevaLista)
  }
}

class ManejoEntrenador()extends Serializable{
  var listaEntrenador = new util.ArrayList[Entrenador]()

  def addEntrenador(coach:Entrenador): Unit ={
    listaEntrenador.add(coach)
  }
  def setEntrenador(nuevaLista:util.ArrayList[Entrenador]): Unit = {
    listaEntrenador.clear()
    listaEntrenador.addAll(nuevaLista)
  }
}

class ManejoMasajista()extends Serializable{
  var listaMasajista = new util.ArrayList[Masajista]()

  def addMa(mass:Masajista): Unit ={
    listaMasajista.add(mass)
  }
  def setMasajista(nuevaLista:util.ArrayList[Masajista]): Unit = {
    listaMasajista.clear()
    listaMasajista.addAll(nuevaLista)
  }
}

class Data(var manejoFutbolista: ManejoFutbolista, var manejoEntrenador: ManejoEntrenador,var manejoMasajista: ManejoMasajista) extends Serializable {
  def guardarFutbolistas(): Unit = {
    var output = new ObjectOutputStream(new FileOutputStream("futbol.dat"))
    output.writeObject(manejoFutbolista)
    output.close
  }

  def recuperarFutbolistas(): Unit = {
    try {
      var input = new ObjectInputStream(new FileInputStream("futbol.dat"))
      var data = input.readObject.asInstanceOf[ManejoFutbolista]
      input.close
      manejoFutbolista.setFutbolistas(data.listaFutbolistas)

      println("Fu recuperados con exito")

    } catch {
      case a: FileNotFoundException => println("No se pudo recuperar el archivo")
    }
  }

  def guardarEntrenador(): Unit = {
    var output = new ObjectOutputStream(new FileOutputStream("entrenador.dat"))
    output.writeObject(manejoEntrenador)
    output.close
  }

  def recuperarEntrenador(): Unit = {
    try {
      var input = new ObjectInputStream(new FileInputStream("entrenador.dat"))
      var data = input.readObject.asInstanceOf[ManejoEntrenador]
      input.close
      manejoEntrenador.setEntrenador(data.listaEntrenador)

      println("Entrenadores recuperados con exito")

    } catch {
      case a: FileNotFoundException => println("No se pudo recuperar el archivo")
    }

  }
}


