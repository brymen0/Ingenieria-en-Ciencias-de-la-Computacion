
--PROCEDICIENTO ALMACENADO punto 3

CREATE OR REPLACE PROCEDURE verifica_Usuario(resText out SYS_REFCURSOR, dni in VARCHAR2, id_Encuesta in number)
AS
conn SYS_REFCURSOR;
BEGIN
OPEN conn FOR
SELECT COUNT(ID_USUARIO) FROM USUARIO_ENCUESTA WHERE ID_USUARIO = DNI AND ID_ENCUESTA= ID_ENCUESTA;
resText:=conn;
END VERIFICA_USUARIO;



CREATE PUBLIC SYNONYM VERIFICA_USUARIO FOR VERIFICA_USUARIO;



--PROCEDICIENTO ALMACENADO punto 4
CREATE OR REPLACE PROCEDURE numEncuestaAutor(resText out SYS_REFCURSOR,nombre in VARCHAR2)
AS
conn SYS_REFCURSOR;
BEGIN
OPEN conn FOR 
SELECT COUNT(autor) FROM Encuesta WHERE autor =nombre;
resText:=conn;
END numEncuestaAutor;
--Sinonimo del procedimiento
CREATE PUBLIC SYNONYM numEncuestaAutor FOR numEncuestaAutor;
------------------------------------------------

CREATE OR REPLACE PROCEDURE getRespuestasCerradas(idEncuesta in VARCHAR2,dni in VARCHAR2)
AS
conn SYS_REFCURSOR;
BEGIN
OPEN conn FOR
SELECT DISTINCT PreguntaCerrada.texto,Op_preguntaCerrada.opcion
FROM PREGUNTACERRADA    
INNER JOIN Encuesta ON idEncuesta = PreguntaCerrada.id_Encuesta
INNER JOIN RESPUESTA_Cerrada ON RESPUESTA_Cerrada.id_PreguntaC = PreguntaCerrada.idPreguntaC 
AND idEncuesta = Respuesta_Cerrada.id_Encuesta
INNER JOIN Usuario ON dni = Respuesta_Cerrada.id_Usuario
INNER JOIN Op_preguntaCerrada ON Op_preguntaCerrada.id_PreguntaC = PreguntaCerrada.idPreguntaC 
AND Op_preguntaCerrada.idOpcion = Respuesta_Cerrada.idOpcion AND Op_preguntaCerrada.id_Encuesta = idEncuesta;

DBMS_SQL.RETURN_RESULT(conn);
END getRespuestasCerradas;




CREATE OR REPLACE PROCEDURE getRespuestasCerradas(resText out SYS_REFCURSOR,idEncuesta in VARCHAR2,dni in VARCHAR2)
AS
conn SYS_REFCURSOR;
BEGIN
OPEN conn FOR
SELECT DISTINCT PreguntaCerrada.texto,Op_preguntaCerrada.opcion
FROM PREGUNTACERRADA    
INNER JOIN Encuesta ON idEncuesta = PreguntaCerrada.id_Encuesta
INNER JOIN RESPUESTA_Cerrada ON RESPUESTA_Cerrada.id_PreguntaC = PreguntaCerrada.idPreguntaC 
AND idEncuesta = Respuesta_Cerrada.id_Encuesta
INNER JOIN Usuario ON dni = Respuesta_Cerrada.id_Usuario
INNER JOIN Op_preguntaCerrada ON Op_preguntaCerrada.id_PreguntaC = PreguntaCerrada.idPreguntaC 
AND Op_preguntaCerrada.idOpcion = Respuesta_Cerrada.idOpcion AND Op_preguntaCerrada.id_Encuesta = idEncuesta;

resText:=conn;
END getRespuestasCerradas;






SELECT Usuario.idUsuario, Usuario.nombre FROM Usuario
INNER JOIN Usuario_Encuesta ON Usuario_Encuesta.id_Usuario = Usuario.idUsuario 
INNER JOIN Encuesta ON Encuesta.id =Usuario_Encuesta.id_Encuesta AND Encuesta.id = 401;

CREATE OR REPLACE PROCEDURE verifica_Usuario(dni in VARCHAR2, id_Encuesta in number)
AS
conn SYS_REFCURSOR;
BEGIN
OPEN conn FOR
SELECT Usuario.idUsuario, Usuario.nombre, Encuesta.id, Encuesta.titulo FROM Usuario
INNER JOIN Usuario_Encuesta ON Usuario_Encuesta.id_Usuario = Usuario.idUsuario AND Usuario.idUsuario = dni
INNER JOIN Encuesta ON Encuesta.id = Usuario_Encuesta.id_Encuesta AND Encuesta.id = id_Encuesta;
DBMS_SQL.RETURN_RESULT(conn);
END VERIFICA_USUARIO;