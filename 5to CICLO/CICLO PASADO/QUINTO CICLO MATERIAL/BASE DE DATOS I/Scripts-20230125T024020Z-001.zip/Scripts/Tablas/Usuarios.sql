--Permiso para manipular usuarios
alter session set "_ORACLE_SCRIPT"=true;


--Administrador
CREATE USER administrador IDENTIFIED BY root
DEFAULT TABLESPACE system
QUOTA 100M ON system;

CREATE ROLE Admin;

GRANT CREATE SESSION TO Admin;
GRANT SELECT,INSERT,UPDATE ON Encuesta TO Admin;
GRANT SELECT,INSERT,UPDATE ON PreguntaAbierta TO Admin;
GRANT SELECT,INSERT,UPDATE ON PreguntaCerrada TO Admin;
GRANT SELECT,INSERT,UPDATE ON Op_preguntaCerrada TO Admin;
GRANT SELECT, INSERT ON Usuario TO Admin;
GRANT SELECT, INSERT ON bitacora_Encuesta TO Admin;


--Otorgamos rol de admin a administrador
GRANT admin To administrador;

--Encuestado
CREATE USER encuestado ClientIDENTIFIED BY 123
DEFAULT TABLESPACE system
QUOTA 100M ON system;

GRANT CREATE SESSION TO cliente;
GRANT SELECT ON Encuesta TO cliente;
GRANT SELECT, INSERT ON Usuario TO cliente;
GRANT SELECT ON PreguntaAbierta TO cliente;
GRANT SELECT ON PreguntaCerrada TO cliente;
GRANT SELECT ON Op_preguntaCerrada TO cliente;
GRANT SELECT, INSERT ON Usuario_Encuesta TO cliente;
GRANT SELECT, INSERT ON Respuesta_Cerrada TO cliente;
GRANT SELECT, INSERT ON Respuesta_Abierta TO cliente;

GRANT SELECT ON bitacora_UsuarioEncuesta TO cliente;
GRANT EXECUTE ON verifica_usuario TO cliente;

GRANT cliente TO encuestado;


GRANT EXECUTE ANY PROCEDURE TO administrador;
CREATE PUBLIC SYNONYM USUARIO_ENCUESTA FOR USUARIO_ENCUESTA;
CREATE PUBLIC SYNONYM PreguntaAbierta FOR PreguntaAbierta; 
CREATE PUBLIC SYNONYM PreguntaCerrada FOR PreguntaCerrada; 
CREATE PUBLIC SYNONYM Op_preguntaCerrada FOR Op_preguntaCerrada;

CREATE PUBLIC SYNONYM Usuario FOR Usuario; 

CREATE PUBLIC SYNONYM Respuesta_Abierta FOR Respuesta_Abierta; 

CREATE PUBLIC SYNONYM Respuesta_Cerrada FOR Respuesta_Cerrada;

CREATE PUBLIC SYNONYM GETRESPUESTASCERRADAS FOR GETRESPUESTASCERRADAS;

CREATE PUBLIC SYNONYM VERIFICA_USUARIO FOR VERIFICA_USUARIO;

CREATE PUBLIC SYNONYM bitacora_UsuarioEncuesta FOR bitacora_UsuarioEncuesta;