CREATE TABLE Encuesta(
id number PRIMARY KEY NOT NULL,
titulo varchar2(100),
autor varchar2(20),
numPreguntas number
);

CREATE SEQUENCE encuestas
START WITH 1
INCREMENT BY 1;


CREATE TRIGGER Trig_encuestas
BEFORE INSERT ON Encuesta
FOR EACH ROW
BEGIN
SELECT encuestas.NEXTVAL INTO : NEW.id FROM DUAL;
END;

CREATE TABLE Usuario(
idUsuario varchar(11) PRIMARY KEY NOT NULL,
nombre varchar2(20)
);



CREATE TABLE Usuario_Encuesta(
id_Usuario varchar(11) NOT NULL,
id_Encuesta number NOT NULL,
FOREIGN KEY(id_Usuario) REFERENCES Usuario(idUsuario),
FOREIGN KEY(id_Encuesta) REFERENCES Encuesta(idEncuesta)
);

CREATE TABLE PreguntaAbierta(
id number  PRIMARY KEY NOT NULL,
id_Encuesta number NOT NULL,
texto varchar2(100),
FOREIGN KEY(id_Encuesta) REFERENCES Encuesta(idEncuesta)
);
CREATE SEQUENCE preguntas_id
START WITH 1
INCREMENT BY 1;

CREATE TRIGGER Trig_preguntas
BEFORE INSERT ON PreguntaAbierta
FOR EACH ROW
BEGIN
SELECT preguntas_id.NEXTVAL INTO : NEW.id FROM DUAL;
END;


CREATE TABLE PreguntaCerrada(
idPreguntaC number PRIMARY KEY NOT NULL,
id_Encuesta number NOT NULL,
texto varchar(100),
FOREIGN KEY(id_Encuesta) REFERENCES Encuesta(idEncuesta)
);

CREATE SEQUENCE preguntas_cerr_id
START WITH 1
INCREMENT BY 1;

CREATE TRIGGER Trig_preguntas_cerr
BEFORE INSERT ON PreguntaCerrada
FOR EACH ROW
BEGIN
SELECT preguntas_cerr_id.NEXTVAL INTO : NEW.idPreguntaC FROM DUAL;
END;

CREATE TABLE Op_preguntaCerrada(
idOpcion number PRIMARY KEY NOT NULL,
id_PreguntaC number NOT NULL,
id_Usuario number NOT NULL,
id_Encuesta number NOT NULL,
opcion varchar2(20),
FOREIGN KEY(id_PreguntaC) REFERENCES PreguntaCerrada(idPreguntaC),
FOREIGN KEY(id_Usuario) REFERENCES Usuario(idUsuario),
FOREIGN KEY(id_Encuesta) REFERENCES Encuesta(idEncuesta)
);

CREATE SEQUENCE opciones_id
START WITH 1
INCREMENT BY 1;

CREATE TRIGGER Trig_opciones
BEFORE INSERT ON Op_preguntaCerrada
FOR EACH ROW
BEGIN
SELECT opciones_id.NEXTVAL INTO : NEW.idOpcion FROM DUAL;
END;


CREATE TABLE Respuesta_Cerrada(
idOpcion number NOT NULL,
id_PreguntaC number NOT NULL,
id_Usuario varchar2(11) NOT NULL,
id_Encuesta number NOT NULL,
FOREIGN KEY(idOpcion) REFERENCES Op_preguntaCerrada(idOpcion),
FOREIGN KEY(id_PreguntaC) REFERENCES PreguntaCerrada(idPreguntaC),
FOREIGN KEY(id_Usuario) REFERENCES Usuario(idUsuario),
FOREIGN KEY(id_Encuesta) REFERENCES Encuesta(id)
);

CREATE TABLE Respuesta_Abierta(
id_Pregunta number NOT NULL,
id_Usuario varchar(11) NOT NULL,
id_Encuesta number NOT NULL,
respuesta varchar(100),
FOREIGN KEY(id_Pregunta) REFERENCES PreguntaAbierta(id),
FOREIGN KEY(id_Usuario) REFERENCES Usuario(idUsuario),
FOREIGN KEY(id_Encuesta) REFERENCES Encuesta(id)
);
