package principal;


import java.lang.reflect.Field;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class Table {
    private SQL2 sql;
    private String table;
    private Field[] fields;
    public String kav = "zxcv"; int _kav = 16;
    public int test = 5;
    public short test2 = 6;
    public long test3 = 7;
    public int test4 = 8;
    
    public Table(SQL2 sql, String table) {  
        this.sql = sql;
        this.table = table;
        fields = this.getClass().getDeclaredFields();
        create();
    }
    
    public boolean create() {
        //Update same order as create
        sql.createTable(table,sqlCreate());
        return true;
    }
    
    public boolean delete() {
        sql.deleteTable(table);
        return true;
    }
    
    public String sqlCreate() {
        String result = "";
        int i = 3; 
        while (i<fields.length) {
            if (! fields[i].getName().startsWith("_")) {
                result += "`" + fields[i].getName() + "` " + SQL2.typeToStr(fields[i].getType().getSimpleName());
                if (fields[i].getType() == String.class) try {
                    result += "("+fields[i+1].getInt(this)+")";
                } catch (Exception ex) {
                }
                if (i==3) result += " NOT NULL";
                result += ", ";
            }
            i++;
        }
        result += "PRIMARY KEY (`"+fields[3].getName()+"`)";
        return result;
    }
    
    public String sqlUpdate() {
        String result = "";
        for (int i=3;i<fields.length;i++) {
           if (! fields[i].getName().startsWith("_")) try {
                result += "`" + fields[i].getName() + "`='" + fields[i].get(this)+"'";
                if (i<fields.length-1) result += ", ";
           } catch (Exception ex) {
           }
        }
        return result;
    }
    
    public String sqlInsert() {
        String result = "";
        for (int i=3;i<fields.length;i++) {
           if (! fields[i].getName().startsWith("_")) try {
                result += "'" + fields[i].get(this)+"'";
                if (i<fields.length-1) result += ", ";
           } catch (Exception ex) {
           }
        }
        return result;
    }
    
    public boolean select(String column, String value) {
        sql.select(table, column, value);
        return next();
    }

    public boolean insert() {
        return sql.insert(table, sqlInsert());
        //return sql.insert(table, column, value);
    }
    
    public boolean update() {
        String column = fields[3].getName();
        String value;
        try {
            value = (String)fields[3].get(this);
        } catch (Exception ex) {
            return false;
        }
        if (sql.count(table, column, value) > 0) {
            return update(column, value);
        } else {    
           return insert();
        }
    }    
    
    public boolean update(String column, String value) {
        return sql.update(table, column, value, sqlUpdate());
    }

    public boolean next() {
        if (sql.next()) {
            for (int i=3;i<fields.length;i++) {
               if (! fields[i].getName().startsWith("_")) try {
                   String type = fields[i].getType().getSimpleName();
                   if ("String".equals(type)) fields[i].set(this,sql.rs.getString(fields[i].getName()));
                   if ("long".equals(type)) fields[i].set(this,sql.rs.getLong(fields[i].getName()));
                   if ("int".equals(type)) fields[i].set(this,sql.rs.getInt(fields[i].getName()));
                   if ("short".equals(type)) fields[i].set(this,sql.rs.getShort(fields[i].getName()));
                   if ("byte".equals(type)) fields[i].set(this,sql.rs.getByte(fields[i].getName()));
                   if ("float".equals(type)) fields[i].set(this,sql.rs.getFloat(fields[i].getName()));
                   if ("double".equals(type)) fields[i].set(this,sql.rs.getDouble(fields[i].getName()));
                   if ("boolean".equals(type)) fields[i].set(this,sql.rs.getBoolean(fields[i].getName()));
               } catch (Exception ex) {
               }
            }
            return true;
        } else {
            return false;
        }
    }
    
    public int getCount() {
        return sql.count(table);
    }
    
    public int getCount(String column, String value) {
        return sql.count(table, column, value);
    }    
    
}
