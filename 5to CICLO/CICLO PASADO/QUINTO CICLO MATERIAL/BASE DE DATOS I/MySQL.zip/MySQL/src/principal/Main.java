package principal;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SQL2 plus = new SQL2("localhost","3306","root","root1234","papas");
		
		plus.createTable("Borrador","Nombre,direccion" );
	}

}
