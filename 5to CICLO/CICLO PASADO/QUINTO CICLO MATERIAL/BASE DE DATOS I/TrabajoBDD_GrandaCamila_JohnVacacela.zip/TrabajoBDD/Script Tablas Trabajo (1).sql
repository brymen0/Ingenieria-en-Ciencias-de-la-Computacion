use usuarios;

create table personas(
cedula varchar(45) Primary key not null,
password varchar(45) not null,
nombre varchar(45),
direccion varchar(45),
fechaNacimiento date,
idTipo int not null);

create table telefonos(
cedula varchar(20) Primary KEY not null,
telefonos varchar(20) not null,
tipos int);

alter table personas
add FOREIGN KEY(idTipo) references tipos(idTipo);

create table tipos(
idTipo int Primary key, 
nombre varchar(45));

create table tipos_telefonos(
idTipoTelefono int Primary Key not null,
nombreTipo varchar(35) not null);

alter table telefonos
add FOREIGN KEY(tipos) references tipos_telefonos(idTipoTelefono);

#PARA EL ADMINISTRADOR
create user '0107616088'@'localhost' identified by '123'; #CREAMOS UN ADMINISTRADOR GENERAL DEL SISTEMA
GRANT GRANT OPTION ON *.* TO '0107616088'@'localhost';
grant all privileges on *.* to '0107616088'@'localhost';
create role 'administrador'@'localhost';
grant 'administrador'@'localhost' to '0107616088'@'localhost';


#PARA EL AUTORIZADOR
create role 'autorizador'@'localhost';
grant insert, create user, select , grant option, event, SUPER on *.* to '0150153781'@'localhost'; #USUARIO EJEMPLO
grant 'autorizador'@'localhost' to '0150153781'@'localhost';

#PARA LOS USUARIOS
create role 'usuarios'@'localhost';
grant select, create on *.* to '0102092400'@'localhost'; #USUARIO EJEMPLO
grant 'usuarios'@'localhost' to '0102092400'@'localhost';

#CON ESTAS LINEAS DE CODIGO ACTIVAMOS EL ROL
SET DEFAULT ROLE ALL TO '0150153781'@'localhost';
SET DEFAULT ROLE ALL TO '0102092400'@'localhost';
SET DEFAULT ROLE ALL TO '0107616088'@'localhost';

#ESTA LINEA NOS SIRVE PARA VER EL ROL DEL USUARIO CONECTADO ESE MOMENTO
select current_role();