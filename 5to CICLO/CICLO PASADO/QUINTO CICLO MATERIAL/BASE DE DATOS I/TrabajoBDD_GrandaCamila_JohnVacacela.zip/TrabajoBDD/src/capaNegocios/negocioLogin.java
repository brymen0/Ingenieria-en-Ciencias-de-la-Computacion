package capaNegocios;

import datos.conexion;
import java.util.ArrayList;

public class negocioLogin {
    
    private conexion modelo;
    
    public negocioLogin(){
        this.modelo = new conexion();
    }
    
    public int dameRolLogin(String usuario, String contrasena){

        return switch (modelo.verificarRol(usuario, contrasena)) {
            case "`administrador`@`localhost`" -> 1;
            case "`autorizador`@`localhost`" -> 2;
            case "`usuarios`@`localhost`" -> 3;
            default -> -1;
        };
    }
    
    public boolean verCedulaEcu(String cedula){
        int numero=0,suma=0,resultado;
        for(int i=0;i<cedula.length();i++){
            
            numero=Integer.parseInt(String.valueOf(cedula.charAt(i)));
            if(i%2==0){
                
                numero=numero*2;
                if(numero>9){
                    numero=numero-9;
                }  
            }
            suma=suma+numero;
        }
        
        if(suma %10 !=0){
            resultado=10-(suma%10);
            return resultado==numero;
        }else{
            return true;
        }
   }

    public boolean registro(usuarios model, String cedLogin, String contraLogin) {
        return modelo.registrar(model, "INSERT INTO personas (cedula, nombre, direccion, fechaNacimiento, idtipo) VALUES(?,?,?,?,?);", cedLogin, contraLogin);

    }
    
    public boolean otorgaPrivilegios(String tipoPersona, String cedula, String contrasenia, String cedLogin, String contraLogin){
        return modelo.privilegios("create user '"+cedula+"'@'localhost' identified by '"+contrasenia+"';", "grant '"+tipoPersona+"'@'localhost' to '"+cedula+"'@'localhost';",
                "SET DEFAULT ROLE ALL TO '"+cedula+"'@'localhost';", cedLogin, contraLogin, tipoPersona, cedula);
    }
    
    public boolean registroTelefono(usuarios model, String cedula, String contrasenia){
        return modelo.registrarTelefonos(model, "INSERT INTO telefonos (cedula, telefonos, tipos) values (?, ?, ?)", cedula, contrasenia);
    }
    
    public String dameDatos(String cedula, String cedulaLogin, String contraseniaLogin ){
        return modelo.verificarUsuario(cedula, cedulaLogin, contraseniaLogin);
    }
    public boolean EliminarUsuario(String cedula,String cedulaLogin, String contraseniaLogin){
        return modelo.eliminarUsuario(cedula,cedulaLogin, contraseniaLogin);
    }
    public ArrayList<String> dameTelefonos(String cedula, String cedulaLogin, String contraseniaLogin, int caso){
        return modelo.verificarTelefonos(cedula, "SELECT cedula, telefonos, tipos FROM telefonos", cedulaLogin, contraseniaLogin, caso);
    }
    
    public boolean modificarUsuario(usuarios model, String cedula,String cedulaLogin, String contraseniaLogin){
        return modelo.modificarUsuario(model,"UPDATE personas set nombre=?, direccion=?, idTipo=? WHERE cedula="+cedula, cedulaLogin, contraseniaLogin);
    }
    
    public boolean borrarTelefono(usuarios model, String cedulaLogin, String contraseniaLogin){
        return modelo.borrarTelefono(model, "DELETE FROM telefonos WHERE (cedula="+model.getCedula()+") and (telefonos="+model.getTelefono()+")",cedulaLogin,contraseniaLogin);
    }
    
    public boolean verifTelefonos(usuarios model,String cedulaLogin, String contraseniaLogin){
        return modelo.verTel(model, "SELECT telefonos, tipos FROM telefonos", cedulaLogin, contraseniaLogin);
    }
    public boolean modificarTelefono(usuarios model, String cedula, String telefono,String cedulaLogin, String contraseniaLogin){
        return modelo.modificarTelefono(model, "UPDATE telefonos set telefonos=?, tipos=? WHERE (cedula="+cedula+") and (telefonos="+telefono+")", cedulaLogin, contraseniaLogin);
    }
    public boolean revocarPrivilegios(String cedula, String tipoPersona, String cedulaLogin, String contraseniaLogin, String tipo){
        return modelo.revocar("REVOKE ALL ON *.* FROM '"+cedula+"'@'localhost';","grant '"+tipoPersona+"'@'localhost' to '"+cedula+"'@'localhost';","REVOKE '"+tipo+"'@'localhost' FROM '"+cedula+"'@'localhost';", "SET DEFAULT ROLE ALL TO '"+cedula+"'@'localhost';", cedulaLogin, contraseniaLogin, tipoPersona, cedula);
    }
}
