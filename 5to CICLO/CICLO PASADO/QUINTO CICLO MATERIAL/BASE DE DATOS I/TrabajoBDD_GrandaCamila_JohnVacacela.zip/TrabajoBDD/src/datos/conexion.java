package datos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import capaNegocios.usuarios;
import com.mysql.cj.protocol.x.Notice;
import java.sql.PreparedStatement;
import java.util.ArrayList;

public class conexion {

    private Connection con=null;
    private Statement st;
    private ResultSet rs;
    
    public Connection getConexion(String usuario, String contrasena){
        
        try {
            
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/usuarios", usuario, contrasena);
            return con;
                
        } catch (SQLException e) {
            
            return con;
            
        }       
    }
    
       
    public String verificarRol(String usuario, String contrasena){
        
        Connection conRol = getConexion(usuario,contrasena);
        if(conRol == null){
            return "";
        }
        try {
            String consulta = "Select current_role();";
            String rol = "";
            
            st = conRol.createStatement();
            rs = st.executeQuery(consulta);
             
            while(rs.next()){
                rol = rs.getString(1); //DEVUELVE EL ROL ASIGNADO
            }
            
            System.out.println(rol);
            return rol;
            
        } catch (SQLException ex) {
            Logger.getLogger(conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return "";
    }
    
    public boolean registrar(usuarios user, String sqlInsertar, String cedula, String contrasenia){
        //preparamos la consulta
        PreparedStatement ps =null;

        conexion conectar = new conexion();
        Connection conReg = conectar.getConexion(cedula, contrasenia);
        
        try {
            conReg.setAutoCommit(false);
            ps = conReg.prepareStatement(sqlInsertar);
            ps.setString(1, user.getCedula());
            ps.setString(2, user.getNombre());
            ps.setString(3, user.getDireccion());
            ps.setString(4, user.getFechaNacimiento());
            ps.setInt(5, user.getIdTipo());
            ps.execute();
            conReg.commit();
            return true;
        } catch (SQLException ex) {
            try {
                conReg.rollback();
            } catch (SQLException ex1) {
                 return false;
            }
            //1062 corresponde al error de clave primaria duplicada en MySQL. 
            if (ex.getErrorCode() == 1062) {
                return false;
            
             }
            return false;
        }
    }
    public boolean privilegios(String crearUser, String sqlAsigRol, String AsigRol, String cedula, String contrasenia, String tipoPersona, String cedulaPersona){
        PreparedStatement ps =null;
        PreparedStatement ps1 = null;
        PreparedStatement ps2 = null;
        PreparedStatement ps3 = null;
        PreparedStatement ps4 = null;
        conexion conectar = new conexion();
        Connection conPriv = conectar.getConexion(cedula, contrasenia);
        
        try {
            conPriv.setAutoCommit(false);
            ps = conPriv.prepareStatement(crearUser);
            ps1 = conPriv.prepareStatement(sqlAsigRol);
            ps2 = conPriv.prepareStatement(AsigRol);
            switch (tipoPersona) {
                case "usuarios" -> ps3 = conPriv.prepareStatement("grant select, create on *.* to '"+cedulaPersona+"'@'localhost';");
                case "autorizador" -> ps3 = conPriv.prepareStatement("grant insert, create, create user, select, grant option, event, super on *.* to '"+cedulaPersona+"'@'localhost';");
                case "administrador" -> {
                    ps3 = conPriv.prepareStatement("grant all privileges on *.* to '"+cedulaPersona+"'@'localhost';");
                    ps4 = conPriv.prepareStatement("grant grant option on *.* to '"+cedulaPersona+"'@'localhost';");
                }
                default -> {
                }
            }
            
            ps.execute();
            ps1.execute();
            ps2.execute();
            ps3.execute();
            if(ps4 != null){
                ps4.execute();
            }
            conPriv.commit();
            return true;
        }catch(SQLException ex){
            try {
                System.out.println(ex.getMessage());
                conPriv.rollback();
            } catch (SQLException ex1) {
                 return false;
            }
        }
        return false;
    }
    
    public boolean registrarTelefonos(usuarios user, String sql2, String cedula, String contrasenia) {
        PreparedStatement ps2 = null;
        conexion conectar = new conexion();
        Connection conTel = conectar.getConexion(cedula, contrasenia);
        
        try {
            conTel.setAutoCommit(false);
            ps2 = conTel.prepareStatement(sql2);
            ps2.setString(1, user.getCedula());
            ps2.setString(2, user.getTelefono());
            ps2.setInt(3, user.getTipoTelefono());
            ps2.execute();
            conTel.commit();
            return true;
        } catch (SQLException ex) {
            try {
                conTel.rollback();
            } catch (SQLException ex1) {
                 return false;
            }
             //1062 corresponde al error de clave primaria duplicada en MySQL. 
            if (ex.getErrorCode() == 1062) {
                return false;
            
             }
            return false;
        }
    }
    
    public String verificarUsuario(String cedulaBuscada,String cedulaLogin,String contrasenia){
        PreparedStatement ps = null;
        ResultSet rs1 = null;
        conexion conectar = new conexion();
        Connection conVer = conectar.getConexion(cedulaLogin, contrasenia);
        
        //ESTA CONSULTA NOS MUESTRA TODOS LOS DATOS
        String sql_1 = "Select cedula, nombre, direccion, fechaNacimiento, idTipo from personas";
        try{
            ps = conVer.prepareStatement(sql_1);
            rs1 = ps.executeQuery();
            
            while(rs1.next()){
                
                if(rs1.getString("cedula").equals(cedulaBuscada)){
                    
                    return rs1.getString("cedula")+","+rs1.getString("nombre")+","+rs1.getString("direccion")+","+rs1.getString("fechaNacimiento")+","+rs1.getString("idTipo");
                    
                }
                
            }
            
        } catch(SQLException e){
            return null;
        }
       return null;
    }
    
    public boolean eliminarUsuario(String cedula, String cedulaLogin, String contraseniaLogin) {
        conexion conectar = new conexion();
        Connection conEli = conectar.getConexion(cedulaLogin, contraseniaLogin);
        Statement statement;
        
        try {
            conEli.setAutoCommit(false);
            statement = conEli.createStatement();
            String consul1 = "DELETE FROM personas WHERE cedula = "+cedula;
            String consul2 = "DELETE FROM telefonos WHERE cedula = "+cedula;
            String consul3 = "DROP USER '"+cedula+"'@'localhost'";
            statement.executeUpdate(consul1);
            statement.executeUpdate(consul2);
            statement.executeUpdate(consul3);
            conEli.commit();
            return true;
        } catch (SQLException ex) {
            try {
                conEli.rollback();
            } catch (SQLException ex1) {
                 return false;
            }
            return false;
        }
    }
    
    public ArrayList<String> verificarTelefonos(String cedula, String consulta, String cedulaLogin, String contraseniaLogin, int caso) {
        
        PreparedStatement ps = null;
        ResultSet rs1 = null;
        conexion conectar = new conexion();
        Connection conVerTel = conectar.getConexion(cedulaLogin,contraseniaLogin);
        ArrayList<String> lista = new ArrayList<>();
        lista.clear();
        try{
            ps = conVerTel.prepareStatement(consulta);
            rs1 = ps.executeQuery();
            if(caso == 1){
                while(rs1.next()){
                    if(rs1.getString("cedula").equals(cedula)){
                        lista.add("Teléfono: "+rs1.getString("telefonos")+", Tipo: "+rs1.getString("tipos"));
                    }          
                }
            }if(caso == 2){
                while(rs1.next()){
                    if(rs1.getString("cedula").equals(cedula)){
                        lista.add(rs1.getString("telefonos"));
                    }          
                }
            }if(caso == 3){
                while(rs1.next()){
                    if(rs1.getString("cedula").equals(cedula)){
                        lista.add(rs1.getString("tipos"));
                    }          
                }
            }if(caso == 4){
                while(rs1.next()){
                    if(rs1.getString("cedula").equals(cedula)){
                        lista.add(rs1.getString("cedula")+","+rs1.getString("telefonos")+","+rs1.getString("tipos"));
                    }          
                }
            }
            
        }catch(SQLException ex){
            
        }
        return lista;
    }
    
    public boolean modificarUsuario(usuarios user, String sql3, String cedulaLogin, String contraseniaLogin){
        
        PreparedStatement ps3 = null;
        conexion conectar = new conexion();
        Connection conMod = conectar.getConexion(cedulaLogin, contraseniaLogin);
        try {
            conMod.setAutoCommit(false);
            ps3 = conMod.prepareStatement(sql3);
            ps3.setString(1, user.getNombre());
            ps3.setString(2, user.getDireccion());
            ps3.setInt(3, user.getIdTipo());
            ps3.execute();
            conMod.commit();
            return true;
        } catch (SQLException ex) {
            try {
                conMod.rollback();
            } catch (SQLException ex1) {
                 return false;
            }
            return false;
        }
    }
    
    public boolean borrarTelefono(usuarios modelo, String consulta, String cedulaLogin, String contraseniaLogin) {
        conexion conectar = new conexion();
        Connection conBorrar = conectar.getConexion(cedulaLogin, contraseniaLogin);
        Statement statement;
        
        try {
            conBorrar.setAutoCommit(false);
            statement = conBorrar.createStatement();
            statement.executeUpdate(consulta);
            conBorrar.commit();
            return true;
        } catch (SQLException ex) {
            try {
                conBorrar.rollback();
            } catch (SQLException ex1) {
                 return false;
            }
            return false;
        }
    }

    public boolean verTel(usuarios user, String consulta, String cedulaLogin, String contraseniaLogin){
        PreparedStatement ps = null;
        ResultSet rs1 = null;
        conexion conectar = new conexion();
        Connection conV = conectar.getConexion(cedulaLogin,contraseniaLogin);
        try{
            ps = conV.prepareStatement(consulta);
            rs1 = ps.executeQuery();
            while(rs1.next()){
                if(rs1.getString("telefonos").equals(user.getTelefono()) && rs1.getInt("tipos")==user.getTipoTelefono()){
                    return true;
                }          
            }
            
        }catch(SQLException ex){
            
        }
        return false;
    }
    
    public boolean modificarTelefono(usuarios user, String consulta, String cedulaLogin, String contraseniaLogin ) {
        PreparedStatement ps3 = null;
        conexion conectar = new conexion();
        Connection con = conectar.getConexion(cedulaLogin, contraseniaLogin);
        try {
            con.setAutoCommit(false);
            ps3 = con.prepareStatement(consulta);
            ps3.setString(1, user.getTelefono());
            ps3.setInt(2, user.getTipoTelefono());
            ps3.execute();
            con.commit();
            return true;
        } catch (SQLException ex) {
            try {
                con.rollback();
            } catch (SQLException ex1) {
                 return false;
            }
            return false;
        }
    }
    
    public boolean revocar(String consRevocar,String asigRol,String revocarRol, String Rol, String cedulaLogin, String contraseniaLogin, String tipoPersona, String cedula) {
        PreparedStatement ps =null;
        PreparedStatement ps1 = null;
        PreparedStatement ps2 = null;
        PreparedStatement ps3 = null;
        PreparedStatement ps4 = null;
        PreparedStatement ps5 = null;
        conexion conectar = new conexion();
        Connection conPriv = conectar.getConexion(cedulaLogin, contraseniaLogin);
        
        try {
            conPriv.setAutoCommit(false);
            ps = conPriv.prepareStatement(consRevocar);
            ps1 = conPriv.prepareStatement(asigRol);
            ps5 = conPriv.prepareStatement(revocarRol);
            ps2 = conPriv.prepareStatement(Rol);
            switch (tipoPersona) {
                case "usuarios" -> ps3 = conPriv.prepareStatement("grant select, create on *.* to '"+cedula+"'@'localhost';");
                case "autorizador" -> ps3 = conPriv.prepareStatement("grant insert, create, create user, select, grant option, event, super on *.* to '"+cedula+"'@'localhost';");
                case "administrador" -> {
                    ps3 = conPriv.prepareStatement("grant all privileges on *.* to '"+cedula+"'@'localhost';");
                    ps4 = conPriv.prepareStatement("grant grant option on *.* to '"+cedula+"'@'localhost';");
                }
                default -> {
                }
            }
            ps.execute();
            ps1.execute();
            ps5.execute();
            ps2.execute();
            ps3.execute();
            if(ps4 != null){
                ps4.execute();
            }
            
            conPriv.commit();
            return true;
        }catch(SQLException ex){
            try {
                System.out.println(ex.getMessage());
                conPriv.rollback();
            } catch (SQLException ex1) {
                 return false;
            }
        }
        return false;
    }
}
