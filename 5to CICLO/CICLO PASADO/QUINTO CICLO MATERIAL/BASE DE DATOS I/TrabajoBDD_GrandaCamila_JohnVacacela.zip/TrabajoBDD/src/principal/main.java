/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal;

import vista.ctrlLogin;
import vista.login;

/**
 *
 * @author Camila Granda
 */
public class main {
    
    public static void main(String [] args){
        
        login view = new login();
        ctrlLogin controlador = new ctrlLogin(view);
    }
}
