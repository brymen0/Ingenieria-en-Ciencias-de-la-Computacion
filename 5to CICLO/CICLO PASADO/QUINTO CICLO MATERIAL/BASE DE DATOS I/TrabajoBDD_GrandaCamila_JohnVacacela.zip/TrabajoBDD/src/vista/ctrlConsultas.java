package vista;


public class ctrlConsultas {
   
    private ventanaConsultas view;
    
    public ctrlConsultas(ventanaConsultas view){
        this.view = view;
        view.setDefaultCloseOperation(1);
        view.setLocationRelativeTo(view);
        view.setVisible(true);
    }
    
}
