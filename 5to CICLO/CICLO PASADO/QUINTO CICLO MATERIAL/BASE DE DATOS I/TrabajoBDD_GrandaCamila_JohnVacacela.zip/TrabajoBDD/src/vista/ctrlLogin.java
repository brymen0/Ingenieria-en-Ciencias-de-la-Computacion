package vista;

import capaNegocios.negocioLogin;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class ctrlLogin implements ActionListener{
    
    private login view;
    private negocioLogin model;
    
    public ctrlLogin(login view){
        this.view = view;
        this.model = new negocioLogin();
        view.btn_Ingresar.addActionListener(this);
        view.btn_Salir.addActionListener(this);
        view.setLocationRelativeTo(view);
        view.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource() == view.btn_Ingresar){
            
            String cedula = view.entradaUsuario.getText();
            char[] contrasena = view.entradaContrasenia.getPassword();
            //AHORA VERIFICAMOS DE QUE TIPO DE USUARIO SE TRATA Y DEPENDIENDO DE ESO CARGAMOS LA INTERFAZ DEBIDA!
            
            if(model.dameRolLogin(cedula, new String(contrasena)) == 1){
                System.out.println("INGRESAMOS AL ADMINISTRADOR!");
                //CARGAMOS LA VENTANA DEL ADMINISTRADOR
                ventanaAdministrador view = new ventanaAdministrador();
                ctrlAdministrador ctrl = new ctrlAdministrador(view, cedula, new String(contrasena));
            }
            
            if(model.dameRolLogin(cedula, new String(contrasena)) == 2){
                System.out.println("INGRESAMOS AL AUTORIZADOR");
                
                //CARGAMOS LA VENTANA DEL AUTORIZADOR
                ventanaAutorizador view = new ventanaAutorizador();
                ctrlAutorizador ctrl = new ctrlAutorizador(view, cedula, new String(contrasena));
            }
            
            if(model.dameRolLogin(cedula, new String(contrasena)) == 3){
                System.out.println("INGRESAMOS AL USUARIO");
                
                //CARGAMOS LA VENTANA DEL USUARIO
                ventanaUsuarioConsultas view = new ventanaUsuarioConsultas();
                ctrlUsuarios ctrl = new ctrlUsuarios(view);
                
            }
            
            if(model.dameRolLogin(cedula, new String(contrasena)) == -1){
                JOptionPane.showMessageDialog(null, "Cédula y Contraseña Incorrecta");
            }
            
            
             
        }
        
        if(e.getSource()==view.btn_Salir){
            System.exit(0);
        }
        
    }
    
    
    
    
}