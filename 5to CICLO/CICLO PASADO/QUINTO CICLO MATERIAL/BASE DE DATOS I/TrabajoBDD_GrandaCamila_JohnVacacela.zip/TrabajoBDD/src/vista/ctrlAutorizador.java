package vista;

import capaNegocios.negocioLogin;
import capaNegocios.usuarios;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.swing.*;

public class ctrlAutorizador implements ActionListener{

    private ventanaAutorizador view;
    private usuarios modelo;
    private negocioLogin model;
    private agregarTelefonos telefonosVista;
    private String usuario;
    private String contrasenia;
    
    public ctrlAutorizador(ventanaAutorizador view, String usuario, String contrasenia){
        this.view = view;
        this.telefonosVista = new agregarTelefonos();
        this.modelo=new usuarios();
        this.model=new negocioLogin();
        this.usuario = usuario;
        this.contrasenia = contrasenia;
        view.btnVisualizarConsultasAutorizador.addActionListener(this);
        view.btnAgregarAutorizador.addActionListener(this);
        view.calendarIngresoAutorizador.getDayChooser().setMaxSelectableDate(new Date());
        telefonosVista.btnAgregarTelefono.addActionListener(this);
        telefonosVista.btnSalir.addActionListener(this);
        view.setDefaultCloseOperation(1);
        view.setLocationRelativeTo(view);
        view.setVisible(true);
    }
    
    public void LimpiarCampos(){
        view.lblCedulaIngresoAutorizador.setText("");
        view.lblPasswordIngresoAutorizador.setText("");
        view.lblNombreIngresoAutorizador.setText("");
        view.lblDireccionIngresoAutorizador.setText("");
        view.lblTelefonoIngresar.setText("");
    }
    
    public void Tipotelefonos(){
        
        modelo.setTelefono(view.lblTelefonoIngresar.getText()); 
        if(view.comboTelefonosIngresar.getSelectedItem() == "Whatsapp"){modelo.setTipoTelefono(1);}
        if(view.comboTelefonosIngresar.getSelectedItem() == "Telegram"){modelo.setTipoTelefono(2);}
        if(view.comboTelefonosIngresar.getSelectedItem() == "Celular"){modelo.setTipoTelefono(3);}
        if(view.comboTelefonosIngresar.getSelectedItem() == "Fijo"){modelo.setTipoTelefono(4);}
        
    }
    
    public void agregarTelef(){
        modelo.setTelefono(telefonosVista.lblTelefonoIngresar.getText()); 
        if(telefonosVista.comboTelefonosIngresar.getSelectedItem() == "Whatsapp"){modelo.setTipoTelefono(1);}
        if(telefonosVista.comboTelefonosIngresar.getSelectedItem() == "Telegram"){modelo.setTipoTelefono(2);}
        if(telefonosVista.comboTelefonosIngresar.getSelectedItem() == "Celular"){modelo.setTipoTelefono(3);}
        if(telefonosVista.comboTelefonosIngresar.getSelectedItem() == "Fijo"){modelo.setTipoTelefono(4);}
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource() == view.btnAgregarAutorizador){
            if(model.verCedulaEcu(view.lblCedulaIngresoAutorizador.getText())){
                
                modelo.setCedula(view.lblCedulaIngresoAutorizador.getText());
                modelo.setPassword(view.lblPasswordIngresoAutorizador.getText());
                modelo.setNombre(view.lblNombreIngresoAutorizador.getText());
                modelo.setDireccion(view.lblDireccionIngresoAutorizador.getText());
                SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
                Date fecha = this.view.calendarIngresoAutorizador.getDate();
                modelo.setFechaNacimiento(formato.format(fecha));
                modelo.setIdTipo(3);
                Tipotelefonos();
                
                if(model.registro(modelo, usuario, contrasenia) && model.registroTelefono(modelo, usuario, contrasenia)){
                    
                    if(model.otorgaPrivilegios("usuarios", view.lblCedulaIngresoAutorizador.getText(), view.lblPasswordIngresoAutorizador.getText(), usuario, contrasenia)){
                            int opcion = JOptionPane.showConfirmDialog(null, "¿Desea agregar más telefonos?");

                            if(opcion == JOptionPane.YES_OPTION){
                                telefonosVista.setDefaultCloseOperation(1);
                                telefonosVista.setLocationRelativeTo(telefonosVista);
                                telefonosVista.setVisible(true);
                                telefonosVista.lblCedulaTelefono.setText(modelo.getCedula());
                            }
                        }
                    
                } else {
                    JOptionPane.showMessageDialog(null, "Error al registrar, no se permite cédulas ya registradas");
                    LimpiarCampos();
                }
                
                
            }
        }
        
        if(e.getSource() == telefonosVista.btnAgregarTelefono){
            agregarTelef();
            if(model.registroTelefono(modelo, usuario, contrasenia)){
                    JOptionPane.showMessageDialog(null, "Registro Guardado");
            }
        }
        
        if(e.getSource() == view.btnVisualizarConsultasAutorizador){
            ventanaConsultas vistaCon = new ventanaConsultas();
            ctrlConsultas ctrl = new ctrlConsultas(vistaCon);
        }
    }
 }
    

