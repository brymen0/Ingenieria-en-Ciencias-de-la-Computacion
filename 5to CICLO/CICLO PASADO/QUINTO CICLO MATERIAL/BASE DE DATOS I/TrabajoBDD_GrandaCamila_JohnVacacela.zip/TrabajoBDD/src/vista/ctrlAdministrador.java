package vista;

import capaNegocios.negocioLogin;
import capaNegocios.usuarios;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

public class ctrlAdministrador implements ActionListener{
    
    private ventanaAdministrador view;
    private agregarTelefonos telefonosVista;
    private usuarios modelo;
    private negocioLogin model;
    private modificarTelefonos ventanaTel;
    private cambiarTelefono ventTeleCambiar;
    private telefonoAgregadoMod agregar;
    private String usuario;
    private String contrasenia;
    
    public ctrlAdministrador(ventanaAdministrador view, String usuario, String contrasenia){
        this.view = view;
        this.modelo=new usuarios();
        this.model=new negocioLogin();
        this.usuario = usuario;
        this.contrasenia = contrasenia;
        this.ventanaTel = new modificarTelefonos();
        this.telefonosVista = new agregarTelefonos();
        this.ventTeleCambiar = new cambiarTelefono();
        this.agregar = new telefonoAgregadoMod();
        view.jCalendarAdmi.getDayChooser().setMaxSelectableDate(new Date());
        agregar.btnAgregado.addActionListener(this);
        agregar.btnSalirAgregado.addActionListener(this);
        telefonosVista.btnSalir.addActionListener(this);
        ventanaTel.btnCambiar.addActionListener(this);
        ventanaTel.btnEliminarTelefonoMod.addActionListener(this);
        ventanaTel.btnAgregarTelefono.addActionListener(this);
        ventTeleCambiar.btnModificar.addActionListener(this);
        view.btnModTelefono.addActionListener(this);
        view.btnConsultasAdmin.addActionListener(this);
        view.btnAgregarAdmi.addActionListener(this);
        view.btn_buscarMod.addActionListener(this);
        view.btnModificar.addActionListener(this);
        view.btn_buscarEliminar.addActionListener(this);
        view.btnEliminar.addActionListener(this);
        //view.radioUsuarioConsulta.addActionListener(this);
        //view.radioPersonaIngreso.addActionListener(this);
        //view.radioAdministrador.addActionListener(this);
        view.btnEliminar.setEnabled(false);
        view.btnModificar.setEnabled(false);
        view.btnModTelefono.setEnabled(false);
        telefonosVista.btnAgregarTelefono.addActionListener(this);
        view.setDefaultCloseOperation(1);
        view.setLocationRelativeTo(view);
        view.setVisible(true);
    }

    public void LimpiarCampos(){
        view.lblCedulaIngresoAdmi.setText("");
        view.lblPasswordIngresoAdmi.setText("");
        view.lblNombreIngresoAdmi.setText("");
        view.lblDireccionIngresoAdmi.setText("");
        view.lbltelefonoIngresoAdmi.setText("");
        telefonosVista.lblTelefonoIngresar.setText("");
        
    }
    
    public void Tipotelefonos(){
        
        modelo.setTelefono(view.lbltelefonoIngresoAdmi.getText()); 
        if(view.combotipotelefonoadmi.getSelectedItem() == "Whatsapp"){modelo.setTipoTelefono(1);}
        if(view.combotipotelefonoadmi.getSelectedItem() == "Telegram"){modelo.setTipoTelefono(2);}
        if(view.combotipotelefonoadmi.getSelectedItem() == "Celular"){modelo.setTipoTelefono(3);}
        if(view.combotipotelefonoadmi.getSelectedItem() == "Fijo"){modelo.setTipoTelefono(4);}
        
    }
    
    public void Modificar_EliminarTel(){
        
        if(ventanaTel.comboModTelefono.getSelectedItem() == "Whatsapp"){modelo.setTipoTelefono(1);}
        if(ventanaTel.comboModTelefono.getSelectedItem() == "Telegram"){modelo.setTipoTelefono(2);}
        if(ventanaTel.comboModTelefono.getSelectedItem() == "Celular"){modelo.setTipoTelefono(3);}
        if(ventanaTel.comboModTelefono.getSelectedItem() == "Fijo"){modelo.setTipoTelefono(4);}

        modelo.setTelefono((String) ventanaTel.comboCargarTelefono.getSelectedItem());
    }
    
    public void mod(){
        if(ventTeleCambiar.comboTelefonoNuevo.getSelectedItem() == "Whatsapp"){modelo.setTipoTelefono(1);}
        if(ventTeleCambiar.comboTelefonoNuevo.getSelectedItem() == "Telegram"){modelo.setTipoTelefono(2);}
        if(ventTeleCambiar.comboTelefonoNuevo.getSelectedItem() == "Celular"){modelo.setTipoTelefono(3);}
        if(ventTeleCambiar.comboTelefonoNuevo.getSelectedItem() == "Fijo"){modelo.setTipoTelefono(4);}

        modelo.setTelefono(ventTeleCambiar.lblCambiarNumero.getText());
    }
    
    public void agregarTelef(){
        modelo.setTelefono(telefonosVista.lblTelefonoIngresar.getText()); 
        if(telefonosVista.comboTelefonosIngresar.getSelectedItem() == "Whatsapp"){modelo.setTipoTelefono(1);}
        if(telefonosVista.comboTelefonosIngresar.getSelectedItem() == "Telegram"){modelo.setTipoTelefono(2);}
        if(telefonosVista.comboTelefonosIngresar.getSelectedItem() == "Celular"){modelo.setTipoTelefono(3);}
        if(telefonosVista.comboTelefonosIngresar.getSelectedItem() == "Fijo"){modelo.setTipoTelefono(4);}
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        //INGRESO PERSONA
        if(e.getSource()==view.btnAgregarAdmi){
            if(model.verCedulaEcu(view.lblCedulaIngresoAdmi.getText())){
                modelo.setCedula(view.lblCedulaIngresoAdmi.getText());
                modelo.setPassword(view.lblPasswordIngresoAdmi.getText());
                modelo.setNombre(view.lblNombreIngresoAdmi.getText());
                modelo.setDireccion(view.lblDireccionIngresoAdmi.getText());
                SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
                Date fecha = this.view.jCalendarAdmi.getDate();
                modelo.setFechaNacimiento(formato.format(fecha));
                if(view.radioUsuarioConsulta.isSelected()){
                    modelo.setIdTipo(3);
                    Tipotelefonos();
                    if(model.registro(modelo,usuario, contrasenia) && model.registroTelefono(modelo, usuario, contrasenia)){
                        
                        if(model.otorgaPrivilegios("usuarios", view.lblCedulaIngresoAdmi.getText(), view.lblPasswordIngresoAdmi.getText(), usuario, contrasenia)){
                            int opcion = JOptionPane.showConfirmDialog(null, "¿Desea agregar más telefonos?");

                            if(opcion == JOptionPane.YES_OPTION){
                                telefonosVista.setDefaultCloseOperation(1);
                                telefonosVista.setLocationRelativeTo(telefonosVista);
                                telefonosVista.setVisible(true);
                                telefonosVista.lblCedulaTelefono.setText(modelo.getCedula());
                            }
                        }
                            
                    }else{
                        JOptionPane.showMessageDialog(null, "Error al registrar, no se permite cédulas ya registradas");
                        LimpiarCampos();
                    }
                }
                
                if(view.radioPersonaIngreso.isSelected()){
                    modelo.setIdTipo(2); 
                    Tipotelefonos();
                    if(model.registro(modelo,usuario, contrasenia) && model.registroTelefono(modelo, usuario, contrasenia)){
                        if(model.otorgaPrivilegios("autorizador", view.lblCedulaIngresoAdmi.getText(), view.lblPasswordIngresoAdmi.getText(), usuario, contrasenia)){
                       
                            int opcion = JOptionPane.showConfirmDialog(null, "¿Desea agregar más telefonos?");

                            if(opcion == JOptionPane.YES_OPTION){
                                telefonosVista.setDefaultCloseOperation(1);
                                telefonosVista.setLocationRelativeTo(telefonosVista);
                                telefonosVista.setVisible(true);
                                telefonosVista.lblCedulaTelefono.setText(modelo.getCedula());
                            }
                        }
                    }else{
                        JOptionPane.showMessageDialog(null, "Error al registrar");
                        LimpiarCampos();
                    }
                }
                
                if(view.radioAdministrador.isSelected()){
                    modelo.setIdTipo(1);
                    Tipotelefonos();
                    if(model.registro(modelo,usuario, contrasenia) && model.registroTelefono(modelo, usuario, contrasenia)){
                        
                        if(model.otorgaPrivilegios("administrador", view.lblCedulaIngresoAdmi.getText(), view.lblPasswordIngresoAdmi.getText(), usuario, contrasenia)){
                            int opcion = JOptionPane.showConfirmDialog(null, "¿Desea agregar más telefonos?");

                            if(opcion == JOptionPane.YES_OPTION){
                                telefonosVista.setDefaultCloseOperation(1);
                                telefonosVista.setLocationRelativeTo(telefonosVista);
                                telefonosVista.setVisible(true);
                                telefonosVista.lblCedulaTelefono.setText(modelo.getCedula());
                            }
                        }
                            
                    }else{
                        JOptionPane.showMessageDialog(null, "Error al registrar, no se permite cédulas ya registradas");
                        LimpiarCampos();
                    }
                }
                
            }else{
                JOptionPane.showMessageDialog(null, "Cédula Incorrecta");
            }
        
        }
        if(e.getSource()==telefonosVista.btnSalir){
            telefonosVista.dispose();
            LimpiarCampos();
        }
        
        if(e.getSource() == telefonosVista.btnAgregarTelefono){
            agregarTelef();
            if(model.registroTelefono(modelo, usuario, contrasenia)){
                    JOptionPane.showMessageDialog(null, "Registro Guardado");
                }
        }
        
        //ELIMINAR PERSONA
        if(e.getSource()== view.btn_buscarEliminar){
            try{
                String cedula = model.dameDatos(view.lblCedulaEliminar.getText(), usuario, contrasenia);
                String [] persona = cedula.split(",");
                view.lblNombreEliminar.setText(persona[1]);
                view.lblDireccionEliminar.setText(persona[2]);
                view.lblNacimientoEliminar.setText(persona[3]);
                view.btnEliminar.setEnabled(true);
            }catch(Exception ex){
                JOptionPane.showMessageDialog(null, "No se encontró la cedúla");
            }     
        }
        
        if(e.getSource() == view.btnEliminar){
            
            if(model.EliminarUsuario(view.lblCedulaEliminar.getText(), usuario, contrasenia)){
                view.lblNombreEliminar.setText("");
                view.lblDireccionEliminar.setText("");
                view.lblNacimientoEliminar.setText("");
                JOptionPane.showMessageDialog(null, "Registro Eliminado");
            }else{
                JOptionPane.showMessageDialog(null, "No se pudo :C");
            }
        }
        
        //MODIFICAR PERSONA
        if(e.getSource()==view.btn_buscarMod){
            
            try{
                String cedula = model.dameDatos(view.lblCedulaVer.getText(),usuario, contrasenia);
                String [] persona = cedula.split(",");
                view.lblCedulaModificar.setText(persona[0]);
                view.lblNombreModificar.setText(persona[1]);
                view.lblDireccionModificar.setText(persona[2]);
                view.lblNacimiento.setText(persona[3]);
                view.lblTelefonoModificar.setText("");
                if(persona[4].equals("1")){
                    view.radioModAdministrador.setSelected(true);
                    view.radioModAdministrador.setEnabled(false);
                    view.radioPersonaIngresoMod.setEnabled(false);
                    view.radioUsuarioConsultaMod.setEnabled(false);
                }else{
                    for (Object telefono : model.dameTelefonos(view.lblCedulaVer.getText(),usuario,contrasenia,1)) {
                        view.lblTelefonoModificar.append((String) telefono+"\n");
                    }
                
                }
                
                view.btnModificar.setEnabled(true);
                view.btnModTelefono.setEnabled(true);
            }catch(Exception ex){
                 JOptionPane.showMessageDialog(null, ":p");

            }
        }
        
        if(e.getSource()==view.btnModificar){
            String cedula = model.dameDatos(view.lblCedulaVer.getText(),usuario, contrasenia);
            String [] persona = cedula.split(",");
            modelo.setNombre(view.lblNombreModificar.getText());
            modelo.setDireccion(view.lblDireccionModificar.getText());
            
            if(view.radioUsuarioConsultaMod.isSelected()){                   
                switch (persona[4]) {
                    case "3" -> {
                        modelo.setIdTipo(3);
                        if(model.modificarUsuario(modelo, view.lblCedulaModificar.getText(),usuario, contrasenia)){
                            JOptionPane.showMessageDialog(null, "Modificación exitosa");
                        }
                    }
                    case "2" -> {
                        modelo.setIdTipo(3);
                        if(model.modificarUsuario(modelo, view.lblCedulaModificar.getText(),usuario, contrasenia)){
                            if(model.revocarPrivilegios(view.lblCedulaModificar.getText(), "usuarios", usuario, contrasenia,"autorizador")){
                            JOptionPane.showMessageDialog(null, "Modificación exitosa, ahora eres un usuario");
                            }  
                        }
                    }
                    default -> JOptionPane.showMessageDialog(null, "Modificación no realizada");
                }
            }
            if(view.radioPersonaIngresoMod.isSelected()){
                
                switch (persona[4]) {
                    case "2" -> {
                        modelo.setIdTipo(2);
                        if(model.modificarUsuario(modelo, view.lblCedulaModificar.getText(),usuario, contrasenia)){
                            JOptionPane.showMessageDialog(null, "Modificación exitosa");
                        }
                    }
                    case "3" -> {
                        modelo.setIdTipo(2);
                        if(model.modificarUsuario(modelo, view.lblCedulaModificar.getText(),usuario, contrasenia)){
                            if(model.revocarPrivilegios(view.lblCedulaModificar.getText(), "autorizador", usuario, contrasenia,"usuarios")){
                            JOptionPane.showMessageDialog(null, "Modificación exitosa, ahora eres un autorizador");
                            }  
                        }
                    }
                    default -> JOptionPane.showMessageDialog(null, "Modificación no realizada");
                }
            }if(view.radioModAdministrador.isSelected()){
                modelo.setIdTipo(1);
                
                if(model.modificarUsuario(modelo, view.lblCedulaModificar.getText(),usuario, contrasenia)){
                    JOptionPane.showMessageDialog(null, "Modificación exitosa");
                }
            }
            
        }
        
        if(e.getSource()==view.btnModTelefono){
                ventanaTel.setDefaultCloseOperation(1);
                ventanaTel.setLocationRelativeTo(ventanaTel);
                ventanaTel.comboCargarTelefono.removeAllItems();
                for (int i=0; i<model.dameTelefonos(view.lblCedulaVer.getText(), usuario, contrasenia,2).size();i++){
                    ventanaTel.comboCargarTelefono.addItem((String) model.dameTelefonos(view.lblCedulaVer.getText(), usuario, contrasenia,2).get(i));
                }
            ventanaTel.setVisible(true);
        }
        
        if(e.getSource()==ventanaTel.btnCambiar){
            
            ventTeleCambiar.setDefaultCloseOperation(1);
            ventTeleCambiar.setLocationRelativeTo(ventTeleCambiar);
            Modificar_EliminarTel();
            if(model.verifTelefonos(modelo, usuario, contrasenia)){
                    ventTeleCambiar.setVisible(true);
            }else{
                JOptionPane.showMessageDialog(null, "No se permite poder cambiar debido a\n que no coincide con lo que registró");
            }    
        }
        
        if(e.getSource()==ventTeleCambiar.btnModificar){
            view.lblTelefonoModificar.setText("");
            mod();
            if(model.modificarTelefono(modelo, view.lblCedulaVer.getText(), (String) ventanaTel.comboCargarTelefono.getSelectedItem(), usuario, contrasenia)){
                JOptionPane.showMessageDialog(null,"Modificación hecha");
                ventTeleCambiar.dispose();
            }else{
                JOptionPane.showMessageDialog(null,"Modificación no realizada");   
            }      
        }
        
        if(e.getSource()==ventanaTel.btnEliminarTelefonoMod){
            Modificar_EliminarTel();
            
            modelo.setCedula(view.lblCedulaVer.getText());
            if(model.borrarTelefono(modelo, usuario, contrasenia)){
                    ventanaTel.comboCargarTelefono.removeAllItems();
                    for (int i=0; i<model.dameTelefonos(view.lblCedulaVer.getText(), usuario, contrasenia,2).size();i++){
                        ventanaTel.comboCargarTelefono.addItem((String) model.dameTelefonos(view.lblCedulaVer.getText(), usuario, contrasenia,2).get(i));
                    }
                    JOptionPane.showMessageDialog(null,"Modificación hecha");
            }else{
                JOptionPane.showMessageDialog(null,"Modificación no realizada");   
            } 
        }
        
        if(e.getSource()==ventanaTel.btnAgregarTelefono){
            agregar.lblCedulaAgregado.setText(view.lblCedulaVer.getText());
            agregar.setDefaultCloseOperation(1);
            agregar.setLocationRelativeTo(agregar);
            agregar.setVisible(true);
            
        }
        
        if(e.getSource()==agregar.btnAgregado){
            modelo.setCedula(agregar.lblCedulaAgregado.getText());
            modelo.setTelefono(agregar.lblTelefonoIAgregado.getText()); 
            if(agregar.comboTelefonosAgregado.getSelectedItem() == "Whatsapp"){modelo.setTipoTelefono(1);}
            if(agregar.comboTelefonosAgregado.getSelectedItem() == "Telegram"){modelo.setTipoTelefono(2);}
            if(agregar.comboTelefonosAgregado.getSelectedItem() == "Celular"){modelo.setTipoTelefono(3);}
            if(agregar.comboTelefonosAgregado.getSelectedItem() == "Fijo"){modelo.setTipoTelefono(4);}
            if(model.registroTelefono(modelo, usuario, contrasenia)){
                JOptionPane.showMessageDialog(null,"Modificación hecha");
            }else{
                JOptionPane.showMessageDialog(null,"Modificación no realizada");   
            }
        }
        
        if(e.getSource()==agregar.btnSalirAgregado){
            agregar.dispose();
        }
        
        if(e.getSource() == view.btnConsultasAdmin){
            ventanaConsultas vistaConsultas = new ventanaConsultas();
            ctrlConsultas ctrl = new ctrlConsultas(vistaConsultas);
        }
    }
}   
