package vista;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import vista.ventanaUsuarioConsultas;

public class ctrlUsuarios implements ActionListener{
    
    private ventanaUsuarioConsultas view;
    
    public ctrlUsuarios(ventanaUsuarioConsultas view){
        
        this.view = view;
        view.btnObservarUsuario.addActionListener(this);
        view.setDefaultCloseOperation(1);
        view.setLocationRelativeTo(view);
        view.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource() == view.btnObservarUsuario){
            ventanaConsultas vistaConsultas = new ventanaConsultas();
            ctrlConsultas ctrl = new ctrlConsultas(vistaConsultas);
        }
        
    }
    
}
