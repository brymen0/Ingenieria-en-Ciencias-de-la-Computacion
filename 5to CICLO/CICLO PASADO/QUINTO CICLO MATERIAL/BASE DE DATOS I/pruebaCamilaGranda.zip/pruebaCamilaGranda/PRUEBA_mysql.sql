create schema CVGS_personas;

use CVGS_personas;

CREATE TABLE CVGS_1_persona(
		cedula varchar(10) not null primary key,
		nombre varchar(30) not null,
        direccion varchar(50) not null,
        telefono varchar(10) not null,
        fecha_nacimiento date not null
        );

show columns from CVGS_1_persona;

INSERT INTO `cvgs_personas`.`cvgs_1_persona` (`cedula`, `nombre`, `direccion`, `telefono`, `fecha_nacimiento`) VALUES ('0107616088', 'Camila', 'Marginal Autopista','4098096','2001-05-02');
INSERT INTO `cvgs_personas`.`cvgs_1_persona` (`cedula`, `nombre`, `direccion`, `telefono`, `fecha_nacimiento`) VALUES ('0107616096', 'Juan', 'Marginal Autopista','4098096','2000-03-15');

drop procedure CVGS_2_procEdad;
DELIMITER //
create procedure CVGS_2_procEdad(in fecha_nacimiento date, out edad smallint)
begin
	SELECT CONCAT(
		  FLOOR(DATEDIFF(CURDATE(), fecha_nacimiento) / 365), ' años, ',
		  FLOOR(DATEDIFF(CURDATE(), fecha_nacimiento) % 365 / 30), ' meses ',
          DATEDIFF(CURDATE(), fecha_nacimiento) % 30,' dias') AS edad;
end//
delimiter ;

call CVGS_2_procEdad('2001-05-02',@edad);

CREATE TABLE cvgs_4_bitacora (
  id INT NOT NULL AUTO_INCREMENT primary key,
  usuarioIngresa VARCHAR(45) NOT NULL,
  usuarioIngresado VARCHAR(45) NOT NULL,
  fecha DATETIME NOT NULL,
  edadRecienRegistrada VARCHAR(45) NOT NULL);
  
show columns from cvgs_4_bitacora;
drop trigger cvgs_5_trigger;
DELIMITER //
create trigger cvgs_5_trigger after insert on cvgs_1_persona for each row begin
	insert into `cvgs_personas`.`cvgs_4_bitacora` (`usuarioIngresa`,`usuarioIngresado`, `fecha`, `edadRecienRegistrada`) values (user(),NEW.nombre,now(),'es');
end//
DELIMITER ;
INSERT INTO `cvgs_personas`.`cvgs_1_persona` (`cedula`, `nombre`, `direccion`, `telefono`, `fecha_nacimiento`) VALUES ('0102092400', 'Anita', 'Marginal Autopista','4098096','1960-11-15');
