use gestionemergencias;

CREATE TABLE `gestionemergencias`.`personas` (
  `cedula` VARCHAR(20) NOT NULL,
  `nombre` VARCHAR(45) NOT NULL,
  `direccion` VARCHAR(45) NOT NULL,
  `tipoSangre` VARCHAR(45) NOT NULL,
  `fechaNacimiento` DATETIME NOT NULL,
  `donacionSangre` VARCHAR(45) NOT NULL,
  `idFacultad` INT NOT NULL,
  `idReligion` INT NOT NULL,
  PRIMARY KEY (`cedula`));
  
  CREATE TABLE `gestionemergencias`.`facultad` (
  `idFacultad` INT NOT NULL AUTO_INCREMENT,
  `nombreFacultad` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`idFacultad`));

INSERT INTO `gestionemergencias`.`facultad` (`nombreFacultad`) VALUES ('ARQUITECTURA Y URBANISMO');
INSERT INTO `gestionemergencias`.`facultad` (`nombreFacultad`) VALUES ('ARTES');
INSERT INTO `gestionemergencias`.`facultad` (`nombreFacultad`) VALUES ('CIENCIAS AGROPECUARIAS');
INSERT INTO `gestionemergencias`.`facultad` (`nombreFacultad`) VALUES ('CIENCIAS ECONOMICAS Y ADMINISTRATIVAS');
INSERT INTO `gestionemergencias`.`facultad` (`nombreFacultad`) VALUES ('CIENCIAS DE LA HOSPITALIDAD');
INSERT INTO `gestionemergencias`.`facultad` (`nombreFacultad`) VALUES ('CIENCIAS MEDICAS');
INSERT INTO `gestionemergencias`.`facultad` (`nombreFacultad`) VALUES ('CIENCIAS QUIMICAS');
INSERT INTO `gestionemergencias`.`facultad` (`nombreFacultad`) VALUES ('FILOSOFIA, LETRAS Y CIENCIAS DE LA EDUCACION');
INSERT INTO `gestionemergencias`.`facultad` (`nombreFacultad`) VALUES ('INGENIERIA');
INSERT INTO `gestionemergencias`.`facultad` (`nombreFacultad`) VALUES ('JURISPRUDENCIA Y CIENCIAS POLITICAS Y SOCIALES');
INSERT INTO `gestionemergencias`.`facultad` (`nombreFacultad`) VALUES ('ODONTOLOGIA');
INSERT INTO `gestionemergencias`.`facultad` (`nombreFacultad`) VALUES ('PSICOLOGIA');

CREATE TABLE `gestionemergencias`.`enfermedadesprevias` (
  `idEnfermedad` INT NOT NULL AUTO_INCREMENT,
  `nombreEnfermedad` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idEnfermedad`));
  
INSERT INTO `gestionemergencias`.`enfermedadesprevias` (`nombreEnfermedad`) VALUES ('NINGUNA');
INSERT INTO `gestionemergencias`.`enfermedadesprevias` (`nombreEnfermedad`) VALUES ('ANEMIA');
INSERT INTO `gestionemergencias`.`enfermedadesprevias` (`nombreEnfermedad`) VALUES ('GASTRITIS');
INSERT INTO `gestionemergencias`.`enfermedadesprevias` (`nombreEnfermedad`) VALUES ('DIABETES');
INSERT INTO `gestionemergencias`.`enfermedadesprevias` (`nombreEnfermedad`) VALUES ('BRONQUITIS');

#ALTER TABLE enfermedadesprevias AUTO_INCREMENT = 6;
CREATE TABLE `gestionemergencias`.`relacion_personayemergencia` (
  `cedula` VARCHAR(20) NOT NULL,
  `idEmergencia` INT NOT NULL,
  `tipoSospechoso` varchar(45),
  `prioridad` varchar(45),
  `fecha` DATETIME,
  PRIMARY KEY (`cedula`,`idEmergencia`));


CREATE TABLE `gestionemergencias`.`emergencia` (
  `idEmergencia` INT NOT NULL AUTO_INCREMENT,
  `Tipo` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idEmergencia`));

CREATE TABLE `gestionemergencias`.`religion` (
  `idReligion`INT NOT NULL AUTO_INCREMENT,
  `nombreReligion` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idReligion`));
  
INSERT INTO `gestionemergencias`.`religion` (`nombreReligion`) VALUES ('CRISTIANISMO');
INSERT INTO `gestionemergencias`.`religion` (`nombreReligion`) VALUES ('CATOLICISMO');
INSERT INTO `gestionemergencias`.`religion` (`nombreReligion`) VALUES ('TESTIGOS DE JEHOVA');
INSERT INTO `gestionemergencias`.`religion` (`nombreReligion`) VALUES ('HINDUISMO');
INSERT INTO `gestionemergencias`.`religion` (`nombreReligion`) VALUES ('ISLAMISMO');
INSERT INTO `gestionemergencias`.`religion` (`nombreReligion`) VALUES ('BUDISMO');

  CREATE TABLE `gestionemergencias`.`fobias` (
  `idfobias` INT NOT NULL AUTO_INCREMENT,
  `nombreFobia` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idfobias`));
  
INSERT INTO `gestionemergencias`.`fobias` (`nombreFobia`) VALUES ('NINGUNA');
INSERT INTO `gestionemergencias`.`fobias` (`nombreFobia`) VALUES ('INYECCIONES');
INSERT INTO `gestionemergencias`.`fobias` (`nombreFobia`) VALUES ('SANGRE');
INSERT INTO `gestionemergencias`.`fobias` (`nombreFobia`) VALUES ('INSECTOS');
INSERT INTO `gestionemergencias`.`fobias` (`nombreFobia`) VALUES ('ALTURAS');
INSERT INTO `gestionemergencias`.`fobias` (`nombreFobia`) VALUES ('TORMENTAS');
INSERT INTO `gestionemergencias`.`fobias` (`nombreFobia`) VALUES ('MEGAFOBIA');

CREATE TABLE `gestionemergencias`.`trabajador` (
	`cedula` VARCHAR(20) NOT NULL,
  `nombre` VARCHAR(45) NOT NULL,
  `direccion` VARCHAR(45) NOT NULL,
  `tipoSangre` VARCHAR(45) NOT NULL,
  `fechaNacimiento` DATETIME NOT NULL,
  `donacionSangre` VARCHAR(45) NOT NULL,
  `idFacultad` INT NOT NULL,
  `idReligion` INT NOT NULL,
  `puesto` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`cedula`));

CREATE TABLE `gestionemergencias`.`estudiante` (
  `cedula` VARCHAR(20) NOT NULL,
  `nombre` VARCHAR(45) NOT NULL,
  `direccion` VARCHAR(45) NOT NULL,
  `tipoSangre` VARCHAR(45) NOT NULL,
  `fechaNacimiento` DATETIME NOT NULL,
  `donacionSangre` VARCHAR(45) NOT NULL,
  `idFacultad` INT NOT NULL,
  `idReligion` INT NOT NULL,
  `ciclo` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`cedula`));

CREATE TABLE `gestionemergencias`.`funcionario` (
  `cedula` VARCHAR(20) NOT NULL,
  `nombre` VARCHAR(45) NOT NULL,
  `direccion` VARCHAR(45) NOT NULL,
  `tipoSangre` VARCHAR(45) NOT NULL,
  `fechaNacimiento` DATETIME NOT NULL,
  `donacionSangre` VARCHAR(45) NOT NULL,
  `idFacultad` INT NOT NULL,
  `idReligion` INT NOT NULL,
  `cargo`  VARCHAR(20) NOT NULL,
  `departamento` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`cedula`));

CREATE TABLE `gestionemergencias`.`profesor` (
  `cedula` VARCHAR(20) NOT NULL,
  `nombre` VARCHAR(45) NOT NULL,
  `direccion` VARCHAR(45) NOT NULL,
  `tipoSangre` VARCHAR(45) NOT NULL,
  `fechaNacimiento` DATETIME NOT NULL,
  `donacionSangre` VARCHAR(45) NOT NULL,
  `idFacultad` INT NOT NULL,
  `idReligion` INT NOT NULL,
  `titulo` VARCHAR(30) NOT NULL,
  `especialidad` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`cedula`));
  
CREATE TABLE `gestionemergencias`.`relacion_personayenfermedad` (
  `cedula` VARCHAR(20) NOT NULL,
  `idEnfermedad` INT NOT NULL,
  PRIMARY KEY (`cedula`, `idEnfermedad`));
  
CREATE TABLE `gestionemergencias`.`relacion_personayfobia` (
  `cedula` VARCHAR(20) NOT NULL,
  `idFobia` INT NOT NULL,
   PRIMARY KEY (`cedula`, `idFobia`));

CREATE TABLE `gestionemergencias`.`telefonos` (
  `cedula` VARCHAR(20) NOT NULL,
  `telefono` VARCHAR(45) NOT NULL,
  `tipoTelefono` INT NOT NULL,
  PRIMARY KEY (`cedula`,`telefono`));
  
CREATE TABLE `gestionemergencias`.`tipotelefonos` (
  `idtipoTelefonos` INT NOT NULL,
  `nombreTelefonos` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idtipoTelefonos`));
  
INSERT INTO `gestionemergencias`.`tipotelefonos` (`idtipoTelefonos`, `nombreTelefonos`) VALUES ('1', 'WHATSAPP');
INSERT INTO `gestionemergencias`.`tipotelefonos` (`idtipoTelefonos`, `nombreTelefonos`) VALUES ('2', 'TELEGRAM');
INSERT INTO `gestionemergencias`.`tipotelefonos` (`idtipoTelefonos`, `nombreTelefonos`) VALUES ('3', 'FIJO');
INSERT INTO `gestionemergencias`.`tipotelefonos` (`idtipoTelefonos`, `nombreTelefonos`) VALUES ('4', 'CELULAR');
  
CREATE TABLE `gestionemergencias`.`contactoemergencia` (
  `cedula` VARCHAR(45) NOT NULL,
  `cedulaContacto` VARCHAR(45) NOT NULL,
  `nombreContacto` VARCHAR(45) NOT NULL,
  `telefono` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`cedula`,`cedulaContacto`));

alter table contactoemergencia
add FOREIGN KEY(cedula) references personas(cedula) on delete cascade;

alter table relacion_personayemergencia
add FOREIGN KEY(cedula) references personas(cedula) on delete cascade;

alter table relacion_personayemergencia
add FOREIGN KEY(idEmergencia) references emergencia(idEmergencia);
  
alter table personas
add FOREIGN KEY(idFacultad) references facultad(idFacultad);

alter table personas
add FOREIGN KEY(idReligion) references religion(idReligion);

alter table estudiante
add FOREIGN KEY(cedula) references personas(cedula) on delete cascade;

alter table estudiante
add FOREIGN KEY(idFacultad) references facultad(idFacultad);

alter table estudiante
add FOREIGN KEY(idReligion) references religion(idReligion);

alter table trabajador
add FOREIGN KEY(cedula) references personas(cedula) on delete cascade;

alter table trabajador
add FOREIGN KEY(idFacultad) references facultad(idFacultad);

alter table trabajador
add FOREIGN KEY(idReligion) references religion(idReligion);

alter table funcionario
add FOREIGN KEY(cedula) references personas(cedula) on delete cascade;

alter table funcionario
add FOREIGN KEY(idFacultad) references facultad(idFacultad);

alter table funcionario
add FOREIGN KEY(idReligion) references religion(idReligion);

alter table profesor
add FOREIGN KEY(cedula) references personas(cedula) on delete cascade;

alter table profesor
add FOREIGN KEY(idFacultad) references facultad(idFacultad);

alter table profesor
add FOREIGN KEY(idReligion) references religion(idReligion);

alter table relacion_personayenfermedad
add FOREIGN KEY(cedula) references personas(cedula) on delete cascade;

alter table relacion_personayenfermedad
add FOREIGN KEY(idEnfermedad) references enfermedadesprevias(idEnfermedad);

alter table relacion_personayfobia
add FOREIGN KEY(cedula) references personas(cedula) on delete cascade;

alter table relacion_personayfobia
add FOREIGN KEY(idFobia) references fobias(idfobias);

alter table telefonos
add FOREIGN KEY(cedula) references personas(cedula) on delete cascade;

alter table telefonos
add FOREIGN KEY(tipoTelefono) references tipotelefonos(idtipoTelefonos);

create role 'estudiante'@'localhost';
GRANT ALL PRIVILEGES ON *.* TO 'estudiante'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;

create role 'profesor'@'localhost';
GRANT ALL PRIVILEGES ON *.* TO 'profesor'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;

create role 'funcionario'@'localhost';
GRANT ALL PRIVILEGES ON *.* TO 'funcionario'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;

create role 'trabajador'@'localhost';
GRANT ALL PRIVILEGES ON *.* TO 'trabajador'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;

delimiter //
create procedure almacenarDatos(in cedula varchar(45), in tipoSospechoso varchar(45), in prioridad varchar(30),
out cedulaGuardada varchar(45), out tipoSospechosoGuardada varchar(45), out prioridadGuardada varchar(45))
begin
	set cedulaGuardada = cedula;
    set tipoSospechosoGuardada = tipoSospechoso;
    set prioridadGuardada = prioridad;
end //
delimiter ;

delimiter //
create trigger ingresoEmergencia after insert on emergencia for each row 
begin
	insert into relacion_personayemergencia(cedula, idEmergencia, tipoSospechoso, prioridad, fecha) 
    values(@cedula, new.idEmergencia, @sospechoso, @prioridad, now());
end //
delimiter ;