import gurobipy as gp
from gurobipy import GRB

try:

    # Create a new model
    m = gp.Model("metodo M")

    # Create variables
    x1 = m.addVar(vtype=GRB.CONTINUOUS, name="x1")
    x2 = m.addVar(vtype=GRB.CONTINUOUS, name="x2")

    # Set objective
    m.setObjective(2*x1 + 3*x2, GRB.MINIMIZE)

    # Add constraint:
    m.addConstr((1/2)*x1 + (1/4) * x2 <= 4, "Azucar")

    # Add constraint:
    m.addConstr(x1 + 3*x2 >= 20, "Vitamina C")

    # Add constraint:
    m.addConstr(x1 + x2 == 10, "Botella de 10 oz.")

    # Optimize model
    m.optimize()

    for v in m.getVars():
        print('%s %g' % (v.varName, v.x))

    print('Obj: %g' % m.objVal)

except gp.GurobiError as e:
    print('Error code ' + str(e.errno) + ': ' + str(e))

except AttributeError:
    print('Encountered an attribute error')