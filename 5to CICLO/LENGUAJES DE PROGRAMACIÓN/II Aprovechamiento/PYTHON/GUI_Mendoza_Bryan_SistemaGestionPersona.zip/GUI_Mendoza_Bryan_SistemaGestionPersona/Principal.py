from PyQt6 import QtWidgets
from Ui_MainWindow import Ui_MainWindow
from ventanaIngresar import ventanaIngresar
from ventanaListar import ventanaListar
from ventanaAcercaDe import ventanaAcercaDe
class ventanaPrincipal(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self,parent=None):
        super(ventanaPrincipal,self).__init__(parent)
        self.setupUi(self)
        self.actionIngresar_Datos.triggered.connect(self.ingreso_datos)
        self.actionListar_Datos.triggered.connect(self.listado_datos)

        self.actioningresarDatos.triggered.connect(self.ingreso_datos)
        self.actionlistarDatos.triggered.connect(self.listado_datos)
        self.actionacercaDe.triggered.connect(self.acercaDe)
    def ingreso_datos(self):
        self.v1 = ventanaIngresar()
        self.v1.show()

    def listado_datos(self):
        self.v1 = ventanaListar()
        self.v1.show()

    def acercaDe(self):
        self.v1 = ventanaAcercaDe()
        self.v1.show()
