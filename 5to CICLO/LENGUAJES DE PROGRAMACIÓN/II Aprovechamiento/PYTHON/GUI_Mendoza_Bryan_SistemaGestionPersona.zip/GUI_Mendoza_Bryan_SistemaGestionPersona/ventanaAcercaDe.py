from PyQt6 import QtWidgets
from W_Acerca import Ui_Form

class ventanaAcercaDe(QtWidgets.QMainWindow, Ui_Form):
    def __init__(self,parent=None):
        super(ventanaAcercaDe,self).__init__(parent)
        self.setupUi(self)
