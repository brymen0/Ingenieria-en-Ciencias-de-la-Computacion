from PyQt6 import QtWidgets
from W_Listar import Ui_Form

class ventanaListar(QtWidgets.QMainWindow,Ui_Form):
    def __init__(self,parent=None):
        super(ventanaListar,self).__init__(parent)
        self.setupUi(self)
        self.ListarDatosButton.clicked.connect(self.listar)

    def listar(self):
        archivo = open("datos.txt","r")
        lineas = archivo.readlines()

        for i in lineas:
            self.listDatos.addItem(i)

        archivo.close()