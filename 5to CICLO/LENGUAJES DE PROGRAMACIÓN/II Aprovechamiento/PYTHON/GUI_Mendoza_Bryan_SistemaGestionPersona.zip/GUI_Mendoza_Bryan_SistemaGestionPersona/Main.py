import sys
from PyQt6 import QtWidgets
from Principal import ventanaPrincipal

app = QtWidgets.QApplication(sys.argv)
myApp = ventanaPrincipal()
myApp.show()
app.exec()