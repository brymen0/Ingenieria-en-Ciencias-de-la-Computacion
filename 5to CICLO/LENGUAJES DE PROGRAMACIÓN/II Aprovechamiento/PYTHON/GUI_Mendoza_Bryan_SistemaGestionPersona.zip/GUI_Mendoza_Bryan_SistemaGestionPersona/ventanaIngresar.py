from PyQt6 import QtWidgets
from W_Ingresar import Ui_W_Ingresar

class ventanaIngresar(QtWidgets.QMainWindow, Ui_W_Ingresar):
    def __init__(self,parent=None):
        super(ventanaIngresar,self).__init__(parent)
        self.setupUi(self)
        self.guardarButton.clicked.connect(self.guardar)
        self.salirButton.clicked.connect(self.salir)

    def salir(self):
        self.close()

    def guardar(self):
        cedula = self.txtCedula_2.text()
        nombre = self.txtCedula.text()
        apellido = self.txtApellido.text()
        archivo = open("datos.txt","a")
        archivo.write(cedula+"\n")
        archivo.write(nombre+"\n")
        archivo.write(apellido+"\n")
        archivo.close()
        self.txtCedula.clear()
        self.txtCedula_2.clear()
        self.txtApellido.clear()